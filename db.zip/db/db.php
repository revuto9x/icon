<?php
/**
 * AdminNeo - Powerful database manager in a single PHP file
 * v5.3.0-dev
 *
 * Compiled with
 * drivers:   all
 * languages: en
 * themes:    default-green
 * config:    no
 *
 * @link https://www.adminneo.org/
 *
 * @author Peter Knut
 * @author Jakub Vrana (https://www.vrana.cz/)
 *
 * @copyright 2007-2025 Jakub Vrána
 * @copyright 2024-2025 Peter Knut
 *
 * @license Apache License, Version 2.0 (https://www.apache.org/licenses/LICENSE-2.0)
 * @license GNU General Public License, version 2 (https://www.gnu.org/licenses/gpl-2.0.html)
 */namespace
AdminNeo;use
Exception;use
stdClass;use
PDO;use
PDOStatement;use
mysqli;use
mysqli_result;use
SQLite3;use
SQLite3Result;use
DateTime;use
MongoDB\BSON;use
MongoDB\Driver\BulkWrite;use
MongoDB\Driver\Command;use
MongoDB\Driver\Cursor;use
MongoDB\Driver\Manager;use
MongoDB\Driver\Query;abstract
class
Plugin{protected$admin;protected$config;protected$settings;protected$locale;function
inject($xa,Config$cc,Settings$P,Locale$pg){$this->admin=$xa;$this->config=$cc;$this->settings=$P;$this->locale=$pg;}}abstract
class
Origin
extends
Plugin{private$errors=[];private
static$instance=null;static
function
create(array$cc=[],array$yi=[]){if(self::$instance)die("Admin instance already exists.\n");$xa=new
static();if(!$cc&&file_exists("adminneo-config.php")){$cc=include_once("adminneo-config.php");if(!is_array($cc)){$cc=[];$lg="href=https://github.com/adminneo-org/adminneo#configuration ".target_blank();$xa->addError(lang(0,"<b>adminneo-config.php</b>")." <a $lg>".lang(1)."</a>");}}$cc=new
Config($cc);$P=new
Settings($cc);if(!$yi&&file_exists("adminneo-plugins.php")){$yi=include_once("adminneo-plugins.php");if(!is_array($yi)){$yi=[];$lg="href=https://github.com/adminneo-org/adminneo#plugins ".target_blank();$xa->addError(lang(0,"<b>adminneo-plugins.php</b>")." <a $lg>".lang(1)."</a>");}}self::$instance=$yi?new
Pluginer($xa,$yi):$xa;$xa->inject(self::$instance,$cc,$P,Locale::get());foreach($yi
as$xi)$xi->inject(self::$instance,$cc,$P,Locale::get());return
self::$instance;}static
function
get(){if(!self::$instance)die("Admin instance not found. Create instance by Admin::create() method at first.\n");return
self::$instance;}protected
function
__construct(){}function
getConfig(){return$this->config;}function
getSettings(){return$this->settings;}abstract
function
getOperators();abstract
function
getLikeOperator();abstract
function
getRegexpOperator();function
init(){}function
addError($j){$this->errors[]=$j;}function
getErrors(){return$this->errors;}abstract
function
getServiceTitle();function
getCredentials(){$O=$this->config->getServer(SERVER);return[$O?$O->getServer():SERVER,$_GET["username"],get_password()];}function
verifyDefaultPassword($E){$Te=$this->config->getDefaultPasswordHash();if($Te===null||$Te==="")return
lang(2);elseif(!password_verify($E,$Te))return
lang(3);return
true;}function
authenticate($V,$E){if($E==""){$Te=$this->config->getDefaultPasswordHash();if($Te===null)return
lang(4,target_blank());else
return$Te==="";}return
true;}function
getPrivateKey($rc=false){return
get_private_key($rc);}function
getBruteForceKey(){return$_SERVER["REMOTE_ADDR"];}function
getServerName($O){if($O=="")return"";$Zj=$this->config->getServer($O);return$Zj?$Zj->getName():$O;}abstract
function
getDatabase();function
getDatabases($me=true){return$this->filterListWithWildcards(get_databases($me),$this->config->getHiddenDatabases(),false,Driver::get()->getSystemDatabases());}function
getSchemas(){return$this->filterListWithWildcards(schemas(),$this->config->getHiddenSchemas(),false,Driver::get()->getSystemSchemas());}function
getCollations(array$Of=[]){$Dm=$this->config->getVisibleCollations();$ee=$Dm?array_merge($Dm,$Of):[];return$this->filterListWithWildcards(collations(),$ee,true);}private
function
filterListWithWildcards(array$vm,array$ee,$Qf,array$Yk=[]){if(!$vm||!$ee)return$vm;$s=array_search("__system",$ee);if($s!==false){unset($ee[$s]);$ee=array_merge($ee,$Yk);}array_walk($ee,function(&$Y){$Y=str_replace('\\*',".*",preg_quote($Y,"~"));});$si='~^('.implode("|",$ee).')$~';return$this->filterListWithPattern($vm,$si,$Qf);}private
function
filterListWithPattern(array$vm,$si,$Qf){$I=[];foreach($vm
as$u=>$Y){if(is_array($Y)){if($Ok=$this->filterListWithPattern($Y,$si,$Qf))$I[$u]=$Ok;}elseif(($Qf&&preg_match($si,$Y))||(!$Qf&&!preg_match($si,$Y)))$I[$u]=$Y;}return$I;}abstract
function
getQueryTimeout();function
sendHeaders(){}function
updateCspHeader(array&$vc){}function
printFavicons(){$Mb=validate_color_variant($this->config->getColorVariant());echo"<link rel='icon' type='image/x-icon' href='",link_files("favicon-$Mb.ico",[]),"' sizes='32x32'>\n","<link rel='icon' type='image/svg+xml' href='",link_files("favicon-$Mb.svg",[]),"'>\n","<link rel='apple-touch-icon' href='",link_files("apple-touch-icon-$Mb.png",[]),"'>\n";}abstract
function
printToHead();function
getCssUrls(){$lm=$this->config->getCssUrls();foreach(["adminneo.css","adminneo-light.css","adminneo-dark.css"]as$n){if(file_exists($n))$lm[]="$n?v=".filemtime($n);}return$lm;}function
isLightModeForced(){return$this->isColorSchemeForced(false);}function
isDarkModeForced(){return$this->isColorSchemeForced(true);}private
function
isColorSchemeForced($_c){$Sg=$_c?Settings::$ColorSchemeDark:Settings::$ColorSchemeLight;$Tg=$_c?Settings::$ColorSchemeLight:Settings::$ColorSchemeDark;$ae=file_exists("adminneo-$Sg.css");$be=file_exists("adminneo-$Tg.css");if($ae&&!$be)return
true;return$this->settings->getColorScheme()==$Sg&&!($ae
xor$be);}function
getJsUrls(){$lm=$this->config->getJsUrls();$n="adminneo.js";if(file_exists($n))$lm[]="$n?v=".filemtime($n);return$lm;}abstract
function
printLoginForm();function
getLoginFormRow($Wd,$Wf,$k){if($Wf)return"<tr><th>$Wf</th><td>$k</td></tr>\n";else
return"$k\n";}function
printLogout(){echo"<div class='logout'>","<form action='' method='post'>\n",h($_GET["username"]),"<input type='submit' class='button' name='logout' value='",lang(5),"' id='logout'>",input_token(),"</form>","</div>\n";}function
getTableName(array$cl){return
h($cl["Name"]);}abstract
function
getFieldName(array$k,$Lh=0);function
formatComment($Tb){return
h($Tb);}abstract
function
printTableMenu(array$cl,$ik="");function
getForeignKeys($R){return
foreign_keys($R);}function
getBackwardKeys($R,$bl){if(!$this->settings->isRelationLinks())return[];$L=backward_keys($R);$Tf=[];foreach($L
as$K){$q=$K["table_schema"].".".$K["table_name"];$Tf[$q]["schema"]=$K["table_schema"];$Tf[$q]["table"]=$K["table_name"];$Tf[$q]["constraints"][$K["constraint_name"]][$K["column_name"]]=$K["referenced_column_name"];}foreach($Tf
as$q=>$u){$_=$this->admin->getTableName(table_status($u["table"],true));if($_!=""){$Jj=preg_quote($bl);$N="(:|\\s*-)?\\s+";$Tf[$q]["name"]=(preg_match("(^$Jj$N(.+)|^(.+?)$N$Jj\$)iu",$_,$y)?$y[2].$y[3]:$_);}else
unset($Tf[$q]);}return$Tf;}function
printBackwardKeys(array$Ya,array$K){foreach($Ya
as$u){foreach($u["constraints"]as$jc){$Gg=preg_replace('~&ns=[^&]+&~',"&ns=".urldecode($u["schema"])."&",ME);$x=$Gg.'select='.urlencode($u["table"]);$p=0;foreach($jc
as$c=>$X){if(!isset($K[$X]))continue
2;$x
.=where_link($p++,$c,$K[$X]);}$_=preg_replace('(^'.preg_quote($_GET["select"]).(substr($_GET["select"],-1)=="s"?"?":"").'_)',"_",$u["name"]);$Cl=implode(", ",array_keys($jc));echo"<a href='".h($x)."' title='".h($Cl)."'>".h($_)."</a>";$x=$Gg.'edit='.urlencode($u["table"]);foreach($jc
as$c=>$X)$x
.="&set".urlencode("[".bracket_escape($c)."]")."=".urlencode($K[$X]);echo"<a href='".h($x)."' title='".lang(6)."'>",icon_solo("add"),"</a> ";}}}abstract
function
formatSelectQuery($G,$Fk,$Sd=false);abstract
function
formatMessageQuery($G,$_l,$Sd=false);abstract
function
formatSqlCommandQuery($G);function
printAfterSqlCommand(){}abstract
function
getTableDescriptionFieldName($R);abstract
function
fillForeignDescriptions(array$L,array$pe);function
getFieldValueLink($X,$k){if(is_mail($X))return"mailto:$X";if(is_web_url($X))return$X;return
null;}abstract
function
formatSelectionValue($X,$x,$k,$Vh);abstract
function
formatFieldValue($Y,array$k);abstract
function
printTableStructure(array$l);abstract
function
printTablePartitions(array$hi);abstract
function
printTableIndexes(array$t);abstract
function
printSelectionColumns(array$M,array$d);abstract
function
printSelectionSearch(array$Z,array$d,array$t);abstract
function
printSelectionOrder(array$Lh,array$d,array$t);abstract
function
printSelectionLimit($w);abstract
function
printSelectionLength($ul);abstract
function
printSelectionAction(array$t);function
isDataEditAllowed(){return!information_schema(DB);}abstract
function
processSelectionColumns(array$d,array$t);abstract
function
processSelectionSearch(array$l,array$t);abstract
function
processSelectionOrder(array$l,array$t);function
processSelectionLimit(){if(!isset($_GET["limit"]))return$this->settings->getRecordsPerPage();return$_GET["limit"]!=""?(int)$_GET["limit"]:null;}abstract
function
processSelectionLength();abstract
function
getFieldFunctions(array$k);abstract
function
getFieldInput($R,array$k,$Pa,$Y,$ze);function
getFieldInputHint($R,array$k,$Y){return
support("comment")?$this->admin->formatComment($k["comment"]):"";}abstract
function
processFieldInput($k,$Y,$ze="");function
detectJson($Xd,&$Y,$Hi=null){if(is_array($Y)){$ke=JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|($this->config->isJsonValuesAutoFormat()?JSON_PRETTY_PRINT:0);$Y=json_encode($Y,$ke);return
true;}$ke=JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|($Hi?JSON_PRETTY_PRINT:0);if(str_contains($Xd,"json")){if($Hi!==null&&$this->config->isJsonValuesAutoFormat())$Y=json_encode(json_decode($Y),$ke);return
true;}if(!$this->config->isJsonValuesDetection())return
false;if($Y!=""&&preg_match('~varchar|text|character varying|String|keyword~',$Xd)&&($Y[0]=="{"||$Y[0]=="[")&&($Lf=json_decode($Y))){if($Hi!==null&&$this->config->isJsonValuesAutoFormat())$Y=json_encode($Lf,$ke);return
true;}return
false;}abstract
function
getDumpOutputs();abstract
function
getDumpFormats();abstract
function
sendDumpHeaders($gf,$Vg=false);function
dumpDatabase($Bc){}abstract
function
dumpTable($R,$Nk,$Am=0);abstract
function
dumpData($R,$Nk,$G);abstract
function
getImportFilePath();abstract
function
printDatabaseMenu();function
printNavigation($Rg){$cg=isset($_COOKIE["neo_version"])?$_COOKIE["neo_version"]:null;echo"<div class='header'>\n",$this->admin->getServiceTitle()."\n";if($Rg!="auth"){echo"<span class='version'>",h(preg_replace('~\\.0(-|$)~','$1',VERSION)),"<a id='version' class='version-badge' href='https://www.adminneo.org/download' ".target_blank()." title='".h($cg)."'>";if($this->config->isVersionVerificationEnabled()&&$cg&&version_compare(VERSION,$cg)<0)echo
icon_solo("asterisk");echo"</a>","</span>\n";if($this->config->isVersionVerificationEnabled()&&!$cg)echo
script("verifyVersion('".js_escape(ME)."', '".get_token()."');");}echo"</div>\n";}abstract
function
printDatabaseSwitcher($Rg);function
printTablesFilter(){echo"<div class='tables-filter jsonly'>"."<input id='tables-filter' type='search' class='input' autocomplete='off' placeholder='".lang(7)."'>".script("initTablesFilter(".json_encode($this->admin->getDatabase()).");")."</div>\n";}abstract
function
printTableList(array$T);function
getSettingsRows($Je){$P=[];if($Je==1){$B=get_language_options();if($B)$P["lang"]="<tr><th>".lang(8)."</th>"."<td>".html_select("lang",get_language_options(),Locale::get()->getLanguage())."</td></tr>\n";$B=[""=>lang(9),Settings::$ColorSchemeLight=>lang(10),Settings::$ColorSchemeDark=>lang(11)];$P["colorScheme"]="<tr><th>".lang(12)."</th>"."<td>".html_radios("colorScheme",$B,($pa=$this->settings->getParameter("colorScheme"))!==null?$pa:"")."</td></tr>\n";}elseif($Je==2){$B=[""=>lang(13),true=>lang(14),false=>lang(15),];$i=$B[$this->config->isRelationLinks()];$B[""].=" ($i)";$P["relationLinks"]="<tr><th>".lang(16)."</th>"."<td>".html_radios("relationLinks",$B,($pa=$this->settings->getParameter("relationLinks"))!==null?$pa:"")."<span class='input-hint'>".lang(17)."</span>"."</td></tr>\n";$i=$this->config->getRecordsPerPage();$B=[""=>lang(13)." ($i)","20","30","50","70","100",];$P["recordsPerPage"]="<tr><th>".lang(18)."</th>"."<td>".html_select("recordsPerPage",$B,($pa=$this->settings->getParameter("recordsPerPage"))!==null?$pa:"")."<span class='input-hint'>".lang(19)."</span>"."</td></tr>\n";$i=($pa=$this->config->getEnumAsSelectThreshold())!==null?$pa:lang(20);$B=[""=>lang(13)." ($i)",-1=>lang(20),0=>lang(21),3=>lang(22,3),5=>lang(22,5),10=>lang(22,10),20=>lang(22,20),];$P["enumAsSelectThreshold"]="<tr><th>".lang(23)."</th>"."<td>".html_select("enumAsSelectThreshold",$B,($pa=$this->settings->getParameter("enumAsSelectThreshold"))!==null?$pa:"","","",true)."<span class='input-hint'>".lang(24)."</span>"."</td></tr>\n";}return$P;}abstract
function
getForeignColumnInfo(array$pe,$c);}class
Pluginer{private
static$InternalMethods=["inject"=>true,"getConfig"=>true,];private
static$AppendMethods=["getErrors"=>true,"getFieldFunctions"=>true,"getDumpOutputs"=>true,"getDumpFormats"=>true,"getSettingsRows"=>true,];private$plugins;private$hooks=[];function
__construct(Origin$xa,array$yi){$this->plugins=$yi;foreach(get_class_methods('\AdminNeo\Origin')as$Pg){$this->hooks[$Pg]=[];if(!(isset(self::$InternalMethods[$Pg])?self::$InternalMethods[$Pg]:false)){foreach($yi
as$xi){if(method_exists($xi,$Pg))$this->hooks[$Pg][]=$xi;}}if(isset(self::$AppendMethods[$Pg])?self::$AppendMethods[$Pg]:false)array_unshift($this->hooks[$Pg],$xa);else$this->hooks[$Pg][]=$xa;}}function
getPlugins(){return$this->plugins;}function
__call($_,array$D){$Ka=isset(self::$AppendMethods[$_])?self::$AppendMethods[$_]:false;$I=$Ka?[]:null;assert(isset($this->hooks[$_]),"Calling unknown plugin method: $_");foreach($this->hooks[$_]as$xi){$Y=call_user_func_array([$xi,$_],$D);if($Y!==null){if($Ka)$I+=$Y;else
return$Y;}}return$I;}function
updateCspHeader(array&$vc){$this->__call(__FUNCTION__,[&$vc]);}function
detectJson($Xd,&$Y,$Hi=null){return$this->__call(__FUNCTION__,[$Xd,&$Y,$Hi]);}}class
Admin
extends
Origin{function
getOperators(){return
Driver::get()->getOperators();}function
getLikeOperator(){return
Driver::get()->getLikeOperator();}function
getRegexpOperator(){return
Driver::get()->getRegexpOperator();}function
getServiceTitle(){return"<a href='".h(HOME_URL)."'><svg role='img' class='logo' width='133' height='28'><desc>AdminNeo</desc><use href='".link_files("logo.svg",[])."#logo'/></svg></a>";}function
getDatabase(){return
DB;}function
getQueryTimeout(){return
2;}function
printToHead(){echo"<link rel='stylesheet' href='",link_files("jush.css",[]),"'>";if(!$this->admin->isLightModeForced())echo"<link rel='stylesheet' ".(!$this->admin->isDarkModeForced()?"media='(prefers-color-scheme: dark)' ":"")."href='",link_files("jush-dark.css",[]),"'>\n";echo
script_src(link_files("jush.js",[]),true);}function
printLoginForm(){$ad=Drivers::getList();$ak=$this->config->getServerPairs($ad);$O=SERVER?:$this->config->getDefaultServer();echo"<table class='box box-light'>\n";if($ak)echo$this->admin->getLoginFormRow('server',lang(25),"<select name='auth[server]'>".optionlist($ak,$O,true)."</select>");else{$Yc=DRIVER?:$this->config->getDefaultDriver($ad);if(count($ad)>1)echo$this->admin->getLoginFormRow('driver',lang(26),html_select("auth[driver]",$ad,$Yc).script("initLoginDriver(qsl('select'));",""));else
echo$this->admin->getLoginFormRow('driver','',input_hidden("auth[driver]",$Yc));echo$this->admin->getLoginFormRow('server',lang(25),'<input class="input" name="auth[server]" value="'.h($O).'" title="hostname[:port]" placeholder="localhost" autocapitalize="off">');}echo$this->admin->getLoginFormRow('username',lang(27),'<input class="input" name="auth[username]" id="username" value="'.h($_GET["username"]).'" autocomplete="username" autocapitalize="off">'),$this->admin->getLoginFormRow('password',lang(28),'<input type="password" class="input" name="auth[password]" autocomplete="current-password">');if(!$ak){$Bc=isset($_GET["db"])?$_GET["db"]:$this->config->getDefaultDatabase();echo$this->admin->getLoginFormRow('db',lang(29),'<input class="input" name="auth[db]" value="'.h($Bc).'" autocapitalize="off">');}echo"</table>\n","<p>","<input type='submit' class='button default' value='".lang(30)."'>",checkbox("auth[permanent]",1,$_COOKIE["neo_permanent"],lang(31)),"</p>\n";}function
getFieldName(array$k,$Lh=0){$U=$k["full_type"];$Tb=$k["comment"];$N=$U&&$Tb!=""?": ":"";return'<span title="'.h($U.$N.$Tb).'">'.h($k["field"]).'</span>';}function
printTableMenu(array$cl,$ik=""){echo'<p class="links top-tabs">';$mg=[];$Qj=($this->settings->isSelectionPreferred()&&!$this->settings->isNavigationReversed())||(!$this->settings->isSelectionPreferred()&&$this->settings->isNavigationReversed());if($Qj)$mg["select"]=[lang(32),"data"];if(support("table")||support("indexes"))$mg["table"]=[lang(33),"structure"];if(!$Qj)$mg["select"]=[lang(32),"data"];$Gf=false;if(support("table")){$Gf=is_view($cl);if($Gf)$mg["view"]=[lang(34),"edit"];else$mg["create"]=[lang(35),"edit"];}if($ik!==null)$mg["edit"]=[lang(6),"item-add"];$R=$cl["Name"];foreach($mg
as$u=>$X)echo" <a href='",h(ME),"$u=",urlencode($R),($u=="edit"?$ik:""),"'",bold(isset($_GET[$u])),">",icon($X[1]),"$X[0]</a>";echo
doc_link([DIALECT=>Driver::get()->tableHelp($R,$Gf)],icon("help").lang(36)),"\n";}function
formatSelectQuery($G,$Fk,$Sd=false){$Uk=support("sql");$Fm=!$Sd?Driver::get()->warnings():null;if($Uk)$G
.=";";$Wk=DIALECT=="elastic"?"js":DIALECT;$J="<pre><code class='jush-$Wk'>".h(str_replace("\n"," ",$G))."</code></pre>\n";$J
.="<p class='links'>";if($Uk)$J
.="<a href='".h(ME)."sql=".urlencode($G)."'>".icon("edit").lang(37)."</a>";if($Fm)$J
.="<a href='#warnings' class='toggle'>".lang(38).icon_chevron_down()."</a>";$J
.=" <span class='time'>(".format_time($Fk).")</span>";$J
.="</p>\n";if($Fm){$J
.=script("initToggles(qsl('p'));");$J
.="<div id='warnings' class='warnings hidden'>\n$Fm\n</div>\n";}return$J;}function
formatMessageQuery($G,$_l,$Sd=false){restart_session();$Xe=&get_session("queries");if(!isset($Xe[$_GET["db"]]))$Xe[$_GET["db"]]=[];if(strlen($G)>1e6)$G=preg_replace('~[\x80-\xFF]+$~','',substr($G,0,1e6))."\n…";$Xe[$_GET["db"]][]=[$G,time(),$_l];$Uk=support("sql");$Fm=!$Sd?Driver::get()->warnings():null;$_k="sql-".count($Xe[$_GET["db"]]);$Gm="warnings-".count($Xe[$_GET["db"]]);$J=" ";if($Fm)$J
.="<a href='#$Gm' class='toggle'>".lang(38).icon_chevron_down()."</a>, ";$Ui=support("sql")?lang(39):lang(40);$J
.="<a href='#$_k' class='toggle'>$Ui".icon_chevron_down()."</a>";$J
.=" <span class='time'>".@date("H:i:s")."</span>\n";if($Fm)$J
.="<div id='$Gm' class='warnings hidden'>\n$Fm</div>\n";$J
.="<div id='$_k' class='hidden'>\n";$Wk=DIALECT=="elastic"?"js":DIALECT;$J
.="<pre><code class='jush-$Wk'>".truncate_utf8($G,1000)."</code></pre>\n";$J
.="<p class='links'>";if($Uk)$J
.="<a href='".h(str_replace("db=".urlencode(DB),"db=".urlencode($_GET["db"]),ME).'sql=&history='.(count($Xe[$_GET["db"]])-1))."'>".icon("edit").lang(37)."</a>";if($_l)$J
.=" <span class='time'>($_l)</span>";$J
.="</p>\n";$J
.="</div>\n";return$J;}function
formatSqlCommandQuery($G){if(preg_match('~^DELIMITER\s~i',$G))return"";return
truncate_utf8($G,1000);}function
getTableDescriptionFieldName($R){return"";}function
fillForeignDescriptions(array$L,array$pe){return$L;}function
formatSelectionValue($X,$x,$k,$Vh){if($X===null)$tl="<i>NULL</i>";elseif(!$k)$tl=$X;elseif(preg_match("~char|binary|boolean~",$k["type"])&&!preg_match("~var~",$k["type"]))$tl="<code>$X</code>";elseif(preg_match('~blob|bytea|raw|file~',$k["type"])&&!is_utf8($X))$tl="<i>".lang(41,strlen($Vh))."</i>";elseif($this->admin->detectJson($k["type"],$Vh))$tl="<code class='jush-js'>$X</code>";else$tl=$X;if($x)$tl="<a href='".h($x)."'".(is_web_url($x)?target_blank():"").">$tl</a>";return$tl;}function
formatFieldValue($Y,array$k){return$Y;}function
printTableStructure(array$l){echo"<div class='scrollable'>\n","<table class='nowrap'>\n","<thead><tr>","<th>",lang(42),"</th>","<td>",lang(43),"</td>","<td>",lang(44),"</td>";if(support("comment"))echo"<td>",lang(45),"</td>";echo"</tr></thead>\n";$rm=Driver::get()->getUserTypes();foreach($l
as$k){echo"<tr>","<th>",h($k["field"]),"</th>","<td>";$U=h($k["full_type"]);if(in_array($U,$rm))echo"<a href='".h(ME.'type='.urlencode($U))."'>$U</a>";else
echo$U;if($k["null"])echo" <i>NULL</i>";if($k["auto_increment"])echo" <i>".lang(46)."</i>";$i=h($k["default"]);if(isset($k["default"]))echo" <span title='".lang(47)."'>[<b>",$k["generated"]?"<code class='jush-".DIALECT."'>$i</code>":$i,"</b>]</span>";echo"</td>","<td>",h($k["collation"]),"</td>";if(support("comment"))echo"<td>",$this->admin->formatComment($k["comment"]),"</td>";echo"\n";}echo"</table>\n","</div>\n";}function
printTablePartitions(array$hi){$lk=$hi["partition_by"]=="RANGE"||$hi["partition_by"]=="LIST";echo"<p>","<code>{$hi["partition_by"]} ({$hi["partition"]})</code>";if(!$lk)echo" ".lang(48).": ".h($hi["partitions"]);echo"</p>";if($lk){echo"<table>\n","<thead><tr><th>".lang(49)."</th><td>".lang(50)."</td></tr></thead>\n";foreach($hi["partition_names"]as$u=>$_)echo"<tr><th>".h($_)."</th><td>".h($hi["partition_values"][$u])."\n";echo"</table>\n";}}function
printTableIndexes(array$t){echo"<table>\n","<thead><tr><th>".lang(43)."</th><td>".lang(42)." (".lang(51).")</td></tr></thead>\n";foreach($t
as$_=>$s){ksort($s["columns"]);$Ji=[];foreach($s["columns"]as$u=>$X)$Ji[]="<i>".h($X)."</i>".($s["lengths"][$u]?"(".$s["lengths"][$u].")":"").($s["descs"][$u]?" DESC":"");echo"<tr title='".h($_)."'><th>$s[type]<td>".implode(", ",$Ji)."\n";}echo"</table>\n";}function
printSelectionColumns(array$M,array$d){print_fieldset_start("select",lang(52),"columns",(bool)$M,true);$M[""]=[];$p=0;foreach($M
as$u=>$X){$X=isset($_GET["columns"][$u])?$_GET["columns"][$u]:[];$c=select_input("name='columns[$p][col]'",$d,isset($X["col"])?$X["col"]:null,$u!==""?"selectFieldChange":"selectAddRow");echo"<div ",($u!=""?"":"class='no-sort'"),">",icon("handle","handle jsonly");if(Driver::get()->getFunctions()||Driver::get()->getGrouping())echo
html_select("columns[$p][fun]",[-1=>""]+array_filter([lang(53)=>Driver::get()->getFunctions(),lang(54)=>Driver::get()->getGrouping()]),isset($X["fun"])?$X["fun"]:null),help_script_command("value && value.replace(/ |\$/, '(') + ')'",true),script("qsl('select').onchange = (event) => { ".($u!==""?"":" qsl('select, input:not(.remove)', event.target.parentNode).onchange();")." };",""),"($c)";else
echo$c;echo" <button class='button light remove jsonly' title='",h(lang(55)),"'>",icon_solo("remove"),"</button>",script("qsl('#fieldset-select .remove').onclick = selectRemoveRow;",""),"</div>\n";$p++;}print_fieldset_end("select",true);}function
printSelectionSearch(array$Z,array$d,array$t){print_fieldset_start("search",lang(56),"search",(bool)$Z);foreach($t
as$p=>$s){if($s["type"]=="FULLTEXT")echo"<div>(<i>".implode("</i>, <i>",array_map('AdminNeo\h',$s["columns"]))."</i>) AGAINST","<input type='text' class='input' name='fulltext[$p]' value='".h(isset($_GET["fulltext"][$p])?$_GET["fulltext"][$p]:null)."'>",script("qsl('input').oninput = selectFieldChange;",""),checkbox("boolean[$p]",1,isset($_GET["boolean"][$p]),"BOOL"),"</div>\n";}$sb="this.parentNode.firstChild.onchange();";foreach(array_merge((array)$_GET["where"],[[]])as$p=>$X){if(!$X||("$X[col]$X[val]"!=""&&in_array($X["op"],$this->getOperators())))echo"<div>",select_input(" name='where[$p][col]'",$d,$X["col"],($X?"selectFieldChange":"selectAddRow"),"(".lang(57).")"),html_select("where[$p][op]",$this->getOperators(),$X["op"],$sb),"<input type='text' class='input' name='where[$p][val]' value='".h($X["val"])."'>",script("mixin(qsl('input'), {oninput: function () { $sb }, onkeydown: selectSearchKeydown});","")," <button class='button light remove jsonly' title='".h(lang(55))."'>",icon_solo("remove"),"</button>",script('qsl("#fieldset-search .remove").onclick = selectRemoveRow;',""),"</div>\n";}print_fieldset_end("search");}function
printSelectionOrder(array$Lh,array$d,array$t){print_fieldset_start("sort",lang(58),"sort",(bool)$Lh,true);$_GET["order"][""]="";$p=0;foreach((array)$_GET["order"]as$u=>$X){if($u!=""&&$X=="")continue;echo"<div ",($u!=""?"":"class='no-sort'"),">",icon("handle","handle jsonly"),select_input("name='order[$p]'",$d,$X,$u!==""?"selectFieldChange":"selectAddRow")," ",checkbox("desc[$p]",1,isset($_GET["desc"][$u]),lang(59))," <button class='button light remove jsonly' title='",h(lang(55)),"'>",icon_solo("remove"),"</button>",script('qsl("#fieldset-sort .remove").onclick = selectRemoveRow;',""),"</div>\n";$p++;}print_fieldset_end("sort",true);}function
printSelectionLimit($w){echo"<fieldset><legend>".lang(60)."</legend><div class='fieldset-content'>","<input type='number' name='limit' class='input size' value='".h($w)."'>",script("qsl('input').oninput = selectFieldChange;",""),"</div></fieldset>\n";}function
printSelectionLength($ul){if($ul!==null)echo"<fieldset><legend>".lang(61)."</legend><div class='fieldset-content'>","<input type='number' name='text_length' class='input size' value='".h($ul)."'>","</div></fieldset>\n";}function
printSelectionAction(array$t){echo"<fieldset><legend>".lang(62)."</legend><div class='fieldset-content'>","<input type='submit' class='button' value='".lang(52)."'>"," <span id='noindex' title='".lang(63)."'></span>","<script".nonce().">\n";$d=new
stdClass();foreach($t
as$s){$xc=reset($s["columns"]);if($s["type"]!="FULLTEXT"&&$xc)$d->$xc=null;}echo"const indexColumns = ".json_encode($d,JSON_UNESCAPED_UNICODE).";\n","selectFieldChange.call(gid('form')['select']);\n","</script>\n","</div></fieldset>\n";}function
processSelectionColumns(array$d,array$t){$M=[];$He=[];foreach((array)$_GET["columns"]as$u=>$X){if($X["fun"]=="count"||($X["col"]!=""&&(!$X["fun"]||in_array($X["fun"],Driver::get()->getFunctions())||in_array($X["fun"],Driver::get()->getGrouping())))){$M[$u]=apply_sql_function($X["fun"],($X["col"]!=""?idf_escape($X["col"]):"*"));if(!in_array($X["fun"],Driver::get()->getGrouping()))$He[]=$M[$u];}}return[$M,$He];}function
processSelectionSearch(array$l,array$t){$J=[];foreach($t
as$p=>$s){if($s["type"]=="FULLTEXT"&&isset($_GET["fulltext"])&&$_GET["fulltext"][$p]!="")$J[]="MATCH (".implode(", ",array_map('AdminNeo\idf_escape',$s["columns"])).") AGAINST (".q($_GET["fulltext"][$p]).(isset($_GET["boolean"][$p])?" IN BOOLEAN MODE":"").")";}foreach((array)$_GET["where"]as$Z){$Hb=$Z["col"];$Dh=$Z["op"];$X=$Z["val"];if("$Hb$X"!=""&&in_array($Dh,$this->getOperators())){$Fi="";$ac=" $Dh";if(preg_match('~IN$~',$Dh)){$mf=process_length($X);$ac
.=" ".($mf!=""?$mf:"(NULL)");}elseif($Dh=="SQL")$ac=" $X";elseif($Dh=="LIKE %%")$ac=" LIKE ".$this->admin->processFieldInput(isset($l[$Hb])?$l[$Hb]:null,"%$X%");elseif($Dh=="ILIKE %%")$ac=" ILIKE ".$this->admin->processFieldInput(isset($l[$Hb])?$l[$Hb]:null,"%$X%");elseif($Dh=="FIND_IN_SET"){$Fi="$Dh(".q($X).", ";$ac=")";}elseif(!preg_match('~NULL$~',$Dh))$ac
.=" ".$this->admin->processFieldInput(isset($l[$Hb])?$l[$Hb]:null,$X);if($Hb!=""){$Jj=isset($l[$Hb])?Driver::get()->convertSearch(idf_escape($Hb),$Z,$l[$Hb]):idf_escape($Hb);$J[]=$Fi.$Jj.$ac;}else{$Ob=[];foreach($l
as$_=>$k){if(isset($k["privileges"]["where"])&&(preg_match('~^[-\d.'.(preg_match('~IN$~',$Dh)?',':'').']+$~',$X)||!preg_match('~'.number_type().'|bit~',$k["type"]))&&(!preg_match("~[\x80-\xFF]~",$X)||preg_match('~char|text|enum|set~',$k["type"]))&&(!preg_match('~date|timestamp~',$k["type"])||preg_match('~^\d+-\d+-\d+~',$X))&&(!preg_match('~^elastic~',DRIVER)||$k["type"]!="boolean"||preg_match('~true|false~',$X))&&(!preg_match('~^elastic~',DRIVER)||strpos($Dh,"regexp")===false||preg_match('~text|keyword~',$k["type"])))$Ob[]=$Fi.Driver::get()->convertSearch(idf_escape($_),$Z,$k).$ac;}$J[]=($Ob?"(".implode(" OR ",$Ob).")":"1 = 0");}}}return$J;}function
processSelectionOrder(array$l,array$t){$J=[];foreach((array)$_GET["order"]as$u=>$X){if($X!="")$J[]=(preg_match('~^((COUNT\(DISTINCT |[A-Z0-9_]+\()(`(?:[^`]|``)+`|"(?:[^"]|"")+")\)|COUNT\(\*\))$~',$X)?$X:idf_escape($X)).(isset($_GET["desc"][$u])?" DESC":"");}return$J;}function
processSelectionLength(){return
isset($_GET["text_length"])?$_GET["text_length"]:"100";}function
getFieldFunctions(array$k){$J=($k["null"]?"NULL/":"");$im=isset($_GET["select"])||where($_GET);foreach(Driver::get()->getEditFunctions()as$u=>$_e){if(!$u||(!isset($_GET["call"])&&$im)){foreach($_e
as$si=>$X){if(!$si||preg_match("~$si~",$k["type"]))$J
.="/$X";}}if($u&&!preg_match('~enum|set|blob|bytea|raw|file|bool~',$k["type"]))$J
.="/SQL";}if($k["auto_increment"]&&!$im)$J=lang(46);return
explode("/",$J);}function
getFieldInput($R,array$k,$Pa,$Y,$ze){return"";}function
processFieldInput($k,$Y,$ze=""){if($ze=="SQL")return$Y;if(!$k)return
q($Y);if(isset($k["type"]))$this->admin->detectJson($k["type"],$Y,false);$_=$k["field"];$J=q($Y);if(preg_match('~^(now|getdate|uuid)$~',$ze))$J="$ze()";elseif(preg_match('~^current_(date|timestamp)$~',$ze))$J=$ze;elseif(preg_match('~^([+-]|\|\|)$~',$ze))$J=idf_escape($_)." $ze $J";elseif(preg_match('~^[+-] interval$~',$ze))$J=idf_escape($_)." $ze ".(preg_match("~^(\\d+|'[0-9.: -]') [A-Z_]+\$~i",$Y)?$Y:$J);elseif(preg_match('~^(addtime|subtime|concat)$~',$ze))$J="$ze(".idf_escape($_).", $J)";elseif(preg_match('~^(md5|sha1|password|encrypt)$~',$ze))$J="$ze($J)";elseif($k["type"]=="boolean"&&DIALECT=="elastic")$J=$J=="0"?"false":"true";return
unconvert_field($k,$J);}function
getDumpOutputs(){$Zh=['file'=>lang(64),'text'=>lang(65),];if(function_exists('gzencode'))$Zh['gz']='gzip';return$Zh;}function
getDumpFormats(){return(support("dump")?['sql'=>'SQL']:[])+['csv'=>'CSV,','csv;'=>'CSV;','tsv'=>'TSV'];}function
sendDumpHeaders($gf,$Vg=false){$Yh=$_POST["output"];$Od=(str_contains($_POST["format"],"sql")?"sql":($Vg?"tar":"csv"));if($Yh=="gz"){header("Content-Type: application/x-gzip");ob_start(function($Q){return
gzencode($Q);},1e6);}elseif($Od=="tar")header("Content-Type: application/x-tar");elseif($Od=="sql"||$Yh=="text")header("Content-Type: text/plain; charset=utf-8");else
header("Content-Type: text/csv; charset=utf-8");return$Od;}function
dumpTable($R,$Nk,$Am=0){if($_POST["format"]!="sql"){echo"\xef\xbb\xbf";if($Nk)dump_csv(array_keys(fields($R)));}else{if($Am==2){$l=[];foreach(fields($R)as$_=>$k)$l[]=idf_escape($_)." $k[full_type]";$rc="CREATE TABLE ".table($R)." (".implode(", ",$l).")";}else$rc=create_sql($R,$_POST["auto_increment"],$Nk);set_utf8mb4($rc);if($Nk&&$rc){if($Nk=="DROP+CREATE"||$Am==1)echo"DROP ".($Am==2?"VIEW":"TABLE")." IF EXISTS ".table($R).";\n";if($Am==1)$rc=remove_definer($rc);echo"$rc;\n\n";}}}function
dumpData($R,$Nk,$G){if($Nk){$Ag=(DIALECT=="sqlite"?0:1048576);$l=[];$if=false;if($_POST["format"]=="sql"){if($Nk=="TRUNCATE+INSERT")echo
truncate_sql($R).";\n";$l=fields($R);if(DIALECT=="mssql"){foreach($l
as$k){if($k["auto_increment"]){echo"SET IDENTITY_INSERT ".table($R)." ON;\n";$if=true;break;}}}}$I=Connection::get()->query($G,1);if($I){$vf="";$ib="";$Tf=[];$Be=[];$Rk="";while($K=($R!=''?$I->fetchAssoc():$I->fetchRow())){if(!$Tf){$vm=[];foreach($K
as$X){$k=$I->fetchField();if(!empty($l[$k->name]['generated'])){$Be[$k->name]=true;continue;}$Tf[]=$k->name;$u=idf_escape($k->name);$vm[]="$u = VALUES($u)";}$Rk=($Nk=="INSERT+UPDATE"?"\nON DUPLICATE KEY UPDATE ".implode(", ",$vm):"").";\n";}if($_POST["format"]!="sql"){if($Nk=="table"){dump_csv($Tf);$Nk="INSERT";}dump_csv($K);}else{if(!$vf)$vf="INSERT INTO ".table($R)." (".implode(", ",array_map('AdminNeo\idf_escape',$Tf)).") VALUES";foreach($K
as$u=>$X){if(isset($Be[$u])){unset($K[$u]);continue;}$k=$l[$u];$K[$u]=($X!==null?unconvert_field($k,preg_match(number_type(),$k["type"])&&!preg_match('~\[~',$k["full_type"])&&is_numeric($X)?$X:q(($X===false?0:$X))):"NULL");}$Dj=($Ag?"\n":" ")."(".implode(",\t",$K).")";if(!$ib)$ib=$vf.$Dj;elseif(strlen($ib)+4+strlen($Dj)+strlen($Rk)<$Ag)$ib
.=",$Dj";else{echo$ib.$Rk;$ib=$vf.$Dj;}}}if($ib)echo$ib.$Rk;}elseif($_POST["format"]=="sql")echo"-- ".str_replace("\n"," ",Connection::get()->getError())."\n";if($if)echo"SET IDENTITY_INSERT ".table($R)." OFF;\n";}}function
getImportFilePath(){return"adminneo.sql";}function
printDatabaseMenu(){echo"<p class='links top-links'>\n";$lh=isset($_GET["ns"])?$_GET["ns"]:null;if($lh==""&&support("database"))echo'<a href="',h(ME),'database=">',icon("edit"),lang(66),"</a>\n";if($lh!=""&&support("scheme"))echo"<a href='",h(ME),"scheme='>",icon("edit"),lang(67),"</a>\n";if($lh!=="")echo'<a href="',h(ME),'schema=">',icon("schema"),lang(68),"</a>\n";if(support("privileges"))echo"<a href='",h(ME),"privileges='>",icon("users"),lang(69),"</a>\n";echo"</p>\n";}function
printNavigation($Rg){parent::printNavigation($Rg);if($Rg=="auth"){$Yh="";foreach((array)$_SESSION["pwds"]as$xm=>$ek){foreach($ek
as$O=>$sm){foreach($sm
as$V=>$E){if($E!==null){$Fc=$_SESSION["db"][$xm][$O][$V];foreach(($Fc?array_keys($Fc):[""])as$h){$bk=$this->admin->getServerName($O);$Cl=h(get_driver_name($xm,$O)).($V!=""||$bk!=""?" - ":"").h($V).($V!=""&&$bk!=""?"@":"").h($bk).($h!=""?h(" - $h"):"");$Yh
.="<li><a href='".h(auth_url($xm,$O,$V,$h))."' class='primary' title='$Cl'>$Cl</a></li>\n";}}}}}if($Yh)echo"<nav id='logins'><menu>\n$Yh</menu></nav>\n";}else{$this->admin->printDatabaseSwitcher($Rg);$sa=[];if(DB==null||!$Rg){if(support("sql")){$sa[]="<a href='".h(ME)."sql='".bold(isset($_GET["sql"])&&!isset($_GET["import"])).">".icon("command").lang(39)."</a>";$sa[]="<a href='".h(ME)."import='".bold(isset($_GET["import"])).">".icon("import").lang(70)."</a>";}$sa[]="<a href='".h(ME)."dump=".urlencode(isset($_GET["table"])?$_GET["table"]:$_GET["select"])."' id='dump'".bold(isset($_GET["dump"])).">".icon("export").lang(71)."</a>";}if(DB==null)$sa[]='<a href="'.h(ME).'database="'.bold($_GET["database"]==="").">".icon("database-add").lang(72)."</a>\n";if(DB!=null&&$_GET["ns"]===""&&!$Rg)$sa[]='<a href="'.h(ME).'scheme="'.bold($_GET["scheme"]==="").">".icon("database-add").lang(73)."</a>\n";if(DB!=null&&$_GET["ns"]!==""&&!$Rg)$sa[]='<a href="'.h(ME).'create="'.bold($_GET["create"]==="").">".icon("table-add").lang(74)."</a>\n";if($sa)echo"<p class='links'>".implode("\n",$sa)."</p>";$T=[];if($_GET["ns"]!==""&&!$Rg&&DB!=""){Connection::get()->selectDatabase(DB);$T=table_status('',true);}if($_GET["ns"]!==""&&!$Rg&&DB!=""){if($T){$this->admin->printTablesFilter();$this->admin->printTableList($T);}else
echo"<p class='message'>".lang(75)."</p>\n";}if(support("sql")||DIALECT=="elastic"){echo"<script".nonce().">\n";if(support("sql")&&$T){$mg=[];foreach($T
as$R=>$U)$mg[]=preg_quote($R,'/');echo"const jushLinks = { ".DIALECT.": [ '".js_escape(ME).(support("table")?"table=":"select=")."\$&', /\\b(".implode("|",$mg).")\\b/g ] };\n";foreach(["bac","bra","sqlite_quo","mssql_bra"]as$X)echo"jushLinks.$X = jushLinks.".DIALECT.";\n";}if(DIALECT!="elastic"&&$this->getConfig()->isSqlAutocompletionEnabled()&&(isset($_GET["sql"])||isset($_GET["trigger"])||isset($_GET["check"]))){$kl=array_fill_keys(array_keys($T),[]);foreach(Driver::get()->getAllFields()as$R=>$l){foreach($l
as$k)$kl[$R][]=$k["field"];}echo"window.addEventListener('DOMContentLoaded', () => { autocompletion = jush.autocompleteSql('".idf_escape("")."', ".json_encode($kl)."); });\n";}echo"</script>\n";}echo
script("let autocompletion;\nwindow.addEventListener('DOMContentLoaded', () => { initSyntaxHighlighting('".Connection::get()->getVersion()."', '".Connection::get()->getFlavor()."', autocompletion); });");}}function
printDatabaseSwitcher($Rg){$g=$this->admin->getDatabases();if(!$g&&DIALECT!="sqlite")return;echo"<div class='db-selector'><form action=''>";hidden_fields_get();echo"<div>";if($g)echo"<select id='database-select' name='db'>".optionlist([""=>lang(29)]+$g,DB)."</select>".script("mixin(gid('database-select'), {onmousedown: dbMouseDown, onchange: dbChange});");else
echo"<input id='database-select' class='input' name='db' value='".h(DB)."' autocapitalize='off'>\n";echo"<input type='submit' value='".lang(76)."' class='button ".($g?"hidden":"")."'>\n","</div>";if(support("scheme")&&$Rg!="db"&&DB!=""&&Connection::get()->selectDatabase(DB)){echo"<div>","<select id='scheme-select' name='ns'>".optionlist([""=>lang(77)]+$this->admin->getSchemas(),$_GET["ns"])."</select>".script("mixin(gid('scheme-select'), {onmousedown: dbMouseDown, onchange: dbChange});"),"</div>";if($_GET["ns"]!="")set_schema($_GET["ns"]);}foreach(["import","sql","schema","dump","privileges"]as$X){if(isset($_GET[$X])){echo
input_hidden($X);break;}}echo"</form></div>\n";}function
printTableList(array$T){$Ig=($this->settings->isNavigationDual()?"class='dual'":($this->settings->isNavigationReversed()?"class='reversed'":""));echo"<nav id='tables'><menu $Ig>";foreach($T
as$R=>$Ik){$_=$this->admin->getTableName($Ik);if($_=="")continue;echo"<li>";$ta=in_array($R,[$_GET["table"],$_GET["select"],$_GET["create"],$_GET["indexes"],$_GET["foreign"],$_GET["trigger"]]);$Eb="primary".(is_view($Ik)?" view":"");$Vk=support("table")||support("indexes");$Nj=h(ME)."select=".urlencode($R);$dl=h(ME)."table=".urlencode($R);if($this->settings->isSelectionPreferred()){if($this->settings->isNavigationReversed()&&$Vk)echo" <a href='$dl' title='",lang(33),"' class='secondary'>",icon("structure"),"</a>";echo"<a href='$Nj'",bold($ta,$Eb)," data-primary='true' title='$_'>$_</a>";if($this->settings->isNavigationDual()&&$Vk)echo" <a href='$dl' title='",lang(33),"' class='secondary'>",icon_solo("structure"),"</a>";}else{if($this->settings->isNavigationReversed())echo" <a href='$Nj' title='",lang(32),"' class='secondary'>",icon("data"),"</a>";if($Vk)echo"<a href='$dl'",bold($ta,$Eb)," data-primary='true' title='$_'>$_</a>";else
echo"<span data-primary='true'",bold($ta,$Eb),">$_</span>";if($this->settings->isNavigationDual())echo" <a href='$Nj' title='",lang(32),"' class='secondary'>",icon_solo("data"),"</a>";}echo"</li>\n";}echo"</menu></nav>\n";}function
getSettingsRows($Je){$P=parent::getSettingsRows($Je);if($Je==1){$B=[""=>lang(13),Config::$NavigationSimple=>lang(78),Config::$NavigationDual=>lang(79),Config::$NavigationReversed=>lang(80)];$i=$B[$this->config->getNavigationMode()];$B[""].=" ($i)";$P["navigationMode"]="<tr><th>".lang(81)."</th>"."<td>".html_radios("navigationMode",$B,($pa=$this->settings->getParameter("navigationMode"))!==null?$pa:"")."<span class='input-hint'>".lang(82)."</span>"."</td></tr>\n";$B=[""=>lang(13),0=>lang(33),1=>lang(32),];$i=$B[$this->config->isSelectionPreferred()?1:0];$B[""].=" ($i)";$P["preferSelection"]="<tr><th>".lang(83)."</th>"."<td>".html_select("preferSelection",$B,($pa=$this->settings->getParameter("preferSelection"))!==null?$pa:"","","",true)."<span class='input-hint'>".lang(84)."</span>"."</td></tr>\n";}return$P;}function
getForeignColumnInfo(array$pe,$c){return
null;}}class
TmpFile{private$handler;private$size;function
__construct(){$this->handler=tmpfile();}function
write($lc){if(!$this->handler)return;$this->size+=strlen($lc);fwrite($this->handler,$lc);}function
send(){if(!$this->handler)return;fseek($this->handler,0);fpassthru($this->handler);fclose($this->handler);}}function
select(Result$I,$e=null,$Ph=[],$w=0){$mg=[];$t=[];$d=[];$eb=[];$Zl=[];$J=[];for($p=0;(!$w||$p<$w)&&($K=$I->fetchRow());$p++){if(!$p){echo"<div class='scrollable'>\n","<table class='nowrap'>\n","<thead><tr>";for($Kf=0;$Kf<count($K);$Kf++){$k=$I->fetchField();if(!$k){echo"<th></th>";continue;}$_=$k->name;$Oh=isset($k->orgtable)?$k->orgtable:"";$Nh=isset($k->orgname)?$k->orgname:$_;if(isset($k->table))$J[$k->table]=$Oh;if($Ph&&DIALECT=="sql")$mg[$Kf]=($_=="table"?"table=":($_=="possible_keys"?"indexes=":null));elseif($Oh!=""){if(!isset($t[$Oh])){$t[$Oh]=[];foreach(indexes($Oh,$e)as$s){if($s["type"]=="PRIMARY"){$t[$Oh]=array_flip($s["columns"]);break;}}$d[$Oh]=$t[$Oh];}if(isset($d[$Oh][$Nh])){unset($d[$Oh][$Nh]);$t[$Oh][$Nh]=$Kf;$mg[$Kf]=$Oh;}}if($k->charsetnr==63)$eb[$Kf]=true;$Zl[$Kf]=$k->type;echo"<th".($Oh!=""||$k->name!=$Nh?" title='".h(($Oh!=""?"$Oh.":"").$Nh)."'":"").">".h($_).($Ph?doc_link(['sql'=>"explain-output.html#explain_".strtolower($_),'mariadb'=>"explain/#the-columns-in-explain-select",]):"");}echo"</thead>\n";}echo"<tr>";foreach($K
as$u=>$X){$x="";if(isset($mg[$u])&&!$d[$mg[$u]]){if($Ph&&DIALECT=="sql"){$R=$K[array_search("table=",$mg)];$x=ME.$mg[$u].urlencode($Ph[$R]!=""?$Ph[$R]:$R);}else{$x=ME."edit=".urlencode($mg[$u]);foreach($t[$mg[$u]]as$Hb=>$Kf)$x
.="&where".urlencode("[".bracket_escape($Hb)."]")."=".urlencode($K[$Kf]);}}elseif(is_web_url($X))$x=$X;if($X===null)$X="<i>NULL</i>";elseif($eb[$u]&&!is_utf8($X))$X="<i>".lang(41,strlen($X))."</i>";else{$X=h($X);if($Zl[$u]==254)$X="<code>$X</code>";}if($x)$X="<a href='".h($x)."'".(is_web_url($x)?target_blank():'').">$X</a>";$Eb=$Zl[$u]<=9||$Zl[$u]==246?"class='number'":"";echo"<td $Eb>$X</td>";}}echo($p?"</table>\n</div>":"<p class='message'>".lang(85))."\n";return$J;}function
referencable_primary($Sj){$J=[];foreach(table_status('',true)as$fl=>$R){if($fl!=$Sj&&fk_support($R)){foreach(fields($fl)as$k){if($k["primary"]){if($J[$fl]){unset($J[$fl]);break;}$J[$fl]=$k;}}}}return$J;}function
textarea($_,$Y,$L=10,$Ob=80){echo"<textarea name='".h($_)."' rows='$L' cols='$Ob' class='sqlarea jush-".DIALECT."' spellcheck='false' wrap='off'>";if(is_array($Y)){foreach($Y
as$X)echo
h($X[0])."\n\n\n";}else
echo
h($Y);echo"</textarea>";}function
select_input($Pa,$B,$Y="",$Bh="",$vi=""){$nl=($B?"select":"input");return"<$nl $Pa".($B?"><option value=''>$vi".optionlist($B,$Y,true)."</select>":" size='10' value='".h($Y)."' placeholder='$vi'>").($Bh?script("qsl('$nl').onchange = $Bh;",""):"");}function
json_row($u,$X=null){static$fe=true;if($fe)echo"{";if($u!=""){echo($fe?"":",")."\n\t\"".addcslashes($u,"\r\n\t\"\\/").'": '.($X!==null?'"'.addcslashes($X,"\r\n\t\"\\/").'"':'null');$fe=false;}else{echo"\n}\n";$fe=true;}}function
edit_type($u,$k,$Kb,$qe=[],$Rd=[]){$U=isset($k["type"])?$k["type"]:null;echo'<td><select name="',h($u),'[type]" class="type" aria-labelledby="label-type">';$Zc=Driver::get()->getTypes();if($U&&!isset($Zc[$U])&&!isset($qe[$U])&&!in_array($U,$Rd))$Rd[]=$U;$Mk=Driver::get()->getStructuredTypes();if($qe)$Mk[lang(86)]=$qe;echo
optionlist(array_merge($Rd,$Mk),$U),'</select><td><input name="',h($u),'[length]" value="',h(isset($k["length"])?$k["length"]:null),'" size="3"',(!(isset($k["length"])?$k["length"]:null)&&preg_match('~var(char|binary)$~',$U)?" class='input required'":" class='input'"),' aria-labelledby="label-length"><td class="options">',($Kb?"<select name='".h($u)."[collation]'".(preg_match('~(char|text|enum|set)$~',$U)?"":" class='hidden'").'><option value="">('.lang(87).')'.optionlist($Kb,isset($k["collation"])?$k["collation"]:null).'</select>':''),(Driver::get()->getUnsigned()?"<select name='".h($u)."[unsigned]'".(!$U||preg_match(number_type(),$U)?"":" class='hidden'").'><option>'.optionlist(Driver::get()->getUnsigned(),isset($k["unsigned"])?$k["unsigned"]:null).'</select>':''),(isset($k['on_update'])?"<select name='".h($u)."[on_update]'".(preg_match('~timestamp|datetime~',$U)?"":" class='hidden'").'>'.optionlist([""=>"(".lang(88).")","CURRENT_TIMESTAMP"],(preg_match('~^CURRENT_TIMESTAMP~i',$k["on_update"])?"CURRENT_TIMESTAMP":$k["on_update"])).'</select>':''),($qe?"<select name='".h($u)."[on_delete]'".(preg_match("~`~",$U)?"":" class='hidden'")."><option value=''>(".lang(89).")".optionlist(Driver::get()->getOnActions(),isset($k["on_delete"])?$k["on_delete"]:null)."</select> ":" ");}function
get_partitions_info($R){$xe="FROM information_schema.PARTITIONS WHERE TABLE_SCHEMA = ".q(DB)." AND TABLE_NAME = ".q($R);$I=Connection::get()->query("SELECT PARTITION_METHOD, PARTITION_EXPRESSION, PARTITION_ORDINAL_POSITION $xe ORDER BY PARTITION_ORDINAL_POSITION DESC LIMIT 1");$sf=[];list($sf["partition_by"],$sf["partition"],$sf["partitions"])=$I->fetchRow();$li=get_key_vals("SELECT PARTITION_NAME, PARTITION_DESCRIPTION $xe AND PARTITION_NAME != '' ORDER BY PARTITION_ORDINAL_POSITION");$sf["partition_names"]=array_keys($li);$sf["partition_values"]=array_values($li);return$sf;}function
process_length($v){$wd=Driver::$EnumLengthPattern;return(preg_match("~^\\s*\\(?\\s*$wd(?:\\s*,\\s*$wd)*+\\s*\\)?\\s*\$~",$v)&&preg_match_all("~$wd~",$v,$z)?"(".implode(",",$z[0]).")":preg_replace('~^[0-9].*~','(\0)',preg_replace('~[^-0-9,+()[\]]~','',$v)));}function
process_type($k,$Ib="COLLATE"){return" $k[type]".process_length($k["length"]).(preg_match(number_type(),$k["type"])&&in_array($k["unsigned"],Driver::get()->getUnsigned())?" $k[unsigned]":"").(preg_match('~char|text|enum|set~',$k["type"])&&$k["collation"]?" $Ib ".(DIALECT=="mssql"?$k["collation"]:q($k["collation"])):"");}function
process_field($k,$Wl){if($k["on_update"])$k["on_update"]=str_ireplace("current_timestamp()","CURRENT_TIMESTAMP",$k["on_update"]);return[idf_escape(trim($k["field"])),process_type($Wl),($k["null"]?" NULL":" NOT NULL"),default_value($k),(preg_match('~timestamp|datetime~',$k["type"])&&$k["on_update"]?" ON UPDATE ".$k["on_update"]:""),(support("comment")&&$k["comment"]!=""?" COMMENT ".q($k["comment"]):""),($k["auto_increment"]?auto_increment():null),];}function
default_value($k){$i=$k["default"];if($i===null)return"";$Ae=$k["generated"];if(in_array($Ae,Driver::get()->getGenerated())){if(DIALECT=="mssql")return" AS ($i)".($Ae=="VIRTUAL"?"":" $Ae");else
return" GENERATED ALWAYS AS ($i) $Ae";}if(stripos($i,"GENERATED ")===0)return" $i";if(preg_match('~char|binary|text|json|enum|set~',$k["type"])||preg_match('~^(?![a-z])~i',$i)){if(DIALECT=="sql"&&preg_match('~text|json~',$k["type"]))return" DEFAULT (".q($i).")";else
return" DEFAULT ".q($i);}else{$i=str_ireplace("current_timestamp()","CURRENT_TIMESTAMP",$i);return" DEFAULT ".(DIALECT=="sqlite"?"($i)":$i);}}function
type_class($U){foreach(['char'=>'text','date'=>'time|year','binary'=>'blob','enum'=>'set',]as$u=>$X){if(preg_match("~$u|$X~",$U))return" class='$u'";}}function
edit_fields(array$l,array$Kb,$U="TABLE",$qe=[]){$l=array_values($l);$Xb=$_POST?$_POST["comments"]:Admin::get()->getSettings()->getParameter("commentsOpened");$Ub=$Xb?"":"class='hidden'";echo"<thead><tr>\n";if(support("move_col"))echo"<td class='jsonly'></td>";if($U=="PROCEDURE")echo"<td></td>";echo"<th id='label-name'>",($U=="TABLE"?lang(90):lang(91)),"</th>\n","<td id='label-type'>",lang(43),"<textarea id='enum-edit' rows='4' cols='12' wrap='off' style='display: none;'></textarea>",script("gid('enum-edit').onblur = onFieldLengthBlur;"),"</td>\n","<td id='label-length'>",lang("Length"),"</td>\n","<td>",lang(92),"</td>\n";if($U=="TABLE")echo"<td id='label-null'>NULL</td>\n","<td><input type='radio' name='auto_increment_col' value=''><abbr id='label-ai' title='",lang(46),"'>AI</abbr>",doc_link(['sql'=>"example-auto-increment.html",'mariadb'=>"auto_increment/",'sqlite'=>"autoinc.html",'pgsql'=>"datatype-numeric.html#DATATYPE-SERIAL",'mssql'=>"t-sql/statements/create-table-transact-sql-identity-property",]),"</td>\n","<td id='label-default'>",lang(47),"</td>\n",support("comment")?"<td id='label-comment' $Ub>".lang(45)."</td>\n":"";echo"<td>","<button name='add[",(support("move_col")?0:count($l)),"]' value='1' title='",h(lang(93)),"' class='button light'>",icon_solo("add"),"</button>",script("row_count = ".count($l).";"),"</td>\n","</tr></thead>\n";$Eb=support("move_col")?"class='sortable'":"";echo"<tbody $Eb>\n";foreach($l
as$p=>$k){$p++;$Qh=$k[($_POST?"orig":"field")];$Vc=(isset($_POST["add"][$p-1])||(isset($k["field"])&&!(isset($_POST["drop_col"][$p])?$_POST["drop_col"][$p]:null)))&&(support("drop_col")||$Qh=="");$Nk=$Vc?"":"style='display: none;'";echo"<tr $Nk>\n";if(support("move_col"))echo"<td class='handle jsonly'>",icon_solo("handle"),"</td>";if($U=="PROCEDURE")echo"<td>",html_select("fields[$p][inout]",Driver::get()->getInOut(),$k["inout"]),"</td>\n";echo"<th>";if($Vc)echo"<input class='input' name='fields[$p][field]' value='",h($k["field"]),"' data-maxlength='64' autocapitalize='off' aria-labelledby='label-name'>";echo
input_hidden("fields[$p][orig]",$Qh);edit_type("fields[$p]",$k,$Kb,$qe);echo"</th>\n";if($U=="TABLE"){echo"<td>",checkbox("fields[$p][null]",1,$k["null"],"","","block","label-null"),"</td>\n";$zb=$k["auto_increment"]?"checked":"";echo"<td><label class='block'><input type='radio' name='auto_increment_col' value='$p' $zb aria-labelledby='label-ai'></label></td>\n","<td class='default-value'>";if(Driver::get()->getGenerated())echo
html_select("fields[$p][generated]",array_merge(["","DEFAULT"],Driver::get()->getGenerated()),$k["generated"]);else
echo
checkbox("fields[$p][generated]",1,$k["generated"],"","","","label-default");echo"<input class='input' name='fields[$p][default]' value='",h($k["default"]),"' aria-labelledby='label-default'>","</td>\n";if(support("comment")){$_g=Connection::get()->isMinVersion("5.5")?1024:255;echo"<td $Ub>","<input class='input' name='fields[$p][comment]' value='",h($k["comment"]),"' data-maxlength='$_g' aria-labelledby='label-comment'>","</td>\n";}}echo"<td>";if(support("move_col"))echo"<button name='add[$p]' value='1' title='".h(lang(93))."' class='button light'>",icon_solo("add"),"</button>","<button name='up[$p]' value='1' title='".h(lang(94))."' class='button light hidden'>",icon_solo("arrow-up"),"</button>","<button name='down[$p]' value='1' title='".h(lang(95))."' class='button light hidden'>",icon_solo("arrow-down"),"</button>";if($Qh==""||support("drop_col"))echo"<button name='drop_col[$p]' value='1' title='".h(lang(55))."' class='button light'>",icon_solo("remove"),"</button>";echo"</td>\n</tr>\n";}echo"</tbody>";}function
process_fields(&$l){$A=0;if($_POST["up"]){$ag=0;foreach($l
as$u=>$k){if(key($_POST["up"])==$u){unset($l[$u]);array_splice($l,$ag,0,[$k]);break;}if(isset($k["field"]))$ag=$A;$A++;}}elseif($_POST["down"]){$ue=false;foreach($l
as$u=>$k){if(isset($k["field"])&&$ue){unset($l[key($_POST["down"])]);array_splice($l,$A,0,[$ue]);break;}if(key($_POST["down"])==$u)$ue=$k;$A++;}}elseif($_POST["add"]){$l=array_values($l);array_splice($l,key($_POST["add"]),0,[[]]);}elseif(!$_POST["drop_col"])return
false;return
true;}function
normalize_enum($y){return"'".str_replace("'","''",addcslashes(stripcslashes(str_replace($y[0][0].$y[0][0],$y[0][0],substr($y[0],1,-1))),'\\'))."'";}function
grant($Ee,array$Mi,$d,$_h,$qm){if(!$Mi)return
true;if($Mi==["ALL PRIVILEGES","GRANT OPTION"]){if($Ee)return(bool)queries("GRANT ALL PRIVILEGES ON $_h TO $qm WITH GRANT OPTION");else
return
queries("REVOKE ALL PRIVILEGES ON $_h FROM $qm")&&queries("REVOKE GRANT OPTION ON $_h FROM $qm");}if($Mi==["GRANT OPTION","PROXY"]){if($Ee)return(bool)queries("GRANT PROXY ON $_h TO $qm WITH GRANT OPTION");else
return(bool)queries("REVOKE PROXY ON $_h FROM $qm");}return(bool)queries(($Ee?"GRANT ":"REVOKE ").preg_replace('~(GRANT OPTION)\([^)]*\)~','$1',implode("$d, ",$Mi).$d)." ON $_h ".($Ee?"TO ":"FROM ").$qm);}function
drop_create($bd,$rc,$dd,$sl,$fd,$qg,$Mg,$Kg,$Lg,$xh,$gh){if($_POST["drop"])query_redirect($bd,$qg,$Mg);elseif($xh=="")query_redirect($rc,$qg,$Lg);elseif($xh!=$gh){$tc=queries($rc);queries_redirect($qg,$Kg,$tc&&queries($bd));if($tc)queries($dd);}else
queries_redirect($qg,$Kg,queries($sl)&&queries($fd)&&queries($bd)&&queries($rc));}function
create_trigger($_h,$K){$Bl=" $K[Timing] $K[Event]".(preg_match('~ OF~',$K["Event"])?" $K[Of]":"");return"CREATE TRIGGER ".idf_escape($K["Trigger"]).(DIALECT=="mssql"?$_h.$Bl:$Bl.$_h).rtrim(" $K[Type]\n$K[Statement]",";").";";}function
create_routine($yj,$K){$ik=[];$l=(array)$K["fields"];ksort($l);$nf=implode("|",Driver::get()->getInOut());foreach($l
as$k){if($k["field"]!="")$ik[]=(preg_match("~^($nf)\$~",$k["inout"])?"$k[inout] ":"").idf_escape($k["field"]).process_type($k,"CHARACTER SET");}$Kc=rtrim($K["definition"],";");return"CREATE $yj ".idf_escape(trim($K["name"]))." (".implode(", ",$ik).")".($yj=="FUNCTION"?" RETURNS".process_type($K["returns"],"CHARACTER SET"):"").($K["language"]?" LANGUAGE $K[language]":"").(DIALECT=="pgsql"?" AS ".q($Kc):"\n$Kc;");}function
remove_definer($G){return
preg_replace('~^([A-Z =]+) DEFINER=`'.preg_replace('~@(.*)~','`@`(%|\1)',logged_user()).'`~','\1',$G);}function
format_foreign_key($o){$Ah=implode("|",Driver::get()->getOnActions());$h=$o["db"];$lh=$o["ns"];return" FOREIGN KEY (".implode(", ",array_map('AdminNeo\idf_escape',$o["source"])).") REFERENCES ".($h!=""&&$h!=$_GET["db"]?idf_escape($h).".":"").($lh!=""&&$lh!=$_GET["ns"]?idf_escape($lh).".":"").idf_escape($o["table"])." (".implode(", ",array_map('AdminNeo\idf_escape',$o["target"])).")".(preg_match("~^($Ah)\$~",$o["on_delete"])?" ON DELETE $o[on_delete]":"").(preg_match("~^($Ah)\$~",$o["on_update"])?" ON UPDATE $o[on_update]":"");}function
tar_file($n,$Fl){$J=pack("a100a8a8a8a12a12",$n,644,0,0,decoct($Fl->size),decoct(time()));$Ab=8*32;for($p=0;$p<strlen($J);$p++)$Ab+=ord($J[$p]);$J
.=sprintf("%06o",$Ab)."\0 ";echo$J,str_repeat("\0",512-strlen($J));$Fl->send();echo
str_repeat("\0",511-($Fl->size+511)%512);}function
ini_bytes($tf){$X=ini_get($tf);switch(strtolower(substr($X,-1))){case'g':$X=(int)$X*1024;case'm':$X=(int)$X*1024;case'k':$X=(int)$X*1024;}return$X;}function
doc_link(array$ri,$tl="<sup>?</sup>"){if(!(isset($ri[DIALECT])?$ri[DIALECT]:null))return"";$ym=preg_replace('~^(\d\.?\d).*~s','\1',Connection::get()->getVersion());$lm=['sql'=>"https://dev.mysql.com/doc/refman/$ym/en/",'sqlite'=>"https://www.sqlite.org/",'pgsql'=>"https://www.postgresql.org/docs/".(Connection::get()->isCockroachDB()?"current":$ym)."/",'mssql'=>"https://learn.microsoft.com/en-us/sql/",'oracle'=>"https://www.oracle.com/pls/topic/lookup?ctx=db".str_replace(".","",$ym)."&id=",'elastic'=>"https://www.elastic.co/guide/en/elasticsearch/reference/$ym/",];if(Connection::get()->isMariaDB()){$lm['sql']="https://mariadb.com/kb/en/";$ri['sql']=isset($ri['mariadb'])?$ri['mariadb']:str_replace(".html","/",$ri['sql']);}return"<a href='".h($lm[DIALECT].$ri[DIALECT].(DIALECT=='mssql'?"?view=sql-server-ver$ym":""))."'".target_blank().">$tl</a>";}function
db_size($h){if(!Connection::get()->selectDatabase($h))return"?";$J=0;foreach(table_status()as$S)$J+=$S["Data_length"]+$S["Index_length"];return
format_number($J);}function
set_utf8mb4($rc){static$ik=false;if(!$ik&&preg_match('~\butf8mb4~i',$rc)){$ik=true;echo"SET NAMES ".charset(Connection::get()).";\n\n";}}error_reporting(E_ALL&~E_DEPRECATED);set_error_handler(function($yd,$j){return(bool)preg_match('~^Undefined (array key|offset|index)~',$j);},E_WARNING|E_NOTICE);;$de=!preg_match('~^(unsafe_raw)?$~',ini_get("filter.default"));if($de||ini_get("filter.default_flags")){foreach(['_GET','_POST','_COOKIE','_SERVER']as$X){$fm=filter_input_array(constant("INPUT$X"),FILTER_UNSAFE_RAW);if($fm)$$X=$fm;}}if(function_exists("mb_internal_encoding"))mb_internal_encoding("8bit");class
Server{private$params;private$key;function
__construct(array$D,$u=null){$this->params=$D;$this->key=$u;}function
getKey(){return
isset($this->key)?$this->key:substr(md5($this->getDriver().$this->getServer()),0,8);}function
getDriver(){return$this->params["driver"];}function
getServer(){return
isset($this->params["server"])?$this->params["server"]:"";}function
getDatabase(){return
isset($this->params["database"])?$this->params["database"]:"";}function
getName(){return
isset($this->params["name"])?$this->params["name"]:(isset($this->params["server"])?$this->params["server"]:"");}function
getUsername(){return
isset($this->params["username"])?$this->params["username"]:"";}function
getPassword(){return
isset($this->params["password"])?$this->params["password"]:"";}function
hasCredentials(){return$this->getUsername()!=""||$this->getPassword()!="";}function
getConfigParams(){$D=isset($this->params["config"])?$this->params["config"]:[];$De=["servers"];foreach($De
as$di){if(isset($D[$di]))unset($D[$di]);}return$D;}}class
Config{static$NavigationSimple="simple";static$NavigationDual="dual";static$NavigationReversed="reversed";private$params;private$servers=[];function
__construct(array$D){$this->params=$D;if(isset($this->params["servers"])){foreach($this->params["servers"]as$u=>$O){$Zj=new
Server($O,is_string($u)?$u:null);$this->params["servers"][$u]=$Zj;$this->servers[$Zj->getKey()]=$Zj;}}}function
getTheme(){return
isset($this->params["theme"])?$this->params["theme"]:"default";}function
getColorVariant(){return
isset($this->params["colorVariant"])?$this->params["colorVariant"]:"blue";}function
getCssUrls(){return$this->parseList(isset($this->params["cssUrls"])?$this->params["cssUrls"]:[]);}function
getJsUrls(){return$this->parseList(isset($this->params["jsUrls"])?$this->params["jsUrls"]:[]);}function
getNavigationMode(){return
isset($this->params["navigationMode"])?$this->params["navigationMode"]:self::$NavigationSimple;}function
isNavigationSimple(){return$this->getNavigationMode()==self::$NavigationSimple;}function
isNavigationDual(){return$this->getNavigationMode()==self::$NavigationDual;}function
isNavigationReversed(){return$this->getNavigationMode()==self::$NavigationReversed;}function
isSelectionPreferred(){return
isset($this->params["preferSelection"])?$this->params["preferSelection"]:false;}function
isJsonValuesDetection(){return
isset($this->params["jsonValuesDetection"])?$this->params["jsonValuesDetection"]:false;}function
isJsonValuesAutoFormat(){return
isset($this->params["jsonValuesAutoFormat"])?$this->params["jsonValuesAutoFormat"]:false;}function
isRelationLinks(){return
isset($this->params["relationLinks"])?$this->params["relationLinks"]:false;}function
getRecordsPerPage(){return(int)(isset($this->params["recordsPerPage"])?$this->params["recordsPerPage"]:50);}function
getEnumAsSelectThreshold(){if(array_key_exists("enumAsSelectThreshold",$this->params))return$this->params["enumAsSelectThreshold"]!==null?(int)$this->params["enumAsSelectThreshold"]:null;else
return
5;}function
isVersionVerificationEnabled(){return
isset($this->params["versionVerification"])?$this->params["versionVerification"]:true;}function
isSqlAutocompletionEnabled(){return
isset($this->params["sqlAutocompletion"])?$this->params["sqlAutocompletion"]:true;}function
getHiddenDatabases(){return$this->parseList(isset($this->params["hiddenDatabases"])?$this->params["hiddenDatabases"]:[]);}function
getHiddenSchemas(){return$this->parseList(isset($this->params["hiddenSchemas"])?$this->params["hiddenSchemas"]:[]);}function
getVisibleCollations(){return$this->parseList(isset($this->params["visibleCollations"])?$this->params["visibleCollations"]:[]);}function
getDefaultDriver(array$ad){$Yc=isset($this->params["defaultDriver"])?$this->params["defaultDriver"]:null;return$Yc&&isset($ad[$Yc])?$Yc:key($ad);}function
getDefaultServer(){$O=isset($this->params["defaultServer"])?$this->params["defaultServer"]:null;if($O===null)return
null;$Zj=isset($this->params["servers"][$O])?$this->params["servers"][$O]:null;if($Zj)return$Zj->getKey();return$O;}function
getDefaultDatabase(){return
isset($this->params["defaultDatabase"])?$this->params["defaultDatabase"]:null;}function
getDefaultPasswordHash(){return
isset($this->params["defaultPasswordHash"])?$this->params["defaultPasswordHash"]:null;}function
getSslKey(){return
isset($this->params["sslKey"])?$this->params["sslKey"]:null;}function
getSslCertificate(){return
isset($this->params["sslCertificate"])?$this->params["sslCertificate"]:null;}function
getSslCaCertificate(){return
isset($this->params["sslCaCertificate"])?$this->params["sslCaCertificate"]:null;}function
getSslTrustServerCertificate(){return
isset($this->params["sslTrustServerCertificate"])?$this->params["sslTrustServerCertificate"]:null;}function
getSslEncrypt(){return
isset($this->params["sslEncrypt"])?$this->params["sslEncrypt"]:null;}function
getSslMode(){return
isset($this->params["sslMode"])?$this->params["sslMode"]:null;}function
hasServers(){return
isset($this->params["servers"]);}function
getServerPairs(array$ad){$ok=null;foreach($this->servers
as$O){if(!isset($ad[$O->getDriver()]))continue;if(!$ok)$ok=$O->getDriver();elseif($O->getDriver()!=$ok){$ok=null;break;}}$ak=[];foreach($this->servers
as$u=>$O){if(!isset($ad[$O->getDriver()]))continue;$Yj=$O->getName();if($ok&&$Yj)$ak[$u]=$Yj;else$ak[$u]=$ad[$O->getDriver()].($Yj!=""?" - $Yj":"");}return$ak;}function
getServer($Xj){return
isset($this->servers[$Xj])?$this->servers[$Xj]:null;}function
applyServer($O){$O=$this->getServer($O);if(!$O)return;$this->params=array_merge($this->params,$O->getConfigParams());}private
function
parseList($og){if(is_array($og))return$og;return
preg_split('~\s*,\s*~',(string)$og);}}class
Settings{static$ColorSchemeLight="light";static$ColorSchemeDark="dark";private$config;private$params=[];function
__construct(Config$cc){$this->config=$cc;if(isset($_COOKIE["neo_settings"])){parse_str($_COOKIE["neo_settings"],$this->params);$this->save();}if(isset($this->params["comments"]))$this->updateParameters(["commentsOpened"=>$this->params["comments"],"indexOptions"=>$this->params["index_options"],"comments"=>null,"index_options"=>null,]);if(isset($_COOKIE["neo_export"])){parse_str($_COOKIE["neo_export"],$D);$this->updateParameters(["exportFormat"=>$D["format"],"exportOutput"=>$D["output"],]);unset($_COOKIE["neo_export"]);cookie("neo_export","",-3600);}if(isset($_COOKIE["neo_dump"])){parse_str($_COOKIE["neo_dump"],$D);$this->updateParameters(["dumpFormat"=>$D["format"],"dumpDbStyle"=>$D["db_style"],"dumpTypes"=>isset($D["types"])?$D["types"]:null,"dumpRoutines"=>isset($D["routines"])?$D["routines"]:null,"dumpEvents"=>isset($D["events"])?$D["events"]:null,"dumpTableStyle"=>$D["table_style"],"dumpAutoIncrement"=>isset($D["auto_increment"])?$D["auto_increment"]:null,"dumpTriggers"=>isset($D["triggers"])?$D["triggers"]:null,"dumpDataStyle"=>$D["data_style"],"dumpOutput"=>$D["output"],]);unset($_COOKIE["neo_dump"]);cookie("neo_dump","",-3600);}}function
getParameter($u,$i=null){return
isset($this->params[$u])?$this->params[$u]:$i;}function
updateParameter($u,$Y){$this->updateParameters([$u=>$Y]);}function
updateParameters(array$D){$this->params=array_filter(array_merge($this->params,$D),function($Y){return$Y!==null;});$this->save();}private
function
save(){cookie("neo_settings",http_build_query($this->params),7776000);}function
getColorScheme(){return$this->getParameter("colorScheme");}function
getNavigationMode(){return($pa=$this->getParameter("navigationMode"))!==null?$pa:$this->config->getNavigationMode();}function
isNavigationSimple(){return$this->getNavigationMode()==Config::$NavigationSimple;}function
isNavigationDual(){return$this->getNavigationMode()==Config::$NavigationDual;}function
isNavigationReversed(){return$this->getNavigationMode()==Config::$NavigationReversed;}function
isSelectionPreferred(){return($pa=$this->getParameter("preferSelection"))!==null?$pa:$this->config->isSelectionPreferred();}function
isRelationLinks(){return
isset($this->params["relationLinks"])?$this->params["relationLinks"]:$this->config->isRelationLinks();}function
getRecordsPerPage(){return($pa=$this->getParameter("recordsPerPage"))!==null?$pa:$this->config->getRecordsPerPage();}function
getEnumAsSelectThreshold(){$Y=$this->getParameter("enumAsSelectThreshold");if($Y<0)return
null;return$Y!==null?(int)$Y:$this->config->getEnumAsSelectThreshold();}}class
Hash{static
function
hkdf($v,$u,$sf="",$Ej=""){if(extension_loaded("hash")&&PHP_VERSION_ID>=70120)return
hash_hkdf("sha1",$u,$v,$sf,$Ej);if($Ej=="")$Ej=str_repeat("\0",20);$Ni=self::hmacSha1($u,$Ej);$uh="";for($Rf="",$fb=1;!isset($uh[$v-1]);$fb++){$Rf=self::hmacSha1($Rf.$sf.chr($fb),$Ni);$uh
.=$Rf;}return
substr($uh,0,$v);}static
function
hmacSha1($f,$u){if(!extension_loaded("hash"))return
hash_hmac("sha1",$f,$u,true);if(strlen($u)>64)$u=sha1($u,true);$u=str_pad($u,64,"\0");$Bf=($u^str_repeat("\x36",64));$Eh=($u^str_repeat("\x5C",64));return
sha1($Eh.sha1($Bf.$f,true),true);}}class
Random{static
function
strongKey(){return
strtr(rtrim(base64_encode(Random::bytes(32)),"="),"+/","-_");}static
function
bytes($v){if(PHP_VERSION_ID>=70000)return
random_bytes($v);$I=self::tryAlternatives($v);if($I!==false)return$I;$I=self::lastResortRandom($v);if($I!==false)return$I;throw
new
Exception("Error generating random bytes");}private
static
function
tryAlternatives($v){if(extension_loaded("libsodium"))return
\Sodium\randombytes_buf($v);$em=DIRECTORY_SEPARATOR==="/";if($em){$I=self::readDevUrandom($v);if($I!==false)return$I;}$jb=$em&&PHP_VERSION_ID>50609&&PHP_VERSION_ID<50613;if(extension_loaded("mcrypt")&&!$jb){$I=mcrypt_create_iv($v,MCRYPT_DEV_URANDOM);if($I!==false)return$I;}$kb=PHP_VERSION_ID<50444||(PHP_VERSION_ID>50500&&PHP_VERSION_ID<50528)||(PHP_VERSION_ID>50600&&PHP_VERSION_ID<50612);if(extension_loaded("openssl")&&!$kb){$I=openssl_random_pseudo_bytes($v,$Lk);if($Lk)return$I;}return
false;}private
static
function
readDevUrandom($v){static$m=null;if($m===null)$m=@fopen("/dev/urandom","rb");if(!$m)return
false;$lj=$v;$I="";do{$f=fread($m,$lj);if($f===false)return
false;$lj-=strlen($f);$I
.=$f;}while($lj>0);return$I;}private
static
function
readCapicom($v){$Qb=new
\COM("CAPICOM.Utilities.1");$lj=$v;$I="";do{$f=base64_decode((string)$Qb->GetRandom($v,0));$lj-=strlen($f);$I
.=$f;}while($lj>0);return$I;}private
static
function
lastResortRandom($v){static$u=null;static$Ej=null;if($u===null){$f=$_SERVER;$f[]=uniqid("",true);shuffle($f);$u=sha1(serialize($f),true);if(extension_loaded("openssl"))$Ej=openssl_random_pseudo_bytes(20);else{$Ej="";for($p=0;$p<20;$p++)$Ej
.=chr((mt_rand()^mt_rand())%256);}}else{if((ord($u)%2===0)===(ord($Ej)%2===0))$u=Hash::hmacSha1($u,$Ej);else$Ej=Hash::hmacSha1($Ej,$u);}return
Hash::hkdf($v,$u,"$v",$Ej);}}if(!function_exists("str_starts_with")){function
str_starts_with($Ue,$dh){return
strpos($Ue,$dh)===0;}}if(!function_exists("str_contains")){function
str_contains($Ue,$dh){return
strpos($Ue,$dh)!==false;}}if(!function_exists("password_verify")){function
password_verify($E,$Te){return
false;}}function
version(){return
VERSION;}function
idf_unescape($r){if(!preg_match('~^[`\'"[]~',$r))return$r;$ag=substr($r,-1);return
str_replace($ag.$ag,$ag,substr($r,1,-1));}function
q($Q){return
Connection::get()->quote($Q);}function
escape_string($X){return
substr(q($X),1,-1);}function
number($X){return
preg_replace('~[^0-9]+~','',$X);}function
number_type(){return'((?<!o)int(?!er)|numeric|real|float|double|decimal|money)';}function
remove_slashes($Oi,$de=false){if(function_exists("get_magic_quotes_gpc")&&get_magic_quotes_gpc()){while(list($u,$X)=each($Oi)){foreach($X
as$Nf=>$W){unset($Oi[$u][$Nf]);if(is_array($W)){$Oi[$u][stripslashes($Nf)]=$W;$Oi[]=&$Oi[$u][stripslashes($Nf)];}else$Oi[$u][stripslashes($Nf)]=($de?$W:stripslashes($W));}}}}function
bracket_escape($r,$Xa=false){static$Ll=[':'=>':1',']'=>':2','['=>':3','"'=>':4'];return
strtr($r,($Xa?array_flip($Ll):$Ll));}function
min_version($ym,$wg=null,$e=null){if(!$e)$e=Connection::get();if($wg&&$e->isMariaDB())$ym=$wg;return$ym&&$e->isMinVersion($ym);}function
charset(Connection$e){return($e->isMinVersion("5.5.3")?"utf8mb4":"utf8");}function
link_files($_,array$ce){switch($_){case'favicon-green.ico':$n='favicon-green-4879473edf8cf0c5271258cb83c126a3__42f453c4.ico';break;case'favicon-green.svg':$n='favicon-green-e540567d773d5a9d5985afbc3de34470__42f453c4.svg';break;case'apple-touch-icon-green.png':$n='apple-touch-icon-green-197f8b4c231bd61bda7a4ba2dac7a59c__42f453c4.png';break;case'logo.svg':$n='logo-bd8f391da3214e5700c2b5d4d63d4710__42f453c4.svg';break;case'jush.css':$n='jush-ee1a1cdeba50e879f7931d7ebd3189d2__07ffbd7d.css';break;case'jush-dark.css':$n='jush-dark-27969342aa18782fe57a825eccd6c044__42f453c4.css';break;case'jush.js':$n='jush-3ddc126093108160f2d571c019b41c0f__8fc54b9d.js';break;case'icons.svg':$n='icons-4894aa2ebb2d7b096ab8b3fe2f922676__42f453c4.svg';break;case'default-green.css':$n='default-green-ede663d7f088590df526dad0046fbfcf__693837c9.css';break;case'default-green-dark.css':$n='default-green-dark-6f277ac6d38bf82da275ff1e9bf26018__07ffbd7d.css';break;case'main.js':$n='main-d2ae9fdfbf41846c5ec920f713a91abd__07ffbd7d.js';break;default:$n=null;break;}if(!$n)return
null;return
BASE_URL."?file=".urldecode($n);}function
ini_bool($Ih){$X=ini_get($Ih);return
preg_match('~^(on|true|yes)$~i',$X)||(int)$X;}function
sid(){static$J;if($J===null)$J=(session_id()&&!($_COOKIE&&ini_bool("session.use_cookies")));return$J;}function
save_driver_name($Yc,$O,$_){restart_session();$_SESSION["drivers"][$Yc][$O]=$_;stop_session();}function
get_driver_name($Yc,$O=null){return
isset($_SESSION["drivers"][$Yc][$O])?$_SESSION["drivers"][$Yc][$O]:Drivers::get($Yc);}function
set_password($xm,$O,$V,$E){$_SESSION["pwds"][$xm][$O][$V]=($_COOKIE["neo_key"]&&is_string($E)?[encrypt_string($E,$_COOKIE["neo_key"])]:$E);}function
get_password(){$J=get_session("pwds");if(is_array($J))$J=($_COOKIE["neo_key"]?decrypt_string($J[0],$_COOKIE["neo_key"]):false);return$J;}function
get_vals($G,$c=0){$J=[];$I=Connection::get()->query($G);if(is_object($I)){while($K=$I->fetchRow())$J[]=$K[$c];}return$J;}function
get_key_vals($G,$e=null,$jk=true){if(!$e)$e=Connection::get();$J=[];$I=$e->query($G);if(is_object($I)){while($K=$I->fetchRow()){if($jk)$J[$K[0]]=$K[1];else$J[]=$K[0];}}return$J;}function
get_rows($G,$e=null,$j="<p class='error'>"){if(!$e)$e=Connection::get();$J=[];$I=$e->query($G);if(is_object($I)){while($K=$I->fetchAssoc())$J[]=$K;}elseif(!$I&&!is_object($e)&&$j&&(defined("AdminNeo\PAGE_HEADER")||$j=="-- "))echo$j.error()."\n";return$J;}function
unique_array($K,$t){foreach($t
as$s){if(preg_match("~PRIMARY|UNIQUE~",$s["type"])){$J=[];foreach($s["columns"]as$u){if(!isset($K[$u]))continue
2;$J[$u]=$K[$u];}return$J;}}}function
escape_key($u){if(preg_match('(^([\w(]+)('.str_replace("_",".*",preg_quote(idf_escape("_"))).')([ \w)]+)$)',$u,$y))return$y[1].idf_escape(idf_unescape($y[2])).$y[3];return
idf_escape($u);}function
where($Z,$l=[]){$bc=[];foreach((array)$Z["where"]as$u=>$X){$u=bracket_escape($u,1);$c=escape_key($u);$Zd=isset($l[$u]["type"])?$l[$u]["type"]:null;if(DIALECT=="sql"&&$Zd=="json")$bc[]="$c = CAST(".q($X)." AS JSON)";elseif(DIALECT=="sql"&&is_numeric($X)&&strpos($X,".")!==false)$bc[]="$c LIKE ".q($X);elseif(DIALECT=="mssql"&&strpos($Zd,"datetime")===false)$bc[]="$c LIKE ".q(preg_replace('~[_%[]~','[\0]',$X));else$bc[]="$c = ".(isset($l[$u])?unconvert_field($l[$u],q($X)):q($X));if(DIALECT=="sql"&&preg_match('~char|text~',$Zd)&&preg_match("~[^ -@]~",$X))$bc[]="$c = ".q($X)." COLLATE ".charset(Connection::get())."_bin";}foreach((array)$Z["null"]as$u)$bc[]=escape_key($u)." IS NULL";return
implode(" AND ",$bc);}function
where_check($X,$l=[]){parse_str($X,$vb);remove_slashes([&$vb]);return
where($vb,$l);}function
where_link($p,$c,$Y,$Fh="="){return"&where%5B$p%5D%5Bcol%5D=".urlencode($c)."&where%5B$p%5D%5Bop%5D=".urlencode(($Y!==null?$Fh:"IS NULL"))."&where%5B$p%5D%5Bval%5D=".urlencode($Y);}function
convert_fields($d,$l,$M=[]){$J="";foreach($d
as$u=>$X){if($M&&!in_array(idf_escape($u),$M))continue;$Na=convert_field($l[$u]);if($Na)$J
.=", $Na AS ".idf_escape($u);}return$J;}function
cookie($_,$Y,$ig=2592000){header("Set-Cookie: $_=".rawurlencode($Y).($ig?"; expires=".gmdate("D, d M Y H:i:s",time()+$ig)." GMT":"")."; path=".preg_replace('~\?.*~','',$_SERVER["REQUEST_URI"]).(HTTPS?"; secure":"")."; HttpOnly; SameSite=lax",false);}function
get_settings($oc="neo_settings"){parse_str(isset($_COOKIE[$oc])?$_COOKIE[$oc]:"",$P);return$P;}function
get_setting($u,$oc="neo_settings"){$P=get_settings($oc);return
isset($P[$u])?$P[$u]:null;}function
save_settings(array$P,$oc="neo_settings"){cookie($oc,http_build_query($P+get_settings($oc)));}function
restart_session(){if(!ini_bool("session.use_cookies")&&session_status()==PHP_SESSION_NONE)session_start();}function
stop_session($ne=false){$om=ini_bool("session.use_cookies");if(!$om||$ne){session_write_close();if($om&&@ini_set("session.use_cookies",false)===false)session_start();}}function&get_session($u){return$_SESSION[$u][DRIVER][SERVER][$_GET["username"]];}function
set_session($u,$X){$_SESSION[$u][DRIVER][SERVER][$_GET["username"]]=$X;}function
auth_url($xm,$O,$V,$h=null){$jm=remove_from_uri(implode("|",array_keys(Drivers::getList()))."|username|ext|".($h!==null?"db|":"").($xm=='mssql'||$xm=='pgsql'?"":"ns|").session_name());preg_match('~([^?]*)\??(.*)~',$jm,$y);return"$y[1]?".(sid()?session_name()."=".urlencode(session_id())."&":"").urlencode($xm)."=".urlencode($O)."&".($_GET["ext"]?"ext=".urlencode($_GET["ext"])."&":"")."username=".urlencode($V).($h!=""?"&db=".urlencode($h):"").($y[2]?"&$y[2]":"");}function
is_ajax(){return($_SERVER["HTTP_X_REQUESTED_WITH"]=="XMLHttpRequest");}function
redirect($qg,$Jg=null){if($Jg!==null){restart_session();$_SESSION["messages"][preg_replace('~^[^?]*~','',($qg!==null?$qg:$_SERVER["REQUEST_URI"]))][]=$Jg;}if($qg!==null){if($qg=="")$qg=".";header("Location: $qg");exit;}}function
query_redirect($G,$qg,$Jg,$cj=true,$Fd=true,$Sd=false,$_l=""){if($Fd){$Fk=microtime(true);$Sd=!Connection::get()->query($G);$_l=format_time($Fk);}$zk=$G?Admin::get()->formatMessageQuery($G,$_l,$Sd):"";if($Sd){Admin::get()->addError(error().$zk.script("initToggles();"));return
false;}if($cj)redirect($qg,$Jg.$zk);return
true;}function
queries($G){static$Ti=[];static$Fk;if(!$Fk)$Fk=microtime(true);if($G===null)return[implode("\n",$Ti),format_time($Fk)];if(support("sql")){$Ti[]=(preg_match('~;$~',$G)?"DELIMITER ;;\n$G;\nDELIMITER ":$G).";";return
Connection::get()->query($G);}else{$Ti[]=$G;return[];}}function
apply_queries($G,$T,$_d='AdminNeo\table'){foreach($T
as$R){if(!queries("$G ".$_d($R)))return
false;}return
true;}function
queries_redirect($qg,$Jg,$cj){list($Ti,$_l)=queries(null);return
query_redirect($Ti,$qg,$Jg,$cj,false,!$cj,$_l);}function
format_time($Fk){return
lang(96,max(0,microtime(true)-$Fk));}function
relative_uri(){return
str_replace(":","%3a",preg_replace('~^[^?]*/([^?]*)~','\1',$_SERVER["REQUEST_URI"]));}function
remove_from_uri($di=""){return
substr(preg_replace("~(?<=[?&])($di".(sid()?"":"|".session_name()).")=[^&]*&~",'',relative_uri()."&"),0,-1);}function
get_file($u,$Gc=false,$Nc=""){$m=$_FILES[$u];if(!$m)return
null;foreach($m
as$u=>$X)$m[$u]=(array)$X;$J='';foreach($m["error"]as$u=>$j){if($j)return$j;$_=$m["name"][$u];$Gl=$m["tmp_name"][$u];$kc=file_get_contents($Gc&&preg_match('~\.gz$~',$_)?"compress.zlib://$Gl":$Gl);if($Gc){$Fk=substr($kc,0,3);if(function_exists("iconv")&&preg_match("~^\xFE\xFF|^\xFF\xFE~",$Fk))$kc=iconv("utf-16","utf-8",$kc);elseif($Fk=="\xEF\xBB\xBF")$kc=substr($kc,3);}if($Nc){if(!preg_match("~$Nc\\s*\$~",$kc))$kc
.=";";$kc
.="\n\n";}$J
.=$kc;}return$J;}function
upload_error($j){$Dg=($j==UPLOAD_ERR_INI_SIZE?ini_get("upload_max_filesize"):0);return($j?lang(97).($Dg?" ".lang(98,$Dg):""):lang(99));}function
repeat_pattern($si,$v){return
str_repeat("$si{0,65535}",$v/65535)."$si{0,".($v%65535)."}";}function
is_utf8($X){return(preg_match('~~u',$X)&&!preg_match('~[\0-\x8\xB\xC\xE-\x1F]~',$X));}function
truncate_utf8($Q,$v=80){if($Q=="")return"";if(!preg_match("(^(".repeat_pattern("[\t\r\n -\x{10FFFF}]",$v).")($)?)u",$Q,$y))preg_match("(^(".repeat_pattern("[\t\r\n -~]",$v).")($)?)",$Q,$y);return
h($y[1]).(isset($y[2])?"":"<i>…</i>");}function
format_number($X){return
strtr(number_format($X,0,".",lang(100)),preg_split('~~u',lang(101),-1,PREG_SPLIT_NO_EMPTY));}function
friendly_url($X){return
preg_replace('~\W~i','-',$X);}function
table_status1($R,$Td=false){$J=table_status($R,$Td);return($J?:["Name"=>$R]);}function
column_foreign_keys($R){$J=[];foreach(Admin::get()->getForeignKeys($R)as$o){foreach($o["source"]as$X)$J[$X][]=$o;}return$J;}function
fields_from_edit(){$J=[];foreach((array)$_POST["field_keys"]as$u=>$X){if($X!=""){$X=bracket_escape($X);$_POST["function"][$X]=$_POST["field_funs"][$u];$_POST["fields"][$X]=$_POST["field_vals"][$u];}}foreach((array)$_POST["fields"]as$u=>$X){$_=bracket_escape($u,1);$J[$_]=["field"=>$_,"privileges"=>["insert"=>1,"update"=>1,"where"=>1,"order"=>1],"null"=>1,"auto_increment"=>($u==Driver::get()->primary),];}return$J;}function
dump_headers($gf,$Wg=false){$gf=friendly_url($gf).date("-Ymd-His");$Od=Admin::get()->sendDumpHeaders($gf,$Wg);$Yh=$_POST["output"];if($Yh!="text")header("Content-Disposition: attachment; filename=$gf.$Od".($Yh!="file"&&preg_match('~^[0-9a-z]+$~',$Yh)?".$Yh":""));session_write_close();if(!ob_get_level())ob_start(null,4096);ob_flush();flush();return$Od;}function
dump_csv($K){foreach($K
as$u=>$X){if(preg_match('~["\n,;\t]|^0|\.\d*0$~',$X)||$X==="")$K[$u]='"'.str_replace('"','""',$X).'"';}echo
implode(($_POST["format"]=="csv"?",":($_POST["format"]=="tsv"?"\t":";")),$K)."\r\n";}function
apply_sql_function($ze,$c){return($ze?($ze=="unixepoch"?"DATETIME($c, '$ze')":($ze=="count distinct"?"COUNT(DISTINCT ":strtoupper("$ze("))."$c)"):$c);}function
get_temp_dir(){$qi=ini_get("upload_tmp_dir");if(!$qi)$qi=sys_get_temp_dir();return$qi;}function
open_file_with_lock($n){if(is_link($n))return
null;$m=fopen($n,"c+");if(!$m)return
null;chmod($n,0660);if(!flock($m,LOCK_EX)){fclose($m);return
null;}return$m;}function
write_and_unlock_file($m,$f){rewind($m);fwrite($m,$f);ftruncate($m,strlen($f));unlock_file($m);}function
unlock_file($m){flock($m,LOCK_UN);fclose($m);}function
first(array$Ma){return
reset($Ma);}function
get_private_key($rc){$n=get_temp_dir()."/adminneo.key";if(!$rc&&!file_exists($n))return
false;$m=open_file_with_lock($n);if(!$m)return
false;$u=stream_get_contents($m);if(!$u){$u=Random::strongKey();write_and_unlock_file($m,$u);}else
unlock_file($m);return$u;}function
get_random_string(){return
Random::strongKey();}function
select_value($X,$x,$k,$wl){if(is_array($X)){$J="";foreach($X
as$Nf=>$W)$J
.="<tr>".($X!=array_values($X)?"<th>".h($Nf):"")."<td>".select_value($W,$x,$k,$wl);return"<table>$J</table>";}if(!$x)$x=Admin::get()->getFieldValueLink($X,$k);$J=$k?Admin::get()->formatFieldValue($X,$k):$X;if($J!==null){if(!is_utf8($J))$J="\0";elseif($wl!=""&&is_shortable($k))$J=truncate_utf8($J,max(0,+$wl));else$J=h($J);}return
Admin::get()->formatSelectionValue($J,$x,$k,$X);}function
is_mail($Y){return
is_string($Y)&&filter_var($Y,FILTER_VALIDATE_EMAIL);}function
is_web_url($Y){if(!is_string($Y)||!preg_match('~^https?://~i',$Y))return
false;$Yb=parse_url($Y);if(!$Yb)return
false;$rd=array_map('urlencode',explode('/',$Yb['path']));$km=str_replace($Yb['path'],implode('/',$rd),$Y);parse_str($Yb['query'],$D);$km=str_replace($Yb['query'],http_build_query($D),$km);return(bool)filter_var($km,FILTER_VALIDATE_URL);}function
is_shortable($k){return$k?preg_match('~char|text|json|lob|geometry|point|linestring|polygon|string|bytea~',$k["type"]):false;}function
count_rows($R,$Z,$Df,$He){$G=" FROM ".table($R).($Z?" WHERE ".implode(" AND ",$Z):"");return($Df&&(DIALECT=="sql"||count($He)==1)?"SELECT COUNT(DISTINCT ".implode(", ",$He).")$G":"SELECT COUNT(*)".($Df?" FROM (SELECT 1$G GROUP BY ".implode(", ",$He).") x":$G));}function
slow_query($G){$h=Admin::get()->getDatabase();$Al=Admin::get()->getQueryTimeout();$rk=Driver::get()->slowQuery($G,$Al);if(!$rk&&support("kill")&&($e=connect())&&($h==""||$e->selectDatabase($h))){$Uf=$e->getValue(connection_id());echo'<script',nonce(),'>
	const timeout = setTimeout(() => {
		ajax(\'',js_escape(ME),'script=kill\', function() {
		}, \'kill=',$Uf,'&token=',get_token(),'\');
	}, ',1000*$Al,');
</script>
';}else$e=null;ob_flush();flush();$J=@get_key_vals(($rk?:$G),$e,false);if($e){echo
script("clearTimeout(timeout);");ob_flush();flush();}return$J;}function
get_token(){$Zi=rand(1,1e6);return($Zi^$_SESSION["token"]).":$Zi";}function
verify_token(){list($Hl,$Zi)=explode(":",$_POST["token"]);return($Zi^$_SESSION["token"])==$Hl;}function
lzw_decompress($cb){$Rc=256;$db=8;$Gb=[];$rj=0;$sj=0;for($p=0;$p<strlen($cb);$p++){$rj=($rj<<8)+ord($cb[$p]);$sj+=8;if($sj>=$db){$sj-=$db;$Gb[]=$rj>>$sj;$rj&=(1<<$sj)-1;$Rc++;if($Rc>>$db)$db++;}}$Qc=range("\0","\xFF");$J=$Qm="";foreach($Gb
as$p=>$Fb){$od=$Qc[$Fb];if(!isset($od))$od=$Qm.$Qm[0];$J
.=$od;if($p)$Qc[]=$Qm.$od[0];$Qm=$od;}return$J;}function
script($vk,$Kl="\n"){return"<script".nonce().">$vk</script>$Kl";}function
script_src($km,$Jc=false){return"<script src='".h($km)."'".nonce().($Jc?" defer":"")."></script>\n";}function
nonce(){return' nonce="'.get_nonce().'"';}function
input_hidden($_,$Y=""){return"<input type='hidden' name='".h($_)."' value='".h($Y)."'>";}function
input_token(){return
input_hidden("token",get_token());}function
target_blank(){return' target="_blank" rel="noreferrer noopener"';}function
h($Q){return$Q!==null&&$Q!==""?str_replace("\0","&#0;",htmlspecialchars($Q,ENT_QUOTES,'utf-8')):"";}function
icon_solo($q){return
icon($q,"solo");}function
icon_chevron_down(){return
icon("chevron-down","chevron");}function
icon_chevron_right(){return
icon("chevron-down","chevron-right");}function
icon($q,$Eb=null){$q=h($q);return"<svg class='icon ic-$q $Eb'><use href='".link_files("icons.svg",[])."#$q'/></svg>";}function
checkbox($_,$Y,$zb,$Wf="",$Ch="",$Eb="",$Xf=""){$J="<input type='checkbox' name='$_' value='".h($Y)."'".($zb?" checked":"").($Xf?" aria-labelledby='$Xf'":"").">".($Ch?script("qsl('input').onclick = function () { $Ch };",""):"");return($Wf!=""||$Eb?"<label".($Eb?" class='$Eb'":"").">$J".h($Wf)."</label>":$J);}function
optionlist($B,$Pj=null,$pm=false){$J="";foreach($B
as$Nf=>$W){$Kh=[$Nf=>$W];if(is_array($W)){$J
.='<optgroup label="'.h($Nf).'">';$Kh=$W;}foreach($Kh
as$u=>$X)$J
.='<option'.($pm||is_string($u)?' value="'.h($u).'"':'').($Pj!==null&&($pm||is_string($u)?(string)$u:$X)===$Pj?' selected':'').'>'.h($X);if(is_array($W))$J
.='</optgroup>';}return$J;}function
html_select($_,$B,$Y="",$Bh="",$Xf="",$pm=false){return"<select name='".h($_)."'".($Xf?" aria-labelledby='$Xf'":"").">".optionlist($B,$Y,$pm)."</select>".($Bh?script("qsl('select').onchange = function () { $Bh };",""):"");}function
html_radios($_,$B,$Y=""){$I="<span class='labels'>";foreach($B
as$u=>$X)$I
.="<label><input type='radio' name='".h($_)."' value='".h($u)."'".($u==$Y?" checked":"").">".h($X)."</label>";$I
.="</span>";return$I;}function
confirm($Jg="",$Rj="qsl('input')"){return
script("$Rj.onclick = () => confirm('".($Jg?js_escape($Jg):lang(102))."');","");}function
print_fieldset_start($q,$gg,$ff,$Cm=false,$uk=false){echo"<fieldset id='fieldset-$q' class='closable ".(!$Cm?" closed":"")."'>","<legend><a href='#'>$gg</a></legend>",icon($ff,"fieldset-icon jsonly"),"<div class='fieldset-content".($uk?" sortable":"")."'>";}function
print_fieldset_end($q,$uk=false){echo"</div>",script("initFieldset('$q');","");if($uk)echo
script("initSortable('#fieldset-$q .fieldset-content');","");echo"</fieldset>\n";}function
bold($gb,$Eb=""){return($gb?" class='$Eb active'":($Eb?" class='$Eb'":""));}function
js_escape($Q){return
addcslashes($Q,"\r\n'\\/");}function
pagination($C,$wc){return"<li>".($C==$wc?"<strong>".($C+1)."</strong>":'<a href="'.h(remove_from_uri("page").($C?"&page=$C".($_GET["next"]?"&next=".urlencode($_GET["next"]):""):"")).'">'.($C+1)."</a>")."</li>";}function
print_hidden_fields(array$Oi,array$kf=[],$Fi=""){$I=false;foreach($Oi
as$u=>$X){if(!in_array($u,$kf)){if(is_array($X))print_hidden_fields($X,[],$u);else{$I=true;echo
input_hidden($Fi?$Fi."[$u]":$u,$X);}}}return$I;}function
hidden_fields_get(){if(sid())echo
input_hidden(session_name(),session_id());if(SERVER!==null)echo
input_hidden(DRIVER,SERVER);echo
input_hidden("username",$_GET["username"]);}function
enum_input($Pa,array$k,$Y,$pd=null,$yb=false){preg_match_all("~'((?:[^']|'')*)'~",$k["length"],$z);$vm=$z[1];$zl=Admin::get()->getSettings()->getEnumAsSelectThreshold();$M=!$yb&&$zl!==null&&count($vm)>$zl;$U=$yb?"checkbox":"radio";$ua=$M?"selected":"checked";$I=$M?"<select $Pa>":"<span class='labels'>";if($M&&$k["null"]&&$pd!==""){$zb=$Y===null?$ua:"";$I
.="<option value='__adminneo_empty__' disabled $zb></option>";}if($pd!==null){$zb=(is_array($Y)?in_array($pd,$Y):$Y===$pd)?$ua:"";if($M)$I
.="<option value='$pd' $zb>".lang(103)."</option>";else$I
.="<label><input type='$U' $Pa value='$pd' $zb><i>".lang(103)."</i></label>";}foreach($vm
as$X){if($pd===""&&$X==="")continue;$X=stripcslashes(str_replace("''","'",$X));$zb=is_array($Y)?in_array($X,$Y):$Y===$X;$zb=$zb?$ua:"";$te=$X===""?("<i>".lang(103)."</i>"):h(Admin::get()->formatFieldValue($X,$k));if($M)$I
.="<option value='".h($X)."' $zb>$te</option>";else$I
.=" <label><input type='$U' $Pa value='".h($X)."' $zb>$te</label>";}$I
.=$M?"</select>":"</span>";return$I;}function
input($k,$Y,$ze,$Va=false){$_=h(bracket_escape($k["field"]));$Zl=Driver::get()->getTypes();$Mf=isset($k["type"])&&Admin::get()->detectJson($k["type"],$Y,true);$oj=(DIALECT=="mssql"&&$k["auto_increment"]);if($oj&&!$_POST["save"])$ze=null;if(in_array($k["type"],Driver::get()->getUserTypes())){$xd=type_values($Zl[$k["type"]]);if($xd){$k["type"]="enum";$k["length"]=$xd;}}$Uc=stripos($k["default"],"GENERATED ALWAYS AS ")===0?" disabled=''":"";$Pa=" name='fields[$_]' $Uc".($Va?" autofocus":"");$_e=(isset($_GET["select"])||$oj?["orig"=>lang(104)]:[])+Admin::get()->getFieldFunctions($k);$Re=(in_array($ze,$_e)||isset($_e[$ze]));echo"<td class='function'>",Driver::get()->getUnconvertFunction($k)." ";if(count($_e)>1){$Pj=$ze===null||$Re?$ze:"";echo"<select name='function[$_]' $Uc>".optionlist($_e,$Pj)."</select>",help_script_command("value.replace(/^SQL\$/, '')",true),script("qsl('select').onchange = functionChange;","");}else
echo
h(reset($_e));echo"</td><td>";$uf=Admin::get()->getFieldInput(isset($_GET["edit"])?$_GET["edit"]:null,$k,$Pa,$Y,$ze);if($uf!="")echo$uf;elseif(preg_match('~bool~',$k["type"]))echo"<input type='hidden'$Pa value='0'>"."<input type='checkbox'".(preg_match('~^(1|t|true|y|yes|on)$~i',$Y)?" checked='checked'":"")."$Pa value='1'>";elseif($k["type"]=="enum")echo
enum_input($Pa,$k,$Y);elseif($k["type"]=="set"){preg_match_all("~'((?:[^']|'')*)'~",$k["length"],$z);echo"<span class='labels'>";foreach($z[1]as$X){$X=stripcslashes(str_replace("''","'",$X));$zb=$Y!==null&&in_array($X,explode(",",$Y),true);$zb=$zb?"checked":"";$te=$X===""?("<i>".lang(103)."</i>"):h(Admin::get()->formatFieldValue($X,$k));echo" <label><input type='checkbox' name='fields[$_][]' value='".h($X)."' $zb>$te</label>";}echo"</span>";}elseif(preg_match('~blob|bytea|raw|file~',$k["type"])&&ini_bool("file_uploads"))echo"<input type='file' name='fields-$_'>";elseif($Mf)echo"<textarea$Pa cols='50' rows='12' class='jush-js'>".h($Y).'</textarea>';elseif(($tl=preg_match('~text|lob|memo~i',$k["type"]))||preg_match("~\n~",$Y)){if($tl&&DIALECT!="sqlite")$Pa
.=" cols='50' rows='12'";else{$L=min(12,substr_count($Y,"\n")+1);$Pa
.=" cols='30' rows='$L'";}echo"<textarea$Pa>".h($Y).'</textarea>';}else{$Fg=!preg_match('~int~',$k["type"])&&preg_match('~^(\d+)(,(\d+))?$~',$k["length"],$y)?((preg_match("~binary~",$k["type"])?2:1)*$y[1]+($y[3]?1:0)+($y[2]&&!$k["unsigned"]?1:0)):($Zl&&$Zl[$k["type"]]?$Zl[$k["type"]]+($k["unsigned"]?0:1):0);if(DIALECT=='sql'&&Connection::get()->isMinVersion("5.6")&&preg_match('~time~',$k["type"]))$Fg+=7;echo"<input class='input'".((!$Re||$ze==="")&&preg_match('~(?<!o)int(?!er)~',$k["type"])&&!preg_match('~\[\]~',$k["full_type"])?" type='number'":"").($ze!="now"?" value='".h($Y)."'":" data-last-value='".h($Y)."'").($Fg?" data-maxlength='$Fg'":"").(preg_match('~char|binary~',$k["type"])&&$Fg>20?" size='44'":"")."$Pa>";}$We=Admin::get()->getFieldInputHint($_GET["edit"],$k,$Y);if($We!="")echo" <span class='input-hint'>$We</span>";$ge=0;foreach($_e
as$u=>$X){if($u===""||!$X)break;$ge++;}if(count($_e)>1)echo
script("qsl('td').oninput = partial(skipOriginal, $ge);");}function
process_input($k){if(stripos($k["default"],"GENERATED ALWAYS AS ")===0)return
null;$r=bracket_escape($k["field"]);$ze=isset($_POST["function"][$r])?$_POST["function"][$r]:"";$Y=isset($_POST["fields"][$r])?$_POST["fields"][$r]:"";if($k["auto_increment"]&&$Y=="")return
null;if($ze=="orig")return(preg_match('~^CURRENT_TIMESTAMP~i',$k["on_update"])?idf_escape($k["field"]):false);if($ze=="NULL")return"NULL";if($k["type"]=="set")$Y=implode(",",(array)$Y);if($ze=="json"){$Y=json_decode($Y,true);if(!is_array($Y))return
false;return$Y;}if(preg_match('~blob|bytea|raw|file~',$k["type"])&&ini_bool("file_uploads")){$m=get_file("fields-$r");if(!is_string($m))return
false;return
Driver::get()->quoteBinary($m);}return
Admin::get()->processFieldInput($k,$Y,$ze);}function
search_tables(){$_GET["where"][0]["val"]=$_POST["query"];$tj=$zd=[];foreach(table_status("",true)as$R=>$S){$fl=Admin::get()->getTableName($S);if(!isset($S["Engine"])||$fl==""||($_POST["tables"]&&!in_array($R,$_POST["tables"])))continue;$I=Connection::get()->query("SELECT".limit("1 FROM ".table($R)," WHERE ".implode(" AND ",Admin::get()->processSelectionSearch(fields($R),[])),1));if($I&&!$I->fetchRow())continue;$x=h(ME."select=".urlencode($R)."&where[0][op]=".urlencode($_GET["where"][0]["op"])."&where[0][val]=".urlencode($_GET["where"][0]["val"]));if($I)$tj[]="<li><a href='$x'>".icon("search")."$fl</a></li>";else$zd[]="<div class='error'><a href='$x'>$fl</a>: ".error()."</div>";}if($tj)echo"<ul class='links'>\n",implode("\n",$tj),"</ul>\n";if($zd)echo
implode("\n",$zd),"\n";if(!$tj&&!$zd)echo"<p class='message'>".lang(75)."</p>\n";}function
help_script($tl,$nk=false){return
script("initHelpFor(qsl('select, input'), '".h($tl)."', $nk);","");}function
help_script_command($Rb,$nk=false){return
script("initHelpFor(qsl('select, input'), (value) => { return $Rb; }, $nk);","");}function
edit_form($R,$l,$K,$im){$fl=Admin::get()->getTableName(table_status1($R,true));$Cl=$im?lang(37):lang(105);page_header("$Cl: $fl",["select"=>[$R,$fl],$Cl]);if($K===false){echo"<p class='error'>".lang(85)."\n";return;}echo"<form action='' method='post' enctype='multipart/form-data' id='form'>\n";if(!$l)echo"<p class='error'>".lang(106)."\n";else{echo"<table class='box'>".script("qsl('table').onkeydown = onEditingKeydown;");$Va=!$_POST;foreach($l
as$_=>$k){echo"<tr><th>".Admin::get()->getFieldName($k);$u=bracket_escape($_);$i=isset($_GET["set"][$u])?$_GET["set"][$u]:null;if($i===null){$i=$k["default"];if($k["type"]=="bit"&&preg_match("~^b'([01]*)'\$~",$i,$jj))$i=$jj[1];if(DIALECT=="sql"&&preg_match('~binary~',$k["type"]))$i=bin2hex($i);}$Y=($K!==null?($K[$_]!=""&&DIALECT=="sql"&&preg_match("~enum|set~",$k["type"])&&is_array($K[$_])?implode(",",$K[$_]):(is_bool($K[$_])?+$K[$_]:$K[$_])):(!$im&&$k["auto_increment"]?"":(isset($_GET["select"])?false:$i)));if(!$_POST["save"]&&is_string($Y))$Y=Admin::get()->formatFieldValue($Y,$k);$ze=($_POST["save"]?isset($_POST["function"][$_])?$_POST["function"][$_]:"":($im&&preg_match('~^CURRENT_TIMESTAMP~i',$k["on_update"])?"now":($Y===false?null:($Y!==null?'':'NULL'))));if(!$_POST&&!$im&&$Y==$k["default"]&&preg_match('~^[\w.]+\(~',$Y))$ze="SQL";if(preg_match("~time~",$k["type"])&&preg_match('~^CURRENT_TIMESTAMP~i',$Y)){$Y="";$ze="now";}if($k["type"]=="uuid"&&$Y=="uuid()"){$Y="";$ze="uuid";}if($Va!==false)$Va=($k["auto_increment"]||$ze=="now"||$ze=="uuid"?null:true);input($k,$Y,$ze,$Va);if($Va)$Va=false;echo"\n";}if(!support("table")&&!fields($R))echo"<tr>"."<th><input class='input' name='field_keys[]'>".script("qsl('input').oninput = fieldChange;")."<td class='function'>".html_select("field_funs[]",Admin::get()->getFieldFunctions(["null"=>isset($_GET["select"])]))."<td><input class='input' name='field_vals[]'>"."\n";echo"</table>\n",script("initToggles(gid('form'));");}echo"<p>";if($l){echo"<input type='submit' class='button default' value='".lang(107)."'>\n";if(!isset($_GET["select"]))echo"<input type='submit' class='button' name='insert' value='".($im?lang(108):lang(109))."' title='Ctrl+Shift+Enter'>\n",($im?script("qsl('input').onclick = function () { return !ajaxForm(this.form, '".lang(110)."…', this); };"):"");}echo($im?"<input type='submit' class='button' name='delete' value='".lang(111)."'>".confirm()."\n":"");if(isset($_GET["select"]))print_hidden_fields(["check"=>(array)$_POST["check"],"clone"=>$_POST["clone"],"all"=>$_POST["all"]]);echo
input_hidden("referer",isset($_POST["referer"])?$_POST["referer"]:$_SERVER["HTTP_REFERER"]),input_hidden("save","1"),input_token(),"</form>\n";}if(isset($_GET["file"]))load_compiled_file($_GET["file"]);function
load_compiled_file($n){if($n==""){http_response_code(404);exit;}if($_SERVER["HTTP_IF_MODIFIED_SINCE"]){http_response_code(304);exit;}header("Expires: ".gmdate("D, d M Y H:i:s",time()+365*24*60*60)." GMT");header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");header("Cache-Control: immutable");switch(pathinfo($n,PATHINFO_EXTENSION)){case"css":header("Content-Type: text/css; charset=utf-8");break;case"js":header("Content-Type: text/javascript; charset=utf-8");break;case"ico":header("Content-Type: image/x-icon");break;case"png":header("Content-Type: image/png");break;case"svg":header("Content-Type: image/svg+xml");break;}switch($n){case'favicon-green-4879473edf8cf0c5271258cb83c126a3__42f453c4.ico':$f='AAAAYCABAIIBAoMdwJAAtAAAiSgTiODQUGgVDgaSSQRClDoNABACANDjmej09IABB8SSIQSoWCOxSuTSYXCqFH87k6GT8CgIoykVAk3Vo1kqCxqLDq0SguxCMWqKAW3RQWk0GjGIhgsBAthoqRgPAaG2m0isu3SomqNBrT0UbHYkioFxcTAINi6UB2YGmaiCwDyc1e3z6P2Ge3g3k2eSaSHe5GCvDuzx25x233yuTOBA88gkD2yPjUA1AIXiRTGJ3Y9WG0DwiVA9wUySWoSa8SMSlYKEKZQQsRYoTeqBYfmAfWY4QIzDs4iUBjgEQaKDEmHMP1IqiOExqSXcGjmGS8ZXO5icFnw0mc4xo3W4jD2Nw8gEK5zAY00An2jCgxQqb4oCKUZsnqEhmE8LIgl+GY5FCLxUncZoeH8RABAiB4wA4b4pHeDZXFkDorFuOgMgaHRQB0JQqCka4QG8JgDjABgymueQ7AWIIamiawVAoTA2gGJx4hmdgCDOY5FDOMAWHIK4ZAWRwtFGb4sBmDJVlCQRcAaSBgnQQhHgOKBgB4L5tg+T5jjCMwRDyOQEEkWhWHMeoIAcUgxFAfwKEcNxzDgaxCCAaBRiUTABksbgOlmbhfi2AJsgiTQfAYMIVAqAAjmwZR6GEawLB6NBWk8M4vHIYYqH4JpGE+EBHleURGE2M4qg2KJxgyOhWH+SY+g+WBdhSfpBA+CQkj+Jo3GKVgviSZQaA8YI8g4YYpE4KAZAARZSHqMYWHoGRgjADpOhQUJOnsbYygydonBOZhQGQJwsCIVxXEQYxmA4RxWkORpHEmQYeGMaZCjAJg0DIOoAieMZCAqfgvkkC5Yj2b5Rg8X4xkoBo2kgdwiFkTosEMLx9BaWJhBYKQ9EyNQ3GuAhSEAE40FcQ4XHoNYimsRhKn4AYAAQDQJjcOpnnmb46mQdgmmwewOh8fAFjrXYpHyOIyHiDApnE8QXnmXozn6fBNHIOo1BEGoBgsPZbl6UokAQSxOAcSgxgICoKDCIopEcVw3jWMZ5gYIJdB8QBnhgIBpAUAxfDIUxCnmHooDWHhFmCBgGBeW4HlwM4JkWDA9EAABWDoJIcHqcQPG4fpCmaIZeHaWwri+UpJnuYwqneeRqGMDoMg0S48EgD5ynOb46AAPg0gWXpWECKJtD4WRLAICgyCIXZGH4RImDcAgBlKbATEobgDh8Y4tnYMIrg4UZDAAZYklcDxPEiV54FcIY1C0BgCUUA/QZhIHCSsLA4h+jPEo90GoJhVg/AiAUOobR5giFSAwJYLBfgjGYIQdISBni/CCDMSwWxPACDOC8Qw+QLCODGDUKQbgBDdDoOADQS1DnqEqHwDgSx7A8EKHMbA0w+ASA+K0Vw1AJCCEUMwa4aAxjXHwFQMw5QDhKFSFwdQRgSALFgJUSQGQTiHBKN0Cg+BHBfD+KQbQGReCLDQDAYw6AlDdBCEgfYVRQjVDWGwIQLQvAhEoNkRAUgZBQAgLMKA+hQQSAKJMLgSBgh4EWGUDQKRNCxESHkaIjhWDYGWAYaAwgGB0CUG8LYIxMAlAGF0dIQgYCRD2A8co0hCjgGSO4TggBODFE6AoRiuxQAJEEPADYUhDCVBoBAPoJBjjnGABQOQuBjgaGsIEMI0ghhTByIofI4xgD1BwCYXYGAdh2FiCsNAxQdjsfIHQBgGAJBZD8GIQQkxGCiAON4RQHQohDBiPIEQIA4BeAeKIR4LQdB2DgKgHQkAcB2BOOsXYsBYjZGeG8Q4whwiNEKDMYYlBZg4CePwKgrQ5GjHAGkNImhiDzDWBsPAnRlD3HmKAGQPwsD2DyKMbQIhPgtHkNkIQUwBr2D6Iwb4qgMgOBkFoVY7BXDIFKGIMANwID8AeGQEQXgYCHHWKIURDgABJCKE5eoQgwCCA=';break;case'favicon-green-e540567d773d5a9d5985afbc3de34470__42f453c4.svg':$f='PDmdjOIDwbTYbjmPREaDodDgOheLzvExcdxmLjecjOLxkMI8L4CZxEIDsaTKdyEbzxChgIJaMxkIJgIh8ChBNxBADoeTYZZrOKAICAbTKZDSYRAKDgcjKZjKcjmLTGbzZGRaczGaDLRB0IDIYTkaxSID3NqDZxcZzYeTgaLIIDMaTYbK6IzCOTINruOxAfbNZ79QB5IJ3PZ/OB4cDCdLcYzYYTnCRFarYaJGZIUbRkNRcNhgORBHRcNRiODGLRiLo6NdCLhiNxbnBhrIuNxrsBznc/MhdttgNNGNRxLhaOBcNBgNNRoxxuN0OBbtduLdUNRt1BoNRz1BmORl1BkMeULu6MhcMPEdovpRqY5f5xxrOANBuNxANtUOBmIBjLfwGT9Dm/rotcHLhwG/79DtAj2Pc8EAOoGIZuu44bhm7gchi6j0BoPQ2vOGLruNCTTOW9j+BdDLttkGgbN4mAaha3IbM3F7Nqi4waOU1LkOvGbNwJGDTtVHUMRi8jbQi6EkSOjwYvU3oaNMlrzBw5IQPm+oQNkG8XP7Lbzy7AQYBa8wZBumMBy4G0FtrKUHNcG7ttcGcNPIHLxhm2zzvRD0ZM7ID+vJErOBqGT9zJL7UubGMvuA0ocDs8yPBo9zWuy/csvs+YaTSltOBlMblwM0EB1BBdJuTBzzTrC9NBbR4cOhUzXVkPQRL+s64LkNiFBGGErJGuK5haOQ6p6hQ3DeNw9KeN4RBemrBpCmoA==';break;case'apple-touch-icon-green-197f8b4c231bd61bda7a4ba2dac7a59c__42f453c4.png':$f='iSgTiODQUGgUAIQDSSSCIUoQAFpD1oCAFD1kr0iZYQCxESSIQSoeAC7GkgYeAAEoH6pU+YEGYhQPSADnJM5rNJtOQckAGOZ5Pp7P5/OpvRZsAKBSWM3hyBl6ryIcXw2lsbW3VaubX5Vqq81qbV2yD6ZjsJmu93MbU2dhuPV+OQ+mjIt2aTE8Jk2s3OnHqvE0iyky1M/Ek13KwWYbxeTz692wxDOdmM+GAJh2OSIg3wgiG5FWKhUHnqSW0BxObz8dEW/xqmmimBcHkOQwoaFYLQy8yK4lmuzg1S2ZTooRG3QKDjeqj05XQ5Cu9nOSkObDo5yWBOQKQwKNyOSuNxExhahBeFBwvFAQDmfTchz2IiKhhkvkgrwqOEYvzO2DIREwR5HHuLRglAYAwlgPACFwIJDFkSRYi+BQOAMR4gG6EYhgyH4QjgDB8msfRHneExEmed4vB0cIdjKHI2jcfp3jWT5vnmFJdhiDp/nifpCg+CQcB4eQgCSPJxhgXYmlgXIQnaYYpn8AZHF0JpZnYYw6DoeQ4AiHAGHgQJxAQf4vhwKApj8IRxGmHZCgGA5/BiL46liYBAlYURdFEMp8mWQwTAYfo3HSO5nicPp7H0cJrzIeBhGmPRPjsJh7jGBx2DocA3DaO5tnMU42lgbptncZzLMwAZNB6G52hyXRoEidxinqYpLE2YRwmaMo5gEA5VC4aAbg4HBYEkKJPmMFIOHKRpykmaYTD+WRwEmVZDi8Zpam+cRDhaEQxD4aoamGVx8joYJTimaRTioGgrCwCIKgmERnHCcBGhoV51hGcJgGCWYUl8cAsCiWBxVYN5PmgeZCBaP5sEkNZ0lUeIJhOeweHiTocneVgWC4DJIlyKwXEwMYcGodBakMZJsEhfi/mmXgHmOQxJAaD5mH2cBUDcI44maMQxCOO4dn0YY8g+NwWGyNBChUUxtA7W7PloH4bjMV4mjwOR9l+YIYmmEIOH4VBLnCMAUDgYZEA2XAeE0bBmhGN4HHaIwhBQQwhhwBR9F6dBVhYWAbmWyJ9CWcZtAaaYOGESLDBCN5hFiVQ4EqYQhCGXY0nIJo1kUawsFaCJQh0JxwnQfYBEaQY/E+Hp8GQNo/muD4NmuVhOnQCBHFYd5XHgDQOCCFZ8GGaQPjwXJoEmBgyk4bxnmWP5bA4RZokHvYlCMP5jE8cRIg+bY9n4epKhSN4PH8I4DlRvYpG+HpnCmOHgmEVotgWAQOGwdpRhvFeGwVQtAOAIAebMHAygzh0CoDsNY1wni1DuDYUgLmtBiA2LUX4ahkgQEOHAcA7R4AOA4E0fwphZj6E8GUBQGRlDOHaH8Nwsy3iCDgFQFoHhSFlF6LgO4Sw8iOF6L8Ng8gnhqD+OUXgXh4gIGOAsaYXwYCLecK8ZwfAaiCEeJUTQ1RxjtH6JkL4XQKD0FuNgCY/Rsg/G+MgZwshUhtHEO4WIghvjJCIDISgzRmCcAyKkAIaRujGAyH8Hi7B6AdH2JAX4pgSD5FqIMOAfRjDdEAPQfIaRnibAWMcFYMwvCJGo4EHwrhfrKC8PIfY0RCC5AKP0LwihdhXCyPwTw5hhBxDUO8KYHQdDBCEIAEY6R8g9C0EoGY7QDCNEyKscQzgEhmBcBkdQzRrChH2DwAiwxGDPGeA0fQmh2g2BMLkZ4BRHCtD+NwHQ9BEg3AOHAMCbQvizG2HiOQTRwBgGUD5YQsB1AVBGFUDbWRsgLA4ARnQeAEAHEcMQc4dgpiJFkF4BY9kuBUEwGAHE8h0gfE+BENgaR6BgEwgUcIJBgCYHwGEew/BDjlFoL0Fo7gBCMDuPgMoBw5jhGwKUZoLhJCaHAKKaYdBEi5DgFwHI5AlBJDUHIKI7xnh7G+FwHAiAzCVDoEgC4RR8CMEUOEGAzhbD7DyDsAQGQxieCQA0DIXgnCkH8GYZINwTDCHiOMWQHwhgtGCPAIoBBPgmHUJ4cIWQcACGCMAcogwXg3ioHIEYCAuiTHEC0aIUA2hzHaJ0MY7gaCFEYHsY43QtjXCkBcPwAgWj/H2NCfo0QYi+n6PEI4/A1DxCuCoGYRQtjbHUMcVoSBKiLDYLIEhyATBEE4GAIIMwNDjAGI0aYgg4izFmGYT42R7hMB6MkHAuxvjZDmXoLQ7hECpCo1ABIxQQBUEOFAFwbgHgYA+fwE4hw0AgFKCYFobgQjDAkIYDo2x+hYD6LAHAvhjjxBGJMIwcgxBSFIFYBY+QBC+ACJsAwMB3DjCcB4YYhwEA5FoIMGwDx5AHH6JZmoUhJh5BqHkH4LR9iJAIPkNAYg4hGE+DMPwWR/BLD8G0XwJQZAiGWD4WYKhJh7ASKUCwSA6B2BGH8fQpAvAnCiJoMI4BTCBCyNULIlgHI/NiHQOISgihKDWHsSoNhKBOCQJ0YAnx9jFHSC8LwNx+A6DUG8Ng+xpi2GcFEUAMQugoGoEEO4vgyBiG0MQWR8hViVCUCwJYvA6DQFKAIQ4uwpj2EYD0YYrxFDBFgCAXYOgNh/HsNIfgpQyAMEYEsDINw8DzHAO4NYux7hYGuIMB4bBnDKE0MUEIGhoAsH4DEAgdAPDZHqEgGoZR3iiOwOwVQoQripAIDIEYRBFDeDLZAcYtJ0AoAKPsTgPxwD8G4JoLgSw9hxHGDkU43wcicFgMACI1QkCwH6DodgNwRhzEMKUWIphTBPG6KcfoPhOCq4EJsGAQQTDhFMGcJg1wIALEMJ8dQDN2jpB+uAUYkgjAxDCGsYoVBODAHgMQcItgjhfHANAFFKwyDJF8BsfQtgCBaFYKgRYHx2i1F8NcOIPRHBTDOCIOAaANB9F8H8Y6MAPh/D+OcGonRUjdHMOoAgBwvjOF2G4U41ROjuA2HcD4AwQD1HXqIGIqQEh7FuN9WwOhfiuHwJUBQbhcArBEDIRIsxeBgByMUTgbgNh1G2F4do9rKA1BCAYSQvBKhdG2OwRQgxyDhASA8X4Ph1h1DEEEXAtQYCdEWLMNYbR4jaE4OoTg+hLB6HqBMPgYBJhgCqJwMYNBQAZEaF8TY+QNAdHSE4PQgQFh5BWNoJdQw7D8DKEca48gxHYHurIGYNwaiBC2JcYA4ajAYDgIGpQyBiCbF2HoPIxhly4HiMYVgG47AC4YoXQCyXAQITYJwcAOAa4AoJIJoJ4CYZIMAdICwfgETUQdZkABgfYRoVYAwUwOQEI44a4eoeIfgR4ZoQQcYeYQoT4JajYegIgYwXQFIMgPgWIdABYRIEIRoWwbQVoNgU57oDYBwKwFYEwSQdAeYWIFIMYB4dwPgWATwMgDgaQfICAUQTQFoEgOAYgGAVITQCoboWgFQbQIIWgfQPYOYb4KYZIaYAQI4dgWoVIOgCYJYGwYofgFIYYBIbgHAcQYwZoUoTYFoboEkBwUgWgXgHIfYZoHobYdoDIPoFgTAXwc4AwSwLQSINQYoJTUQSYRAcQAwL4AYeIMAcgZoNwf4eYewNwGYYIFgdwWpcYdoW5CAUYV4aIaIZIXYE4QIQYeIH4JYXYHINgBgEoYgDweYQ4RwNgdQFgZ4RwabeAfwdwbgO4XIbAGAcIXgLQCoWBCQFzNwIoFgZQLoagbQRwEoeoEoeYOQcwOq4IRobIF4QwAocgT4HIZgY4U4DINYaoaQQoA4CwFIOIPgBIdINcIwIoF4JwDYWYbgSyhQDgbQcoaAYQXQYQeAIYQRIgEob4DQY4ezz4EobgMYTADAYYyhUwzIeAYYSroQH4VAaYIICQdgCYXrgoEYXQDwSIKkKYNIV4QgWQQgYYXQDgEwSIMAaIaAL4LwCAag3QLYFoZALoMAX4HQBIDgVwdYd4WYToagGgMwcANINIEwUQSgDIWIOQPQCQIa6YAAMYAwRgBgCgWgZQQocgVIE4AIYwaIawP4I4NAGQS4CIYYQADQPwTQYQDwC4BoXgJAaYdAOcBwUAZACYF73YLoEwNQFQVAFodAXQUwFawYEoGoYIRgXgCoawdIYgfoMofYVIEQFwAwHQaYGQUwXoGofYVoKZSAUQIobwRTgQIQYSP4FwagAIUYSwK4IgAQeoawS4VgE4C4SU6wEIUgH4eIcwMQNIFYZILYbIW4YYXwM4eoHoRYaQN4R4JwPgSgfYBQFYDIGABYGZFoeQRQQQCoCke7EgfoQDY4JwJQTYagM4IYD7ZwRhK4UIWAAQboeoZoLZLgFADoNINwNQYQJaKJH4LgCgeoBwZgQoQYSIWT9oUQTAegEQcYaiPIOwN4XYPYPIMYXL9oVwBAeYG4CIBwUwdgEobAY4OoaoGga4VACQPoAwDIYoQwUQCgKQFQMIQQKgb4GQBYBwIQYoEgJgGAPQMQLQZYCgGQHwTQf4jITAZgL4YwdYYL1IdQJ4YwMYSYDwWYUQF4RIHwU4fgHIYIXoHQSYILowQIMkOAZgCwNAEQWgKYJ4GQPAeAOIPQKwNgEr7AAgPwdwawtgVoLgDQcgNKY7UQBwdIJgTQFkCIDQBINISoNISwHxH4KgaIT4fwDYfYD4bwcoeALAMIIIXQAYVYf4VINAEYQIIYaYSoN4bQVgNAIYcIcTHoQIKYRwPQCAMwVgB4EgBYAAKwGoKoCIYAIILwTQbYLAeAFgQYIoTgWwSwFJH4NgKIDYT4NQBACIV4cIIIKwaoA4eYHwEBbIGQK7UQHoDgEIEISIVIF4VQbID4aAeIQAaAQBYYaYQIagbAf4OwZIW4MgUYTAHIWACAHADgRAXQe4FgE4f0bgB4T4TQeQagDoUYd4MAOoHwcQIAZILAEgeQR4TAIQHwWAZIJwBwaIAAc4G4V4ZQI06Ye4LYXYOgEAAYh4GAZAb4fQDwL4GIEgA4OQEFq9rIZAQIDlrlr1rtr4ZAeIQVsFs1sVsIANrFrVtltdtdtFs9sNroCANAb4MQC4NIOgSAYQk4JIIoJwIgVwIQMAQQ=';break;case'logo-bd8f391da3214e5700c2b5d4d63d4710__42f453c4.svg':$f='PB+eDabBAdjKcjmaTebh6IhiLhgIhAZTcYzeZDSbjPDTqdDMLRwIh+PgUPDmdjOIIEbDcc4aaDodDgOheLzvNxcdxmLjecjOLxkMKEL5OZxFJBBSRAPDIZTMc6RSqlJjybTEb4IaTJDTYbzOb4kdjSZTuQjeeIaMBBahkNhsIBqNokZjSbDYLTkdTYZYaboWeoPYBBdLtDTGdTkcoodCHWJ7RwVUslSh4cDCdDQIK2IjaLYgMBiLbULhkNxvnhuaBcMRoNDZpBuNRdqc8MRuMrvqxmMs8MxqNTHnqENeFrOLoYgMhzxRtwhoNTnx+EMxnzOFwOEMObENt0oh1OtEOJn/HoO3QuX3+RoN5EOfrxh1c+MeDnxp3NPnxz3/loJ2GAaPS4buPOh74va0DZQAHDshs7jyhjAwZvW2z3PyoUHQS47vwRCsFtyGLdhc3waDQ2obBwPQ2t09sQvuGAavkGLlRGGQZPm8UbxnFIRMiycfqkOg5DClozJ6NqGjay45DSPAUBoGDkhoG0YBktcryhKUqBiHAahiEAbBuF0ptuHAYByt4aRuGC2hsFIRBeqMgKSyrLsyzcVtLNcIvrAC3hg4QcQLFsbOmGzoogGwaOu88uuEHIbz7BE1Om9YcQFCbahoGY5u45AYtA9VNBmMbkvWGkDQC4QbxfRyIByHFOhg01DNWGVFu+G1SzYGkrws+1Ev20AY1lNT8US77+OTMUARe1tdwjAjuBxZU2PE3L42o9A7N7NTVBiGwYjs2cS00HNsTO2oZQlNcYT7azQQvM7+OFNYaVjesFOU517T7D0ZunZl1uFDIZQY5N2wvKdPVXT0VPdT7qV3W9fT9BtE1w0FYw5ethUo8TuYzhbQYy2Ls4yGuMuMiAb104t6vXW7p4PAEEOg5zi5pRWcudDLtYI/8uX9bWAQ45MBWNGDi4Q4sFBpC4YwVltZRg8UX6jll9ReGdtaS4FjvY79hS5ROgx5H05x/IUiDnIw5SQzklybJ8o15KgaystS1Szu2NS8EAcp3GK4hzLle6TNs3zjtE5zqzDNSTljRW4F0Yhjb+8PhqszvPdb512GGabJjTpv+/uRxC4r/tLetnQQ6kCOzYTduY8WYPw7MFBnjNZvE9fezZP4QZAoUXhvA0Z4Qz+u1M8UM65aWNaO901+hWbcXy7N29FXT9drNlKu/kWgv7ELk5pW73PK6lZd37+8du+Ly+B+DP0j6mKtN5bV82GV9NEQygFiDGGWNBa2mtzz13moRByuM3a5TVrhcohM+igFTHZP6DNAS6TxKcaa61ep50Jr+QQrNerUFTsqQor2CybFmHxZm/Y4q7WMo2YYeo7kG1tOhOK1d0SwmDO5huUJgR/XgAzBtA5cCJoIriN6jMMcLYSwZXkgJLyiENJShOdMGUJDsoXLad5msYjWFrhOZ+DMO2oQ0Xqns9bQYNrCh4g93ByXzxCNBF9pj9jvg1iUbSJoeketpSA2tIqR0ktySc3xW7d28pYbrI1vyX0IrUeOgEHJ6E0wILc4pOTjTLOPTwRBBgMHKOWW/ElyqE2HxzBtEhPoM4zNWi+qtmKFECnlf8dOXR5QbN5da949yL4wnibG1CAK9T/xgU5B2PjwF1rQWY1hNjul9IKXCxWXb+0AS6QygWaZ5ZiH9BtEAGcgnGSEKVIZtsiG4pCbnIxKaVUrt7kjPNLjf2ooOBkhNAK9wQOIk6nCT6QHHJ3cirM0MpjPSoNW5k8j/GaIiPY6CMExGetiYIod6kvFgnOWYb9nMpGVA4V3Cx4asz/uhf4gZ/yy3or3PcolNZt1ZQJNvAsGMDUag2iYuCJyI0QxRZhBg6ccTrweQe9mO56ovQyWXGI57L2QyzhcZ918co1n2jadx8JoI4vLabHVeDBosUsTZCVbRvolA4p+DadE6jJzsbc3BJU8JFz3kdPWgNepJggXA0QoKqAZstoDJxN1BJ0o/oO5AzlEnJmoNUn41690HSvq28Fd7v35oUg2qeErMYjHrs6oF38b7QsEtKq9mkeV6HzYI7w9bgTssxs+de09G3KMGBnZOPxs4mIfM8vc9KinkQ1pMjg/1yqKLwLi1RAyCl4A3By6Cl0O7os+TWDiZpQro3Kfvd6HNzF2oSBvA41twQa1xrkkFIch23yJrw3RLU9G9V9vrPmSgOUbqbSmm1ilArEuLnVY2UaNDQJ9BrVYHMKjangfFFhC7KVHoIBy+s/oOKJoyTVURsRnzzmxhybWtDRT4urQEuF3ygWCoIfSgBpB/2aXPYwvWlq9VdxIYqijECr5psbRhMRYSrHfMTOS6ZpzHkFNEWSyRsp3CdgxXRS6QBrQZOUT8apVANVsQ2Y1lhW+HoXS1g6vVQMWHaHuitilC7nT8qgZipFmdVqclCYOqCBEupj1JYgw2lUWKXvXXyauncUaUnPm4l05JsoGNgdggC6OQ6a1rT2tp49MEIsCYFgs0bSlgKzUGrKkWi5SYzNwcl5+co6Mki5VFHNGo7LDX5BdRLAl8O+q9KQ7l7L2lJrpO6u6TK831bxXyeSW0upfRsQ9AL/koG7sPqjAdBbGShoRY9oOCpgWshng+ic4rRKrZsefC6jwb5oPLhqXimoKnXT3hatZ40QzmOdLRlia9yqvWdMqUkItGNcl4rJWB3EdQaj7Sd5VCmrb64Ymw/6qHxSkWY7s3QOWKoxQ3G8+5rFiHXeMxnC+Pk+zjxZH3b0fUVQta/pB/LotCMdtfWA8TNGRstVW2NTDq2aZ1iDoTTi/HZKBXrnfEyXDpvjOugJkzLMNnF6V0M2qEeoP4hbdSYSEbrulxHzOYaq1mA3dFpSM8JtMIzYqps/UpIEJiQigqna1TWrIVn192ae1hTlen1ho+vNe6/vjO/YV9G+7Fvvsev6tydgzRg4FcNhsBSesWZPAySUJojVYCA3xqzgkPv4DjzCYzQra88bKTJ1WsWFV76SGCYjlSyUA+Y1pzb+209ODc6vqj5JQPSbc9svz8nUO375hAdrpHAb2C4HDTwQdsle4D5HtrAFvP2Dj2wc1wAtX0W/6/0/bLc+Lh43zB11sHVYriX7nQZStjC8nsFJgWkPUuW9oJxNLSyNkjY4jWPUmkl2mI3ZP795wRAAFpG5gb/T7D/g8aDQ5CX73ozxgz8x7T4j5BS7Qw+5KAG75aCKWRMRSDzxcEDUDz6w5pwR476IFsDrsD70Ci6qCxgw9ooK4r3qrBFT942RRZcCoSLokD5CwqM0EBG7Bo08EBBwGoHBcTKJALQwnZLrBb5iWRBxWD6JMAFxWEEYFrKJ/0E8KIHBbkJMFsLAFyV5RcJ4FsIsI7945sM4GKQTAiQjyYzhe40QMY2RLziwtRUCgJMcI6wEPAGA6MC8PhUD98P0QgFsQI0MQcPMREQkPsQkGpG7DUDhcguEMTy5MRLwNAh400LsQhypEzzh/wO0JIGjQxMa5o+75Ld6wA0ilZahriaY/Y2J55Xoh5UDtw2TzJ+UMT5JRMVgoR1cXJ0ZGMMQtqkkKrLxeZ0J5BahcDtY0hNQu42RFA3hMRRSnz95ckLpUET8UKP0Q6YzDw1heUGBSDMg1q1reR+o/w3pmSLRyroyG6nY/pfcU6pI1BGZbDdS48NrahOgogqoq4NiT4HgF4pop4kkgoookgA==';break;case'jush-ee1a1cdeba50e879f7931d7ebd3189d2__07ffbd7d.css':$f='LjUdTmaD2LRadDKeDoLTGbzYbzkOhGMIoO4MYjPDIdEIkZo9FhacDQcI1D4jExgM5AczocjSbozDZMOjOcjKZTdK5bL4ycDYYZfJY5KByRorBjWZTyd4gZKFETcYTseZAaTJODoaTMaTKcqeOpsZJAdjCbDqZa+cDqcp8ZZAbjqbTFXa/KBuRrvIDCdJ2YjrCK/CLLIDUcxbGLqZhhio/BjGc8NiJlQ49HjKMJBIpJko3J8ri8xBs0LTmcTZh5jnY6ZjFrcwfYBAoJk4jZDkKINCIVTxSO9hAYGLTQdDaX4abRZseDx+TwDRGuLDavzdkLTebjL1ODmi+ZDeY+1z+5zOV4pGX+v2fKLcL6Ox4fYc+73z3tJocjDVN/1c18O47A7v884zDqNz6tU2zcJCkbeB2MQwjGNaajfAqnPtBLRQYziTN6/btvOOI6jfAQ4C+Mo3jo+D2weMcDpnDDSJ2mEGw880SjCOERvXEMdOcFsePc9UfRxHrqtKNgvyI+EjjShEkxzJbTC/HkoyRE46RcjkYJYl0Zp8oA3Ro9buSA20SC/Mz1yPNAwjlFT5RYED1sKPYzOuhaWDyNgyh1JqyjSMbfTG88iTlH0yRFNk3UHG8c0M/jzttOs7xjPU+DciA2sHGsFxKNCyjoGQ9xZCQ5QoN0LQRNsFQ2iDewvVbcoShbaQ69Y6DCM7jMg+C9jpXY50e4NfSnEVer5YFhOfYklPXYjH2DZ1kLINkstrWKD1nBtSQnCqvxhaDUTFH1cV0wtj1+wtlBbYkqWldNoyHZFm3leF12Jaj4WgL86Vg29ZN3WsHQhUtT1TF9sMLcWBU5cr4DwNskXLawdRgpKlqbcbq19h+IySvl0X4OeQ2hkLhjoOGKRhXyXL8wGGXfYsi2HecoZjamVWxaiz404KsZzf4W52tGYR89uLzeL+L3Xd2jPlpdnRzoEFaHnrnvamwz6mpClKYOWD1dQVDvPI910RmcbC/stGSftFO7U00mjLs0QWNtkmIRulG7c7g4DPtexxLptIRLv3AcJtszjayDTb1mXFcYNnHXpxCIQhPfHcHD8S8sMfMbZIlR4JbtUW/bDRyPhbO1tH0WTP1z1jE/D4cXNfZDDKu5ZlrYWqsrCtK4r2iuquDkPXzw5d54q5+F1exNkEAw95i+vbAOXWegML1jQMo2ZSMa1jmjnue957g7L3E1Sk6W5/TH28fa/2/8b9zq9r+j4c7zH6/ONI2ltDIGJ6Kkw3ELDuGUNIZzhg6DEQ4sSnDuOHc2zJ6KZ4JNpUK9JO0BQWwHgTAtTAclNBsfMc9csFV3woSGo5/hz0eQqcRBlM8L4WtvSuDKAZ9iXvcJcHQ3z2kfPgJYG8NoOg2EvDWCyIB1YhB0iIxUNIc25BkgJAaBECg6A6hDCMHcOg3Q8SbCUEDKVNByDOS8HRrzykFWywE1QIwZxxJAq0zxjQWvUYyfYiYM1AkGd9AV4BdI9A4BgDgsZZWeR6DIDE0KMUumpJmCORcjUuE8JCT8oMipGFvLi8wuoMAcyNZYGllzRI3kUkJIQwhkZIGUMWDaOy4Y6GrDMGEy5mUGR6IpI00cswRmVBmYqXBJHUy+MrLaNRznohbDQTYMwXQdBoDeHYrp4ZlzNDLM8HSECszUD2bohZVyGn4KydcHSFSuxHOwoJI6bQyxLIG9F7b3XvvhI5DsrsYQ+hhmZM4LrxyBRODa7yP5WStyCecH0=';break;case'jush-dark-27969342aa18782fe57a825eccd6c044__42f453c4.css':$f='LjUdTmaD2LRadDKeDoLTGbzYbzkOhGY4oO4MYjPDIdEIkMY9FhaazKeTvEDJGofERGYTGZpAaTIZTcdDSZjSZTlKI4IzKNjLIDsYTYdTLOpUZhsNpAczocjSbozDZTEqRSoNTKdUBacDYYafRqpSZAbjqbTFOLAIxgYxhIDCdKaaTEdYRaRnFYMajmLYxaRgM6tDDne77Up2NBhiBhbYMcDQcLTFDHIMdkMLG5UNRljK3jxaczibL5UcxEsRirafQA==';break;case'jush-3ddc126093108160f2d571c019b41c0f__8fc54b9d.js':$f='djCcgUajqczQPT2YzkZTCdDKXzYaTcazmOjocjqZRYdDSbTKbzqdB0MRhJRYY4KdDebYhEooOj2fRYYTgaZhMjgaDgOhePC4PxQPxCeDabBTQR1OTgKR+fB4c4UaTgdC4cxWbDCbjOdTCZzLVRUPbBSBFShEfBPShOfKUKbAPheaRYbjqbZ5SBgeC2MBaOTCLTMXRWKT5SC4Yr3fcEXBcP8SOS6Kj5jMfgqOPx0ZS2KxaXcdfMhgx/cRZC68eDhFTqbjIZTNEjKZBYczqYjhDYccjdFZjszoeTYZR0ZtWY44bzcKDRCzMLI8ZDSYRSe4BAojEx6ZDfKI8bjoLoVDIcReD3ToKBP1zWJxSO/ULoWbB6Jznv+DBjKZToJx2aTMFDnui6b3wCMIewKHY+ve5bXB7BgzB27TuDK7wXK8OjyDK8w5iEPIqK6Jwwo89A0IYMj2L2LoXJoOEKDIIY0DSNgyBQ9T2plGIzjQiMdJE4g3OMNLkRqrKtq6jSHDwOjpjpGI5hcrD6i+Oiuvm/kmjTJ8ojoL4xyiOcrB2hY6Dq3QQSxJ8cx2NMei++qGjKOYUC2rCtK4rwuo2MslPgMo4KwMYyhQF4uDkLg3NGM4WBPQ72BYEIXi85Q6DaPkqDOPiiDZS0lBSEgXhchz6yJO0jhSFMUwSFk1R4NEuVcorhuK47kzrIyvVXSijOogIFDeOU2IkML5VgNk+z+MNA0GHgxDkFCqhWLYvB8yKmLgM65UYNz2B26oFVZNlXNiHqCIMF1wR7Ulbo1co0XPXQvwojjfi+1oxje1oUV/YI3WHY9AUEntpWoFVr0W9lT3/ZOAhQLzJjcPgQBSEAX0UE4SBiEw3DEOY4B3blvIkNQyuMhA+27Xo4DfMAYZQ6wwykN4zDMOb9B7lt92xftjIXZFlBeFATWkHbBB2wikB5gbBB8FIV4qFkfyDIb6jkFl5DS34WZlmj9OnlSrB7fWZ5qOgWy2L+t7JpoUau34fhiHQYPa/wUBDto8unkWSDoLevi6HuqQTs+05twg6BXqkoQoM8mwS9uv5uHd0XEMkHXDVqHDJhWfzmLwTB5aqkaDoei6OzGk2npemj4EgU6fqNaBRqk9SVqzvaxvA9jNX4UZCHsku+4KtcaNIfciNIWhbvL/7042+5WFY0i66eqcAi4XNpjiLhQGAWDTpvm75r/osFxPs6oFHvwiMrgocBXw+eq3pQSPvx9/Pfg8XJoV7Z2+3NwbkmI/SZQ3AgcCH09qY4CAgcm5lVUDUpldVkkB2KlyNhhDEF8O4aQyJNOmt4OBC2wm/RazIBSlwenzaoRIM4JwfoSLqvJCx+kMobQ6h8M6IURqXBSRYrp7VvJUDEmF3aznfAoiFBqDiTQQwpNWa014bjYg/iTBuDoaAdA0bm8lowe4hArPmCA/gfXfMtW9A0HrsEhHJg+r1N4cg6A9ikHcBQRE4AoPaHdGJwX0g8hCGVxTww0RtIEG0hoYyDtAYcVUy4Ol2h8VsndQQPwegtC4FNU4KASGTDmHwFqzwpmDdcC5PbJAUR/C29I8CX4dBlbmf+QwdJESEAVJFI6B5DhoC2DMz0sZES7C6DoE6sD+LeTACcp5t4CpeZgmAES7QRA+mSVkEEzA5zOXaC0E5V0iySBWCeaM212rncuuFV6ul1SSBZKiVREopByCQFQJoTHNsBC4HRp8QpAuMDRFSDEwp7sIm+DwF7HSszSoLMoHx/G6TsRUSA3M8Z5gmBMpGP6nw0qhTieehyoUQIilc14hcqaHkhDLPCeQTAe0dohSeiU9JfBoUG0oFZcFUAwfLQMF826OqXlbN+haCX2M1D3R2d1LqUuAnqoNQ7T5kLNYpQtG4fQ0grBWf0/84yOEeohRSDZrA3h3ewfoKhHSPkhooCiOcdY7gpBbG9JYPqtVmogdOr52qxNkrLVwkJypyo9BYSSAKzSGBrfoyeBseFVHqC/IYuiw4JtSVrN1I7tElq8IEvc1p2TtwxQqeFOENV5Hos0GVblpQXVHpRPN36TpyI6cxOmyrwIgK9ZgD21CF7RHeQ4h6j6IwThhW5EV3qvQ0vHB4zCfbxKrPLBQzCki5zmHTgUma6EqkHv0uqtuMZJyFpwJaROyLsT1GzJmHQi4c7qQDN1Mi4T/E0Hgu+Q68JFKKHqB+CeBhzAegim2eqb4Ipqpfv7NlEobA4X+mEey+AeYShmhPa60F9D1JghUReFkLr9TbvjhMh+FalqRWgC9g8PQT4MufegOUnS0YMBPQtxFOgw1BJkGsMoeQ7q/DIHO+pFY1NTSoQ42dzlIhqTlBpYBDg+JdXxK4Fan6NKjTeQ5U4e8phlPnkaMbdFIynJ0F8OIdQ3hfOqWzL5SszBwTcHFTZSs1kRyVm4OAZw55szTY2a+ds3K/WScHO7JA0BvzuUoiQac7quDoHDO8hkZKeVAqI8+V8q5XPmUoGWWz/6UhVmzJhrT2ZWyDlg+mbNMRItdhUGVFL46oC3ld6dmAFJlPlfHWQc9W6hC6y6WpLg5gytallKGvAZa3ThrlMCT2esARrsJqCs41uyIuc6XIMTp3Ed8QEraG7lhoBaDQ/oPgYn9eTc7bFng6a2elLQ9TYVI6INSZjR9GwUaylSC0GL0w+B8BDvR5G9wf783tMHelOMQhcBJjYPLT+Ab3VODsOcG5ZUy0kQlmFpi1A63We/ZLC6mMYafuVDd0SVBMrDScIfFY8HtsIGGwwY+Klpy/HME/GCXA940n7ZShOPKK5AvLdCKuR8lDlydmvKeChcqdNrlV3+W8v0IG4NPM+Mku4LzsFigwvG00CHMiRjN4qj57bykipwf9h3PSQHXZufqhDfyQO/JuUApxCF/pLCAd8r6azXmGakJdS5rzdn09urdqujxtn4XguBXadiXpdhQd8u71kZep2+/HY8BzngwMePhy2zz7wvOOOYiCuCoFALnXbNgps+mM69qB7u2CAOAMe2BVDgi3ofcXHeN5Z4/l+7vKhr5t1Tw3gvNc885ubtfQe3+36Lw3vHvO9Z1DZ7/4JE+q/FJn8fkMqvh1MDECgIITAqBFCkHwIYUgihB/GHwIgUgnhQD5+gJwQQmhFD4FMJATwrluKsFMIYJAIoJoIIw7Ehi4GIEAIj9QIIIQIIKYIo9jtjtzuD5rgoqzJbur5zpj6C0z6Rsj6jy70LzJp7ZYibXrKI87wj7j0Bn7uhizpQpkFJFT7oF8FpRbpTtL7TzzdMCLoTohQUDLxzyEDjNjKYgsD74UFb4kEYF6QxYAMIMgMTr487gZ6bssHLsSVT5UCcH8HDzsLB6b3TvMIbOC0zmjy0JDwLjr7EGMHj5cHyPECppxizuz58ITUcMkD0Mz4EEBn8ET40Lzs8LLtsHruMMMDcO5rCjYhsI0PT6oNb67zcQD5MQcN0Qru8DUOzOb6UI760GcPz7MSTkUSkLcOETwq0Ea44HoGK/KbTBZU8Q0TLOkIg/UTkR8TzwcK8QMGUJJQcGoE7pT2b2sUkID3cOwMYNwM0WsSEP75EUUCT5kH8WDl7LURsPkJUZj7cXcNJQgFypyncYiwyKAMIOoNgkTqcTsXjnUNcXLn7uUTzpEFxbiMhXpeY4JMJuicYmgNLYghzV8erLEfImsfgMoLoLbaBOCFIE7LUK0UJ6ULsZsQUZ8N5U7XIPq7ZADaYH6mJuDE5pqcbDy+sEgNcUEiBPKJBrA4K/JM8lDLC/wFacZYpjpkg6INiRAgLHjMIN8k4Og4JpqcDmcjptbwjtTbYFqXkhkZsoh4SfkoyYMjqw5G5ujDolIlbHsgbV5ugIIOQOQMIPK1IOcrUrgPLUzYAlA+sqrCsq7KpbzWTX5J8swlQlktLVxVJbyEUqcs8uTXkq4Lbe4HcvEuMqzVxk0v7CUqkvUEsvjWRv4hZBLaxXrWR94NzCMssw8wTXB6ipT7swEtEvcukxb1CyTaAOSWhwwHsocdkooGTXLLh1BgjKDSB2R7A2p9B7pw0V71y9iAqA67a9y/ZBsl0mBXUmQMcmkmzFbMDMTeYORnkXhi4EwE52y0oKoKQJIIYlZlSKQ700cV7ALAaZrAogrbkuAlacJxAi7GShaBC7U3SAxVQMQOpGQMgL40xPYnbH45LhAjYOT1suzLALbYw2o269Ck43YHoLbE7XMx4gQNcySE8/iWgiQL5ZpAwMxYZmrh1AQ3FApJ4OE8QFANa2ogRMAi4GILYNZFQOYkAORQLo4FwyYFAoIEIn4wgLgLYPgLowoLYv4PR6YpCT9HYFtHrshiouU/E0baTiIGNJKRAGS5x6psNCVCi/ILsoFBDKtKUrgHoENLIMJBJulKAE49B6lDVAg3VDtD9ENL6WDabVU/lE5FRNgNxX4MsHy51Lq9ZMhMxxMLUaCPE84OUYL20iZBM3tBAFcjcNsYdRDadQVRYE9Kp/imIGUVlQ9SdRVPxptS4lT2lQbuKb9KsV1Qs9qA6BKQFDwgw9A9DGI9keS+J7NAY3I3dE7G5v9WFDdM8wrYE+o1DWzhBv6tYKQMoM4Io1AFAhYFwNQN4iQ9AtAFJRaFpG5Vav5VxNzULHzZzIBOAOayx7wNwL4pRqwqAmiVwPZugEK+NXg1JJi11dRMAmIHdBYBThFBy+Ii9djYE+E+U+lYc+1EDG4ja1wi9WgPJ6Z+ioYMp3R3hb1egiUyhJ9e6L1dtftXtghFRLYJI1hPZyIPsedEbUJ61bcgZLR/Tbkv1c9ewOUtU3NPQNwLa+MmJFs4pYc45OS2g31bcis/yONAFeNha40VQ/op9a7bY/q5tlgF1VCmSZCgyZbAiZ88SbU89kR6TAKqRBJbymLXSRFfbK5MFnqY1a1bbXSuByKPRGRQSuAHh4DbatKmMtxPo041Mq6UgPCUy2lLDTNa5FKJqYZSgE6ihSInxoAqBYAqYPg+o4CVwHyjEE8jDiJFLKpe524ugMtrBXs/QNtA9BVn4gS46mNop5AFqLpuimKkjfIEN0zgkpaDwPbhFuFW9M1Wcuh+ds6PlV9MtWTW12jgKFLhBvKLgPt2xQV3A21XF2bXCkl3zG46YNtpND90zdNoyq4Pr59jtc939liAlBFdQEFOYOgEB3aJ86NAEipulCQpSil17SonTT9yYjlyty4gSiBsLhA8ANAgIII85uUhIL5kBXo6AOxLKNaXDiK1NjQPB/l9bvYL9/EcrS8jSXJFLbZuNEQBVEh/E2Z7RYArUg6OAFmAOAY5GCyP4O1sQh1kJUVkc1U1g/7Lo3E5LQWGAmmGS9DMhYbR1xzSStOF+GzIwPmGAMaa+IGGzd2HM2OEuE6VzfLEQOYFQNQMIgFwoqQkQuOHU3FrhGeJRJ41Ygw/yjgheEzTS4OG2IQObDWM1cAOQN7maU+MOJUhOGD3y/L3yYTLThrHlr1uCCFrwFGLM+dr1gLYBYpeJ/wPJepkjJp2VZ4i4jLq+MeGZlSF1mE4dmU41/E5GGgHUg+FA+eGEnOSa11mMmdmmTEnDMQi2UWSuUkmuU2GIL+GkV6oQNhmp99vUhA+eNLLTfOMcY4M2Bq9AOAtdxFkGXMZFcAnTQuYeMb6TN8D2XmYsRC+j6UROZ+YmXAtMWQNlcGbUDw6eP+LYF2LpGIMzSLULEILxaQL4wTujxjh2LePdahLmPucGQNbmRqV2WeWpumTjLF9jNWUGaGbDN2Gg9lwJSTOQnTO76WhbNkRLQebTRbPLNrL7PhLwMrQeZLqDQ+YLRYMLRs2DeWJLSWb6PeQFomceL+NwMuMWc5857aLQ9uPNa+eK2Cc2LeP2k2LeQRJ6FY1JKJEpOS9U/eR2fshOgmSSKi10J7HeoBOOWBlWVLYGpgOep2U4N7hoPthGW1f4POo7L+BwOjS+ktrulA3ecg89vwNpbmmdbempNZNuemnWe2omfOrWWgMurmo2T2SWgWToE+UAFKimkeaLyQO7JIh60t92ues2L2cpElv+mWeFmGeWnGeta682fBG+refmSGvua+v+wOweN+MbyTdzTq02smLVr2cWs+lVvzROtmyeUWyuuWstbezIjGu2zg/9GOMbN2gO0Gf2BmguwQE2wmgbL7QGNgwgwu3+5QN+sVwAE1r2Fd1jbiXmr7NW5ZhDWANNnxZy4+1m67cV0akWlmOG6p+ahu0ml02jDGDp7oGYFNvotW0e9DK9vuT7MW6e5Ah2/WG2gu++lpOHABLggD6Y6d62/zUSMZbwMxsO5+7e6OCC+Oqmq2TfCWqGNmpWqYMmppmGoPDeqRJ/C/EOp8nOPF2DDGn/E+oSV7rDFJLmH+IOIeOWYOI+kW9pOEtZXoM/CNvaqre+OOG2UHDpNOVdmeVsm+GPDPIIFfIeT3AOpOSgos4mS/JmTXKuWmS2UvJknPDbhuy9be1ux2MG/GaOGEhchWM4pPHYh2DR9GmOd+PWymm2uNa+nO25UWnhd4ouQpeeQ5e2RWoefE0J2KFYrVPKBY/4M80aFmrOzevGrnBiinMZUW1Wk/MmlOx/BmyXOu2nO9au221ezGe+3RqHSSolEmVXK3LvJbFeRfOmmkgxOLlxFoH/W1cmRYHWoZuqiF1GHvGaTvGvYmIujuXSTuw2xG1APm02YPZuhLRTN2hnamhzOLM+iLNwNuibO+izPzN25ejImujbNzd2j2kEKWfopnS5OIHVAAFMiuu/VePfJPLHWK9XWet3WtcfXHXRFvXnXwEPYDfXYQL/GmMvG3Y7RIPnZPZzHmw8RPZvZ7RPaLM+hXa2ijNWanbDNUTTPTL/bnauisrmi7P6RDQXaTQujnhnbej4o2kLKTUPdmxlbfd56cirY+LZVPdvnW6sv3VjYDhDHIOTHbHufrIaAQ79pXWWDBPml+DnR2ELrg5FJhdwiQ1uBN1Vi9kumRsN5264HgGYoAOa/Kadp08FqAgwFoN7BLGHLfK/L3WPf4MvXPfttKHq9SnVpqhcV2TYNsvoz1piZU76a88Ptfts83uHV9mptnu/u3W5QXwDhgHXyZ6fvahUoDBnxeVnxvunyHXfwE1aHv0Xy5ACYHs1pvwqbFqPxPt/VvLnzuU3x3yP0HgHwCXn0iYEnygnvnzThtc6utcw/7VbXjVTU8vdX6in0rIgLxS/dV39fBLRmBLiFH0tTFQljzXY7H69PtQlhi+qIlztedev5ExNX6WgNrX34v89WtOFuqU35irBAFJ34f+nwJAbmv9XwP7DuLo6BgQSBrfwlhhuhwhwMafXrL1w/7At22i0fpCUH6gl0wIogL6lFBSApIZqBsAzBbAgIvJtABpAxgfA6CaRcamxEbAPw9SqIqpALL6pmX05v58GTUJrPrHxD24w4+we4usBOT597pAvHpvlX/D5goO+/OHEYDDpfMw+EuUYm7WYL2UJ4uOgBQJ4KIS5xIziTmKvlWp1U4QYkgphExhKLdwQYkOsG7oJz9CBbAoOqP3juKHqC+jpODPz3Po2ch459ZRuSnzz4+B6/MggPo2mRGB9OlHgYvaHwz2o24+ugbsg3ez3KB3B4e7wf4H77h8uTIKEwQ4FSRYP0vPVUwgX1b4c24TbOELVk6LvltY9MXfv83DQR8P3APHru4XCgC4C+a+Vgqw1YoHBVUKHCjk210xvcm+FHAdgP4Wwtwvir6YtK6g9EKxukdXXTJqyFJf4BEA/A9wr4KsKtug1ihXAMgPsNFUDDGUnOqmvKmBmi8fZtwqDT6ylaSzaF4wrYV5HIDKR0VhKxFYwow4NC4YJHBEW6AUC5DxOGwwU+MMNYpC0ZsszYVBpdz7CrhzRASqawh/s4aCPB+345sAbPAzJaI/xsKQFH2d7NLhnoiigg0sqQSDGq4CMDMm+A6JhDiDuUGo+alOa2LcEkAepLIxcgrrdEW8FuDjEfEvpPgFxNtYgijVMl5knaSkv1ESSXPnIOzK5JzE9MnJP0VwjcTHCYOJB7VeRccCaENF3AbVZjeNZKAsAVr9nqACg2oRbbzLSHpkJJ980yWiDKoWhVNbKugesCe1Ri5BdWslf5gIYqxIJwUgaA+mlG6sXNKYl+V0w/V3ZriAgH1WMvWVkJHBVG9LUPl8XoZjox4YVekRQne6zZgy9QIWMHhJbLKKetBA0rQ3MjeQqqGDiwKH4sT5kRu2sczFii7YFuKWrKVmJHVnAqJIqK5dXPskm5eM2e6JAzui1PbfADOYhKKjFgEwiIY8gQQZlBI4COUY+juR0jBlwA4yOSQPhEwOnJqkeNxG6ICpwo2cUNJu6PdFGIQERU4BMk5A6RzxHEdFZq4jjqRvI6wCCOw+xjtO+I9RiEBPHgARgMwHMeSNlHujIsr2TUel6jHrj2wOY88UWOrHyj6R9o/DIQbuyILSxtjIEf9e1G7eoxvo5BU4B5HER0gJo5xU4qlG+jxAOypxf6OUjbGNDHBjxU4C4B1CSgQQGEhiRIAjHRBlQwYpkTmGgC/hgSUUiAWw6Hjbm0T2JOt/qevApxvAFwGZjWBtEYBAU64vk9iA/PYhSUm4GVYyUcAZFgQGzpGN9HCkdCi06CtJxMH4VsHqZB7pCQim7kiI75FBwaS6KqkvuIo/qtkOTHVkykBpM6OkC3D3VISaQEkmsJlJtcUMqI/0mQ9fG4MQydwLgCIC7J6k+BvlwzVVxdIOk4x6pOcoRHeJzh7l/h6ZU4YwjyGTlWgOQQhJyEwClEjk8S0kJ0riAxhPIe5iQC+NwAXx35PrVEqKE6lSC5lcLraVUdIAWSrQnkfMJkL3C7SswnZONXDK8FCAKjpAC+V+lVIpB9QmEsAC/LNYqnSALgCqVZKulqyyQnErSGfLYAfhcAmUriW7BPllDWiKQTCWMFBCxAbh1wTILpLBl0y7Q2Zpxk0B7lcChJXQF8BhK9j5yu5V0r6XmzblQy9gqErmVZL7lXx35fwTyVhMBYbgcpdEq6XUzqAXAJFHgEEBaBaDQSmQmTxwIfL1l9S/Ja8r2XLMecmwz5hACKYVLGmGgYhZMxEJ4BglyqFJmAC+USsdAdk4zWqYQnGYVmeSpTVEz8XMjjCVSwBP4foDKBTM2EaZOD7QguBiD7p1wNgXUN2zfDkB9VeZjd6IY7AiBrkcaOUIQAnAvHM1BCA4CYBFAhgVE6ICcCSBOQHAUgKgCCbaBUAnzawKoFBASfjm1gRAIs2c/GAgAjH7gJs2sCoBSAqgTgIZ+pAeKLP2n75tYEUCwBQAmAQZtqpAUWBenITkpygE4jE7vATzZptE2oTzNim2zb5uM2SbYBHAnATz9E5adJNuPyTcQFwCuHuMTnUAPwKx+ECqBFApzawJ85wCJN3AmJ1pxQCACWBFAsgIJu83lAfOjAvTy54sPcDuArnOzZQIs6KcvPQm/z0p6iA6dlPUnbgV0AE62edN8m/ARZwE4IBBPcnqgJ58R+SebOXnGgUJ9oFRAXNnnCIAQKE6wCCBSnkz9gIU/gUWBWAkgRQK864C9PzAUAID8YE2f2BSn+gWQplAyfvPonUASQIwCCcgBJApgVJ3s6MBABKAnzbZ9YFyemoxAQIDaCajIBRO/A+AVQKc20COB8oVDEp7lBOdRO/m7UMQJwEeddD3AxToJtM+0BVN7oOAVJts2mh+GHohTsgFQtIBYBdn2gP5wIE+cHOjogUTQECjIBcAqotz7z9AHwCOfum7gIAIQFkD4BIAg0BKHoHydZN8ApUZqNE8MCaBJAqDEzuU9SiqBNAQTs59s20CcfkoQ0IwJ02ubOBGm40IpyoosB/Rgn4w8KIM32dDRbChUXaLdGqjZQzo30gqM4HyjpR2o3ARgI096jxR+o90fZ8E54B/RjAn0ZaM9EukjNnoh0XKL1C0ClRwo5UngJNHUCpShpRz16UtHqfVR+nb0mKGVLCi1S0ot0n6XoE+lFSkGJUpqYdKlQQA/pN0caV9FiiZSSpZ0laWtM6l/R3po0wqK1KiinTMm101qZ89edcAgpr0cqSgCGksAopmUvqaFHmfbN8P/Tlhk6fgAVNEDtp2B9q2k1CAsAxBrlOgTNnKUnfmi+iKTw0JWuIl6DKqiSGRzC8xZzOPI6yvCBWAoqDkRSQBTEqZLHUYhQpbIC87kApAVCny9Rvmo+p0AXVIiRRJwrcAtFpChwyIp8yqXbqOVLyEVT4kAielj0XYX0sgBeGFJFl6h5NTcDcGRC0C0lSBN8oKYlMQ0XZECtxI6KhFgAbZIYQEPOHtAw1C5T9WENyYhAd0XaqaU+rIUnTT1Yjgp98/OfpP1n4T8Z+U/kf0P7T8wPk4WcPOJP10TQPk6WdjQvm8Tij9lJI/XQwq8zfaXdHY/IB8nMzk5toUcKrRdHWDrqrBaeauB0AFGYSk7V6qAArq1gcjx9Zun+BsA2CH5qAnEB6BPAxDIw4wC44Qs2IMTUQN81MDbNVrShu6zgQUNjWqD7kaXrFcATiAorPAchvFbuawGrA01npqU1RXfT9HeLk5rBEIOCK+MIVrq2Ad9wQEZE5VvgMlcQvUbVrp1phe9bhMmQmrrCca59bk1tXrNX1zK51beugBbrzzVBv4y1Y7XUrOV9691a2teN7rZGN6751CvnXod8jdK/wbs22A+AajcghNfSvcbbWODdK7VgKtmbzGa14a2onE7k3XNwV5BZ1fytOHRA5qDq8FeKatYIimFzwiIzAm/E3Kp2JCP4GYpOELHKge6SACij3WBAnTdAPk8+sKfrpFATqvc4acROKnbHaa1FeIUXRAAUUAJs4HygJQGCjzcqDNBug6SYAf0W52YCwYkX5smVqbDtViygBerBTcKF9DwCOMTFpAKAyMPdRiLSd4gK7MAUw5nYLqsDDZ7U+ij9PeGIzwZyU8Sb/PHnk2fRiNGcYmels7WYbPNhIN2KLovz4z+1MajaBBAnARKNx+WhcA9sl2egFgyeMW9FA5zXVCyOQb5SQom0CwIlEeiTR3su0yqU4Uei7Z3UqFuLSAHOuVX9DkDwAHtUAqW62VhB6JQwHcDAGCASCjkp9UC1/UIVkH3bYQoIBPRdqb0JrY82tjOrPSn2JBNFe1QMs9sSLb197BmpFbRD0AYAoFDe3RD3mKndl0pLkQGH6IT2HWApL9ZOH/V0WZbb1e+w6j+t6WKbMqy+36prIkW+rXNwKtWj+EnW+7FoC64dXrA52+7hAcFYNY1sbhsVBFuxUglut9j9BulcdK8ESEvAdQ1sIsDGuRgLGIgO7uqqAZVFh2ZK1Yk8iKBFFklMmpgEUKgHts9SRRX9zQkQXPcP3OAMYe227a5ueAcrn1za6Dc5EE2JBZKYQuJYktRmO67A30OZcXDZXU7Us161Qavuo1pghag660XOtxifLcoVC2HbPR0jFBi0PcKtIuPMUJgLiHIUXbroTAK7dBi62SKLEsjCLEQjW3ldTrsTWTHEYyNUkELnXUxFKQkvyHTupgPbqbnGN5FccYXIKmJLkrVDrAFQ7YWYei7cTfiszWjHRN+8/NrOosWLXoRIIzcegF3onotg22A3XX1XrhzSpxGEqZHsCVCOAHMCuNYKZWwL2yp4+auSrTCWZqS/W9pDLAVBZwPl1q8ON/tcWCDfN84IXfQui30r5t7Q1tfVIU3L7FQDsWSsEmtj/L41bcvylAIxO8bZtSBaKsdv3HrxZKY6ThT/ulgYy4oGwBYn6CApYg6d/tK6sWAeuthFICtwQcFDGin5VD4Em/J7R5U/rcwQsagFYM6W8azhccZaevhYw7oWl2pG3MyFFEeAHoD59peLD501YeD78BXgCjPgJX0eBEK675A+0/iKNhy5jXGCM1yJq1bwAUUxrWXlimIEGtQ+0th2O7HtkWx9ZAs+hbhaAs+7uB8AwTswH4GAKPhMCrUKoX2EuhZSHpe0gKx+EahdQwoZAfKR1GKjIfwtLUmqW9Y+mZhKAxYSp6eE7ChhSs8K0L09zq7AJxtUXUK8uDopjeDweF6rCODqvXb1JdJq7YN2i2kBeAwYTrvYCdWiYltd2JS2648l+A1JesEsS2IcDHhDxFYjJteI9I6Q+rVuMLiFxKvgXrDaI5VHdi8DmN/r13rButhetjYZCF4qRJZtu7/bcsOq9bg1gjFRaouJpBB39h1PYstAQYtbVAgmoBNGqBgLntohQQ7gBxEB6GdM9IDAelAQAXbZKqbGNjLqBTSBBMzmVKPAgOiBgFCkc2rfzwZgUx9gFAZW0rJaQGQHohfHYHBTROMIDIfASKp1CQB3iWiVwK0ZYx8iFwKWPtf0PcxuOjHrGO464OxI/hpcfd7mq8nXDvNHyd+RDIDkSI4ATxsY10fpgyyFjKxrBs8fYEnte5Fik41rI6WXIQDKwhA18bjT9yQ5DSNasIJQYrFBZJV9+SgaqOGJ1jK8hImYa+tJGV38pMSZPBnkMyRhyMmwmU6Kx/yTZFQ2GT3JXk/xAWCmkwC5TmGtAqGDmfzfN/sx/IU5O8qY14ZXlEGwDhnpRAtnwIJyhj9mP5RoSVkUCHCFW8jvOG6H/yxWuMqRO9+awBgSm8suJT4pAZVy3j0F6kZkZbGby1RnzauTPKWBuym5OHPQjNfunyAnGTTn+VESplTyVDXAOmVaKUnty25eH+xl0WbAiA0gdjRxRlNjmDLflISouWcfHmJfx4FloWXFj/mZuSroVo43TKTkiFaZk8p+VnN3maKSZnMnmZ8bJmij15pajpRbMCKjzYEOcwuWZQ7mILD5IA1mRzNANsv8DX49eDPO8NkziZOb/GbMIqNfT14McdT1jPKH6zz5lQ2WeLLDlZytgZcroi0hTlgysJ8suQHTLoQysQFK82mUCTLiBzOk7wHWVAcMFJ0Dgcxk4/XQiAtLcZWR4GgPLtFwzTZis3OcZpNm8E45vo0BlwC8LNzph583WiHOQhZzYreRuuYfEBU8yyaDNB2SsB0Bp0J6MiLiufRkUURU6K8zGZpKKet0aZJ8qeg1pNnMD9aOdCeaZP9i2rhZ3clefPSEIz0RZm88T/PGQjlj16XY8d+5Y7T+GyY9chjSvNE/2z7Exr3RHHPJkr00aW4b1V7H/j7LOCEyz8EjILkBjUZEdMum2MsHg0kZFyuGM7JWwWx5Y9B9g3s2e0yH2CfQNoG8DsBlwgAbNPYV4TlqOFjNTNS4oLIAFeKp57so7BcrIP400DwB2wGQ3UJFD5gdBJRQx+IwZewgMQMpFo1gtvqZkjApBI8ltqgJPklwwYqAlLf2I/qyU8QFQfxjlJVkzSVoe0Vs9fJcsEVyCasmETEEbkZxXQuSVKWJFbFlpEZ5gDdIWFmrVxshS/TQLFVuiLnGGM8DcBBAxlaR4BE0v7fMAQrkw18b064PCA6VXSOBlXXYBBCQ1AQNs0cIdjwZ9LCRLwyvUpsBxmTSCxQH3X+BjI0qF1y2qIslqkA6a5sh+ujVRn21ilqil4g4V0A71iiW9kOx8DcTvKX7JFZAu3WQJK1lV3TLA8A4cH60zY78h+lvYsK0vCFeA5LSwXlg5msBxk5g2HaAWfCLgbAJZjc3ztHDvxCwMO0uuSrn2nCK0cu1Iudr12klFBZIeTGcFTI1rJIumIGaxAZG97RtSYhVgWlhKwgRCsItsB/FREm1MVZm10WM9tFabYovYTMDHte2zBxg2MYOLYbUZN7VdtaVsrCe0IXbcoqYGEDwPc2+bftRe4ADJuCA8G9iHo2zbSHfYFgUBI+24Dvtw3GbdA5O3ba/t50i7kRY238czuWrRbfd1YGkD0Su3C7m7AbV4PnueCvbituMVK8vuPHu7pt1m4FgQAt3hbst2gXStQivx8bkwOmvLeUK73hbzt4kYTdZlrEzKFmvFwQy6BFDvFJ6vZBhxyKj3DLzIC21VzNtYVzBuyk4HTYBNFxv7BRNGUEgLvaUMQCmP20kudvl3cGGw6ev/YZvxXiCTog7pMbpje2B4zddgh0rTwI2CEgOBaV5Njv8bm7/EhIEIWSEUDbigWYe5ohkwL3vBuW6e+hrRtY1/CLdduxLNK28cY3QlclDTcQB3AmBrgOnDBjWB3ApE5qNIStoxve1VVGOD22peYzfA2bCt9+wLgfsPqO7RANm+fdsLDA6b6hkIHMCqVg20cHzG8ktn8A5IA8U1YQdrivxCA88WiFIDgByb54g7nOLJk0hTxcKKcJGL/CZ/mJZ4qh2jfIlni+1Yf7ceA2PHpKkWuF28dQN+Qxygtr5AJ4uQWLhYkbA5AlYOQhVdLZxWL48jQ7Sy/kOEG5BZDDY2qUSVEtAWETwN+gHk+VgJSBrAFKx3hZyT5EcjhlY8awhyq5McrAOZFzkjxg5YAaOQXJbkZyrDtcmjfIHsWKYLLLGCxk5XrVMJo5Rh2uUXLflzzM5ZOUFFOm3NHjG37bFc0w2QCY/U0z78x+luHccBT3kAPQHGJHbtp3NzF8g8QGUt21p3WC3N4+7MlwB45wbs78G7DWWTXJWmWVqPA6oGH83hB9lU+cJgIXBGOV9Ah3P7nsuJDggLgPW5ZaDumDkCXoEB8DBAA+31jNSOHEfYbsFI/iNwHexHYnvb2EjNejXAIsVncAyVXdgufnApg7JcgO14ZWoybAW6ZBree4HMlatuJcjYc/PTclbeXOIigxhtTQmyLPnpjrt5lykUkBDAnzfAPgFA/RvjDz9PcwgR4yrn5I5GTVpMB0O9zrjDkBMShP2GTEoEb0/uAG/DgTsO6O7ZKzjCXHqN7Fx9ENsE1dR30J3qblWBBrnpHsL60cScO2DrUTs23najYU2o/U/j8DVll7EnYccBqPyCZBl/fX+awOQx147dnAQvslWcNKY6zUKsfT9pty6ZPMfDzPrZT/2Jc/NhxlcnWrILVbLw78ZRvjmi7VkgO1sZNve9RJT5QHGGLLjUB5E5CybD710D2Pt1SY9iOIy26/g6mtqDu4HaXbwwEIYB5udBaEPKWjAT9zw5AtzuwBuAXbMk09yea2a57t6AdDRHGa3z12vCLBFwvrrnLsf59buu7gPrfuU7yWvReRCma2PU3nd39r3dvb0JNN7D9N6fcbeqsb3r87zLG6OKoHJ8Fbji5/Pbv8bbAWKTjaXPLeQOP6BByOkvWnYLVg6E9AAFwdAY6FYavGJyw+zsjWAKGv5kfDfX7tL2B199gxIe80Z5j7Tr9idrnhDvb3/JB9peyj1jZuJy6O4kexmQPPl2QyEeRMfZr7sOSrDkAZdTun3ICAyKx6+9QHk0rh2hzPeDd4GRgK9kaA6Z8RsvXLbywT2ZOYq0y03nN3SMPc6w9C01rYTKYD7KipJhsTF5LYD9GAOmiIdkTK8PbfvEAcFnKOA85DhuGbOUm+BwA8dCPQC4o7YBwcI+hclYFR7aAt1irha29al7aOI9JZoAJAGUnMAqPZKTvRPos4d5yCF6kdSZYrTL2W8hYENnXigOQAK69+LagZHgD35k2w2FBlvP/0d4iFkeJVOZFIjHT+CJeevW3Wrsx4vH2Y8+wXcbsJ2L07Y+ew/jcO8UU8jAdNTuQcgCN07D9LfY++3v5t38d9ddyXgTrw9ZOgD+O8uJFNNuv7++5fAfXD3SJ7EVbMm8AoECdDr5BDv23WywkAJbyGaU+lPq7YN7e7P1XvMW0Ls1pt+CeYtOKsj4EMre2ah/O+RnT/Ve1A6NclOoVNu/zF+sAgM4Q0V+zi6MAQQrwhWpkGvDmAbwPAXG+JiCH8FK+1mykpP2uf5rbG65Cn5p8B5tDKzVQ/i6t8+D65DPiuaBd6kJFGjed9hHAPmKNHo/TdMKx3uiQy1hp1wNpY4RoAn9wkcO1ydHmqre89OMPru0+8wAvAQVOt//Cj2T0c7MZ27+fNj5/6vVyt7PogHT4GROWNEUQ2LeeMD94yXdlQNmmfyGsdcHiv/fXvzkl7/p/Fietemyq989+/5DPgH5PJcRPDXBsAMhrrZAVJ2UedCefHP5sWrAmETdkr9QpeS0EXfBPIPwf9Hsh/Ok8zEIswDlgiAULgymg0wBUuDIX5qxpijIdapFkeCQ7l4aUo3v75TS9g1i8E9fi10wjj/mv6ApV+xJ6IMwL37QMONKGClGKqkcWo8ByzVZrP7I6kYL/CFtXcD0MiUY6A7/bnSBvoFAC6GHHXDFpTet89CuDA4f4xgmCIk2R+/9AyIaY/zPpYxCGghjb/WGmhT4DOA2sSDmM5OtnJWQ0Mu+wQqRPJFQBgkWCpy/S1Uv6AkA5KOUL521iwDrkINws4D8QAyvfYDu5BF1EBA5eQDxZKN8wFbli5KwGDlw5ZBFQRc15CuD79AOrFoi8H8HN0A41jtZIu+7uhYZkcK4HXrTa1UmTYiK/EwFArAN/vvb80DMuUxPXAZuTLO1AmQEz8U4wOarYOKitlsBY+htY0Bi5Bhlb3WElPyTZdAhAhkCImply0CsKwQMUBDAzOUocqEXPuDVGCJFDyq+5gGeSJa6yr+YNuD6snLc239t2zokA4AMQDeCAgMgjsEqO/QDo5svorHe5uBuj6qEKvq4JW+tA9D7KKXvsDYoAWJAJ8YfZtqsERBFQRkEcAwiGYDpBUg9AeAu/A6baqYSheS1Mmvqr5MdASwE736zoKfzokAxgNbjSLnONIPA2ktqTaa3bNqDaw43t2y90ELi6QNc+1hCkGHBmoS4QeEbvWrgC8OEH4cEt5CP4Pct5O1BhQ6KgFAJi1nLeTXsE2Ewi5u3NgJgSyy6ik4PQxat5BOi8VhWj7aZ8j16n8xyC77PACZwbLgeGqwdAK2SuBWjayK7isMFW75wgqTKuCQcKoY9cwf6oGTTwiKaQrSOJYOQ17hMoIaI1sHLXuy+QjMIII1stwhFBLg77za7qk7YLSCFhbjWKtxuroOgxBstsJaJWCkDACFjIGYp+L9BdoP49LvEEEUeiqtgBOAYvRQBA9wl8ABGAxwpMJ4VkOhQkAIrBJsJsJVgNIXkveiK71LCliQEKaFzvUAR7CouiQXk9Pic0Ku/KwrQNucPiFgPmAZvRUKwvcvRzUkKTgMziKA7mTzYDC2QrUHk54AE8EUEmtWDPAAXGw4JoW+hrY0/CevRxbOCHAKbg2NRCP4BbDAGYUJHAgAgztcxywmz8rAOlzcMtAWPgbwC1ig5A4Q2fLyAxu2fPyoORA9AkIB7DTI8cM6A3QQRhRDWwN5WQ6IgiMF+LcQ2YsM1iu9QNYEYE+QBRCSu6YIc7XPPjUe8zg9r8c+3hujUeSZK1AkQGSD4AhS5qvv0OUZWw5rpC37tR6qA2DQ662cFBNuxxhDfBZII41Judb54H2Pvwd2SzCxRXPCBB7BbQDvNfgDo3zhYzzOA9us7iQ9bvwoD69fOhYd2DvPZzQETsCkzpS6AMeC54DvAHcOS8QPYDxID5vYYtM3sCAsG80Jgo4PalPB7CaXD6Jc4BeHkgEAD4ARiTwk+JKBQ6suMSJaCQaFCJY4BCDKgySpPESAlaVUljjEhmaQOtJoaACwAo6lIFnkCwdaUZD+Y/qApgw4/Mo1KCCbSPyRIACgQGgKYCuo3xIAKQAjgJgCeQGAJgWgP7p3ihinfhaAKYnCrTACmAgptICTErgMQD4AgBaQCAUcqQICuDGKNwCYAiAxgdcC5GZsRMI8JZTHEFzB68Tg42DKyomA3pkiYclQpV4xImXJVIBemZJcwOFENAFsQ5EPB5KXVERP4LJMCWREyWoAVRFKY3EVqo0RaC7RE6WrEYjTgOqlVAIQCAMSJd6VqF3Jd6YWAXgHYMmPvgKhAAsjJvpAcpPAJ4/eP4gIoCgq5D9gCeC3EKLR1E6Bd0TsNORGYjjEMRQ0Q3EOxD8UYGIRRyWBEXxTaYCGyGG4DYCeAHqZHFUB1kTnEKxYMWgCEGZpk0KdxTiYEZURP6oMmXxQYxI8ngnkWLFFRECXXERxR8WYlrRU4BYlWAGQJ5FUsBEVGJxpd6U6xxlQMWCCEJkIBeFPxfcTrF+kIgyCCCxf6YRGBRXqq01BRSETwl4xa6VKNaxCxm3F/G2ANSCeAF4NaA7KmLt8M2Rh0Y2DtkJkY+A2AF4QpGAjhAP4mdIK8YqUDxjAIqAXxjZpZGPD6UZCEJRkg+lGTtcI4OMbptbigKTgFraqFixn5HLGgq9Zz8PphRcaAA5AFpgEh1xpMZ+GdgPLdmAWxpEaIFFjD0aE3bRrABPGtE/EajGsoJD0sY1hQIDIEyiQEa7GtItYDxGwxr0bHGrhXSbXGtDDADOCvFQMbVGxxp4rFGugMhjWA4AFsbZG3Rvz0rG4goqbWqDhnUaEDWRtzueiqRqscNGlAE4Z6aPxpscitsA/UasyAAOcPAI1xtwIMKwgFq53Gux0ADvHFhnTRHHSDQMdNHBR1UdCIQg7YTiaqwd0c/HVit8YOckRw4UXHSxqyzLHax0IOqDormMbcGMR4gBjHbhODulGug/0eQCHR5UbkFFhnoPFHmhDQhlGumRoSAE4R3qtXG3JYCKoDvx0hiiE/FZYt5G3OIsF/Htg+8e6ZTRzJcmIpCyUbc+yntgDcAWxs4T+gQBOEbcDiK1AeAK3ghhRYF3RroT2jhA4LeM2AxwISA9Ux60ehGvE7AICEsg5B7YPbPkgxXGkgEbGfCCBX4C+lNxrMgcFgFFUfpIMSCkdyA2AEZPxINgGMakA8yBAre4eCt4NqrjwqchJGigNkheAxSGMdTIGBPcHc5ZgrIDIAWl78aEA8SHkhtIcSGZWgY1gOscAAxSFbUiDoA14pPIjg+iN4DAJOEhJILyCYJUA5SFC2xIqJo0gfIQSKrKPIryEUi1IuR6KH7ILSMsg1IORycjSFiyLApPIKFfhbkm1uIoWwOXSGsjXIKyOEj3IzyBoO8Y1yGsLjHQk/EjJIsyNkhTGljJIDQiFoEEjELJSQ8jlIzSNo8gGyyQ0jVJESLcjaAyR7Uh9GrCs0kg3USOEhPJOSTz+WKtgMslE9dyUiTgF6yTxw+m1ptaXeKTyR4hJJVAOYDyyKxtsb7JTyH8lTGrMrwrfJdBKkl5IGI3EmCEWyYcl3G3ANsZKK3lAZJpH6ghoIayvSKQliESiWMfxJByK0gtJSyRT64RkBX8m1IIyTElayjyP4YxHbjPgK9HTg2EmaKTydpLOSuSdocXJ3xroNuI4MyIhYAWvJsnwqvSfYK0GzR2kn/J9BWkn5HRyBknyF5iNcn4X8Bc0oLKGQ0soEDrx/4BbKHyAMoVKASg8oEX7RtUg9IISEMk1Iryb8bmteyQQMBC5SVaavJvSV0jbJkScwV1ITSl0nBJkSL8g/JyybsnOLJSP8mwENQjcjzKVrBkp2FaSP8k6CHN40lRJQymIKLKZydEkqfqSoUpJKaJtYU1KpSlsqfJwAMQaxKryogjXI/hCgIUMHBWkq7KZSkq75JxAOUnJH6SpkhLKzgE6KoCoB9gTqKzuWcrbKnSnkjaAzyJMiXIVyu8rfJDRqwDfHRA5DUmI4AFoK84eDDATiAWqg4DoO3hCgMBJxghsqnJ0BmEq2F+q5CbXLAglUsIA3SwwbLLEohYWBLGSx0shK2SyY3PKsSnh+oH8SzcitLJRywo3J+CgwI4FhyfofZCNpq8saD9S08sQCPy0ckeA3rAIONLKyvMnBLOF/AbLGtCOct/LFS0krskjyIUHdJ+PJ8uNKiyvUuAD9K5EbJIMA38rLKmyt4Ww5ZgO4DXJLynUrNJXA+oBbI2uG8iKwbyGUf0RyRowSVH/AgIkRLVyoopiVIRhkYpF/FBCDJGNRjkZrGQJYEZEAxxnIzZGdxlMZ9K0MrYDE9LAgIpADcyK8lyA5g6sp7JnrkcEHGmx2Er2ERSCTbyAWyZw+kHNSPrvaLGxkpPnI2zEgzZHRJqcw5LcR+45dKyNe0NmGysWroNHPTE8v1MVTDI+lMXglMaCNkx/ErICoSbMFVGuzFshrMNg3MxlDZy3UfoK4CFkmbMNTGEydMLR50adIHx30jhMLTDEvaOcTIojXMQtsMsaFhS7kjvJMzHsxLI/zIkxpMyO/0zPLMyFczVMvO30zBJwTN8yjMyy3YkNMOSC0y+CAzN0zFM4SCMzklHNSczXKvzJZPnI7it4Kw1JgFsiVKjhOKbXM9ysk0RNIxtMpk7tzFMzbMwzGcz5NNR8U0DM8TQc1DMoTTLx3NFg5E0+M2TFcpqKTyw0z7KhzTsxRNGlCYTZH0zS0d3NZxoLwjMeTRkx9KXzX8abMshDUy2QnR4czvMLzVE1kA5TWk2QA2zZUeFH1TZswxC5GNQSEMkmQ80oVtxzE2jGgzac2rMuymU0FItiQwDweDx8gTdB5zX03FNju30y1Hgzc0qbN0SP4mvI9TVk2FNXPlMjkZtpTY1zGWGWkYqQilr8ZhMBRmkyXGbxkcyXMFxnoDzNwzaUdxNyzZk3OMgzDD6wAvgPE47OJzcc4rN6zi83vOMzZ8v4mejXkYqZnBmyx0GyR6kefHDoJ4adGBhdw1RGXRGrDaPwD8Q/IDDAqyb4AjJtsSKYnAsRic1gApgWgAigKwCKsfgwqrpOeAzAWgnfp4akCJOAFanBOpgIoKZOegFYCSnVJ1k6yhfAqyylOszps52ApTrY/CAjp1ijsAkAJoLBOiD0gMwnDzn86CtND+oCkAjj+ygaAoTsY7JOtzuikCApTt4LBOjAoE6gP+gKMSkP+ptBOoo7ALLCWDMTwCsem2gKwCenjgKQ7IFoLKo/3Omj+YCYAsgLQCLOtp1YC+Ark6o/GAvpugC+AhJtsSeoZhaESenEgJk6POxKCoaOq4pxU7+AizoE8DPBzoolDPaAFc6TOlqO4MLPcD8c91PeToQLDPCT4E7CAVgIyr6okJ389uP0T3M8OAVzyU8FOhz5oNEFoOqACeAhgIqeC6oz40+tPkT7E6lOgzqs6vOgzrU+wnDgJICindzqs+iAmTnYCwpehaACnEjqJA/DPgptqb4AsT6qrlPRT7E72n+J/0+DO+z81ALPkzoM+3PmT38+9OxE6oCPO8zzFAbPrgHU6jPtgFY/QnNT8U/fQOMKoCZO1T087bPfTuIB1O5z3c7qA+Tu87yq9p/U77QRhaE+1QVTws62ApzxM/3PGT088eCrApE+0sfTys8vPMgq082GjqBU/SAnTrE/YpRTrFAAtMpyFCWP3AKE63QEKCFAVPn0BgBROlgIgaOP3qJCjrPQz0YCfPSz04CLPU0NE9ZQnAJ89eCrT2M//Quz2wMLQQJyk7PPsT0k9MrHUNk9XPW0OE6rQ5z2dDqoAzsgBQnvTrcSdEoD8M6qQHAKcSsAnUBaggm3RLs+mAnBaCg4AnpydExPYT4c9mDCj/A/1Otz+1EKFoOpgCYAqgJqbcGj0UYCvQdpuighO8z4M6WAjzoIkxRRD/MTRQhAzFACnILH1AEneAPi0MJMUV1F3RSgKs/vPgz8E/FRIp4ag7Rj0Uk+xRGRKNEfEqxL9EnPnqDo/UoYUaVFhPsUU1AWoK0XNETRkUakSfRrUH1EjRsz4KdyTq0cgaPOnUD1CGQFEBkVgP/EABAEDCUec9hQ4ToCbOFoKVibuoaTs1B8ApTpQ/LR+z2tEPP+RLo/sQGAIYCWm7haE7GPzRLpABRNUKgCxSLz+8SCtMTvIWgQBKDs6EAVrIA/+m0AJdIqoKxINJSAp0VdJXRDj80/OAizyAB0m8kBZAaP7UfJACAggwk+PSa0OVH+Ak0gIKtSBj+FKBSD0hNJnQC0mKbPSHT8VKYnFBaCsUPyp8yeurFj/xOqAhKvICeP2UK9JtScUe9J3SUUfdK+P3zpE6VOmJ+YWhPopxFExSzgKE++P3T8U/Iq80sFKEAj0gFKCAV0o9LjSlKx9LZSGUp8SPSo0wVJNQLUDFL+CrUqtMWAVzzasgnIqySyMAjUVQ/wwyLTCl6o1LTKbOPykAACYP4LNLC2m3J+0/vPv0VVFusjMIwCXSiAJkViAgxNk58QFUtqcFSREBqrrTX02M+yQFU3NI1QBU3oKsAsCebqeTqUkIKtSRqutH8AjgKcVpEe0vlHqoAUnQ/vSy0n1Oaq8Upw/sq7j+tKom3xWlBDTsp3ievTbUkirtTwgKk/2nJzpUVooYp1VEcP0KDs6/TsRWlCNSdqbil6nvT78SRElKW4/vRdhaACCAqxVidZTmUV4WhQ3KCNOVUCU/wKtQ3T11LTPiVBQ/1RURIVEvSSrQFQKCrUVNE7Rs0/tQlUMp36cKAkgIVQDUB1DtF4AV0pNF7Sb0e1OlSeUs1QxUUUmlPlUYVFNMeoCgK9RNSw1FlHxTqAFNQjUT0W0/XUYD8g/cApVH9IFRKqD1RzTj029Qsn7AKihhUlzq0VtRM0wdGHUYJyQCrTU1I4Ks6oAJKgImzzvNS4AV0nieDTOz/dSfUo1GACnT00vg/yst1KVTYo10vlG5UoVMc7HU0UbtTvTEj8lTGArp/oCcoZVH4/vOuzzw/un7JuFPRU51Q9LQP+1NqhfVA00g/DPFAFdSzTU1SFQ4tEKxQaPEnxWabPVFqxyggP1p8VKJREKDCsgAmEBygwGj0EEVunDqJFFCsorJCr9QDUElJNPbAH9FdVEU89ArEt0S9Q5SuVS7qYAmqXg/jROAJlIiAl0V1Tmn9pudWNP71ZNIqAnz/dWYpCT4qpLQWUbU9jSVVKwCnVc0UVPECrU51QJVw1FFQpEiUDylIDCxK858nhLQlL4tDUqiyHVTVKoBWAhRWVU/V6gJrqaP7JtoWgP51KCghVKJyah6AqgINOMAV1fbqcArztgWhP5j8lCDPhJyMS3R2zptRIAvqJI/QP6rH4aOoOKwMR/VxUZVVjSuAKgCuAizpYD4nV1XlXsnr1k1ZQm21lICfWVqyc86o0AKaitREVSYaOstVJVZVOkALCiPRy1hkVYFoD90/um70VylatM1kABWnhp49U4Akp49ZjWV1p1ERWfAqw/RO8pyMVpWtAKFVZWqho9ZUoaLTK02A+ALCdZPb0nVCXUvho9QPQFT4xOoP5AKgC+nmD81bjPiT1Kl2P7AIdbusf1vMR8n7KB0VjPZUMg/tRCVwtG5XBVAICHW6Kw1cXW/j+1cfXEVwNa8DCpuY/Inc1WMS7RnKGNJlTYLTVHnWxj8M9AP7EBqhoP/V086WoYqJFPVSuAI06+A+Ve8VZXYqNCcSP/U2Fb3TN0GQ/+n+1Co/LSUUiQ/NEnxWFQ0rDUVNFWsjOpi0yo7VDleUoOqCFWdXlKJACdP6V5VISpe0oFJmAn0SNbtUjJ1g/ZUdqvNfDTmEBICyAvj/JOpXwV8yjqPz17abQnfrTVfKAvqOteoP11+RAdXlV+KbQnJqMM5/UAD8SsOnJgLM/GrD11Cb4q61+i1cAhj9i1dS32Big6tXj91Rwq9J4NEcP0j/9VRFYTpYCHXh2Aid4nExWy00oNqXoCMPwxWACMnr2DFMqAnj9QBoA+WFY/UAcWF9e/XXgKVKjYagItULYXpwVhfWRD8c/ywyKVrDMo1sMICROugJAC/UvTtYCoo0V9AClX5k6w/dX8V+CjSpW2J9fpUArStisAv2KdbJVC12FF/SOJttL2sfTwKx8pW00ZAcm3V5lPUm5gGLCOAZMI4Bmwj2FybnYZJudK8tDUYieRTmVT61ao2sLSl1VizrCf6pdKQNj7YWLTVW3FY2QA/1Ykk6tiWo0U5A/JYuVNgC/SEqDFfMm30hIC/PxLNRAEAqWDCjqAiAIibPVnWLE9RX2WKVffWyWVFDXYuzuzqaoMKAtOZWAE6lEdQ+UNVD/UG0QVepSPKcC0AoXD99ZRQxqxs9Co3TvlQ5Zip39Umo0Ka6jdUA2aFNxY0WMjqgm0KDlQ5UvEASf86n0uk/GTqD+wChTi07NJBTwU2EVpTYU5k+sAiUNKsdFaWFA/lRnRWlU/FYU7VPBP5gJKjDT31EKbTFaVgKyNQLCeNOnR9AINoHSe1clfzYoV9tlhEqWNddZT6xI9VFXv0h0/9TXT/lmvOgWBdB5aLTxKchPxWZKhdaN1OtJ3PE1P4ClVIqGdo3RAAI4C/T30ZVPvPE2To/DXGV187naWj/VQJaYgKZAFP72lqd5aXj+9TZVDp/tenaUxLViPW5sI1ItYEJtqcUtNRVlZQsgWo86moZ1ENAurHqvlcitM0r0/jWH1SFkWnD09ikCtNKGFYPXIrNiyondUYdHfXeRIdNxR3gLLDCn3rIzDHWhgJDDFQ1Vs1e/YBp/tfnUQWu89CP3UgE9nFdFGQC4I8RVSo8GsBSwIkA8giThrBFK24D5bIg4IKyXECQytRbHgPgQCC62zVs83vxu9smF+OGskICGoEQJArVhaAj+TinqgYgDtA2oz8LvhTYXsCOhYaBEGSAPkloFgIEINeW7AMgMLNKoEQThJU2xgI8E3tgduKaMAPMf+Gjk44D4Dq250swCAgPNueCA26SuRbGANwDymoS4duyA8h4Fsm4ixMNvBbOANtu5Ew28tvA4igrVvOJIA5AcYH8APgQoC6lxAa6DCy0Uu3bqBlVs1KKo3ALYrbgPIDODkWza1QCpR8jhqA23Atv6jeXAhHLcDANlwDcB2/AIuA8q872gYRgwsidPb1vtbnSq1jrZSA3gIgCFQYAPKg4P6UGBACnWV2oCmArKGlhtYjV1qcnSJD/KynQYj+1hQo4WpwaOAmzvFfncSxLgCaGj2iKiRRPVBlYjRK0WgMLch15lXZV7ViNGhVr3JdyLcnUVFE5XkUctylRs1A1Yio1D/FyFaiXJlXqozz2E6Cn+haFy6AkXL6bhcw3Lc63ZCTzE+etDBU8SADDmP0EWD7hQID5K9udIPqA+BLLejc/N782jbbWytz6H0oDYP9dAN6IP8GjhmBOKNDSzFtEEuG654aZMXSs0HdKE48PAKTgiEBcXJzGiohHshLgDuJOlyYDtb5EctvkDUBX5nmD9APkigEZ3V56wAvlCQbJdXy1ID4ESgPF0C89XXgIuJIEIQkg4aXYQkFb3EJ4C+DXjP0fOE4W9w+WJIQswkgMMBSokMMbBN11ciqW34O24a3bQP1dO3Yox1b/smlwGjxGjEelbTD4YD4YwyKN3K4dAOV2gI4KrZcQx+nrN3kInoxoDSMbFxEMUXEO2934YNiFl38jcXWhgQFLXeIDrdgg1d10A+SJQ9sGjhqgDG2B3RoY4YgBe52IOuBiEmpeMBKgDdY4hQIRkeGvUAOuFMXiqog4aghQDGAZ2OINbc9hON1UNFSQgV+JIBiEjvb3AM9jjI7gkgLYNDBlQDvb/3ZxK4DoArIk6yAW38iSDWFxBTlekBiAzqI4BS1stHsTGhiWugHD92YamW4l1M32hKYD0eGhMtuCyb24luDNKyJ6A3NKmWBw/bhC+giKJY3tAIeHs24VupJOyXQpBe3hmTUiDvANF7oAzSyADXe825YIDdVAi8PBdXpI8le7fXwZKqrmBJQrNc9Xbt7VbTDQITKJIICN7jbNjlgNjdmXagP1fFoqgIU2FFydt+8Fik1s2te3vF7sEmhfoI9bcisILZJahfF7Nbfj2wSET53sYD4MwqrzfAGa3z9vqAxhKYzHbiBql97JXjJQezbgh7N9+7fW4NuJJU32klTbjjRV+aEqNgZqZbk351+YKzXZF1xJU34N9yFLDMd7iJOglV2tfPiTt8SEpis1+cA+Xvd/SD8gNd8pe9hmV78/wX+ID5f43vduafqXUMtAGjh/B5KA6NmV4WA4TSoU0GjyrYS4F7uxN0aanysKuQXDgMJqeF7YBl5MTsMWok6dBg1tvkEgDJttuMeYCErHgNmQsrEXD4BeA8A2gMgBqA+K25PnBBDh93BgVprZcQX8YGADDY3g4uAnHZXheAy2B4CgNjdvCfmAJKwyRoIDe+Fmt1cF7ik5OLKtjOFupcLTKN1DH3yoog5e0CDA4rdbiJ5PoKwiTobO+y3Wl6KKwjJjsSXEQ5gkNb6ia8q+rfP8E2mAv4M94W6MW58ijCOW4C65dUhC4IgDt3vgNgEuPkgYhg8JaIJUAw3Pwx4kjA/ODrBf4QGDUsN4Ql75M/g3JXAGViDRo+4a31BsSrN3dLUWOK4RJcQDghP14WT4234DrhOhNw0DemtmSpaLngOwUxgCmWF6PhU3mOFSA8XmOAODvKiDsSF6y6ggpc9SvgyZdRWzYIlfK3XYPrbf4YEY4ZiHD5vQizYYkY4E3I4V34FKzDGGPMMRzluRN6hIF6lLLzNFuoGYS8rDaDCy1oSUYgDh8vMGj28xRY1BiTuHG8RI1mFlhxgMt9sFN4cdsfd1y4ts2Fmwt5OYCaYcwWaCVXg5qDh5gOQ4gEYhiDRrdSmNYmveW4dFwPb5Ydok7h4MnGHlh6grANTfu4fd5bh/giWAIA6hmbfBesAPADRL5s1WIyCF4al0DMKNRlwHJc4EoP8sbYkIUCGjg6AO7bW4DDUm4ihFt8ZLn277K8XEBYFt/BFCJ9unhABDQKnbqBLI6460hTN/pgMAMlv3hZAM90ol34pQ3Pb/2x96W024p+EAeo4QDr3bfsct8BfWkrd4BiGTbh6iGIJd+LAFfnqN1KF5GNeCjcJq5GLGC64tkhkGjy0VwskjAldvBLRYuoDbb1A2GLzbySiuL7b4tgdwPjAYb2MFcIYwjhrin4xFv/jDpI9vAAxAMmMMA84xeMgGVYxuLtb44ub0zi84bWJqA24zgDXEw4v6SPjOgouL5jSY0Ns3jFY1FvRjLYyeNZiog72NBEw412NnbJ4yONrjYYytwBjbYtlwq9M4kt5mDYW/1wTcHXBeKvjigjmKrjk3B9wiGIYquNdcBJdgMK4b4cQlyYgPkb2OjLxHKWQAUREYWxGGTm0X9OcAo5TkU6FCaH2X4XgcwfdAzB97MCaQ8IIfKMXgd3oJ3BfAgyamMyIWGLGhDWEarbzdzdnj24+5lg2Ah/ARdeBg8IPNkBEKGQICVLkWESLG4DWPtkGE+GJBj/GbYDCO34/gJZbzZBYgzkK4lWQvkAGjGQmIMx7waxhdMm+JXihXEGQZdPhMuRXfzQX4P1iF5FogzKjgMN2QW0FcCKlkPX4WRyNAgj2Fq/wZEo8nbYIdZsRkfFCwSkCDAkLZ9klZHYSEEphBhCfka4912SCHj2wgirV5JUxgA0YOoDOZYH6oDlN15E7hrkiwuJPFj+BJoXxklQEpX4F7yw2RZj3Q5kF+DaHbmR9HzoAQDvhIX8wr5kz5G2ESMeGLqrCCHiIs10A3XmmSLI7mWEgBkh5PIDfkwy+4Ri1J5SGTDkQXTg65kA5ReUjkdA4ORHlLZTxqeUJSvYJANFZTmTDlSyJRga4eZR+SLN1ZIYXoDbtTBXADjZH2VgUPDzgw+Cu5W4DS3ELHGTAAv5VWIjkitdmVFkrZAckEA2RQKAFNXSVJ2BkijKYx5NXNqGRxkfA2g9rdWTjmD/loyXV94GOlCTiKe25ZGQYr15QWR8Emi75PnkXkrcrDk55AeXSETBN2E0O+S3OXfkGK3106+RgMZkOOXHooWFglGWADZcBSRgUqK1EKAC2AWmdaZcXIZhQC7lNXqQNYDEZh0jvmEmdc2+CHZiwC6LoZhx4iMlZiWWDmMYHgORcIBo+ZBlGBnN4dNN5jS5eKw5jWYYWuHRQMKX8NSaWiQoTJrfBjmE+jH3gv4WWZAqALkUgUDvGNQNcD9CRATdet5kA5dDmBLoRLBf5PxoxmQX/mRzI7hnQUxmQQLN2tej5kGXyF7gOFscCtZgWEYr123OXwGaheIDxDwZnuEjkGZPmRRH3PegaPmK5h0sxmNGRoPrmNE/GY0MJhX+CzlI5l+IsDCyzGUZmlhEuVBlYZweU7nC3treRhfZRGUZmIFxGW9nH5SN0a2A5BGaEEuZoMerhZKgGcxnOBLhNuDC5k+U7igBekfGJEYUubmZ1zRIM1mHZkV6HHxiOGY0OtuGoZ7dWZjWBddwZ2+dnmHBlV6bneBvmdfg251uY0IpZ4RnXlngkOEzHxZjQDmA1gqWY0sb5voaONCmec03d0hP+Thh6mQ7IBe+Z1oyZgdR2WB5HYN+AU3nwNYeQjgL58F8CDdxzs1cExy6Corl5x8QTdnoDNWFiDc460w5nAXo+eLmKQRYDJm7NgaBHb6zeOY0IOXhw05Kt5MK4hgCDiugLoGZuyzLbRZROb/mHXx2AkrUTKOedNjYKWgKDWk+AUwDWvEmY0OEZjWY8aMSewilm9g5EJgI153JPFkntp2edDmRs4OC/wTf5K4A2ZjV5pdNNwBZVmHBsmbyW0Tad0vf+ik+g7nkZh+g9ofg3OiUNbZh2gLnraIl2ULKAr18lldZ3ISPm/AM+ellf3muY0KIQPejDmHSI2eMbo5jQIKIWaBBgReW51eYfC5ZjUiNoymdeT4DdCFmi7dm53IWAF9g3+jVgAlbds2ENZPWF4WXZh0gG8FrjGYc4b6HoI7bF4FOi2JrprYk612aKoTjpHR7951oBaDBbRb/3psc4sbZ50dXmNZHCZcGa33cbRmWAkN7xfc6VWk6Dg6PjNWXEZ++ekElFAoWHoe4O14Bnn56OYdnjnomegCtaWml9nWaUmilJqaU5owaq5l2jMwbgPOl0FMFFWRm4aj6WY1InGjAUpgA5X2DcMV4OAufBs6TWenIt5/N1uCFlOQC+OEZpsObiFg1pkNdeXrOCjgtPqWC4C2GNd2TeAR2GnxmwhJ0i0ZD5yN6JdrA2NjfqAhmoNjY4xbmcuEspaOI8Zm6Bl2s7jCTuodiMZELTBn55Rl0iZm5lAZnqL5TuZFn5l795aZm3cmFDgvDD2fnpQgh+dhn56O46gCtX8F/PfojRSvkCM6deTtf0ggOpdkw5/OgUZtzbQhDNuB3GDVpAnTBucNOZWGHTkR5yxLjKgBNx48FgGAQOC1MWybgzkwWyZHIgBYLeUxIt5yOCZKi5uAskqIaDcqLpTYKjo3KvyW91DkVBeV4Hde6sB+qK6Z5d7LoM3tl+1q6EcS1QINX9l+xK1W02hISu4HmC2CI6TWr/blk+eC3nlOGusLgeKz2prnImAOaJbWSr+c3kFE+2V8MP5SOA4SuiTuTSCDXV+S9moXV4S5bKAhhW/JcyXetELGtxwg0MdXb2tS8F61h6LrXGcpOSrP5tAmVbWgluk1raEs4Dgmt5UV8YJ34/eUZksYXGVNkUghutVN1h4V1zn65SbNWaMZmgIemoODI0DlP6Feujn6po2Aprm5muBC4a66QS7ML67oIeAyXuV85g6kJ94Brw6RKaOZCx1GvJdkA2Mkngea7Gvjjfa+ORLr84aOviCPZXWveDYa+LXZN9a+MoXKAhTGvCuQBLq5rrs5mpK5go68LhuUJ6CBX5NRBWmvjd4YQatnr47AmvDiTg9V1yGVgOmEloj3Teq5duwr+FlonZTOxQDkYJ4jXsS6IF2sEuasulRsV7E4S40wXUpkxsTbGYTdN5hDV0Dm37Fwb3iRyOQSDma6xJ2dN26reVAMbBP2WOG0Fb+pPp1bJucjp1ZxZlgCvZKbFrrrW3+yxsGFCeT1snDG+wXmmHqcq/rB2xYKxr/5WecZkAkmuagloikGCygQBCmlRdlmbYIlri5PWsCVvgjzUjbsajGF7b15MOwVbiQuV04QhZUWx/BBhSu0TpyYS+XNhJYc2tXmWjt+BU4M3a+tXq3heOV/tK5MuyJJI5x2sWT55eOSrnHacebXnHBEoJpkt5T+cjlYYLe1LsuBE21BN2XWucblYG6+r4E3ZbWWtlcRymWAD64vW1XlYA+JK7lg7WOtXqDAim16OEZxxRUI4YHoSbtojNQIWyb63INaCp30utXptbV95blYYM+F1sXpq+cdoU5CGnLJnBLIRFkf4RuIZnD2x2GjrlbX22nksbeO3YCWbbGHqG0PHds3t5bdscplfbWu1Rt17ee2lrR6imUztdbgAJZlpZNY0DfQbhuEOCHvrIJpbcikGBUCpZqN27sm4pt27l1ZqB2BnjlflwptV7km3RslCOeBRdYxxzeRItiEINWMPtoAU3uXN2exPlJmRG25gUNsEcflMjiAkQC2JqYZ1lHiP7iLdj7K2caI/yfOB5tiYAzH7jEmNefMMyYN9wGDUgMq5JffZKmsPbf7BWZbfeW7mafnI7BWyzs1OGu7Jsw62DFrg1DqG7Ppn7M2cNux7t+yzq07tGaYA77MYIkcECDl2ZsFCP+6/lQOw+YFHz7MWDtvA5eW6TkA7kOZJbqbkIN0T57xN3Ll7ZYOVzosbZBkPnIQxWt1bFggyA6T57QAV/bqbzuWBvQK5Gwnmz7EmmYA7giBHGEgZL99/NtbBWuJpPbhGPRkLZyMRk3nbzemrItBI+wAqH60994kjBSuDTftAPTyfenK1e7hpsrDpkQIosyO+Xvk5T+zHm3auGT/vpAh+WNnF77ASnicbU+XXsw5yO+/kU5GGXcFLbrZgbIfXkW/PuQhN+ELq7X7N+vvjqh9+WLGikxbtfwNge3BlQZ9sc5LWK1AO3vC7sWcbv+595W/u/8AGW/wCTdcggCsbC+YxvmxvZ4gvfb3em7rcx7yA9LDcC5OxkdiQ2ZiaMcDUq+mjZHYZXqcZFGsTeHGqub3g/zfXBWUB6VvBVmHBQOlBwYmdZOKCc33HBqAun6KpKAQh5T/kUi48I2FODR3EWmI8AFE42nZgwqdmJMv+Zu/EKocEW3E9RPiZNE/JhSHAhzpabARFzxQ8UwloijcXeMScLCHAGyAu7/lRzD/USoo7xHLWCC5RfCVLF9RhiIIiAG6LJeiCnCgLuUglHqhMAVTo7+5GIzmkYbwsIgKaFFfIbKHNwyTlkW4aoxbyYCeJcK3DFw78LUXNEMh5PC8lpcMILmC6xUjK0C6xU8XtGJRgiHLF/JlAJ5GFzghQ7xEGboZtOExmQDvxXstADpc9xmwV+AzzA4DmAX6tYO8KCjIKBBMGTiUv7GW8KMwAgmxjXFeKxBr/FkxaxkHFrxb8XO/LxdjKfF9OIrbExdHix0nGsPZcbEhrGmHtqBnHPzFww9xvBL/HBIaxwiLNxvxrssDNKyVMvlIxyBAd3x3SSIbNlIybfHlMRSm8pDx7zMwpjMqcdUthfP4/QWNx/8d4eyvLRrstfx3ybHH3LdpQnIJx52683mkJ8h8xFoMl+CN7yKTM3HYKzchgN3LnS0ZK9yMy3eePyOuWYZqrPYanJK3jErZK7yVArtz2+RnOHJFyPAOYDkAzclWz25Q8mch7jIgiUajOBxifGFxVlnnFaAX8Y/FjxZ8Zg85xncXQnxxpTBAIwHbgj0s817y9ko9KZAI4CqAhy9knAqAAgAJQC6xuYIiF5Sk1+kCOK1cpM+bCyUbmTDptcY4H2SDEs2W0cek0MDdyO2DsYzhReaqMMhRYj+QPBRa5BNLhOJRW4OR3fF6D6oEHLyAT5Pg+nygBcwxBwx8oabDMgAEjALGiTmXFDOa8IfCjjycJCispeUucVqn+2AlRrXNxKtJEnrj/NfjS8AFfNNRI81FQFzV1Rs6sAr2sdm7zRD9FIrRKxLkS8oXT61HYnVTqPNrYCD9FnpU6VatWdWjVZES7VuVStDwP0LTVfxPG2Jk9gQFpvvDVcq00legsf1clZXWjU+tZXRIUSVP/UAj/JOqAtD9VQ5T8VXtEtzerI1G5VE89nN5S4D8FXus1UhfNbQL1rKsNz8V4tLhz+p39ITRJUgtOTTZU6MVhz8V/1pfS51L9VLUxdAlJKAiKKyc30IUD0+Gsf83U67TFc/CcgPx2Nahdz8WHFULQb02YKtPTAIIChFbUhVIMCrdEXODUrdCtLbPpVDnPxS/c/FjD0Y0OVJBWDUGXPxX+VhESgAlJ0PRzWEpxVHgnhz0NN1TIc/FmHaJdFfQLVK0ThOso0c/FGbZvqMPSqAqqAK0J0adFlA/ROV0vS8oyV6fTD0oJwyynz8VF1oL00gItYenEdMtQtXMKx/TTUn2BVOZ009LVK0Ak2kCyN00gLNJIAm9IlItz8TsdKh04UD1qt0N9L1iZFbdIlKrOtkAXRSoZApnSJ0lzz1dJXYgItWFVJ0ltIlVmzplg5X3V4ShhTcVYdY3Xscz6lA6mAKFdrUZMKvP11NV43VdUUU29KkPx3Ks/vz0qF1RrXrVPteb1Z0sVOlUa9CRAFWYVGvQvWV9RKsf1jz/NdV1f0pvRbOv9EfQMQB9Eygh0U9ZfVn0XVetItUa0t3Pd1bUvlL9Ua9HFRrWCcrNrN1w02yrqAkj8ICT0kzzVRv11Aq3SaP1V79Rqn9p4YCH1W9aHOdPw9K9b31Z2cXS2q/dZ9KnWsdMHXnQP0ZXYD1+9NXYUQHdN1KjUa2TfWz2HdOtggAh05nYp08j8/T3S4VGs7HO0LLnYV1C0wvYb2D0xES3Ya9QPZDU+V3/Vn1GdlHVvTGJt/Uh0UAKHUmCm1GtMgm+VSc/CrDJvlg5zR2ANKxYHpxNP50JUx1YOox9WNftzWV2yl7TD8/1Q52p9APV8oXUw/WDFYdrXQnWYUw/WR0M2q9KtzWdDvWd2s81nW30SJ+wWh0T9bHbJzZ9tXRhTD9b9LhTD0v1MP0cUw/XP0eUu/NnZQD8nXb0kT8fXioDUx3XrRZUx3Xz0p9xVm9S7dxXS119dXSyNTD879Md0xz9fcr2GUx3YfTD9iKd3039znTl24UuQ/72MKJHY13OdjpOr0+Ux1ItTD9k1If3Xc3fZZ3Z9DVMDzWdmVMd1Hz7HUj2cqHvUpTD0yFDBTIzxg/WrI9ClhRZQ2u6jHTMqwKgcnWVlfblUyU6ix8nTKXVJIsjRJ9nPZF3G1BgAn09VZVZM829ojTwJwKd4AkddfcD13deFCT15D9HRxT3p69PnPLU7NWPVk0LMVyCmxLk6V1P0+9PtEqKWVZmsf0r1QvRdrI6r7XHUJyiPWULRCdzW+UVdrTRVJ3lHl0vdxCdZRUJydEjQCdlPgvQPdofg2DC0w/g94MxJFubxobGl2Zym60PhXfoYZezztEA7bihqY4ZY/VSK1vQWgAtJ39ER4V4NYZrgyzV2DXgz0eVbJWxVtAMLWSVl1EmDC1qtUIo61/lWlW0xWFrmq9xVtgyP7Be4WGdbZqMvmD/YXFz44a3QoSWDC1nlOZWYLTFZtWcUgtc11L9BACkoIdKnTvXUEBoCzViJ65OrYF1AFQFzz9yddjam2bldla79qPU6Alj81WPXjeQ/ZBcrUVnkMnEXDk8/5G156c3XsUmle1XuVvnjfW8Kvw/DRBeTFblXGj9fk9W8dy3lFW/dh/lLW51wte75P1yY/pSkXDgC/TG9BVgBOf1IlJYp9WBa1bYIWB1o9Fa2ElhNcb2GnWknVWHdZPZjrHtFNYg0gjDOrA+JqbbXmWZtjLPJrH9T70h2PFY/WP2X1NcwjUTo/JRHWPzDDZAqetcPW9VwarpW9VxI/hZbVgVan5tVlNZEp7d+dmFQnWZzDStOWLK05SEpyYChTmUELDDZtKCNnen4dN9nUnrk6lpQP42pESpR2J3/ljTuqGPifZCgKfjqP62fg/v0/qBvodasUlnUL5XLKdqlXoWqngRatVTNUDavUxrDAo20d/XatW2BdITV7+Ka0owxUAPDTa7XOcTDc6iDF1Lh83kF4/ePb9d5WCF3lpPtrPgN95iA2XmeUjfR32F52OhXdOvVehep4rAFK3o2GDkaA/OGDek3pjhreoX9IiXkvk+GmpeKcEoZhhe3jJiICs3jvBKF76auF7eN5wWRRdMmTG2pe8XrF6btIYFDcBdJwF2IeSu3cLMjeA3Bl2lgAD22G/dH2yfsGJEP8GAtoVYDOAvnrHW92IJ+XZ5Cfdo3eOBLgTjOaAlCp5ocrCF8XgGpIIOID2pIQyaHeEqW5bCoYBhKhFt3OQk57Psrd4Ajt30M4ZHmlACLhr/sC/wX8N0cA0jQ1/DeFb/vAdepYOmALfGa0du/pl7ju85uO+5Fs3gTBo9/DbnX8N+SMxpd6oP7dX33hpeI4bmiw2E5p/hdbkXssoXe2BKfKigQ5qeVsEs754yUFygjgDMdBazZ2cCUg/xkPfIDFfvlzEe994GDcnBF9VeejK4PNmoX9GWeAzXynALKee8AKXhuC795BdBM1Uwm3wBErh0Es4rOEA12W3OKeJOgODr3b/uFHqeDoAgvq8Ir2yb5ceG5Xx5Ma8BTHBfjY4xNwBjpXiQsJdT4ehCfJLXV4REEZW6mdrsQ7YgZhhFfHuuZnjzP975pgBX+e/du/IWuZbwXqHhOSt+/oikEle/obIcEXRvJYZDw3OK18q7Bbhqv/HQQI6difLPrx8uZojhR8sEsV+3cGfMV4ZfcI3l+D8uXRuFPdJYVWJ3kUYVvqNkMYVfzsG0P8GnK2gW7E3VpDYZiogStqiGGce2/Qk0HhojRQNNItmKIDPdd/RZlhhT7xpWHpybqHtPIt4hgUCXD/SADlY4/SGmZiafT8479LhNwDx9Jyvex/vRAOmGLdT4YWGN9DfVxjFhl4adzz9CjRWGgjhYuQQpr6Xa0uh8mYkPhSIhas3hQE3YMWD/4VzI8p/ka7FHLHmhmpmSJuSbFIS5nf5QF266MSw19f9ofa02NhG3pvs1JnBKeKB9izJALZkw6hZuiESyLceceN/Y33LhG/Hkw4WxbaduJwQ3Acofkf6ZU23qolfuubhAyV2qB996LH3u1e5LOqgW0fgQZh9xyn/31+D67Ix5lzfgH4b9+7cAoMFA/hmqkaMezX3vJBfjOp3LC7qpW/qFmAQ65kuezUhP+RGAf5LkwyP35R+SHcH5X8NhL91oMefkYDT+Vb/f5b+bfl++6EW/mYzJ+UjP2gz+efjuWFsWq3mweDvCKH3dg6E+z/B7NYOkbZ+lfp+5ARya+aA3+p3VpCdGLYdgIziRfrHvKE2Ru/6llU3buDPImYKP6/G9/sf4pvNbGt5arzmRBim724FCtf+4gqP7nHQfuq5L+7wgoML9kA/XIvb67p5GQE2fdw5dhqGbeWYEXfdwPjoA4XX6vkw7qQvBI764vs0K4bCcF/Ilfd2t7/MANf81/LboGS+A8Xmns14V/0eU7dl7C/9L9if0/3Np6f1Oxh7Nf1u3vhJBtDJX93f2eR3sSf0q0hlQezX7d/ffyMtzKi5yP8s3kZogvRb9aBqzLvNf4ugabo4/e2R/ibpWTCZabov+Fdj/yuTCMp64Hs0Qn/ke9DhMf7wDJ/wb02zHvRg2P3duTf78gh/zYO3/VvTf9m2lvMbw3/RfYZSX/J/2zb2gthC/8f/K/+3/OMmH/S//n/03bGzGXLwkynhGO8fwWPAnKBBKeVHESEcXM65XgWSwn20eynYAo5YGQ4KEkbOhIVwHAGYAs29GmCkURiAbAXK/AIQX63PRoxAIALqMN4A02tUdAusYBYBLAKyCw0aoBD2XjAMWK1AJoArALYBPALRXGynxQsBxl5jAM2FVANjdm+xXi0uyEPBARYB5AL2EEAZYCSysASPAJQJVAPwJZAWAyYCUmsLAVjUlAPYCzAYIC2uk2kecNQdkj/2aO+K2rwI5X7YDCwUs+4i4ghimx2hzV2QkrkEUB0GIMwcmTGvQnAM/MytuwTYDXAe2fclPG8WyiW9Ejskq+mmIESVt2mWGoXwC2SoC1AUYCSy5oCrAkXqFAUxQlAVQU05EQUyBRTu2vbEKa2Rl0GMtDoAtyW/m02QrNApxlgAYnxiB0TbyvgBK4uyG6O2NAWCxUH2kwIHs+0w2zitxkc41U4F2eTy90t1GzituiBAuwGtDAgX3CCSl2s3OUIEQImvOQIAJaKFG9M+K26IBxAD0Aemn/AaGS+3ZlvckeWaI3R00c/NhK4+vmG4OHwsaxQwhYuyCSOMQHyyb0Qk6yzCUcBBhhiGSoGQw/wbQEHAk6PdBWsPUWEe0eGmGKvIFkMUV5iMzQIk+6QawBWVzyCbwNYgjH8ek44HSRuGoky3gOWhpYCS5JxXGBu14KvQl7U1DCtQC8WIUzckHcCFH2yz43w0urGcc1bzbCu/A9s24zFqmv2XW2ooFev5WmmGNoFo22Gn8wOADSm64Jmu3WWHBOIJ0wdl26HtkritrYHeByBWUCZWzmvqQlkGamyeBtwIiakwx4EHAz9BS2nSB+YKc10IKiugnv7BVIKaCw4Kw2qyaICJQdu5dW5Ezy2wIm+hX4EUlwEltkqLA3ILQ4N33S+Ggma1v2BG/cwDWAcggy+1104HCGuLBd4Lym0WxJBfmwWDNT2O3FHvuzZl042lEMU8JxLyTD02sNiQS+WHmG44AG9W3xW+akTmAqAZWhEMsGIKk+m3Mx5gIW2jUecx9AlLBJQSlBYRkQeJGnsTH2lZBqXr8vgX4sL33vpBGX4s3CGpwM22hCAdQUw3N1+8CIgSO2mTUwxLUmoyQwb23oV1Ca92uAAaCZc1wHtEzQ2uKyBgN0x+wJqJ82SwxLQRM2Y2yU2u3LwK4F04+B376CNWU6XJRfgwTXL2zYVwtBxT/AyjCBHB6IGEynWSw2JGUY/kkqLAVYPi/0H+m2cGU6vUAvAz8IPs2MEws1xAWSCMgdwzkmmY+5mnc9bTX0z6hoxAt2thAvGi4vNYHO2f0dlCD2UY2qksMgijIbB7WTC1sG1U+ACA8yjGthAHUyiMSmQUzhGacAa3wzCEIJQ25oPU+FIJhBKYPUhGmwuyjGdrB8H9QBsGaItvYQg31GEg0XYRJCH4Py+4mSxCPklTAp2AI/52caw8Ebuvwl80txoGM1Xhow2cQOMxOGVgkJw2w2t4Oa97kKmkW10o2shgRBVV8MDNUAU1bG9w+3Hs8B0GmHBeki2+9V6W+3ITY1DAUq5jHAEQAmcjCcoTE+AWYgv+wX63ymAKEhgNS/h2Aw3zUow5L4UC3ykoww6YUKyn0bZBF4US3FUniAZYUQCFG+aS0mXEGioUk3yoItCgIUu2sIJNCm4BxA+IUA5J2R42W14qztkh8JVWzdAYx4aKHgSmkSmU/CpYVWAdYNIm6wTI17oVgAY4VYkfoVgBrixs2SBsS34WcaBXgDiGgoWE3Wmy6wKV8ZCwwXiDM4JNCxWREzkYWc0OkyiEnYWcbrEq+lWwZgtty1PAbHGk5iBiEEEWV0wEn6OZFgS4Ce0w22MG2ykGoVrAQl/62MGLyGTGg23V3Aq1SWCZC8m7MvDoAE3kG4U9933W3tmJU2t26W3nnvLAfG1G0wWQ2vlWHgC/WGo1sSAE2gG2iCVGae2222rCVWiLB3G5gjZWBu/9oG+/jgIjA0khkt1YBfCpYNct1IC1DIoVSCMThrDJWxFCo24qxQ4ZBAIYZM3viBGBv4ZfALYZFA3ADEAZ2hSkW4C7DOYZ2BEAIw1ymzdA74Z0NiIS5DQWOYj9zfBCvDUYzNWSky7GRW90B5KQAkc6MAgI4vLYNhDVGyQ1QmwU34oamza1/BDX0kMwAHvFDGAmuv5hJ5AjUso+4W/1B64CIYOAMKDNGW8zkm9cMaxTmBBWfC0moTszkyIW3EV1el84ZYGSBmrBt4X9AJITlDP4C6yZoZGVED6yyKH5c0eV0qhzWKeu1oTGFvIcigv4cm2SmTrCKFwOz4TYI1aA2wwRYRPDk2pavAGuezNWmxA7Ba413kE0kPodUylIU+yf4ASYbXCCiFR5EiFyZMi3SX64VUXCTCnC44lkXcimkXhDt38SJXCVUAW0VE4m0XyBdXECD14eIKExS04pSZsSiUVOTN3GCnBYeIjL0wCjMh24AZDu4vnGIIDMkJMBKwBfDHYHGHCU4iCKwY6eiwUWO3ABiAOABiANwJKTa4fcANwBwANQBoAM4foAc4feAOABmANyIElcIf4cZgBqAMgBtD+4feANgBwANgBrECIfsANYftEDofyAOABvECDi4AM4f/EFgBgANIgpECIgoAOIg3EHgBvD/4grD7YgHD/ogXEHjjMAMgBzEIgByAMogDD7gBxD/gBtEMYf4ANwBuANgBhD+ohND7wBiAMgBuk4IhlENIgbEPYfhEOYiLEAoffEI4gVEDoh0cZohUAN4g5EDiweAM4iTEQwBnEHYh7EOABzEWYg9D+QBzEQohvECwBkAOIg1ELIivEA4fiAMIjNEW4fyANogOCi4FYANgBnEO4gLEIofhELYjkAYgBtEOIgxESYjnEdYjLEeoiVEM4ftENoiXEUojjEhYhXEJYkKAMABiANokJEMgBzD/ojTD/YgxEbYkKAOYilEmohkAMgBrEWokLEQABhEi4frEOojrEDgBvEBYjFD/QBgANYkvEM4gxEiIfgAM4hrEKogxEpogHEkIjvEW4hJEPIiVEI4fhEiIhxEdABojcwDHEZQBhEOYkWhSYmVEHIkdD9YjJEx4iNEIIgzERokhEM4hdEDIlVEfYmBEMokgAOYkJEc4hxELCRbERoj7Eq4g9EQIfjE3QBxExIfzEVohFEUoljEIIhZEUQBzEl4hHEI4nPEhYj6ANompEj4khEuofjElQBrE4wDEANQJJENYn1ElYnfEEokrE0YgHEkiPtEHgByANIlhELoi7EGiwfE/YfqANInjEGgBpE4og0vKYlpENIlbEsofvEqgBrFAIosANABtErYhzEG4okAMYgvEAIg9EdIltELopxEbonFEnojHEdIlpE5YqBEPohZEk4hvFI4hHE64mLEuIgjERoovFJImqANImXFJYpbEUYj7E6wBpD74ipEpYoDD9YizE94j3E6QBlD+YpfEdIipEnIoJEOIghFHol2AMIgNELgBpExIlWAMom/EA4hHEU4qhFMIoJEsojhFOYnNEIogxFKYhAANIprD9ooBExIoPFPYmDFM4prEC4hRFFgBvEnIqZFW4g8AMYpHFKYnzFZYglD+Yn7ArIi7FW4flE84krEDofvEZYotEBYgDE5IiCAOIq/EN4h1FMYmREz4hDFY4nLFlol9FLYliAMYoPFmooxEwItZEg4tSAMordESwBnE7UazEyYsLEr4pzEq4nrD9orvD74k5FCoglFYYnnFIIjxFcIgdFBotfES4hfFBDi5FI4n1E9ooDArIgIvKYqRF3op3E6IilFJ4q9FZ4gDEzosLFeka9FyomXFWYh7EF15TEKoh3FRYllEEIpZF2Ip9Fk4slFUomDFHYsOAM4phF0YgpE+YkXFoIwVFmIrXEOgBhF6YshFhopZFyIsbFCou7FKooQAOYoBEAIqLFkzi5F4IppEsYouWD0cREfIj9GFYtNFMYmBF8oppFCIjpFcIqvE1YilFj4t5EKYjdFW4vLEfIkFGAIqnEO4i+R9oxjF9og5EiDi5FgYi3FMYq5E1YkhEtAJLEQYubFqIiNFbIwtEP4pHFEIklFIohBFLIorEe4i7EJIvTEUoodFL4y3F7IjDFzYupFyYmUcZokJGMolRFEDi5FOYk5FhywfE6oiNEBotLFPoxBEDof/GdYl9FSos7FVYr3EXo0HEL4xXGY4gXFj4ovF9IiGcXIuLGjQBjFKYhHGlYsFFB40XEGIhxF/onzGmIyvEL4uBGLIhHF64mDFc4y7GbohBFAIkBGQIv7GFop1Fq41dEtoxHEOonzEuI01GqojZGVInRGIIsfEKI09E74v9FFIsfFeYljGNYprEF4wxFUIhzEtIs3F6YgvFaIzFGCokhGo4tDFcIw7Gd4ljEIwBrF0YrzFdotnEIIpbGR4mVEComJEqIr7GnY09FIIuLGS4qXGTYmXG54lLFxYmFFMIxXF54tlGzIqfEm4hBG9IjJGjozNGL42XEm4hxG9IlXFGIsvEoYsJEq40nE+YjZEyIhrEI4o3ERofjG9ol9D94u7ExYhxGgIftGHYsnGVo35GT4kLEI4s5E2IsxFQ15TGDIqFGDIk5E2omrEL43bEO4zTESogvFzIxxF+4wHHGYpHETYnRF6I3vFm4qpE84lFElIpnEHoyjGKI27GHTjNFNohVEL4plFB4spF+Yh3GGkKTHEYqpF/o25FJ4lXFMoh1GKoi3FM4wtGl4zLEOo5nEMo3NG3owVGPIn9EeYwLHOiPtE+opBFxIidEr4lpHVoslG3YnxFfY4dFh4gXEkIsvHfYf3EtofxHcoz3EsIwtHS439FLYrXFYYufHeI17HXokZEpYplEb4lbEF4yFEwY77HMYitGIywfGqYkYR9oxHD94vxFAouPHHIfhF24fvFj4uJG0on9EQIt2R9o1hElY3pET4v9Gq48PFVIplD949LF7I5dEwYh1G+4frESIyVEO4tHFU45FGEI9xGHYffEoIy5Gk4hRG3ogXE8oi3HGIx/FColLHJY5HFrYotE9os7FvIm7HNo8xFB485GFY09Fk4xRD/ow7E6YwZE5YzLHGI2PE7I4hEQI9xHc4+9GV4wVFj4fzHzInREQI5RFK4r3Hl46rFGIxBHBoh1HlYh3FYo5pHU4zLFCgBlEYowVD+Ih/GhY4NE742LHW4u3EYYweAYof9Gn449EtYnXE3opLGkIgHHLYrXIDIrXEq4lvG8I0FICV5TGw4jqlWgDEvKYgZGBolOBJInqR9o3pFBor7FroiBFJZAjGvY+PIGonzILYpfGioyhEpY5/EBYzDHn41vIQI6RIP41PEQI71D/on6OH4nfEQJCMAJ5CtEMIsnHXI0rG2YvbFpooPFdIpjHswJJHKIm5GvY9ZEp4lLGsIjJF1Yf9HRog3HBo27FigJLHKorzFl4qpFa4gXEOonxGeIlLFRYgvH9Y1OR9pBPEoZEBHfo/3HUYkZFc40nIXY/XHMIqdGxYizHHo4dIYo8hINY4fFuY89D7ov1HMYsNHGYifHDYgLGv4g3H64k7EeAJJHc4rnELowVHqIihGPZB7FtogBGAkL1Gs48dIt4/VIr4uTGrIhnGsoxrEWYsPE4olTHUokzFOYhnHXJEDFgpBTIuojrEf4qZE14kLEkY5BHRJEzEJ4q3GFgJLGuY5HIMpDlFGYvZGiJGnFfIv5FmIijH0o8xEdI0tIXYsFIS5E9HU4r7I6of05jnM1ADypiNE3CM4Z1c+nWzqYqrw/InwVrEo3SjCnOnjYoYVZqrbXOYrSHiRJCXdKqKCdiss1VpJCFIkpFFSYp5AWgucpIXJE5IasmxOspfFkmoHpIwAKFWCrNJJE6mlX8qHwCc6Ancm8N07urbZJMq9S1a8nCza8SJJeoNyiOpW1iypugKQiWnPapcJJ4Cp5JopqVJtJPHPmqHJJ/JLlZKrJ3iWq2AOqBTHIiwBAawrbU+sqyniQoynOaponikoiCr8H/waOBSJKaAPxOOntxAA6nlWsnt1g7JZlfcp43ShJIXVCIDlJs9E3jss/JIuTyHjWn+3oo8dxOtJc3T/JQHM86uQ/Gnt3VSq13VMUdpKG5u1V+ULpKOnxiiss4pL/Jiix+TbSd3BwgyotwFuGFZpMlCTQDKKTpMoBDnwIZoFCWH6U/u7QJMahvRJmtmFtyEMVt3Jn3aGn5QBQ7Qlf4pfHkwrN1AzJrSsQoiCb4ATigk8IlxMoh3bEoGFZ2qqVEQnSygrJvZH+8ZC0yrOy0y52ZJUomFZ2AWFo+poyrqr+FWuTkHeMH9pOoAQ5K6BmJOusWXeLJ2FP+o5XjKDR3eVJXIbjAs2EqMOAMKsNZPETgn10ykRK4BOQbwt90u0uFAaOneVZW6vVSNJK1KMYZZPqiuQMKnaibpJ9VSTKAliEuWwaOYZwaOCMUjkkAFscaqlctJt1yJJuQBQqq1ctJS5KwBhQKQ0DFsuXL1u8BTFserHXgIrHQCmoZy1gq/1ZEDR1NYoywMLKKVUorDyf8q/1ZlJEJP0qZHdW7H1YqAKJRYqeSg8C0ChEAQlagrTwMKuNpOyOvVswBRhI0eT5PiAKFX2nSpOUqfXcmzJlucln2UmBAVbCrMmZM+SlvittTVAq61SooYlSpJalJLJIVmGq9ZLg9FXjxJepS9JzFXXJsymvKBlXWqAZMYoYlISuQhOqrHFDuTvFFkoiFn2p8ZIrJayeQqrJTxKfFTIrmJI7KYJJBKf5Tus/5UAr15UW79VVY793OY5ulV857pUeq0JUi6JidZJVBWOFYYTYqy5SY58pMPJSyiaorlDBKpFWuH+FQC6EnNqvDpSK5GzqsoonjU8aGp7BjgKy8YxJPKryyiH7waOThZQkVfCyS7NFVuohwaOn8U+oBhWpoeoIQOB/oS3Kw1XnKzCeZKOnTtKzicUsP1WuqmwMKo7waOqfyjtJ6gMKUjpWysRibPK2U7ZK4laIpwQnmq43ZOrQlDVK1AaOAWFEusXFSfJWnVm7THP3Jo3NK6KXckuU3O+8HJWAiSBACUAZQk5pZTLJeACHKaFA1KwACEH7k8u6DFkjK/JNhJD1oyWSpYPJsFRAtbpYcoqHOgnxHcFLF1QyT/k74ocHWusRpYKqXQ/cUBCjhLHFN26B5Xk6/Xa2pfFQAWrXPCitgCHKMpTU4SHWAr4U6QTiJY8uU5LY6wE92r/5ME6s1DA7/pZQ7YVXFKMZYjLNXWOpanPCo2JWLLNnX6oppWooqBAUnrpZRLUnQ6pvlCrLE3Rkn95am7pg/euUJau6M5aepQE62tXZMinz1jDLKE9dJJFRrJH5YNLUHZSiPkS4rCHZlLKFyyuTXbrKN3XwuYFymqLpZW7KXSspdpZQrD5MjLXFawuKZWBJHE/EqBlAC6k5cQoHyd4sVpcaqXVXxLKJX3LkXTHLgZWA6Z5c4qdFR7LkXYqoHpZeUdpZRLo3PJLME/3LMpZpLfHVnLjJc/K0HYyo5XYpJd5LkBVpZ67DgCyTq5NwuQZcioXnZc7t5Nm7IQCyitpZQuHpcioSpcip+wCW721N0pR5ZQpwlUo6anVw8ApRuph5Xo7TpNs5rHZxK+Vy07CJXC8Ipe4okZX+nn1Cs5s3jpJcZTPLuJURJrXNZLCXfqoHliUoQJfPJDVk8USJaTL23Nmr0pYtL4pf3LGZMen/5f9L9pZ3LIHRRLIlLm74ACTLJ5gG7a1JyIDpfrMDlLHLqZMIH/ZdZLSZeu5rJZbLOQ/PLxZZ5L7Xa1LP1pfMEQKtLQ5LLMDZhLLTJRhL+HS5LT3bBMKk8W9DJKW7dFh9LWVQzLVVDhMJE+hMNU/zLWlAHMKJh3LXphsqZCboWg1GjMQJb3MLnNZLa5iBLbZhm5rJbhL7JQkph5botZlIrLxZf1JDZbyq9ZiTMT3NnMW0/2pZZizMCVLqs4Jh1LhpjHLiVX3Li5UJLlVXtLj3eBMQFPfLlFL4T+1E5MOpczL7nNnLm5jw7DJh06apj+7o5goq13c9MgjCqAVZdVMFloxMLZi9JG5jbMaVTIqhZIFMkFTrK0ZiBLA5duAK5JC7npd2Tv3jrMOlC87sHZfMoJixMOpeRMepIbLyplQ7bZUzLzlSQsQph1L0pjCtBJeqToZRu5+Je7MjFaK6YHgq6UJX8ATZYBMvVJLL6ZTNJeZilMwpdI55U7W56JZq5+JfhLC5ZIiX5fonZXShL95ZorOXS8VcZQhLG5mopJZg7LH3eaAUJgRLJJgVMDE506UJZbMyJgkpOpkHLq5kW7BZae6CZZxMJZZ1MHpe/Mmpfa6HC0zLRJm66FphhKg5hlM6nRbMPJPvMOJJnM51JLLWJh6BVpiZNCFA9NCnPDMRZbFM/XRkpb5lu6Xpoa6PlDhJJHPxMUZnxKEpo6iVZisnYplLNFFS7LfpnvMXZoEqlZpQuTZcBNK5cHMZppMAK5jRNK1Y0rMlTpMj5ccry5jjNDlaLLkxOpMbk7UpCSdXJs3PxMc5qDMdZcvNM5jzNR1jRM2HShMgJpnLqJkPLMJpXNVHNbMiJgqqZJgvMjJqvMj5q+pCJULKfZTDM+XS9MmJfXNH5pWoXnUJMo5pnMp3PxMqnPxLzJldJ+5lhNM5lkH/VOpMtZUoiulsSIC1OYH4DqYo5Ze6n4QCWtfib4o8pXxNhk9TKeJsUAUAC+pzlHkH/gCSASZsnNHJfJMwE8+n4HRUsTJsm8dS0MrGJIMH4JLgWhps4TsZpAT9pKWH6gCdJmg/AAVpoOrblfMrwACWpLyj48UnVRJKSdint1hytVE9ub7QCgjfzfbKSQCGvWZgXJYif7NyJTqoApLEpLlFXNzVIlNtgC+7TJMAH4Vg/JWnkSo2ZtOTcJYConAC+TZyh6irJMAATJsiVeJvGryJu3NnpMUoqlFYAU3liq85tGryikC57pvTN3Sx+Tm5doqIJvxLwFRA6HVYwATldfJgJt0TcJMBN+ZMErSpwOqr1pWn1Zg8AX07yATlpaWmHWIuG3kyrfg/QrDyg7Nopwo8rHnQrlJw2reJlPJsSdZK8FT0oS1fCsjyiS6ew/DOGnhEr4ZvrOJpZVN9Za3JrZaqotpvFOLQ/Grn5xgn4ygwARpx3Nkpxw5uJkIAQZimAQpxZJrZyNOQJyQAQ5Ow8IibRLOyjPL6Zk3OT5g8UZ5fvJqpygAWZynM3wCoUZy0M8elhZNpZhBOVE75OXieROYJyvOTpy4UZ0SOokZnEUEJghOTnaa8FJycTsJwiATpU0WrSlE9A1BFJxpzWAWZylL7Vg3OWZzSoX5nrOZZy1Ogp0POXZeKiSJzeranjI8b5xGoUp0iqRVfnNIlySoX50ksT1epMwJOLOmp0tNMZNYqRJxGIDlkxN6p1BOpZXirO5aYpOJOarlSx4qpZyOpe5tFOM51pOSlL2pR51m6DjDLN5Q/rJ4p14sQpxfJ6VVLOwyx4qnZNm7LA/VMVZ0y751Kwn+ZPWrJ5WooXpog8m09dOxpohLsJ2NJ9gC+pe1eeH6QCanqZMM57lk7N/Z2hJ/yevO4kS2UdZhlOJFTtJ9SeurFHm1O8ACoTzJ3ori53tJ/zDLLkABQpRyhlOR1y6rdFIirnJQOIDViSH5ACbN7ijPOvlEQuaCjOH41HKqb1bnNxwMLPEp4YrHZQgsnVw5PGFbwrGZ448plZPNo1jDNoZ2MsYZ5KpG53KqsSg5Ol509Js55W6QSdCtYk/HKIli4pCHO+H9Z5bKIp3zKEwCnO81ctPPVFW7gZybKOGzK5WZ4pPRBkPPR5tDOSjC0qnE6WqnJhy8TFDgBJJ6gpqZ2MiT1ZNJsw/EJ1Zd9KSgCDMP5SVJJFfpN00S8nSlpuAV3QFKN1X2WP1zSBhScQiQlbCUBp6OiZ3c/LGnXdNo5MfL4QBQ82pQoULQCE6QibSrdFBcqgZZrPMJ8DPR58Mrc5yVPiVi4p1J4uq657+ToZ2NPiZxlPYJTGpOFZvNSZS8nS5RdKEpTGsElXUULVSpL0lDEoFlqbN5FxFPjylsnXZ9PN35o3JS1oisapvMuSiKkazVyU56VI2uQp4QUHFEkuWJssuSg/1On3YGo0FiMUPZdHOSgCgAVwCIqw3fKuQp+VOg5g8DR0/nNOJyUUEJJiorVDuTlCbeqRVVZOEp+7OeJUApsJXZKd0/EqX5T0srE6A5WZNYoIFxlP5y0HJEZTu6ApT0tSJUenc5UeAV5sioq1K5Js1glI/Vb8nrJoOTcJ64orp8dPR3TVPqg/8sw51rJj51RLo52M54lGy9GpNnQECd/QD3oMTb1FcqhVFcKcgQ6AQWJObWFFFQHDjGb7aAzKolaVNzFFE7J1FctMXpWpmVke6TaAaAUZwIook/m5o1V0H6pvdPOyg6TfACsquqB5OsFeequgCqUolFc6eVRDNPZttQRSbfOR1JfQS5yVQTVkoUMZtHQUFifPPZ9moiVaGH/1mAUwFFE6fyeYrhVFdQXpWmreqC3Kp5tATyKAe6f53xQY51/QXXUBQEpV2WmJV3JDyginpVhyARwnio5ZWonfJNnK1FczPRybpQX6DIU61Wu6yp05KeCbOnSlVi7MpyPQjJyU7Mp2Mn8TqZNiQMKYSaEq7b5WHQGKErQS56OpVZ9Uo751gAVklq97znAAZwikAZAQ7NxTX7K16FGAeaFLQp6A7QHxeYBhWAHQtBz++yQkNBSQTjBiwMKtfE8wVlE6LAC3Cc4ckYKIZHCkVFod0i33EfDvUUBDxgUJDyEXGigkUJDvwBaimHEyMzUU8ALwC2AOgCAAJIeoTJiY84ZXM6dUFYOo+3DYibnE0BdoeWAbYebQxR4lQ4XEUO1yY+4jId3Q8hyai4iZpQz0UAi5KGm4laGrDwUUlDyaHU4cHE8SxnFBQ7UYqM1U5YjAHFOi/KISGkBEWK76IY5mSCsnBaHBQ8gbIB84e25RnFgTHjGc5S3GpD1xp7Q8oe04xXFdRHaHlRH3Fs41HL0CRUhQj5qJcGHgDsE+ka6CtoYHAgwVpRMIPMQSEdakDKJsGHkcvRLaJ2c6Ubqjd6J01OyCQje0bckdqJc/TUgskbaJ+KdAajRT0nBRNk0rRU0jhRUKJc5L6KwlMk4FRIqIeCcQZs4xA0SjMaI4FeaJS4zQhCBXQkNRT0ZU5fUnpQuaK+4qKLCnB6JLRZXGNRKBDJRKnFy4HDoXRWaLeIBk5OTQE5TRFxDwnLEJVRbEySjcnMw4gWPFRJHM66hFJYWmFdGsxw/UT9lgw6qyjQpV1ftO8Vgw7eVI27rnlu7uXZepjneGpknQoponkaplROsUvXfhRoZ/Y7sisAWiJKJKoVrS8EHUDLcpWAUBCbgrBlUooXpJGryZMCqz3OWpEpYdLZ3pNLaZh9Rx1AOT+k6qoWigio45WFLE1CzRzlIqT+lASUElC7NbqN0qtaOurgqO+UD6Oinz5rk59il7Rtlc+UNCkQ6c1I8rphAa8eVRIrGRACnxHUysOFdopF1dudTpto8hpvZRwnO08k3ks7G3lgrdXlQrkHlWreHlargpZaVh1hKtQHlq8b3lunu1SIsBHlwsD1ems/Vgutd3eI8vU74pkVg4YYFPUsJVKIsMw/K621h2UVlh6pHlL88zFVOsXyjCUuw/rJMQ/WsYVgI8z1oq8kDC4H5SdLOOS00rl1SM81ngI82FNXJdHnEVjSl6861lwpXlbErKnnc87imc88SmaWRlmfNTw/KTmiyNQ5ACOIAlm6Uu3oDPnQ/jP2nfNOfFGG5xQ/Ss9ZOEH9VPWs/KNc9ClgkH93OQnTC0BR0Fm4YSFUCYX6OStZzDCrmSd2pzJW8BhQIiu+WKYt3RXUvlQ4it8h7uwgF0AufxuiugEtMB+QYgkOwPqupWCoEegQo356UqLCB4av+ISgugRiAvR15iL33putiXp0VEHi0lclz0t4lz8AZl0AvCmnmeemCuEVnsk21aT/CUX8cyBgN22MHrwuiyA2u5HqkB2nqpCp1vNSqHqqu9V4ITJoTY9uQUsZXgZk9hDfAhvV2YvYJMqvqQIIWL4IW+qnJskqXzevI30s+fzwW+gQJUCVAKNQwGO6x33CfRhJHtQ8IAkCz05yznoCxSmWaY1XWEuDNaVux8QJau+WfyzTTH3BmYW2wBoWAyAWdMz3TDxAbEjyyyzgzA+XscvACpA06Gw2j+xm2WC6F01nEvnDcgSAugWQSC8mP3S7YKPB0Rm3DqaYyDO2RG4FWqkCyRkO292royeoHTDqYVS2y03XCqWnK3IWBrDjRQIvRQZIZTmug/YEbtAJF3UZOG7YGOgpO3TTec1EqZnBoWhITSGBgy2qYc2lIbo9igOQBIF/A+4knm02aackWmvK1l4bewSz0zCIwIiufX+BTWVtIKdKYU2Zaa4vgwPzTXG1WjbF4GDu10CPWQJaufaZY+lmXM5OWDCmSG6o03lwG4I2U+d/myMle2qFDm19qJ8WafTfEnydGIYG+tRChAOB5K4IKcLTa3IuVlIdpADaXMBFDypQ4XCKDQC1oBg0TkAZ6GJRHwz6GWETzQyHEYCiCPmib6Hs4kEUKi6KH+iy4eFRAgLunUAMQTGydoBjURUBkwBcSMgkaBmgM4BnqdoBjnwKBngLi4gUYoO3xP+5RTZ9A4Kc0NF04aMQnFyAZABeAQoptEdQBsS+g81CagBdIZwBeAYo5OBJXF+kXUeSHPiVbIdxz9T2kedT3AsEANKe+5hqe2FvKe7Er6fKkU6fOG56fSANqfXCHqfQFggBvT8YEdT4gJKAOKftT7Qx4FggBzT+6fDT84kgAMKgAzoAx5FxIkhUBQQ2QrwJKeVAmJT5qgDT7qgQAM6gVT3KgRT5KgfT7KgjUB5G3UFafRUCKfhUGaflUEoynUHqhJEbKhNUHIwrUKagYBJKhZFxI0rUL4yjUMgBjUFKhFT96fREdagTUN6f4AX6h1UDhb/UEKgMAX4qpUO6iDUGqiHURaiANa6iFUC6iLUNqiPUIwx5URagxUUahxT7qiKANahZURahDUVqh7URafrUPKg3URKfzUWwJLT/6jFUSagHULIo642qi9UY4o7US6fBUQ4o7UUKiZUSKgXFHairUd6ikAX4o7UWqjTUeQJLUXaj5UVwx5GCKjZUZakDT3Io7UaKjfUdKjXUi6fQWD6hjUkqfdUlKjlUTae5GFKjdUhah7GFKkzUeKk3T3qksGPIwpUe6jnUC4wpUgKkfUqqkHULIwpUYalbUo6hRUpQC/GFKkdUnqjHIBagJUtpALUnalTUo4h/UsI2rUxIsxUxqlZUuqiHIBakJUwafRD8qiNUyqgXU0KlDUfamhUdqmdT7qmhUqKk1T6I37UwKm7T7o37U1akMAX437U2KnCGPI37U3KlFU3qg7Uto37UzanTU5qhLU8KkVUs6ndUK6ntULqn3U4KnbU4qhnU+6nRU/6nVEkKnZUfYhBFvKhZVCanlVBKnpD8aoXE2aojFNqojFxKorU/qoRFcKnJUPYntVA6ozFZaorUyamzVBYgNVFallU0qe5E9qf1Uto0lVGKnLGkqo3UY40lVHqpeBJaoPVNafVVLKlfVOomXULI0lVK6nxT7o0lUuapGAXzi5U/KqCGPKqPVLqh7VR6pjUQ6qPVNKqbVBqp9EvKqrEkaqvVJ6qLVR6qBVKKfRVR6qJU84yXUvaqTVRorhVTKjGFgqmjVRarVVT6gXVaqqlVaQJLEG6hZVaqpFU86rVVDaj7Vaqq0Ci0kNUDafXVf4h3VgUitVNqsIkY6nfUR6sFVDasFVfQBPVgqq65CUkjUZ6sPVk6qRUd6r/UlasVVhamHUGaszVA6szU7KszVd6sfVnKsZVnKsdVmasjVfqs5VYatLViKotVnqsLIDasqbeao1VtTbDFcKtBVs6tFVs6tJVf6pLVsqthVqatnVq6tfVk4hYOfgBGAaYh/Fk5GTVkqttVyQVhVy4h/D8IklFAar/EdatwTV46nV2wN3IB6u8Ac4h3Vu6sRGCqvDEdqvPEtqvTVxKvLVxquzVrqr/FVKvPFW6vnUoavjV5KsnFIKvnVv6sLFMKvnV7KvzV7qv7V8KsKWD6vPEBawPV+KttD+KwPV/KsRFLawPWAKwXWAqwfWBKsREOqvPFMawzV9qsLEdKwzVvawvWDqsnEcKwzWEqtzECqwzWFqsnD8qvPEQaxbWHKsREI6xbWIKxXWIqttEOaxbWJqu5D9qxbWKqttEIKvPD8KyDWMKsnD/qyDWNKx/WNqtzEC6yDWOqu/EM6yDWPqtycXKvPEYayrWRKttEXayrWSKynWSqu5GIKyrWTqvFElayrWUiauFgqvCBJKn8khpDPWaasHVwkkiBJKy5WZ6pzVm0jHFC6zdWYgJJWFKzjU+qztWcasvV0DbDGlazWkVo0rWWK0HUNazTUx6zgbeY0rWXgN3GlatPWd6ohWja0TWfK0dVFK0tWZ6tjWf60dVtK03WkYhhWaYrtWpKznWoq0hD/KuDWnq0HEQK1JWmK1bWZq0jV2q1DD/IuPWaV5TWuKwVWg6vNWtahrWqahrWeoizWuK1lD/KvlWvqvpWyK0RWZ4fzWaav1WyK2BV/q2RWeog5Wzq2LFvKrJVmK0NFCqzTWCK19G3a27Wp4f5EsK27Wk6zjEEKuUB9QQfIDY/1Vx60dW6KunW6gOZW7IkJWbK3gClABHW8gNdIDY5xW7q0HEoa27W16wxWvqw1XBK2XWkaw9XBK3FEka2BWJK4JWeqxRXBK2vWLK19WLq4rXB4hvWu6zPEUqzTEq647W5q0dEOK47WsK43W14nfWaayNWvotdXKK2BWTK5VWeqypWvqytXMq4xTzazTFF65vWwKzBXMq5JWkYnFV4agRXQIrhXQq40Bu4uJW4ouJWqY9XXQqzFFxK56Gvaz9W2kjHIDa2zWgiavIDa0LXU6s7WrK6vWiq1rIDa6RVCq6/VWK7HXTYffXQK01XXK6NWna6kkkYhhXWa7dWo66/Wpa7nXSIlBXQK1XXbTbzIXK7xXT4hhVRJHoGwZHtTwJHynOXP6pllNxNPnWopY5pWWrVY2okq8aUHACXL0JpnNKppnNGZowpG5bvNMwCUUa1OrXinSK67HfY7hHfcWVppm7gHSO6769IqNigMpyppW8Hq9eqAZ0pXoFMKAS1rNNMHcdNMq9otglVLNNpqAsNpYpMR69BNTXTFKkFIkoPqSynxJq+7Epqg6cZoDNU3owIAZrWodq9A7sZz7X1aO46hJpLXoJrg6Xprk6l09DNk1ZvLM3ZTMlZdmo8pq1JglZ1JinjtKdnM8qxJdNLkaQ+p5JZQr0nQ7X9ZYqonFL3LKJnTLkZg2ocibbKmnWGrenQ/JS7AGH6CbSuKq/5Xkq8pR3ZorKlJcjNDXXJXmq+2qNa86TuZbYqIlC3LAXVnXqHcFXqnSUqN5ZRYHq9HYIa9apeZZRXsJcisaK9nLfVIlXt5cjXtZpGq9jqbYHHX6AUK/3YMa9zJrHXxXvJ70qNZT25uZcsTc5cxMvJc1XxnOaIDq+TX7nYpLobAcni6+ZLp7BxXvZdFMnZd7LKJeA7MVHJQKpd/R3JeJLxpd/MWFQNYNZePQmrCfXrE85JtCfOra0S4okU/C67ZcW7pxOso5XanXiJ0+7VnmpO55lXXi50hYe5ZTMD1L4nU5zzMGrAJXkJiAWrbAQospinYhACnXk5P5MSJbJMjaOXMQFjDXm7D9YF68+7e7A1R0ZiBYJHcHYJrDTMVHSNYH3fbYaK9dMQLBVYfrBYn7piBYMp0yph51FMkE/BYObD9YQZqVYRJjlYRrFrYSK+Q6p5kDYUZkvYVpk/MQJlC7ubC2pD5lBR3HdhX27GWitrDGARLEW5s5lO7wrBE8ZKNRJJ1UqrBJPE8GgCQq0bD5OcZ2OIDbG7Kl5WDPenebX7pQuU9JsMp2Fx2H5J0yTq5dKuUVnHKgJ+qnSZUcod7CRKnkVrMJ1ESp9pVM52XkkTc1W9Y/5fAoiHPW7KpJ7KN5V9P8ABRQlgueDHF0avFV0bA5l9MAaGFK+Vxj/QtQueBUHt6DVF0bZHAe+w3F4uujV43ZJHrTS2WAJB7zMK9cBW+v4SXfJUF43KDhj8gjGYADuF/uB9VuavIVuaMmEi0FYWgS/fgOWtzUyuunLJ+MfrKHDF0uGEGIQEBv7KEmQmxwtzVzu8W7KgVqAb3ZUGMEDNbKguorKyv+n78xZrKgJWwTdZX0i2KIbK6wpV4qEg7K6wCLK6+trKg+uHu2MfghiwtbJw/fn2ImlX1+1bHwStzTNYtwADFCRTyfB1gtLZgBOwbCoOsVA7I007mbOz3oOs23IOsF01uABdXwUDbDYGC9AC2AYgDGAXVvEv+0iHSkTpYBhRPtZmoNhKtnvQv/kCKvUixsIi4NDZRbNOKel7at9jHOB4kbQi0AIyDRz5ZZczHOyvgSkeZ5PK9RhNJDcV8IAdAD0xciCRZtmWGwXLOEyph0gt90r5A6bKKuum96Ad2eq3bR1vZ0Tz1ZGQKLZ1DfbAm0O3Z1BXuBhRETAHhW+91ioZSfgh/Z5LNsDZ17izciAjZui8AIT2bkBDLPOPXaT8x0wRqbKQDsBRqT88MlwctxmpkzcmcrZ+Q+WzckLMzcl2kx1l2rZjhIwAeGHEBsQOjZ9DwWw4gXxaEF7uGPKUaCFGZMBWbPvKULKCzoyHWzUGZMD+F8KzJn+swRGxoDJGp9aFmdHaI0fYzmrJkyiQx5aJKF1aIoKyDWLOnaKSMaHQrRk3CLRk1Q14azowI4JPWdG8XQDMzJgLqBKgx2xDHynaQWL0AbwDyeC3v5J6ArVaGWdHZ95tcGfG/SBBgaO4L7SywR2rZZigMKHtgUCDt4VeWvbS2KLAauynzxEXQ7S/aOLTWHy2OYDarTaFJ7Te9zGwWy/wZ3ZNrS+WOCBBB3wj+B0Ep5CpbSzaekp4BrTM6MtLUDaDEp4jsCZcwSbTwNK7T8/xLNc5fgXlZ9rUPS8l/9ahxgFTTAaPaXjs8Bx1+CzwbU2yGQJUuurVCAdwJUAbrVIx1EGhaqhnKAb7VSKxyH61bbO7asHtQHw7U3asR6hat31QBSH1AyJF0E+mmAkwYH06MQGFOuu30a3on1GkubWQDeLVuGjBY1ZvbVgHgbU2u87Wm3q7PFa0DhuESwO2MmLWra2m9dKVGOpaA2OpaBRucIx1+DZeRudAiC9SBHoSNa6ZVsHXKFMvDmcCDsoIKvDl3mCe2gVQqxk5aFAIkBKxJo+4bNs3D186E1wiEvDgyCwgbYBa77YO06X4efxxudbC2mxbBobWAbW9WGkLYlT7jyewj3ysKcwIBbF34fbCWykvUm4eP1Qo2yPGsvZMrZHbICLWKHlW/a+wg05NbYTbBn1ZbMmGSRZrZoN+H1yNzjtuvDgLqvDjt825Ab2KExkPaWhudbPy7La77Z+IUATKCbLRQDsrZ/Zo2DUEsrZ8GPAK3ZRUws/Q7atbPwU05L7amnHAKKfKbanZdraK5iLP5bOS4LZ9F43ZaJVuIim/0v4QKhbaAzG5EWSMYowMKv4bbktpZVs90bW5bdQzGbCWG2ESIN7Jk7cAC9V4vaT7Pxbg7MzbfG/suDraFbgrJdJYbcUCQLcTbg7Wu90AzGvF2KY103uRblnwFZ/bcU+CV61bnLSbaSLSg9wRx5bdQvnDUgI7DUgOK90AD0/tpM9KxrKKVzLI9KxmqICe7OvbtrR6WGrPHbvGJDZey/vZswMLZbLeG+iLbM+tF6kAdoTyBhUKe9YF4PBNAaPbW0btb0QKKAY2Rxb1BJrAfwvRaSQBQCmnAwY/qFtb2bK1b4TUWB5rewVILNsCmqcCvUrfVZIbe6BRS5Bb2BjWN0bew5J366xLLfCdGBJoeF7fCV67ew3/V7VDs6GGi2AI6TRxChQxx4lQyXEcF9KdIigSZjRFEv9cBQODcB6LIjGUZkCEhxKupARWEhm/mjIQCDcHAOQc4DrSuIofKK2wnwTXWJkkGACOwnQDK4v0bcAUQzE5FwCk/VQDmhCibWe1nIugqbhsCiwCmurAhZcOjecTa7hETR7hgktQTjcOwBOAVbcwhCgCelIybWanQCtZpbiKl0LiRRg3Me4Q2KJcBgiG5nTdYEkIDLZabfAC+kKAChgKskTHsMwG7TUAKKUodmGcElvaUdcXl3yCWV0Cv+2TkDR4CKzWxuivhwUrSiV0EvuUILTjLgHRDgyMZLyVoSxCVOHkgNMSqk6KDQAKESdwBeAKiUygoWWmVr7kUSyAD2i1AD6GJA8kicSXbTmbk2ieCVHchgDgALKdJcCg8lcDkXLckrZCizEZlcqgQki70WbTqKIDQ6XE4iph2WIiXDMnOWhSBSHqQBTCsoicrlUG7nDMHpoDOe2n64FGz0+ITzfAZBKF2TVwDLcyQNaJpAWfcwAyMSqrkuSuwBmBdwB4VlAoK/fAKOgAQLkQ0CWUi1AWkALgC4D0wD6AJC7kYraIoD17luMKCWE4nBXDciBWHclQ6QKMrkdckA9Pc72EmBrQLvcnUQqPFD0hc8blFcqrkSChLkXc+A6Rc+rk0GPBtPcnLnaKgbn4NqLkISwyVKK4blLQ9Loa/mLgfcqnC4S1LlbcskRhctKHXcqmhSSqgUGSu0XoChA9OSxipvc6LnUAdwKrD1roDdDh2gFpborc8iVPdGUT24jblPQ/Lo3dH0RPQ1qdTdJKIIgC7oFdKEXmSqrpaSrrpecp7pjdM7oiKyWWmEUrpzdBSWMFTbmxc2rm4/cgSWAKLnBRCLnoOP7oJdFyVOS9yVXdBhWHD0ADDDx0Wof7hR4Bkad7cngx4BprrZdV7rNco7rQS+SVddNLkEwHAO2i/yWwil7rEGPC/3deCVtdO6GYBM7o1cqrlQihA8ldQiWTRALpG4bwXNctrsMJW7rddHrkoChLmuSxrr84orsiVr7sQC7rnndVUUMnhLqHRALkWizQ8kOCAJ4BPEVOBYLkzcqg4Rc/7qndrwWHdpSVNco7p4ifLp/Q0rqCiGbpBdRLlndlkVK4ng8kX+7s3dowDVc1kWoALAMKElAgRduQx4Lr7rLdibt9di7lNaFLqBdHruJdq7pEizbuQ4nUAWS6QkpQ2wD6THLro/mLt4StyYKS+LoaSqrnVdnyVcTMqd8jLbn5RGqJMjM7hSHtipiAbwD0CMgKxRfEZRcGABe6xLhc5lQWGjK3KCnBboFd/KLxRJwrEAd6go4zScKAL5ekASBmCKwis8B9QBeAIwSakqrwYkNaJDRdLkHcFaLM5b2JmFJ7wDeA2g3eBkZ5RgQCUMUQDCAU374ALxWExKkrDcLQCOt4mP2dvHFwkbbxqBALxwLhgnxeO6Z6w1ABedKqgMjAUnBeRbxveObyUxK7hbeTgQ2jIi4chfwj2FpgUXeUryOMVLx0zRbyteTakMBcXJuXDhYQTa7zBeVLzJePbzNT/ABeuFLy2mNAkRebLxteYQKneY7x5eTLiakk2b7eTR1feUCb2UVkwOc50jbeCrfKEMr0TehjarejQCaAL17UTFUnBeCkaRekHKMPWEIQkbaI25R7wtRfLwzeG7w7cx7xBeeLyNebrz6CgQBfeP7KSM27yEALxLC5LbyJeeb1ReS71VerCZderkuIG571g+Vb1nep7yRefL1tePryBeuiu24uEEcAZb1/eU72DeVbzheuLyDeu3FwARiThey7z1eSbzfeTL2hexgb24uACcBdXuve1r1reZb22AX71eXnANRe4r2be2b1vexb3Ne0rzMPUaLneDwSeHkgQlRd7gtRfTpsuAmUidC0wMAcABeGRgQklgituz0AnwEG2egALwhxRLKMECizc8JXKjubAIcqG5ybXe87iuIJbqpDgrnhIWgs6B5g5mGXWhSv6RsRcvaIbfFwIpfGQ3cTYYb6C+L4+QGDPlepDYyCJrmXfLwY7czrmgVDL5LI9achdVK8KiNyN4BjGLySSQ6GwGr2SBjAKRb6yhesoQMIbjL6NJ2ik9Nrb6evOU9cAMlcNPUwBgs4QCSH96BkAVABiQr760TcFjjSowWS9ZF4u9aF409aXp6Cm15I9RF5hB6XqVS3GF6vPKV6VEaWHfZXq2vTmOnesVuoAQnzs1pQ/YuzACK0YL2oZRwD5eUr71fhbxsAQwS/fiAIAdvL8YAYTc8gv4CqbjFZTe4DfBfjr8iAa4Qfe6A0USQ2KuLGXvWt1ACUrNyyMCISyMfmD74tv78CMaz/AARRwRfq15ianb9gf4L2cw1L9mH90mIbjr9uZ+znU0YE8bft3sYnjVtuJ03jxZgxO0cNYTOAZb+FfyU8afWBOyQHhpYttgSyARmesyJDpwAYSyNb6wCNJ5rfWSU2cEHTF1CL8AIy05ob/fhAu2LiH9C37F9WGZReG9Xgg8twBqxZ3iA2LCIakwS2OuEUS5fKSaaGGSmF6x2oIQBHyA23KwTRSyQwetzxWXZMoK8BEyalcdx5Q99wRYD7YaJgCz/BAd2CW2PGiAY7GAk5ZgCawGkJcAdL94VEADez0BoxAgQCshU156XJRTlgG2AuCEmrShJTnWtp7Wct8lvMBsWs4AZ8Ak05mTw+EgR6ufgkM1U7gkzoIPIP1MBVKyn/SB6sBuGFW6FBuj2O+HUiUaImEqxKgIWwaDoAAUwRKyNFsZDaV+6Vt2OVgThOoprrPuBLsBvbzR4atlXz2QSBf0GGBPgGSgw8bbjTwAdACNRcSA8hJ2dAPDSCQc6ybdgdDnTfrsDiQSCbcKwhRUAbEsNgeATgancEEhwAfxgTgw8AVHqEAVwWGGNj/Bf0SamuzEEy3Fl6OFukJQAdAQ6ASVt/glqgMCHQlbgPH2pgToHAAT0sNBqi5AfWD60b3iw63XWmfgqEh8bggNyClcFPDrQNZeTqb6Vn8FcBrLiigbr5END2hTcvWG4GKn5sFJmx2aQy5LgYzWYvc32khYcB2+0j0OvJn2bgHn0M+0kKq21WgLZtTQENJlz8tvz+ovkoF0P1EN2usWzzgn2xJBigYXfwnyea+350vADPzg5AybgHzPzgu7/GDhsGYCrmBQZK8Gfg9zNBfDyA8Dhj0oGigcNg1V7wbbwpPgbA3MQHH2BgTixrBOYNXamQIKc4Cag0vF86VqMHq01cImAbMHyemCya+sMIvhAhmILim+Sbll6cZ1oKUe7EAk+Wy6Cg7IJCE7xiAIwkN1g2iagvkUF8wQ1vWgJmA0ewAlzgemFkh53xCCF8DOCwMDSNGMJ9gwsKDgd8KHgaApNgTsKPhQMKSGTcKMENMEuFvQhxgn8E4ENgt9hJEBMpzEofhP8GGGSsK3hRMKThWgZhhXMKCEnUofg4QDIaWWngEcACEh21z8jzl9U1fQIi3igQ0hb8LIvoj1ThdsLABDsDvheTUnhd8L4wGsL8KdcG1hg8J0gkcJWb4A+HhaGDCyyiSmAb8BKQ638FhgHuSb7sL3hWcMnhl8CcDZMMoaIsDuy2H2o0lQY2TUz/AdERfwZAWBRbkjonhqRCgJNUNthqcJ5hokM+bb8NSHCHL9hsgxu/mgOQakSvBhtMN3TTMLqylcN+Vvh2BhwwZqw9cNThvAZrhugDcheGGqbVzaYJ8IFYB92quF6Kbrf/wDYAQgNqyXH8OCgQKxh3MGipHH2kUaDiYgxnKaCH4XCtt7UKt8jc2AUEoe0KgNQhswawATwWADOgWHh6AQuwgL6EvkluWAclI4eJApOUaEGSbTAZyzAMPwurmzcpHGzcUaH+kVv4dDhFnqEAblI4LhaUcUaDfSbTEGo9XArMVXVuQ1aUb2v6QRi3QWethh2yEcUQxviJGetgGyt9iKG7aAVSgKbmxmIPbZuCPbQK6wTUFmB3kFqWqF/3hUW4wvqQWTawL6EutnAMwGISmxNITOvAL5WwwQNq0moJbKth1u2F75i9lcDc9RmdswWAUtffIDwOxAR4DEIZzgN0J/c0V5AVqDc8hZ2mHh3gDYhiYQC0wySMvcwIxh1GTuITVupgYsETc0FtuVA0VYCJsEKZ+gCNiVMTqTSACpie7jyGHg5O/c7/2KdWPg2MD7KAUl9XihcUVZ0LK6b32xUcRSw3f4WWVAJGu+GgoECdKnxDDbki1DH0JKvgwpBgL8TXCTmn7BxjZAhXMHsFqsI8/sFwHirAY2vfwO6BtV7/g5RiiCbEgo3PH13hpQpME8MVQu28V3hHsQSeYiA4BXgCziwm6Ywsg9skIAWGTLn6cAaxiFGlcMbcb7xsCMsH/axB5fg+cWmAbMIri1gRlhHivOCvya63O8B1g9j0ExiYJyD7MXC21QJUGisDFhGqYI998XcRUQDxiE8Ivi8sQthF8XoyysQsD7CA2HXGhCvf04ONoAILizMCzi73q8FYF568Wl6afJETCyzHsQgi6UyBU0bRhh11LgZCSmms1tsNFwICFewrPg0DYVBx2V8ClUbOtyB7ousl6OERWjvgmwP1gZwauuEgP1fzkQCSQ8JAailwuDEGSCNGD1UAZQQ6vozUmelMVwDEDXYARBJo9SmqBiyCSO+m2EsDNcYowlWYhjO8OdjPsXdhjT0zjO8XcCHUHaSzcakVqAQ6bumpFhF8agB+sYvAo38FjHB2AzED0od5cRi1MyWaPkYbICcMFyGO8NSEGIJMhssY+0Lkno458NS048NTA4MNSBt1s0ByMSbhqcajczjuNjgsSW0kALo0FrPcBhb1EGibw8V3pVsN16VCCzwBdfR30MLSmEq4GmmWNaF3k0oExmNGB05C4l1BCiEdnb+McoBSAQveyXuMEdluoCF72oVqACyj/3uMASBRXC1AP0ATbwICWRkSBrMdsAdMdwBdAVE9xsA2vd3uMY7F/G9xsY5jyIFSeT8WECF53wuzMecsocdY9xlcXjrwDZjsV7/j0Q//jtceosocdwtmV9y0Lsd6ri8d/gxMe6AQ8eG21ce1jxsfE/gsdUDZMetj2GDQB+sdoZTn8Fj36azju8bgDZMfLjwcf4vpH8Fj7Md5jY18WDZMeevwwP1j1Uvnj8n8Eri8fri8MgTj3sdzj4cgHkBsgljwGpFkEcfRkAMgs7Gsf0v4FxCCcL88vAA6CkeQDLeychG0w8hK8WsY5kKQUwBKsha9ggDeri8hdJfL6aHaQ9quEKUybywaPkNwJUQszyeDt1tsBKr+otvl+7NwRJmtrchtjlQMwaw4DfZOMh7kTDSUL+V5MMmDi0L+mrUtpkbYZHF8kRghgRkXGzyY/F+kBC6UI3QV3QDNWUmwmWzs9s284u/TthkLxEHkJhIkwVMhWBwRU6IW1+7kc2lQXwRC2Ir2O4th2O+4QpHte9rsCEigC2T6wDoVTgUOnhCWQMTrumBCAkyAQAKQI474mOxGlY+dThjjFQmauoYIVC4gaovB0i1knBkaw8oECtt1tWCcFt+/e7yQ2MDacuqkgINGF1gtv2SxgpE1ngJr/K1YYNBavsJYDwsbg2gHuvkXMVotxl32k+QRE09jNWuzEdgHtoZoKHsIiQIQIWGYWsuzsRZbTQGmWXIobUBHCBCy6cStiHn5ADRwCAHZsm9Stgx3kPQD2AQARtcgAYqAOw';break;case'icons-4894aa2ebb2d7b096ab8b3fe2f922676__42f453c4.svg':$f='PB+eDabBAdjKcjmaTebh6IhiLhgIhAZTcYzeZDSbjPDTqdDMLRwIh+PgUPDmdjOIIEbDcc4aaDodDgOheLzvNxcdxmLjecjOLxkMKEL5OZxFJBBSRAPDIZTMc6RSqlJjybTEb4IaTJDTbFDrEjsaTKdyEbzxDRgILSMhoILZEjMaTYbIaYzqcjlFDoQ6xPaOCqlgaUPDgYToaBBWxETRmLBsSBkMSsOCQMysNsYLBiMchkhiM8qVs3mRjj8jospltKWhEL6jgh5RKrVzZr8DVKtWBBWrqbDeczLYLFZLNaLVbrbbxBcbndbveTde76cr/gthhcPiYaTRiOccLhoMSYMRuLhr3hr4xlmhh5hyTBt4BiLPSNe/4fH7fPmhkTPs8j3Pg+TNPeGL1s++TxvK/buvG70APO8advC/kHPuGLWNcwDrNiObZqw2ypw83KssUNA3q64SxrKs4RLStbkhouC5LoES7LwvS+N86kQw47DEMUNobBA7o0BmOwWhsNAbDtJUjhaHI2SSFoaPNJIQSqGo9DaFoZLdJEDDYHErhwEEmQMNAWhvJElS7Jo9NbHqkw7D7aw22ERto3bFIsNo2jCNwyRU4kWxe5DkRm5sbOfHLpuq6ypx+7TFqDAgrBuJAaNEHLIBgJtKhmIL1y9F7NLc9Ya03UQWVItVTUqyNM1XVoYVfSwaiG9adhwHK3Bc7wZywFjQKC7jGvI0QaiQGIcNFTDPiaHLzBwzQZv88wbhZTgcPA8aH2zAwXBmIdwhhB4ZBcG1e3LB6dhnYLNhdcCdhu/tuBpA9MBrANpBrajPwzOSltlEmBNxPTeBENI2jgno6UHFjjRhRDlxo50cOjHS/YFSLDSA7YYhpCoY1rZrNsg0TQZI0TMUrZjL1zWsq15IlpPmttmBYGgkBtWbj1qtORBsK1OaGx+X2Znlk0y1GfVKtIbVYGFlhxp1XLXWtmYDO7b4I2mDTy3WEjKPGGjlh6CuHiMXOOtmKOZGsbug6Ud0fSE50lIMDSIGwWhrv0iPAFqHhoGtfSHdEmJAFwYhqNAZDtbnGjZxMu3TwOcPBLUuSGGgxha83DBhwaIMj0Du77wkDdBfwb9AGYchl1/Y9YHExhcHAbBn2sx9VJ4Z8eO3gQNJHgcgGYxrT0PThzIaHhh01phvzDP9ndHYBj0Hcp31vSPD7gcBvOENUhOmC65EU6z2ho6DCMQ2DKFowjJQW0xW4u2Ym5W4YvueNI8fQj5jykzuL/Z2UFZxkDVKcgQDIGTVFNrLVSeSCDIQmsiZU1VUbP1Xq1gmugGAOFyL3P+Q8HCXjSq/QOuhZiRF9g2X+yoGUCUEQhXIugHK4DywwSJDhcC3AZuGhqv9TgNGrNZLcZoG4VgaxHVNBiC4LIlsnZWpgGh3D1xTM4y9Z4MoomfhoDBlKmWtvla8iCAKc2wolIaWEsb8n6MQfwoZtz+2LKLYw3RjcaTbt5ZAetLIQ1spZV8DcxsOwYpEP4rleSxz4uwBAuBfsPUCHmhuuJqJ3TzQ9XkgeScQ5KuFXITsGCx2bLwWOtyE6RJUyWM+ZpyTOJSMiQADdMqCD5oAXxJcG8tDyg0ec9eHUm0DRKkstwtkxnDMzWOvsGaQyds5QMEOZgLFuA2LbMhoUxD1nxVw41eTUZvM1cYtma5yT2wnkWUFeR/AXR1P1JldDhS3HtBosdxMIjIkQXO7g5K30DzRkTA6d67ZLUEBrJlYNBF/rocMDKfCuSHgyWzIhIkg5uM6PNFhbQQTGrBaeCBc9HlhwcLTMVxtJKQNXhcfylVJpKA5gKZpLKzjzQSU3Tdl9CFO05WVRCm1P4xMhp0Dg1gIHyIcjOnZ8sa31giDMHUiodCFBujg/WNyhGJKHjsopuSjW6scMHH4EQbTyQ9eC8BI4Mk0pHeAm4Ftb0n1sBmluuK4nXHxBuDFz5D3suMcsDA8te3LVnhMDJKU76Hu4By493DkK2VxsSDQtq+7BOfcYr1dDsoWLBV27tKq7wQE7d06QGdfzNuWPC9oGldwYOpdwDcNhD2/20DHO9KsvVfuBtO4GQ1vJbuMcYr6wToK9q+PI6SE4bDwWgsZW1JFdJy3Mopa4G9tzuuWS9Z2u4OFg2hd3aReC4q/UDPlP60ZEHnWxSlbRwINbMFsuNa1X9pnsrfd2Q8GYOHxsGqW2B9TYyDHRqvHJQrbUYqJbioxjKjqxN4gGYo7i6wcmTCRBNTh3TuPOggyoHLMXGSJoXiK3ZkQQYYolPXEOKjNlukSd3F2Fwhq7s1iLFlo2axMxnelmmNMcOGNA0MzizWVZCO5IlfqyzVUOWXkJLOSqgrLM9k9k2TDNtEPNUepJsL/x8YO2JPgaAyhjDXgarcdUZMVq9gyPUAG71jwidsyMUgmIPPe9xap5gmJVBzLmEB70HnxPIg49x9EA5zBvlq/0a8AIkqe/OrDao54IbfHer+Dawx8Y6dnCR3Vq5QO7lKMcE4tmSWVGCKmFWAJxy9l2puATFF5DaG8g2Zn81czS/yPD/sHaazhpxkB3j4n4Qgeg9R7EA7DPmfVC5+dCoGP9Mo9+ykCbHQRsRBedkLbFQkgPaGntlRlqVozL1TmEhoUAGR+Gto6YJzVguPL/27N3MJnFSmLzOGWgYZ4GKn8XmgNVT8zwM9xZc3Jq/RzCQx5iDsHIhYLQyBvDuG7dmlKu7w15pnN+ENgGLl+fNbi/trTRBueObx3uQg4PGv8GG1gbHwPYEzj81lp8Fa7wdDm5jFBhLxxIFodQ4cVf1rnS2bN5YPKXWRYzUtRcqX2f97meyIUN6nsdKppdCOxndCHlZ5s8nples0oPNip6u5zrAhvPOHB34hxLij9qta3zRgp/tYI98b6TvbI7OtQcvWZ15kmepNdaXi7Hay0gcA06lCEzRD/DdP2R2CXLQwadkMH2ZPHaARBlIw2irLa926VzXvHXveN68dDbEKxrhAZA1DYtIG4N2/+w9k971vtvZry9lSL3Tm0upfSpYq2ZO3ZS49lbd2TjLvHgeiDP1q6bS/MX2Wy1B4Act/cYvsG4NvkuNDmeb54MPtey+yeAGx5fng2X24W2deIhHg+R8pd0wDwXNmvZbPtinGAzQX/uwZ0QECd7850AGD+gGp6Iz6wb7kAh2K3D5KiBe76Ke6a53S9rkiIUC5NJKr1pLY0pwZKq2C1pwiux7j1q5D25eS40Ez1j95fBLTViMznDzLhIxTzgNIOh+QuboTXDujXbuzNzjb05j6srIANBNayJNZkINBkJJAG54K66k6fh1xX6Uotz36yJkKvsKQtRLp0AHKUsLpyED55J0heJXkK5LpLaVBJEDb1xaR2Rmz46d5075ZfCv75yF8Bb6UBx076xvr8r7Z3b7L78A6yz8ZfacCYD9CF79b1y/T3Zwj+JZj+bYb+xdL/CicRD/g8z/xeUAEAUKcAqb0BETb7b5JcyzZfB0ECD80QUCb6AGZKUOJw0WZLawb2sN5vz3rE73oO0FkJb6QNkQ8XT2L7BesYy/rVsGQ27nQhoMgwx9wMI4DAruD0Dizoj0bjLu8ILpQoKVifhS5mJLBeRdbYZLxeEc4KYtq3JXotqKYG6aicjEzbLFyHrFyS6YEepcLGsb60SdgHIGiUZxi7Y9q0Qz6ciHkg5BshRbj66S8hJdZ671Uew7oIZyReBXp5xBZMyi40S3MeCiycAGsWiTpvkigG0h6IR5z4h6acB5sb52yFyxhcjPheDq55w+K7yVhmqVhchaQGaWUhElqWaesb5cyAqTiUSFMoY8BIhKpfEp0igGgKY8qVEpqYJzTLCbCQQ8Elqex6ZaQGzfEigGIKaFIGpeEr5IhMssJTRcJwqLCkUiz/akUjkjZIYG4Kci7E8eyIRMqcaFslpfZ8MupvamSiEtYKwoKnqiCCExZxo1CCqoUyKiDyxObzEZjzQOo4AhEHbubd7urTEbbN8ISAiGsrw+QIJw0ABQ008cY86jxcRXpdxXs1qFxLE2LICTc2xxpIgGM2KSE2hn5Iko01A8IJrp6SI803K9MADF8ws357k5s4aRM5JBYJsjZBYIK9y9yk448jM7aYk3c4c7KjY0sjrUKGY8gKaFBYJdZeEjUkw8g7hnEeBBB3Jvid6FBxMwUwoGsdQiElqR6RM+o7hfb66Vk1RcRLyZxWk4iFpZE9M9UvKB0fswRX6WUyxgcZZ9MGgjkzkajz7SbocHrS7NreZ8rpRxqmiS5d6miSIzSZxYKH8xRqaoBZhXKZpcReCHZcBnA/6K6TKMSKw0RqYzyB8txZTISB7VRT1FZAwIJkQtqkLTxqtKSmFFaI1K9KjkFKJnVLA/4GVDR8xr7crzQNgNIObzzSTA9Ek0EH00UIE0jpRbLgRS4JCJYGs7Bao0Qzg04z9PCKJLM8I/88aJDyBnq2gzVQyJ6KU5dRU7pVy8w+1RLwFRlAijVPSWg/VQlRc1hUzyFKFSFS5YRBCJtUdT9Sal1VCDlTDwNPSSSBNP5TgG6L6b1TtSNQ7wBqtVhUtVxftXFUihyWFYNVNUqb1MczFDphAxQOzngNJ9zdcatEcHlN9Ezo7XzjkIZT6ew+ZcafZaj7SgciTmjxJU6daE1GJxhxA9qH6gstZ3AxoyJBRcRqSEZX6XJBclrxFIB3CeqdcgpkUN6chXg+5eBbiQYJidhCgGc5CcpYZASQYIb/Fg0cdFdgaWgGTGb6Cmlfzq5fJbEXleTlq0g+YyKRjObv4GRdcS9dSs6FdlFcotpdzQy48RBbNhpcrlhdLlSohkSX7U4+IHJayXFMJzQ8aZw/8qpZ6UhApb6XLxUN5f8qrIKcLZwGyeSd48TkKQ5zRZadI9TqbZCGFZNDgwcZoEVNQw0zczzdzXVa70sbjvU3qMCJqz04YtJXqCZUM1Y46RKk8DEuKI0583hYJVIyjK9U84k3hLzysGDcZOrRtZkZ0aFtr0TjEH9FCAT1ElsJxki6JNJkhLZ0YGkJYGF0BwYGF0ZKl011F0RLk/azEkcLh58BB5p7x1Z6R613ZaZ257Z3l3BJ8LJ0Z0KzK2B6C2h214M2UO7/J3L5J1p6l6B8MJZzx0Nvx0qv0l53x6V5k2Shx8J3B3R6R6hI94cAMkZ5i9d5B2slo+UQR2B67Pp7V8Z7t7h1t1atkJkD90IGl1cJhkMZMGNyNM1D1tIOgOQOoMYOgu44NadNtatt7o1uNObvSzxZc+xyTGzGAnbCjE40SECESXSISw8mR2KTlCEECW5lQzyLrqZcjx1ztnk3xX8lqICIWEJmoypci3bGDF+DVB9PJci9Nlk2bHFhtGdPoJDCpTFnKRKLWDFO40aVCBLVTgBT5dCWycj51hVp9eBXCfa37v8fxb8vycrF0T0tc9hb8+pdJ6eMLF5BdhWLNAVnhXJdE/CFJxGPEcsrpU9eM/KZ+LuQCoh3SiT3UpyTafabGRKh87hLNhQ9oGSW+MCk5maFD2BnEED1S5uRtokN6WVrUnyd8qxcychvchU9+DBcknOFc/L2Mo2PsSD4g8Us55xLJcaFIGWW76GE0luS8mS45xo8cp+X6Vy0OXiIUDcmyYkm+RJ3Tbs86FKZ8gTF7YcpmVA+Mlc/U/KGGYid6W5BcmkASi+N2RMFY8snSokFYHEs0DZ5yIGZmSeL7btCqTT52asjEpqXCcktEb+aUtub886fb/mcdCqfeZRcWR2ZuP2hFpBeSgYGJclA+N6vyW4+ME2gklQ8xxBwjkspah+LLD8peN6HGay2It1HmlJZekZmy7efUxCgjPseWkMcjQiymNAGk+2TONEoEoqfaFqdmedeehGNGMAh+RmouMOiuRSEyf6vGOa9CTUremWfqhePFfcpqgmLWe6L1CBfpcg8qwyT8wCVU+CYmdpAFCGss/OTiIWsWrMv1eFcyTWuWurRUZWAjhFydtLhYMpP9yzi80NE7pE0pIJXoHAOyyJxRJRJithxWx5JpNOyBNJyAHB4JLpJeyRJN1AGhMF1V2GzJNytgGUDpUmyuxRx90ZIgGG1G0mAVyB8+vbMAhsG+v9ENNjM9tzor0jjVuTjqjgoMrg/cbyWjZVUtjVn4905Q/ZnCQGVhAadFRw89f6aZl246FJCkbyYpYu7k7ZrJQxoCJNUW8FLBUYGW749imCB1Ve8tKhUbpZZ7flPCMbK6CjVBlWKCMDRNx7g2vTs+AxsgwpQOwMbFzFONzQ67ewNsbwGt12x0I0XyFi2UXRv7p72x6k5WE48vDaFRNXDz1l3HCsXnBxwfCe2G/22XAGvgiwNgOoNolvAtEuCe32Cu4CWgHANhkQGANhWvExKXHfHo/gLRIQFnHnIPHxMJKnI3IRA3IhqPI/JnJKxHJfHhrNMRLm7hz4/Q+wtJ0l5AFgFo9p1AEF3A9fMR6XLd7/MMguE/NBfxanNB7fMo/R23MJ33IXEx5PNl6/MZ5vO97ItV3vQB755N5nPh7HQV5/Pl6J1XM/Oq2Q0vI3Q0kfIxwPMHPy9Z7/I3NPNo+fNpUh6XTnOfSFRZ7/JoGXPfLnOl41Rd5HVh1vUwz/NV+PTnRPOR3XTl6N4PXR8K9vKFsu/8Gevg4DnjhfGVa3Gk0beisis0sLFxJJcXaJ5B1hwR578ivZ1ygFA4GoOa0xfGhSwL8iIMLQHCs50ZdwGq+j7gHL4MsS/J3B8J0j1p3qxXdqE3eWkS2B2x10EAz77/diu6IJzJ2xMff3VMTPer1qzUci2veJMvg65R2wOfdMEFlccfd5wPgoMfhJwPenjUwmkT9/fnjBvZ5SQ0QQzd90Fx16xawXbp1j96Bz7FBHbYNiR5MxcSuzwJ7K68TJtq8j5Ke56aaPeS/RAwOfo/eFoa4K068L5R28CZyy074q8np5ZnbRX7/i+3q/o3q3qba6/au5ZnpvWZ7S3R8Ph3qhwNofrPtfooG778CZX3py3kg/oq4Ptvu0c75V93qnFDm/YUzOAwOZh3ZGCW3vZdFOCxAnPKxHKHIXKnYANvHwGnxy2ZoHyK9poHInyvy5kPKRVi9vHfIhnJJPzRwZanK3MKxBnIGHYPFXYe2ltIOFNFNZ++CEz/xEbVOXZnxlO2JqJg0gyTfeJWJBS1QFWYyv2FMu2aNgEQNFNIOgnoPPw+3n3nBKPtubPFxE9VomjBf7p7xQ8ljpd7btoz1oybpZUI702qlljJZbqXP6FKUrOo/hngIKitVqVg+n/KKT/sZc3of9Kvn/iRUXiWCECHvD5xLBa0AgFuFrwzS0I8UzaccEmEuZRQak2sOvGJiV4ZECC/tb1kK4D4tpSwUfb+vgX2L4Nr4jSA6BB1NJmVge26XLtg1bB6ZG6b/FlpTzQjHEXkr0asstWZgpoVi32LQiAkjD/JnKcvFpEsg0IydLDBIJHwRkca0494NDGVG+hbogAc6O4EHPOVohaFN8GdGUvzCND84qeZiA2HQYGJ3Jt2jZXMthVFRLlcQGqGjhngHDcFvSMkb1t7W9Te8VY3oGSQfSljexvJCCbxN3G4IDBuGHebiwEQ+Tcgmo3TFem2VL5MVIC3ZGbq/0ekAEZjCODwp+W7RScVGpOJuqXlKZSw5YtfInGLw9ZBoVY/7fQDJEmgfxN8eNY0hm1GJkolGTuRILWUlQeyFM3mDHNeGAcClWW+zDgBMQjIGcDm/Wg3OCIOC3OFbDBgCOklKCltUkSUDSw1IbJQ2G4RIJiwdylADAicUncrw5YbREYg2pUWMw6IcYdwVqQOAhnsA+yhUX6MiVwCXhfoqxeSZ1P9wDFoaXMP+TXEyuHCTJEBHcHgJfKGH+UQMV+K4LckpgiBd8/NEAJli4oCpIZYVEYV1FFFlBLlEMK+gMFRGLRPMkyggFrCWRcBD46kphiWi4A8USYW0V4WUC2UN5dta0c0UED1xkSwiJTEcPpo8Ep41GJDERKNJLzPgfZEMcyiFB3z8SVxz+h5gHHXlBp7wleWWOSw+yeaxqHuKsPlHvD2UK+ECQPGQtBoerIkmBFeYUwGz5jN8fCaGLBNE4qigtPygFNDLWGtpOIIgdgFpH4ouBN9DeUYXtxXYkLVOKITvOSsixqMT5kOA3OURD2NBIaJm0HLaLAmqBJonueNNCRLozAscWs0IJaRKIxosctyJlYwiD4kMYqI60fSwxByRrKN3VEWR5EkgiAziL7EOPrnJmjhMZIc/0gKtPkkUAxISMzV3LQ2b8PVeSzji0w+Wc8PUhRD4iyKTkTIzo2c52ZtNEksItRJyJDJrkWSTbOkPsRAD3n625REE6kLqOaH6hASztY0bDhbH/HnKxkXSFtScmeTlTCpXUyCP1kjj6EUwdyrqPuJc3XKWeCqtTHGDOCdJMMv2LeLcHTBcJ9tmiLHSqtIy0KyAZCkyP+QjmjcLEheH9O/gNRcDNo78k/EDkzjvx+iPs0SgtE7mRkisXjHwEACB2SRoQtPHpOwHIRqKVU7AaCjwpsouRftumyJgFx22f5N0XTIeYsh9hnYvE9bBkKmHlwpoU8JIIdCUBJAA==';break;case'default-green-ede663d7f088590df526dad0046fbfcf__693837c9.css':$f='OjkbzedD2YzebDechaczGaDKbTKOjYaTOaDoOxaLTMbzcdI0YTaaTYeR0SDKbDsZToaTGYRYQTkaTCbBYczCbjnCzLMTNGI1HI8ZpBIjyLTbHDeOiVKiEcjCaZwICbSBYTTKboQLCHHDnBzCcxYTDSYp2YZXHKlVKObjeczgYTGZZ9G47CzSeoiMRpc6BdrxRqQOhiM59EDcdRadzSZDoaMEMzlD58YjeZKKYjOOhGZs5k8rRToZTwdM0M9NnssLZZHM0NtdPrZoRbodHADOYjCKBgLN3uxoMBKKZ9CDOb9notIIzCMOXy59bzdJxbmM0ZjH1utz5v0socjJO80ZRh4vFPocYe/CtpyRh7eGaTnHjQb5Sch0aDmbNyMhlvRKFj+v+Gjgp8qA4DqjzqM2zqMwNBDjtqEb2hhAo3QPBKEvSzQxw4nzIjiOo0siMjpwy8ARjG36fDmk4yjGjwwjkgI7h0Oo5DYFARDIswwh0NI2jCM4yheOY7DOFY8DaNgdtxFgbBoFgoCQJwZC0PIhBoMQrjwOoxj0GCZCQKQYDGIj6CYGYyTSPIahmJs2DsMY2jGOwmjUII7iaIYcj0Mk5jSJIkC0OAtCwMghjEGYzhyJM7jPPQgjyJwh0jSYkhXKQhDQMgjjOM4tCJMAqCoMY6icIgijmJ4hhoGIniKO48CaNNYzeGg8CcGFYicNNWieKY7hoJg1CqGgqVRYVUDvY4ijyJlUBlY4sjmJoqCEJonDy34m2BYViBoK9ADOJg9BoHE0SoLVyh6EThIyMUEDojjpszBae3feN5u+oQ6jYjz1urBjp3yNwW32MN+3+5AWvm+uA3u2YwjENgy3ph6fDpiWKYYMr0J3izNhsM2RBtjGNYq7sNBG8jxwojOM4nisZxK70TjKsmcJ8gzv4s/EcP43YcOAFgchvAiM53lETPtnwUaAFmhP+HIZaOowyjmm0hBaN4156/IUBi/oWBvoYchrqqIaxIOK65mkNabsLfaGHGjXdq21a1tuAbhsQYva/8A7ttOs4qnaAoU6mmt2G2z6Js/BavwgW8MhO3PBxQWcZqTgchvHCxlyu96+3e/aGGfOJ8O8YjcqAzwg0mmhlKHSv+GvUIy+o5jTefRZ/2e/hZ22qwdDGaoUpwyDSOo5h0GY4DwuY0pOMkWeK9IW+R5Xmed6F3jePHLeO9Hteb54dj6gCBIIjKJjdrve7BvvgBlur3/d1+GPpy+v7iFnaP+fqRlFjFEXu7YK4k/JuX+v/Bm41sLVSJnxBaXAlZKT7wJfi6R+bRmxwQPgjCApKX8sOZ9Ap+TQ36H/ge3ZeAdF5QHdcw1/aOH+vCaIDZqsLYXvhgvDSE7gIAsDhcvNlLH4ZNMf5D9ADVIWMEdfD2DL/oNw5iceuEcM4ov/P5FSIbBWDsJa9D6DUKIgw6X0GVfi/l6RXiRGKKUKImGTidF+NURY2xZinE2LrBo0MIjq0uNkUIFvzjiH0FQLAdA6LIRsyMiAdBhDMaEOQezKPgd0Hp1sipASVfPImAaLizhukoXANYZyAh1DcGQHQdkYgogEi2AsRAznCfQRtUpOQ7HwLGxQPYb0EPtIiDJ54ICukTDICCVgcpXAtfa+85EtCLJKD2XQj0lyIktDYGNpwMAQAqBA7QEAL5vg2XcHdm4aw0sKNGX5ip6A1PLNIWw6JGCjh6fxNaCYZJ3nxB1PIuUVp8TunhP0jhcn9ByDMQgO4LSSEMICGxJYfTKGWD2kAOQZyoA6QobgMcpZTyplXK17xqTMHCIMQg+0yZl0TNBM8Hc1AdTYm1SojM1J2Apm7N9v84QQH9pxTQn5dShEhJGcKYDHCKEWMEC4vYfQwh7LeGR5IbjMvcBAhSk5CaQzKfYVCZxozhRWO+QYp0oaCTzqcDqWzywWy5d0zGXsvyoNsM49UwT5o7PYfG8ujQLgavmqcFsNBkQzBdPvQcFgYbBWEsNBQNJKSCkHq1UCZr+Ijy0DCC5vdiLMsAsdZCsSLiElmgNWcuVTgXT7DQxwNgcLDn1sjShHwbiHExIuH0NAMZpl9mtTEmc2gZA2pzOCcRejhU2nNUmeJCUgJLotRgNwOj+vmqzSmkTHGPHqpdQehIb0aBoMWd8NwO4rXcoUDok5Ew4O6Dm+cNAMrdl1uSRW5Ycrm0vt4Xea9v5t3Dp3cUGhwrn0ZdPMO6YeJv1/egH0OFFUY3QMFgqnoMLAI/DOHs+pK5sQTImGe6JIapMUSY0ujT5yDgsX7g6i9GQY4SwODuqNUzMoUgjNUOgeWKWmfOC4uJHSdh7isTMil0ceySx2TG+mQGF5Cw8QC5WO2Jhvo6Ht5Jbj9EkyjR3HYag5ggBdeCqRVwWAuLZlzL2XCOEjyofAOGV8dB9zJd4p2DQ73gNkW4uBES2B3znjsNYZQyhwmZXMOYe86zpYrnguIOg4GRx3nwMIcAQB0DJobO2iS36LLZfYmeOwzSoljKLIOHbo5IItjsw4bSyST1HkPJ19Mdo7NCSsiGSp15M1Lk/OGNw4Bl0MYsxuETRY7mtr8xhjgb7DzgQ61pBUbFdaYScOGO5chlDvfHG2OCIzpyEGPHetNfXdLNq/U+A2Crytc9y/Bdbe0ybADG/xwKeXGB3dWrcyzYsVPXLQFxUK3S718YrY9d3oEOuVwQHe5gdAtBi+a813j73hKvjAts6bSsSmKgguWMZM0bxJP7et6iASgN0bzkwMN+GrlFwLYO7gYg4IfvPAIO+DX0t9NlsHMA28yOFhklhM8OauxAGTEW5jZhvtcC3dXRioVHKvKoGFfjJZw5UC6Yob8x9VIaGUOxAZRdMKxXNydIEKdUIMG7HhDuurz1MQTsFRz4oxNIhTt/Yun4lDoU4nEjA2vpYyaGVwOQYHflnt8N6nmKZe5VkDvTuqzd5JuHPvmXgZZdY6iw1V49d+HDOxQF3SCrhlmPv3s/jPI9878WYMsruX+DDL4XzfiAy+f16dH0fWu1deexcr03e7mep8Byh86KCgFXIIHDitZjIn6gqXLup0SFsZDkaSoBhjEcsDQcLjlVOj2uBkZENuMD0YyRLEPvuLw+gjIYQ5IGKroTMjQaR0r5vkeOtL8u0hKZ6Bvns8tj6T5F7HQxKc6dIFr/whUAC5atD9TrZIDLxmCXiOzgiYgg4xaZC68CBpR4z7T8bjqnq6jZ6rQo7/T+riw1jjAg7jT4b9Yh4MLLywgnYq4uLQsEqs0FANkFT9LZjBsGri4MTjI0LEZ40CaYsCyoA6A7hpY4SvJ7KvioB4h8KvR5J5cJaUiUyXykCoBpJekDiqSTLBTdYoIoYkbe6movqoYogwAti46/IvDm6ma66myfAtYN6nCby4ib7mamyZImQurDosxGxq7HSewqA74PC6QGp84IAiB5MFyhzQANwEAm6Y4FBIB8D7AwQGAGR7gFIPb4jHwjr9wqDzLuD6Tub4cHYPcQiVI0QHURIPoPsRb0QmSYgMYyIq8SSVIEESoMMS7YAxwGg3558Tq3LbCdkN5pwGTeIErnh84PrvkUS6LsryYFYEDRr2YgwNowztzB8UbdB5rCjBbyYH0azNbKwMIkihLYbXA1Q0INp5hJok6ual5ikS7OYHTSDaYM7SMVzCpCxBALbXgMpdjrajqSoEQLoFh4kgIPLXpdh7IN8hDZwOTaDRgN4qDIzhSYTBDukbpgrpruykEMEHo1j/D5rI65QEEhcgUggh0gx78hDMbtslUf4OkhkhwEUiEiT57RMU0fp6EnjsbqB88lchsgYEUgoNcg6wytaXCXRmMhUmsm8o8nUpjKStjf6uCXwOio4N6uolThEJivZ5jqMMAPsosnDVLVciQwCezSLXpGIm7RY9YMx6QNgMkokqUlgEUupikiRUsiirT5EjAncvJC8qZdkvoMshCtUq8pyt6Xkrcrsr7+SvCQEJp5jd0J8msKMzCnCcQGSWh4iRMAYMSdAjwqA6MBAOEUaMyUU0s06CYOEuDvTTSgswxBAFxD5EJEaSiQDeyoE3ZET0R8M0UmoF0Sxiiqgxs3x4wFs4C684REc4s3A0jRg/QuI+cu7H86CrjzJC5144TpAuCdIkjqKprfsmomqWAOgFg9ZGJjqqEDqqgHQGiYYG0y0IbhrBEIqY8zc8CO0Jcy8scMs75B8sUKYOcKqjsK6VCVU/9A7ws7qZcKDfcMMY52jhMXoxMX8TI4B8894yKp8kjUok7/IuTnzDbXAHTdFDTFbc7pDhcMCm0NEMioFGkMYPKozsTmqpQGKph88BIPc2EAst5js2rPU29I0uIN02yecwEiswbHwOVIM9iggOgFALaawLsTr7Z10kD6Du7l6vEKyj9B668KCksC870BKCZ0AO6nEmbIonYEAth7DQJjoi6jij0LBEi3oGM/DBc3UriYlKw2NLNLcTtPdBqVIFtEgiT+IEFOdKgPo/QsgNkczNsdC2ao7LINb8UL0+jCSbjdVKEwUi9KYHao9Hr+QFyBoG589Swk4FzKpk7Ss8YMc8qvowkvqSQHQmwOhGz1Q3T7VVCSRyYlIjp5jkFSpiQk8mkw8vcpMpYFlWQNlaEgEvcqsaL7rErowyj8zErOFazQrKtTQklMBisdR6FdYxMe8fLesFINpgsfa10sr8B86b0aoF1cgFgFVK4FFaynEata1bldL6LuVXdfDBgyK1J5YNE+VUIzM+zBFQIEAEJH75D6Ym9PTEk/cCiY1NdCkzlANi9jIhJjIjsIR68zFAtNNAdBNBdPlB1l1kjwtHCogklG8M9HMNUOtC7dq/lnbdi/Vn0OynTeTAENgusPljjQcfdYIyNZc27OAOYOI/VESqD5K0oqC2qdIHcTFDLqkzi8EUNR8kyx7jc+Z1xiiSKpYGYyVczN1T1Fz98b9UqyS607zfM8LHcKFso0iRYhLXzs40IjoHQEQcQQwWYEAETij+0E8H8FMINtsU7OE10xqW6tsp5ijrMmtzMrFzgMs9aAg0kptzcyF0dEJjt0Ex7gAFka9hwOYx108rMyKuT6FsM/J69Carp+7fdkwNtjVlK24F010qNaMo0xIkUxawytV5gnV0pys11iLGU+qYZv13Y8Fj8/tkRfCPdANlZj9ltCB618csdmVRlM87010LleK2SoF9tC0OS/VDwEresEI+1KTI1y5gi14nd5FbN5Uvl5kxl55jcBN6d/yI7MdzCz90ctEo8xWA0xV6KUGBSLqR6ELX1RdM059vNAt9ozCNlAU513qISHavKy996ya69+RheFd/uDNWpmIMmAMm0veCaw2GhiiVWA7RM9mDCF6XrTNXTqNXgkVX1YFYT4NYswghTrj41qatF4xgjxT0soLu7qIGQGoyVXGIwFwHERLo0b4Ftilus1ogZeTvrhiwGKqLuK41kusigjwhokTSsoLuL6bhcjbKGKz0gjjqyyVgzsNMKkAFuPuL7G4wR86zN6luVTdg9ulVYMrg7Ta++GSF9fj3kCTkFL0n5JlMtPtFjxot4yNlWE6ytC2TOQLDqpWBmN+TWVw0mB62OFs72VWGCg7fk12Tbm12t0SuMrjsUTGPuVjtCOggmDtPuD9+GFyOaPqMCkt8QhWE99uZM6ma2aCNKdQOmXhglWmaJf1/4OWBucGZODT5qUdBmD2bSPebGEeFavOdyHeeCQGFeeiM+biy2XePyLucObl1t1DgGYSo+Yrh13CugMyu0/eakKR8kzVNFklmB7Uz6nqWhpOddmcLK68LeacCV7kCs/2joysDQ9MLt60jYEDdVBB8l8szt9FC9GtnUONnlnNo1oF+uiM71+gv8Olo8PDekPZGMPoj0P9qMQVZka8aK6UcIHbh6hcQ5hBeVx8E1Er5ltIHcVcQ2RlhgMoEEcmjOSDLAhDLWT97LBDFrhw+q7uqKR5BAN+h1yoHQG6Yd7sLWks6mlsJ2Fx7+mFmJ88a4EFfaZrQuMlGLhjpcjz8uNepqwGwVfZwZtdbkb7d2REcIEAFt7xEp8GvdBWEp67dGZuW6ZeyRvJruj6QG0UTF+Ov2z20Bj+0Vyuh6vjj0520Ttu2ksmwNhsbMbbSzRAhbTIiMa9dzSOwMawyOpjstQda8a8mVQmsU4bUIiTvLI9Ql2O3z4zYzYMuuOr4tlTOB1QOR1iqmw0j1GTA2zDF+E+8e8p12VYF29x1rLsDNbmucjtF73bm25m+e8zSZk7SdiGawz9vrOG010YFxyiSes+lWtTBAHB80jWp3A5yOyeZdmj6vC20992kGu2kWzfBBre1EJWuT+OunD9kPDRz3EevWimvl9m13F9BWFlvW0vDZtir+bzHfBHACuHDGjnGKklCWEG1o1O+PHu5/BR0AOW5LX2w613B/HnHHJzMfJLMfBfKvJZw8cro2/GNBgrttcU5HKmyDL2wvLHJnJ2wfM6r28+/VcGxoGHCpzzL2/wM/N7CHB6q6q7HfBejV9VAvEXBfDtj3FMIy6/QfJnF052ueus/nEHFZyXQl8Oz2EPGU50z3GvQXHByfRe+OwtTLN1deqr5VE0k9dsfMfDPtesn7CawBfuTZ9zQtdp5IyO6ik4OtebHewsSV6rjtsDS+4TPKgleFcfN0B5H7X1R8G8FXMW5j6da/WQNbLqzXZQPfL/MWqeuLzbQXUMjTF3CizTpBiMH+pmLm9R83VvR4EEs3cbQRmDLqp/KG9J6GT7CWtGlaYfCNQW0XeMSQF2WvIF9aZbGqCeDe2B8VBNmtAHGaWg5QNUXruNYIObL7iUSNfe2XNwFniHiTv55fizMPjEB/cneOylGL9AF0up6YnQOnPLFncJ82satUeseg0W4y11eEdjREd/mnm+PQi/VutDT0u1PwlTLtfahwg9SyXnenlPlcu56o1T0vmbkDhSbnbdsFDtH774yVVipfrr8ORU8wFwGR8/qB6glW5dUF63fGzHofD3SHFS68JANmvWUXDPug7fu21PTNAlG/ovqW17hMUfr7lzCUavfPxIFwHL8DAUUcTHw6YfxOzHxfxoh7fjMrLvtB6oEBihIUXSp/AnI6l1/Zj+KNZTN61PzfwIlTHghBFiVSI/zz17p/X2VKr2fg+rfjM3zn1wMf2D0UidKNY0wrOH3v1oOn14tr0TL3301HqjNluestT/4/1h6Z6v5f2P535OD8UAgnqtqn58awFn8e+zhXfKbkaf5PJ2pn9PV8cX9i12OaCWO0u/8v9kDN5+Ok568H+7+NGu/7f6v/mPDYtG+3Mfnv3lwwHRrAAgHkgdlbjnEDed9d3QCVwp8aAbAPCJBX2OsASAixqgJq4n8aAlzYgJf8P2AlSoVdLAlRbAaQOEAxGqpCY8pPks0CNPY5sHiQJ3qMCmBJAxgWwL4HCTVkIilWEwNX/JMeBy/mJjwMm9B2U0kjVfnvJy1yWYM2/dgSQGg/UANjvANTdBDx/TxyASIsEYhDYBxY+A3BaS7wXD8EF+CrAoJqrKIMoHaDPAdgto5ILqCM18/hQFwCS8AfEISB5gGt0kc7WQykqfOFKoynR/RbWiZXsQVIPhB+D/CBaSubHaxrV3oyILAQbYHYfKEgByhANYYSaNUDESTg9Fp2+y2d1O1Zf0PMR6BXk0U7AeBqBUDLoVP06HaRp3oWa+ED6gZVJNJXQCmYx0ydTbsnzGijxkqc2euKsIXbDZOYyfWKQiTBDMY0oH3CvgKF1Yj1/pB0S7qXVtat0ByWATmQsUI73tfcatMmrlVC5fMqUyXNOwuyljgJzYaUT3Q7zSkPFYgV5WDvQEIjpFAwMnHsF3k6kLsPOaVVHh8QlgGsDyXkeUK+GraK0BiogiBuAk90RE0o6/T6LFnfLGeHFD9GYl2B6732I/AgO+tIXucLiH9C6A6BGwgcRKJSPqNJxBIRcRhsxEae8OQSZcLOIGMfiQNsVGMSR0REmiOxKIegGiHmGfiXpzYkKuGJ9C3ibw/hma+FRSdAUVo8SYCiCHoH2gsw2iY6OQMbFFDLGk4rEBx/7B1ijleYCR31WYgZM4o+YlgyeLWZzcBDHSY8RU0OZ3bhuxTPsLuLcZ7i4AdIehpWLqaYdiI11EDgGK5DviuDTCg8A2K7C8jDxRoxLOSMYaViNsuCD7CSMKMxO0iLgNcYY0nGIiwRmyjr82K5FEi1JSYz0X6MhGhSkxpIssTV4IVdIJMDyWkadJdGdGYxjI0B3mNEZ/fZRi40qe6LdGojcxj4r8YmN6eijJRXIykbBQK8GYHxmIvUZokrC/ZRw4w6L3w8K6WbWtnXh0Zk88SVjdRqzvMYyHvHOKgROIuUTo8LDmNcmsI6ceEe/HjjjxYIycdZZpFpi3R4o40J+LBACitR5o4UdSPnH9jGB9obMWODTHMiLN8InrhSLVH8jPx5JBAiKDRFbiXw1AOcNYOQnwhsSForUNxYkrdcpR8T2chKNVH1O8wc5BUhiMbH7kCyE5FUWGQvH3UvNjIEL0ORMvGkYyKY/0eWODIRkexu3JsgyKi92iphX0eRPN6+AziNEm4kRm+SEYIkDRiYycPGJhIjcvwy3HxLxbCN/cwK4oephYwci+OBh/WpyJYqQc2k0Q4CY7Ut6uogAyHtCUJl1SEzFDxmCzSjQAj8EeJWIOGr8D08VBCgZwRYcDk14CahMusEUlsZxKWYYCdmGoqRqQB0dDMRQu5RBY4K4rYDSRWRrYGYNmlGghpIUocpgy9KaCosgDr7YuHzA0Y3GZjHivIlE7MXJIOEIMZWKbEdicjiDwpwoBa7shEIYHuKyCJ/K5GNulSQDXM5A6WJuNL217ZtZe9+WYufX6xl51yrzMvL1GT6xZYsxnZKHB1H6eh81LWlZS2V/yod9WZpUdOomSLIUtOWah/RKlY7KZu2EhGCyX1D6Jhu9AKPjG35eI+oY/L0COubDBrvSR1LwiOy8jH8QUw1EIMRq4W/K3aJ7LCj0NfXIaeJrYUKAWtUmuEv6YTMAA5HVphoHmKRE8cowtmzb3VOpENRDvZjXcv8IGp0eVPRXlry9Gk9sJMu+TA5gkfMiYk1QF1lTqlHvF8bjzL5j8zFybBRd6NzAt5dAtIEcl2I6XmsnGGIqqjLh8TbRjp1a7ummhUJp6JEIm7YhjHBx2TG6a6BumvokjMc2ebSHxOvGF2T5upaqi2eljJ27i7RALNAXivSiiDgF6TN0m+pUDq04B6Y1fbIuOIKSfV3FCzWpDCYD6uFGEYLRZIjUXZEctMidDGxclrS5Aui8TCWTHhjcwoIVMCCCImHrM3MofOFm7tb2qjVCY3Osa4yvnPbcyb5OFhKTtZuz05LMixRGItEXkmY2CA1Acw3wPE5iRgB4mokin6keCRPJDDPyA4+UlSRlI/ZyyU4+k9SQFPWkqx9pBjzNbpL4X7yO5FEkSQbI4gKL2hxElGKW2bnGRAIlE8eevIHkWP9oyklBXDH6kCT0pH0geezPwntyQIspx9Nu9fesx7lSBJGeZI8n9SRI80g1xQ1pbMGEljC8JZQsccwT5mUE+KedIzkbQi3txMOgmvDoLUGh8DLOdXL7m9UCSSq08ItPxjEzJZ9M/dapJToWQDJ/8kVwFH4KQPVmxcWcxLI3ofE3KENBVvCbLRJkvFUwfYlMMSAdyRzoJk2UsFyWwu/DmkMdR9RUojEqTxMqo6ydnMv0RzXz2Mr7MuM4hC4OFF+i0uEX8gOmZLU9iKyLmmJ2AMqdoPSxETyUcDWIU4U8OtnNtViR8rVBVJxlcFIwy57BVpR6LoAZybr8Mq1RLAxAYh1tAkDJSIo+FeZZSbdCYyWWqGX49bgxa2xyA0geD0UQpXs9aOBqGXr72FlCzsjrveo7MLSKS2Nn1x2EJKBtq0eZauDfjKCiIDIi2ddO5qVKviW/JsV8MqTw4cZQtOumONVFy9Lyl8aqMumKXmbqSX1N5bwBF3q7/CirNkWFrxqZwHKl+ZdmwxgXYabZ2NTei5Uz0H754DSSPJIp3Ka64gGEC7XHU2WLYDWm7Cjp004KaFOyfnAEp3Ekp5KsynQHop1O1TxcJdmNOTRaIj0XCJNF3Jqkvom0YYHuk4XZnyyrVhNKqmbT7pwgIDFMoVj3O7MyAYSXK1AgMqOe90fSsyXWlEl4cvwB5h7nIB3TTeaq7WtpTGVlSmNguGgw6hw2O8JRSSpIfcSUmXMqdKzFU71Ug8LMsammqKkwRSa/UqjsmXpXdSwtLOeNvQxFVx+Am+0qKsORS64cSmQUuaeheQFwDFXxL2k1lSqVTVA4i8iqoVJ6qb3WqtSdgGvoqsTLimOnhXg0IllU1WicorUWloSsk18tNV/oiLxZtFXQlDVUVnzBYJszhPo75f01c6qVY+rs5kHPT5aH0wesbWZqU1m3UNECSi6PaHVn5lFLR744lM4O0TL1aGpQLze6u2HE71l2fWYrZkBxglQOGHSfLo1LqUdTFRiIUZiq+KYIZKGJWKWNrKqpw7at1VTTXMcTlb1t7LXIorKraVVNmiHXNrGVUa3bCgLQekTnvwa3zFStlXSZwHoD2zFcasGHrzy769NY9l7Xsfm15H4D8yeSrpdeUxwPb1+XCr4nTTHawcpRRaZwHckBqrCSWFSf6gD1aaYtXt4LV9X5obQiJ1EBsr4sCmrrA4C6wSRED0CQm+7ic6VCKWJMoGE9h83OTPrmLxAHcqqdWAxevV2QwR1MzgBkAxMFhF4QmgdWWbMNzLHFjoXlNJLmTyXUlTgvPLXLxzW2N1kFgS5NgH2Rnmtkx36MnCcqvZhcIux8TDsgWObJ8ColAZjsnMQZREDmYQMUsrsSZmQ8SxjJgP0oGTQs64JI9ZmDOFAEYcQKhM2kSOFD61A5/U/wc+ycQPp9anZNiIJTWDHLJ6uAcjasH+rQYVcDqZeNGiPxGMySe9PLhnL2G9amSlY95qlw5GadOQ0UpJV4VcDMBeIvIMLq4F6YFxex025GKWlYLFtCO0IAutJlFkdKY5oGlaaEyn2haWCExCtcZq4rWtre0rKJZ1UgzQcbN4RavqxvuV4Fd2xdaPDD0/n2drYJja4AWWhAibOlbTaSts2lTWwR4rGWjKzSy6pTwWMuwxtuU7ba9saE9bIW0227SFP5gfbgtKW8XgVumNkQgPmx0rWoiw7OI7hPWCy6Ls1CDaZMEGLrEx+RYOpianVMn0YUU5US0uAloiVNpWupR2Vc0cGMKK+4vcDtKxkrGFGKIfbUA6wXR3Nfe3hMkkb1GmPZy57KxdOdviTBVxa0hcqCdv2zq1xi4Jcuhu3DzslZRS/LuWEMe5g9bA+tc6SKV97gQRy5/W2W3VuDg52W6WBkA6hM7fFriozdGO73MmLhzG5sjDtZt4bq91l2ldPuM3BWud1Rv43XVr3IbqFuJ2ycHnTvKpkFDqNjWQjtVQq1T3KWKEZqkOJVR9cJLxUyrc1yT8NMOrcAuAYU+K5UIsm4YvqbGw3oTetqc87R3I8JJUVWqdS6Vx0xxBACBGheVV2I9XnDqtuPeaCH3nCAaPOypdwfnXeXbUx2S3UMRHItkSCLlEpUSetomkTlRavnWjqVwpWp8xmIBZzmO3vqU8mChWuzD0HEKsENABAUXDcHJQ3o8EQJI3Rv123yD1sMgdTqS1jr4kdk9oehNK2l4QtdGs097q71GLwtKGlG2sdE2kKoAY2qFdCJVUs6V1LVpPdEqhn0IfV96Xvfgpu3wyIlb2/UZarXqhL8daLASRdupMtJjtbmzfZWJe3yChazpdEPns+1popTuKdFcGVfnf5z7vR6y1ne33mJ9FBg5BZIOIWSgHd6x56rtegU2zmz1kryjfv+Wn6V8Lp3GEHJKmY6sggjAyE7qc2pzid4wvqX3vmGwVsU7xFmgutJoocB9eF7qZjwR3xj9M3qVHgCSfHZQPoA==';break;case'default-green-dark-6f277ac6d38bf82da275ff1e9bf26018__07ffbd7d.css':$f='OjkbzedD2YzebDechaczGaDKbTKOjYaTOaDoOxaLTMbzcdI0YTaaTYeR0SDKbDsZToaTGYRYQTkaTCbBYczCbjnCzLMTNGI1HI8ZpBIjyLTbHDeOiVKiEcjCaZwICbSBYTTKboQLCHHDnBzCcxYTDSYp2YZXHKlVKObjeczgYTGZZ9G47CzSeoiMRpc6BdrxRqQOhiM59EDcdRadzSZDoaMEMzlD58YjeZKKYjOOhGZs5k8rRToZTwdM0M9NnssLZZHM0NtdPrZoRbodHADOYjCKBgLN3uxoMBKKZ9CDOb9notIIzCMOXy59bzdJxbmM0ZjH1utz5v0socjJO80ZRh4vFPocYe/CtpyRh7eGaTnHjQb5Sch0aDmbNyMhlvRKFj+v+Gjgp8qA4DqjzqM2zqMwNBDjtqEb2hhAo3QPBKEvSzQxw4nzIjiOo0siMjpwy8ARjG36fDmk4yjGjwwjkgI7h0Oo5DYFARDIswwh0NI2jCM4yheOY7DOFY8DaNgdtxFgbBoFgoCQJwZC0PIhBoMQrjwOoxj0GCZCQKQYDGIj6CYGYyTSPIahmJs2DsMY2jGOwmjUII7iaIYcj0Mk5jSJIkC0OAtCwMghjEGYzhyJM7jPPQgjyJwh0jSYkhXKQhDQMgjjOM4tCJMAqCoMY6icIgijmJ4hhoGIniKO48CaNNYzeGg8CcGFYicNNWieKY7hoJg1CqGgqVRYVUDvY4ijyJlUBlY4sjmJoqCEJonDy34m2BYViBoK9ADOJg9BoHE0SoLVyh6EThIyMUEDojjpszBae3feN5u+oQ6jYjz1urBjp3yNwW32MN+3+5AWvm+uA3u2YwjENgy3ph6fDpiWKYYMr0J3izNhsM2RBtjGNYq7sNBG8jxwojOM4nisZxK70TjKsmcJ8gzv4s/EcP43YcOAFgchvAiM53lETPtnwUaAFmhP+HIZaOowyjmm0hBaN4156/IUBi/oWBvoYchrqqIaxIOK65mkNabsLfaGHGjXdq21a1tuAbhsQYva/8A7ttOs4qnaAoU6mmt2G2z6Js/BavwgW8MhO3PBxQWcZqTgchvHCxlyu96+3e/aGGfOJ8O8YjcqAzwg0mmhlKHSv+GvUIy+o5jTefRZ/2e/hZ22qwdDGaoUpwyDSOo5h0GY4DwuY0pOMkWeK9IW+R5Xmed6F3jePHLeO9Hteb54dj6gCBIIjKJjdrve7BvvgBlur3/d1+GPpy+v7iFnaP+fqRlFjFEXu7YK4k/JuX+v/Bm41sLVSJnxBaXAlZKT7wJfi6R+bRmxwQPgjCApKX8sOZ9Ap+TQ36H/ge3ZeAdF5QHdcw1/aOH+vCaIDZqsLYXvhgvDSE7gIAsDhcvNlLH4ZNMf5D9ADVIWMEdfD2DL/oNw5iceuEcM4ov/P5FSIbBWDsJa9D6DUKIgw6X0GVfi/l6RXiRGKKUKImGTidF+NURY2xZinE2LrBo0MIjq0uNkUIFvzjiH0A==';break;case'main-d2ae9fdfbf41846c5ec920f713a91abd__07ffbd7d.js':$f='ZjqbjGdDSbzcCjOaTIKIULDHBjoZTwdB6bjqbDYKT2cjKdDqcjcKIebojEz4fDIbzGdTaZZIKRcZ46RTYZZbJCEeSTC4UKR2fYBAoJBgUcTmKDmZZrAzecodEIlFItGI1HI9IJFUJNKJVLJcdJgcTqZTkeSnSjLTDlSLRap9QIDA4LB6MbLZSzpTafJKjFYvGT3IzmdAVSjmPaMYbvabzTpHJbAO6tHzcIMMW8MLpqbjOdDQLRiXZ/QblRMTi7Ve8hfqpG47lKzfK3KZXN7ALrFZLNbcaQYxqMbb9JQ4OcDCcoIYbsZjdGsFhOOZ8OQTkcjCeRcYTgcDYeRRUzYLOjXpIc5gczYaTGZRQMZ9k5AIOHcxRVdf8eZ2e33RRnjSObxDk6S3tGuLiAU4zkDS5TqDOFDmOcgzBgU6Lpuq679O47zwQCM7yDo8zJPuyr5oMFDoo1CothgLoeujESrxIN0Mv4/0AQrAi4KEuYFDaNI8DSkI6OijoWDmN6PvWjQzKa2MJjWMo8gVIIFSPJIyo1IcBI6LcoDzFsrDk9cuyi0Q+x00qDryM4zpqhgyI0hKeTgFwxjYMI5jmJj/joF01za9gRDQhQyJcET3xG+TlKTAsdqIh43jWNL2TwOY0jONwWDI67zMDCTCU2iKKjKO4FCIMKIvqHdQjKFykjpU9U1YmKO1i9gUhXTY8xC2kPzqN9I0nF080uNwVhOHbLDwOA0o4w4T1zVAy0bNIFDssg0jMPIrLJS0TDFPAyiqOTwrzKDmj3XrbOyMgyCLa6ST2waXLIFARCIJ4miGqF4jeMNCjIEQWPqHofU9YL2BONwyjeL9rjlbw3B6GAThY9wdjCNQwjwFATjQOg6DgOYdBeF7tDSmI0s8OoxV+NoXo4OA3jnkwyR8N2FjeFqmjPmub5zmC0XDmk7oiweKhQjjcsGFOC08N0J2dmWoDKHolCmJ4nBdBKk6SMulz7qUJDKKiop858e1QMY0DKw+xapPwwjOL43DCloXDbtQ0BQF4vDsFAuDIPYYhYGQ+i4F3A8HwvD8TwXCcMFAWxONg4DQMI+DEjvMTEFPAh+FPQBIF6fWyFAQ7yOm17aFL4DcHe0YfiIe9T1Y5i20PYWBSWE5zh1urmHtodkueLbPT4FVCMPheIg3hBX5tjBOE1zJd5/q9fjONhRcCk3GNljjmMY5DSOCKejisOeUt4WQ5Dg6Dksa3uFA0eKSvArOUsbgI10wQv3MYq43gZQyBJDcoUPB9kYgggAQMFwdn9LTD62iBpEQyA9gqC4N75i5u3gzBWAkBoEGidcCg4EBDssgfIGIOrRoHwRJOHsPp5w4FpWypMMgP4QBkheGwsYOodp+bMtRA5/wqNyBQUoFiQwzoRagYQjio1ShSDKGcIqy2OheY6CuJixwUgkYqCcNIJ1EQLKUCYExHIhGDiSGxuIZwnN2SxERHiCSvxHQdEqJhGg7qDTdGcEwIYjRIj03IFJGilA9KU1s45XwnBvUKT91xlg2R0KI/AIbbAxhrjbE5Cb8Aex2JJHiNoLATvwjIDt+CdU7p5Xkn1P6bgTurk3ARisi5aJQTgDt00i0mByDbGiXxTQ2hbBOcoNgJwuzCjdL+YsxyMTKg0QI9Mm5ETNmJMaZE0iDJ2PVJwt6aEDwVX2QEOibynzmk8YQPRZA3g9IfOYHs8wYEnniSSebwmKT2SRPieYJ1kKvCQHQNpdiGgonaHIN4P6AA6BPFsrM5ljxkBczFO562+BcCECgH4PXAOCBnDMFYJAUgvDPEsNCSA5hhgOHMs6CVUFNVxGSMjx4nmFDYD1OSb3ShmdOUp1qI3dU3SCHCFphzTxiDdUYOgWw6B5hqD0EQc2WI+DoCILst43SiDpI9QsjCOEkq9HOX4KCamEqLC0BQbwzJTqXUd/tb0+hkP+GEMRNYL0JDeT+cSPJnSZLTJxupLUlpNbQUqtdbUbAumcC4tBtlOumsGq1o055F2TkOHuXEmpdA9sXLmAkqg5WAk3J2vlfZL12JraScAe6ytorSYSthRaVsdSHXdVsubVBlBAHQMgOgzLNMGC1tYaQ2BkBBbGmoe5MWcIZXKcKJSDzOCqQK5xPbXTEurLk3xdgRAjBECsnslrp3autYG7pwKZXZLXYcmptrE20MVBWmU1ybFfTrZyAgPQzKLWnc2wMbb7kvr5dIBVf79E8rk+2ORGqzgKtBBcGAO7XvIsRbO2NjJiWOveV+yNPrJxrstG6zEzL82BgIc7BIKwV18knhG8gCrb2rmrJwMq8A6EOxqQ6lgRa6EUfg/Jp8n4L1clJje/CWiZY5lOGSVODzIS8p8GPHuP40W+jQf0vtvlaB0CDCoNMLFUgneUC0yFNX+0+nJjVOsyD+hkBZkgkgLIuFRiXDzJeX34ZhhawnModzjhuSCGfNBrkY18m9Juj2iQ1knBCHdIJKQ75dLOXguZJ8l6VMYfQmB/19kYO0UmXeD5E5ylgkQOgO4+3GPZIIOeRzwynDlct00g486xxmGUPjmLYh8MhI0MOtKfSLqfDUEM/5chiDeHiMmhjKE/2TssIebMqG/iVqZs+Nb+X+J/qWrcjaxSQWm/6oGziQV829Yy4QdJM3Gh5cFiG7I/BkykSLGs18Ty1guCGzeKN6SLm7jXE3AZvqqD7L3Ekcp8yzs4FurO+JnTamiF3fNnb+hsUZdS89pZoBsBacYmUqeD0+b6f23Ycw+B2UmHc8wXAthcC66PEUbQXWYsLMC7dzuGWBBbNst+ALS1AJ/g+Vu8t/YUfqo+zmyg8bT4LtgPb/rF2Y3M6/kcSccKuUGGYOgS0o5ZBD0W1kBCT9iwTzXhU8+p4NnXhDBNHuzb+B/3HfXFYCA6yDHPB8udBg97Cnjo2+sKWGeRbG+NSblAsyNEhG0ptc6F1rXLtBLZ89rsJ1HKdnNB1xqZ3aC+MOgSctiW/yNTPKqD5QHy2M+e6S6zSSLzRnCNBiI4GENe0PYhns8/GCSZw+mGDKHv1t+0bYF6SQegVBKDZwY/QXtsiSjMdC2QqqS0CFUVDKdwMNGAX8vC5Vik0pguBcBICaMix6sSp4R6/5tOTWGAkXVysYLkgsLDkEgKgTQmPCWR7/jD4KRb+osj/D/QHr9q07AwNzcQKBmZlQ+jcrB5mQw7CbVZNyNqRSrYjjlSlQKbMI9L2QjUCTFiSRRMCTGLkAMrpy0oNAjgMzxRuRLDzB04/6OIJwFEFAFKNEHD4QlRVAuYF0FgMoM0A0FoFcG8GDY4HoGKhgE0FB58I4mQ0AFKhzkS1Ag5IJlSOLlQM8HxEztrMQvJiSnYERusLcLoNwFsMAgxQ6oZCY4xhanMMcMpS8M7j6lgpUNkNRGZf5dzHCV5egtYETRhgRghg0PSVhSqV5PwN5NhNwESDZehgIn0N6XCVpPRPkRcRpQMSBhcSQn4t7KDk4Iy4wiIOQKgNIlpJAqQv4HcUK3AOcUYNkUp/KHxqqgDpBR0K7QQOiI8V8WMUoFAMgMSOLy50wpJYggwKYxsGAjRdS/EPhd4r8P7+xjpfBfRfgOgJhfxgBpBppgx00YUYhqqecY5iMZQpsGDLoJIiINpjp3zXIOYL64MWQsgL8YSMiNEcoucc46wmUdUdkdxhgL8eEeUUgsi5anaU7k4FsecUqiiCEWqDBtsc0ZcfzJcdYm0gJhsgkhsg4n0jsUzk7gz4APcfUZMipVojgNoN5a8jEdphUgUjkgzWYt8kwN0fkdJV8l0jUgbk8gsegOUewMRiscLBsT7aB5EkCAz00hMeEhkmaVMpTyUaEPxPkQBjrxMQoPbSCA4N7SZOwMo48U8VKFrk0X0mcsZhiFon0eEX4sktMVQHsrjSSAUXkVEtSc8kEXompAAGQGAGB+ZVYrpdbZQMg7EqkaUq0agE5LzSQNyW7HBpzWoOYIZ+AuzbCYTrIObrbrrr4EzUwFxL0RYKo7YsgIZcJgif4IzZsqTzpJglYo8j8mcpaFqAQvBVU0AOEDQr4IkIQMIi6c6cJ+kXLA8tEkTtsiAsanQhS20hckEh6CMRcbQO8001CnoFE5Mcaz0UUmcWjIR1wn8ts7qCIHs7MVojoBQjgM5Kan07MJKgE5CCKK4OCjwMAEgPc7IPoMAmCiz7Y9j7r8YFwFYFQH7lwLzmAEg+qGTvwHgHwPgHQLr8IE78b8qVM9SKQBSKiKyLAMAFE+87M+aGYMCUwhLkUY0icfclAjUm0nEf0nUgEmEjcn054Fk7I4Twim7XLw62oE4EceAEA9K5bB55b6IE4FQLbMs3UVA44PKqTvL9KJa3Yn0VwmscU7a3AFx5RV5uK3EcTerXNKz95LK3dKwML+hnEAb/IJhPx8kdsti3dLJVBcLU9LrhVMCOQn5007KfIERQ65lOBO0RMTElUlhhJQZdolyVNM0AT+9NVK9KtPD/wpM9ks1SBu4vM6c6prrTqA4iQJ89qCIFIHxidMdLFQKV1QYm1QpjtQ5Qsx4n1RdNFRsAtO5u8/qjE9SUwHgwahQzgHwEgGIHgF9XggwM4HzkUkjXMRFVAwZdghZjxQlRKcMKytxlUUYpQMhV6njIYwi4NbBV85YhYMFby45V4Fs+4hU/U2Vb4jtZ0aJeMxResQTGsQkb0GVclbNdtU8S9Zox4MJIIo9eZmaAhQ5JZSdctfUS0RVQha5exO1gcTxM4nz6IEQmomSA4EAMJgVfBV4mExFeBecaleab5gTUxp1jlhNQVZqWJQNh7UUNk3M3Ykk3q/s4E3EzQvIOAKChTkEM7g04ZasLEXkRhQAo6rjm5JwwkD4NdHYxQE8TJQBito7BxIINdd0qtkNeUQbOMyJgy2CC9pbLrPSFbPtVkFqiiqgMVXjQY9onynYntZdfiWFokR1VpQ1KdqtuMRVlhe0Tlggn1mLU1mk38WVm6/AwaDdnaDZuVn0wJM7A1oQs5kDQcWCYlBRtCZ1cJexV4ggzgOcNi2CuSpC2qqY3gFi5KuSpyqEWzaLZgLt062N1SqIE46yugN6ZVjaYkj5JrB7wzDF0Tzk2tj8bNeMQJtalgmVesyTySxttKq1n7404iCoIJdoKUrzrAr7ttfCzz1ENqKEryeANggwMqsZB9g6Hj+TcVda46ad44zhqqCta646TN5BadfF9py9997DAjCqm6CtppjqCpiqhQO6zKDKyciQvDyclL7Ki8/4LYMIFoPQLrlxwIFYF6Uz8oGKVKD6AaAtToPBiY0dHBCd3ytrxCuWAcryzLDOBGFqOT7D7T7mCGCWCjl4MmC+DIE2Dc67DLYs7TnaTbpjZrDLCLbb/7br/7qLyVPcW5M5tEPQxAo9p9hgMuFWAoHcQ7gjRSCqKklZa96wO97xBDcAil+99Kr+NDcanyrlvUTFf1gFzYprXNguJZlQKeOa3eMN81bCsAr4mjAYyIPuNo7SGqA7dq45pOFbGOLtVWMF65LL1GPwkmQBdeKpVSSbi5RlaiCos445tbrwPMx1/YsEGU0BLxfZQqfIGIGYk+U5KOVM7QGMwC5mSRseT4NCj1ewPqviE1e0COBylK44smML959oqOYp9UfoJApSGoOT9884wgwY44OgKZ8YN4jALJIxLQOmbRm+bxjebTosBhIMUubWAmZhS5j7VTSMr1M+O+PK3C/j48I6sOao3i9ZtCrmKWeor7TQtzeoENo88F/pqMry+ONq4q46sL14EOAmN1foiFf5qBe0BQFpI45GOtyOeImuPeAlaedkrrSejY5GPV8C6WRWAojed1fdheRxQOi2jCq6mxCd/IMgmufgEUIClmm4MpgWj4Hemwmtq8xNrMQMlYOrUUrwN1ktrskubmPBBQzmlNrl7KGeoOnmod4cadeQvIOpteaejOqqfBg2sOauOdtmAmsYsGq+Xkuedw/+qNzr3WlCBQygEAMmZeZoskJI8An8XBaus2uWtMr2taRDrM3VwU31m2mgwhmWcosgLKnQjucgvgOQLOUmxuMmewHuh+NQHewWa+bMuWdrSZ8ShWbO0GbmyWx+ywLIFrJdT4MxV4KiDelIn2b+yYOm2W2m21o4HZvIPGyWb4FeNqtm2YjudIM5j4Fuh+46gQMudTVOGQMuYRQoOWYuh9h5hd8rvMSeYObG6+MOiBPsPhe26m6wskNmNtgAsgOgIUIQpo9m9G8OYmwuoGdG6O5Yim+mYe7Gd25+5O/WdZ02h6JkcUJIEQKgKVP2/O6QFaUI44pII18RVAFGt7SbJZfYNqpiAkZQPJN2/u8WFZvA6JIIIQN5kAN4Not5hYie7Od3FwOmSuf0DzQeaLGSDaUIN+yGy+i+1fHAmrrm3W3gjoJkISc+oDB7SAMgz2zudzJfFAgKugzjpwr6KggY+oF3JgzzevAxuVMKqXBdP1zDdeRCC+h7eAwfGgknM+MbZQOW64K4hXJ18zePM6DQM25AOnOfJoz/NTeTdyVhSYknPozykoGXN4pu6+5Rj6j3QHPHAIOnRoOkp/O7efQYr/SnRG4BIO14HvOHRnAbVO4PT/UMAfUaVSDYFvUHRfVG6U87rnVnU4OXQwNGdnP3CAGQFXWnWzwa9p5GhQMi+O7TeehgwPTAwfEBVvLmXPYTLvKSA7QfKwknLE4PLfOgNAFYEQOAPAEQn+vJuWZhyosgHsZwkhOr2oiPNic4EWOgn3cIM/ceZxDIlwMnM8YMwa/B8csPdbDokhewOkwoPNgveuQ7ee2+JIpJdOvXcmZ+AncHhvenZWodnIHs+y5iDeQYPAMBVfiQshVyp+ofIQinjHknjfjvePefkHinZnbPi8+/ZvlHj3cWvYOW8lZxe3eIhIzkNnc5Pvgfg3e/hHlXmwn3DGolkAiNkWpApOL+nwFgOoOBVmwb2WkMumrd4vgJJBtfp5gXqXqmtHq3pHrOo1ze0QNnr/qZaXqqJvq+d3svpdeXpoMvqVjcLEzftvo+0vpN4ns3d3rhtiA/u7QXvPsXt3shdtd/v3uUQOrxtbKggUPAFi4PwoNHvTGPsHtnw+zNbhBHHm123Wyuc2zOMe0+bED4M/aJTYsoHoGbCaCiGqAhfcIS4IMfQgigHHHCumafyXHfHu1/04jDQf1dJjev3hIfyQHgGCNHpH4QNgLIH2Wn53tAnIFAGBTRPilg9dYf2Xe4N/2o9X3CMrZ4Pv5H7Zqu1ucwFvpFRnSgFf5/4ifv1gPP4/7XyX6X5vvn54LIFf9qrJ0oA8efqWXfTJR3+J9fnum0rb/t+qHefsP53yT90DK+zfwOen8S9kRg/lMoOOgJoqgDQN4EggKIDoZ5xKMcf1NkXH7NR/6/UbUP0IFIchmtAtZvOngFICx1K7wePvN3lqItPo8YWcvM2fTGUlC3gb/N42z5g9vCBOZkL4HGTGF1Un0WcgLW4jcZz029A4OOCypoNmK4ib7MYglKDJZyA+gshnG8bpJtqBwAVuDm/YC8BkArD3IMgEME1pYsKY3tEmOKGQZ00yY6wYwM7MmCWxig5AdxUbi9xiFRd2IHSu7jdUkfBPaJYT24mc+AqUWcwaUr0AGD5BlgqhHYM8JQDu6Ug2IUgPcIEs8Nta5sxYS7O5sSgbakwh3GwZx4VCMPawjwPqBUPZCBTrwgUJMEmD+evhbAe29g1QOQ3wJft84IjiMDuzHhCMWIRcL5jK9Cd8QXG/8MpcefHTivlntqgp6K8OecMlwETzs0G8+gcvIXZcDxmhDZeJvIhVrySHLDhgduzYcsAV6ASQDsMVXfEOYLI3fT/N6YaLJMq6biUzhSYYLfEI4jBhwuBztLmICCBCAmARQEQD+Hs83dIOmIiJu4B1EPPFQxYLsPgPXD6bxsl4jTdVvrDRhBgdGYsQ9mg9IYqvi2rjUcpU0ve1PYWqT4h75EpWsPjXrbV8DQ9eeovawiL5iJQ0viVPWiqb2iJe+biYve2kR9h6fFBe/vdHuz5R7w+XfDxSEukTRqLE2fAROHez4QP/FSijvbzScVZ6UlXisvkH9D2mKhDWipmMTJb6Nsi+dJenWWH6mcTsB1FCrAXx4GhjqNoi8kiouT4EbaIrAusrjrK+4JkBkbaxWh24ixFaeAi3Nlyzz4F0yEkAswr1SiaAm8FfAsoSXKaEISCYpPhRjn0DOaL877D0xmkEhAtnHGjbIlfAFIqowMEPIfAbQNwE2Jab2FKo4lpD7EpYwAATgc0N4xURswsOSRsglgG4BeczjgFLFuMbpRWhvjmnCiWbNiOOLQjcCeUcQSdPggIhqMnUsImIb2dUL3LmgE6yh0qFJZcEqUSsbmOkLIG0FdAOy6NadHwKtKU09AGl+yB2dfhDGEQGmAEBpj4hmglwZ11uBpMWIzZADuaQAO3A0hoo8akUC2WTASFUgLcbIC6pQj4J1yQBBVO8HsKgE+TqkI09sV8Nak+Y+AHOQEGcdDi6ZABup0u6CU9lkxVci2ImvsJur+QmRwaQhISkKJEJC5VmPyEwTXtSWTAolk0QSXIJlEyz50hLGYTLMoYwhfgJaJDZQoOSQKaAOUmdf6q1HgbKFlGamAWIemw7P5Zy+lRQiWwiiaAyUEdUvmqAFwGpqSBoGyhEzYCmOTQnbk0Sb5OMnMS0lhU8lPjT0ktMwAmZSJoWWBuJlWytA+MrwPLLFlWmAI0Gtjk0mglMQVNfBUTYB6phSWZk1vQCHwWtOvJiU/yeTiKHo4oaMSRsSh00p0w0TAJprzhlUnYyXKtA2yryqoyo4NKsXmyt04KeGTdJDTYwGQ/BtwD6STO8mMXgaCoxsY4O2ynY0ruiU6b1CGSShcjZmSi7oTNi2ZLUlaVYw/OFysAOg9MBNKSlOkpi5UpyV+YblnAJwL5XcpYBrKAwmku6Kpl8NOldS6jVB/wJ+AsTAL0RaoQYx8gODOSXmpcXAp9KFZUSiCeYDQnrKLOszCWVRPMBmA4krSgZaptiTG7ohUpvGxa4Vs1LOk1GqHHDARwiz2JSS5XdwHJDYP+aPnVRRTEiWKvglGSjphYDAB+0PcZQrIRIZwB02eQNBBYVcAeEQ+paAsBDR0pJrUayLlsmZYg2gPWEYcnpXzeZWMdugKFCoDBSwcRn6SjPGGqAFju4DQa+RJAKQ0Q/6aeGAmmTMF3pXIngFKI3OwpqkhFAWgNmtSnZsjQE16B8NXEpC2M1817KWNfntQPjYkcyQtQwihwk7EWDo0RCSNE1gK3ZqYwsm2LFC2IDpAUTnQgK0Q5q6cgrOWcUgKJzKoic2W9lMHtZz05ichA1AQNiZPSZtdOh6GBTZz0koAugxLTXBXZYMsWSNLEi4rh0zjKEjQAhkuiUZL5jiXNDAlwlmVwJjhcG2MlhCJJYksY94YxLpL9F/S9oLiwJDGSHQ/p6hs0WxUrHlmBjdQb4BeLpMGI8q+cDmSpXQnpixZxGfARyjBmvmSRxF4xPxCWgfThwGCbKU+DSEaA0jgkCcBVAmATAEUpE8kw/cEo82nx68wyFNFLgVF1ZPmM6+VjQUDx8gGegkVRYfLqyXh5KggBngOgeHI8iplyYZUtK7W4IZuQIp5PJMVVsZnwzGZloVyAwzx+qgTQTJThUT/sJE9Km1oQ0G0GNB2g5QgoM0QjetBgUvQjoSyBFUbLQwyKvoYmYjPynKCkMboWUNwFlEqhEMbomuh5Ek/6eyTzARUA6AoCIJOGkU+ICgO6n6h+SwoJ0ZCCozsYXRuPJHRZDoD0wynmo9p5AEQF8C+L/GfpAgmw+YDzSAdvwi1ShhmiyBoMHJ6DCJK8B6cOj9rvY/oDykZQ2kCyB3zy7UILR6XUyDZoov8IKeeAUhjxIIWMdgYJRFFRkzYQwPfSkA3nnmI4oxwLSyE/UcSqVJ4Dep+kRQsqRh4CjzSRE+Qr52ybWjwnko+otaD551T2p9N0H/6RdHemEqhQZURAMrgmjmvjoDy46O9JpaRNrIEF8aYIYOQ6vBKmmkQiUqc7fLHhISqmJlMqmpTmII00XhdG+lyVRo5BvKOlA2mvQgIOCEowRD1OVRkpAUgkAQw2kKVPpEU6Kgg1WgfUBGoDuDiieaneqTp8UjaBBUyoHLeoyUvKO1RwRZS0p3HVyQVN+hMEaCDFsQFEqMyWA6LYtbWTgpIDgBPoMiQQ5TnYaY+eDmM/wiikVgEUoD/jW5n6ByFa9uHYp5JDhBEQek3DeJ16nobxNsGMIQsIAHjoAJOp7oyUZqA1VlPJRko2KfqqLAoh2QiCJF/Ddcv4QOr4nrSOTtsyRu2vkNxTW0Xh4w9QeOSaLu3YBUQrlG+PEtH6hzE0/6eLEHHjUhRbgooyFd7O+GoBYupXNsStMvFag9oY4EfDwoyWr4esTyzGHlMxk3SIwWcBzAmpE0GDMYv6XGQOhmwOgd2lqgxG0VlEZQqhqTHkrKM0wj0+tOvWfAz1oa0YnlGYB7rYCQ626mc/sgEP9gJ4/4HYBAr7KpBLa3y8lWO3FKFVu0idb0pWEyFjqwo+CscYwMaA8Vsa4bS1VS9PF7TkENkMuuDWykUV4lZreYUFOarzjaBpQWMMGoYAsH+igYyEioNgkijYCDTIYhMPKKGAUAJ4FMCoAnKHARwItgeBrWWFEV/hV9fuvo6TSwt1xjoFgBbYShSEBAFrnOi0Anr7gTK/IHCw0NHTrj6w11hAI7YlsKC/xeoCcX2F8CSALaIRGFkKTVQzgLwPD+wDuB3SGExAFtZYJcEPRuBb6+cKQmme1TDVtgtMjgaqlacCjX7CZ9gX+FmrhJ2gGh6+yOrNrbNSVUaX5+YRpspWSLLoHMB4+vooFPqzAGOs0Kds12bRrw2AnDQ+n/K/wNlakK+HdJPM2BVoWQoUFrstwCK4TUmZvZjVmjbwpMnwB1RlA3rqEUowsDpXLCDDCxNNedJJXprhv7lR1nGynZltC1/rRA2QKiUOrk1y0SxVKz8FNARV0W46B8DLXWQYV2QF9dtUVXerwNSYbbS+vLXwaQWgSARAdGCpyfyB8bQJjGtg3JPlAKLBx1UBDWUtlC5AFloEadHvU5NpIpI1cayA/tsDWhrgey19ahk+IUzG9TkoeLQtvjbRqdokKiReSosJAwgl4rcPJthJJbZBQUBQJeFNKchMgl9OFbGrvARlyxM6BtWkCZSYZwwQakeKgtq0lGgoYQwuVtLGljzDx68suRyngki33hbsTggyG+0DB0Yygsqc0YfyViRajaZdJHk/jpzkq60D5S8A+S4APlAwi+AvuQQpLkS6sBSyum3mCbnRPmVEPKGtycSJIQI3EBVApASXDY1MK+c0LMCxx59kO6LdHukr43gEpIiVG/DeEZCHQbye4VAAdXJVUKtOs7dAA1PoBjp+aPsGErLF/DDZ9sOI0BAXoEgOlzQ5mWNkplKROARq7XWWYYsDijID8BcAqn0H5wE5QwWiJDFV21WJxJO2dWWto2hgijWW3qF2Jj13rMrAO8gfYjgDY7cJvV6RJwTNhGr0EB8UG3LD0t+0nog4qTZEYrALEhNbW0HW4gay/Tg6LttqiaCj3r7y17EprL7HlXA655HNWotCS9gZbgDikXqvaFgIpWnKlwJrY/vkTKk64CESZfRKgmhxtBBsOIGHaVuKQHSxS+cBlvoIpUOzPYUPbRvlwHRAQkG0WAwdugIL9wHgBAGgv338RgQZ4Wc3WAdAMQFz9hl5fZW1BZBh6hggMilCkiaQJ+AEDkMPITBXx8g6y2mYWCSPrcBwpOMWGivqopXnC3wqmEEJNvBDOOBMOwbKcpu0407tUgCbKcVAbQHmA6HnfLfVyKMFQXlxZL7vtEHQnwG/AUMPINYOw9mBmHuyMDeSymUhEszsaACQHm3zxb5e4H/YxzIIuUyIf9MWTLyzAk5lyhSJ9ICTAgM4Scp+manfpnqwkpMyWSmNgkh2u0sOZhPLmOLNZj1540DhKDlN7nC+HF6tPSpVEEx5FCGpwU5MuWmj/RKoy2FRCTgLwLkcg5nh8G6hGWMZ6uAG78FpO7DLQRMoZOBSw2CCpRUw/UU+AQhkKh1exvKLtF7Fsa89A8DcmNalyz7yLKaYfKHmIgPQGQDe4vhgltTwJK51mSzi2NXJlZi8swSyQ8wsljjH532mhh/gAKjsRQcqg+MqvbrRTN5OFjHhZLPG73MxvMB+ZvkXBg3PGFkhiQzAdEMnHFHwp9jBT3E86CsZ+43HvcVqGEawFBwlfJKwOEyhQG1GUPkap45CCM18MgAvP2obFPYSmVq8/d2VxEt4VGmMp7xjH9pPiUhRyBkcPtOHpDhpxW4dyHQ6MZ9M1NrDteXwI4D7cHGxGZdCu2b8rhNwqTnLfZDxVocYXaaDcjnXAFOSO+NklM35KCRmSuDI3Sga4kwOgD+zAA6S/EhxY7t0WRKrGzHwk9DAQMOAxAdp2bvqf4ozHIKTpWspCCNquYZykTUQOdyk8RHCE6UjQjVYLIYhuGZ4qiiq/VyKB0jOKnaCxDlNAHWX35ZwHRpkN4acDsl1gpuWclVjAU5KW8LbXNSce8dv5CVNKAVFuZcrFPBzdxc8qYOlXmTuBVWUQImT5AZYaQyts5fEZUDiIQEIo9MWhdQFC3RrpGRO6pkmIeBPbp15gbAmSKfW57zY1S3DTHE+qe81lum1EETyMCfWBGH83osSoXUzk8lHw8lm5zSm9KKOXNJOzUcd5Wc4ppaYAQHzkzzy3s9NWo4VAyQSgieO6RyHpKrALM6hoPNfWvwm5WYvgyppwqxriqamMaEFCGpmz1NAc9WZTOjh5zzZgz/ed0M5kLUzUMDMFFRbMhCULCI7Ztd4BRnqvH5qVrw8gYWB3cUJhnc0PB3S79Ay4kiU7wMlToJ0Fh2MQB/vNnecyDXo5zN6ZulepAUBp0QRuIYFoWh5Xs8xmMxboNtDvipNC7ZpnHWl0UJhi/Ju4rDIpkCAPM7QyrCeW70Ls/FHprkt7oUejkfoWujCHlo3aFhLtHUis1zoXhnPCNGodh2EVhjBTsys0Y6t+pmKuZA4j1MbPYgtQiIQspp9xgsOjQXhMhgrcW1iMXz5qsz/YQStWe9WgCBzUyOcDhMGlCriFnSzxcYHEmM2glxOoBC5NaC3pJIzEWcCEMsZ5VJY2K+Ju5VzNyl7gGSBglYvjbunvGzRfRmfiZIWznLrLGOhCE0j5F6gpx0KadqS0InGGKRfNnxqpA2Zk6SsfekvqlOMaT6TYCs7bq4Ae6uJBmBi3cAKt4CVNXB68b6EGjk3IRL0lbVxb7AuhztVmqY+mBd1oav6DITTWgWnJJhSnRKtRtjCZWh6e7iQS/KMGEOmIGGQLtB/ngmfcO1pIpAs6ZA8f/QDIGUWwI7lnyWmI2QNwkAVrp1yifXKOu1yrgniSBjNeLXfXm8k16xSX54FgJ/WPPTLJtA6jmXzMhk0MY24NF9lzKsM85+1spmSitQ1oTEqZVmKBagSy2SSBI4Um5OyRo2N0mjY4eAyvsuTo0jQH2zGpS1/XIIuwKYHmcaB4AkM6r04x9bYPRUau9gvSb8LyEPcOFZwubQ28/JxzKBP9D2JAIiBfWlizy3svmj/LuxTgIgEARwpzB4QW2fgsgCBAUt+mVZQ09o8C4QXsKzJ6NYoQfQ9WWFOwSAMQGoB7t3FyZyinzD8tng6A1a0DY8b8z2GcNm7hNX+3vW2Jej+7b0rrM8n+N5HyC/0odOHVtlKj/bhNXRLyk5uE1q7jdwsg3TOMJQgHyiMIC8ooq3GEmZl1bRfaAJDNmEpgFpmVh/W43TjfAiwS0fIBjHJ7uF1YeafQrAVz3aN3Y0EO4HqQ64NxCQ5MbyLzA5DmanAWUBaviImgXBkpKYotvMDiHPSA6GneqB53rojN2QvMDaAtIIbl0V+6xP4wNynXWMBYWQZ3USGaEYYgAw/fOjs31BxxBe+3dbvwKMFSpqwGK/KRywDbrJ4/AXf2E23+77Evm+7eSAjCkVwt9dy8V3wX3nAbgL4G0V2BxLjgKQL86ABUUlJTAIwEgDLgDPkAXgIwOfBkOPwjvA8JlHqsBCqB93RCXhFqdjaVuUrm7/tzEQ3hyJl3dmZDG43jg/NvcV2swlQC/g8Bz4QEYdywgtGEMuAXga9zIDriHb84i8TAMfE7iTurDaDQQMw3mOQPD24BzTeovAJSByT3hDyTZQo+2Bo3F7juHW6TWhxdDaDNAlYdUK/xiCVb9x6HGlWmOm2ppmxPeKcU7tXak4NNrS1UMPej5Ega8rIH3Q9elA0bRQOmiKOmKFGKy/bhpjKdKlhjfYlsM56/lNHRG7jtRvYC8BQBeA+AXA816MBaOkO2tidvsnEiFJ0Pa5OjYAeIhaEqyJ7UAgwCxJKasCSVsQ5B3g95lVY2BHBLPKNTNI3X6suhp06wMhYxelmQOaVQ8B3Os2JJZRHJ74wMw/x3CeQO7oslLcZLcCWQspZojdLeRgldS3GJWh4UODjc6HRZyLMwNrIkhGoaacRaEjaeeARB8mAxrzIACyVPkZvQfoXVS5qL7+a2xUk+MQmSkdyJHQkYfU+PHFu91qV7PEPI52FeAHqsPhAMqAy6y7m1UtFrEE6FAcuhiWwYhUUwN6LVVk5pKJz0K8dMh24aEy67sA5hOSPCOJKxKbqB9Iy/fUjN2mCDaoz3xUTVKuAnRrc2kaSNslsMDV7dGuh7ArojVuSjgfTB6MLF4SVj3gYlnZjeaBfcZeGBkYUbZqSBlAiTBTqE72WhJuiDHlKMgE8CgBUAkjWRQ6eDrEmWo9S1MKsBhHB1mqitSSpzJIsmItxzZasdCM3sR1oKVdi6ofY3PDze6Ai1esVk5QV2H6xskaoZY2XXLtE74pz/s+8w3LgFVdqpV0uvbcjBAxdYyNCMLrPCqHbz4gLuWkULlr7RSKMf/ZPtx2WkUdjRVfcLrT3EYFiLcc6J2rUP2DeL8noa/VculJJidmSZ2qQDWUeStcoWExfLqLiafKLuqB1PFFqRouOhf8fZzNheWEz4VJYJHdssbo9zY09TB9bsSQn0uUTTo6kbTrVH7IKBvI31UEmcWZ7+FOelg/sgrdpG0jqmXJyUj6FkFW6vJC0ckIkFpDgMC06/KzV6n08E4PybPKyooLHINlWdaLGNIhdsJgAW/EQaEWPI+JpY4grIGy3jTqOm9/RqB2ABeBMAkgSwIoHwCkBFsFAWAKHSojYQbucgfAFDjon/488fS4kiBfkOOZffrgKU94CU0Lh4IJWdPGdV4MAKRrW0YSE3KzpKRajjd/lAQCkKCoRLHAePDDAc7ZrIItAYQO2F0nuB0A+ed2vAnwSCEDA+d+HqQF8JHmYA+NwfQokG5eEsuZnM42RZn0BBQzpVSfBF1yqYcR8WgXRY8hYmUnXSICEY2dRONkRojZcbyfsuEoZYIkfISvMXqEBNrJc4hZPIxOfzh3ug4eM/GrCA0/HHDzVKu+UsSl/5i9Hxu3YPji3j5nGoNDfGccf1uQI9c9/izPmC5Qe+JJikUT4qo+Tb2GFPoCBA0gUj6nKHAIb3oH2XqMGUhqiCC608WQdEPAUQpfT/9WtPqmA5fmlBrmWbpAh5NOXgUPK/upSJVe9tGz3GLJioA7tTAFkwDGHMDniNS2zWVfRIPw99luNGOrVe+KlLZ5SCuPu9W/7xgtL12oAmdsARFRd90gOfxqDJ8cbC7TAN69QDJCm1Oa504qtjSFIRI5SEwEQFtXxI/Yr1UF86wZj78AWRYpGteBGr5sTwo7GRQoREIHcACOCxWUOYpLWb1+UfKmMM8GhRMdA6U564C9VeuejGMcwfqTSeWI1tXtyO/mchRh/84v0MWF+/z5XlLAamhXxpx0X3Z4flCzdko/2vqfFXiyRhnqAQbulRCq2kc1oTvP6Ux8LjjA1Gw04knUWIl6nDCi+f5jI8+a0jftDUD7wh9+9LIvt3wUDd3S2OXAE2C+sh59sRA/QNij549XsYMl5t+mqJoY7XzFm9V6k+b5Frq670b6z2AcfeoN1Cy+i7kP3QwyxqqidlGpM0M0HjZdA8ISQ/3f8gsU+ZHlCY/MEC/59SVBX/QTNhdx9p+dK2Pni+z9IsOV6fQeihWibZ+qk2OZfmBhk4jPpVvkxi8XeYLGLH1rfNyZTQFfvcm/70fghTt9fu+8DjPBx8W0XhUsACARMUj+WzeAoD+aYpv54DK+aFJD6s/KmRYdMV8P7r9G+8osb5+K5Pt5rIfPNgLLIlWIVLrSmdJojYCqSJ6Y3IgDqqYIGqqiBAvsF1qsphA9VQBAweYolihD1AGALweEQ+P7JqAHTJUREO/vlkYk3ANsVZD4Y9ozAI+mTJrxu8AdsNhZm+rF6AD7AalgMBuLJwHIzIWeP64mSkLv7Q3rAfrg5D3ALnxj72/wv05iqviwI6MLAkujCUoARFfBZgbEFmQVhAoFxxWo+jgxj6Ub9ANz6aPRnzxhczgmGBbSW1mqZ+w72odKk0AWgG6Y+XVqnylAnbpVzYCmqiOQWOXZAMrxM1SN+ws9BGOiDfs8UKeT9opVDvZp4CFBaT4kEptX7fs3PgNIBaAWgHY7a8yOVzzSUOvNLws83AMbyW37NaqoevpvDhBkfIiugVYlIifLg2kUKRoBaAZCNCq1BUL7aQrBRhVioqTot1wb4UBAMC8GkrGBAn+WOKig2aTwQKSFiOhk9A1yHaBvSooYxvY0HG8HALYBkkHB5BHgpJjXJSiUsQaRWG01E+EHiahweYbbB6iMjWEq9iT4t2L4keA9fBlPYzy8qClR410CUApRFQ6UAOQCKCxKnJOzB7gMoKe9PvJIUK76AskIeA6wiLHy9jQiaOICRQZwWk2qiCcJGFRANJizBvj3wdNBfwUgIiEswTarIYPKsxhDCXBVglVCZCAL/8G9QALQSAFQAI4YX6vcMDtCFiq0I1CIAu0IkEEgOgcJCmMyY6qTsKr6ZLCmhY4C+FoQp8IMTtQpgBi03A5ABlCtCfMK5CvAOgBk8pAOTyoTAE0ZNKLRk60LJCzQQTcSEHA9zTuEePvxfO/PsxyWaILixZs+HTOVwJcCWLl4I6/fOlb0o6WjLkBCqjJnYDO/kHM7DRAOjH6PJDAt9LL6j1DH6oemSgpICK3epDoKOLFlGzLy0psxLL6S2GSSB2//BO5Sa9shhYWQy+ocRqHDUg64eEEgrV0NdDMJYA4MhZnvkLuVsNjgCElPmeZFy7qim5e3C+mMo/mkajej0kTlQ0Cnq/8kiKfKATgLZQOA3PTABOOZLkJRsAfk7IB02XgEwBEATi8LKZB5sQ4pHBrN5IBOPww8MPE33uFg/GUJD8Y/G4VrvzEMyoJr4jCFDnbcPa/HmPsNQD/j7UNXDaoz4WQLFw/6OBDVB4RAVDWtniGotuwzgJZDPOCrHsImqToaq5XOWABYHPAOYBUKHgFEOpD5owZQCA+E+DhKUJxDgpMYxhZxOApJg0SCQ1xGEQwe5WDVTSQ8xhvRs6s+wW0QmPNwkJ0kQkuVhTPAWgPb1+ndCqhFkugqV7xFB1w9IY6ucj8adAKSik8OwAYuFK96dJHCDxEqRqRqNSa7nSQnzBBwxqkatCxIwT6uyoEJQmVXiIELkMYw3ouO/AOzyWaoJj4obQzcl1ZgWFXBlkTAfriJcTsMQwYwBsmPgvr7ouRvAAws8aC2aLmuIoA4w+umIg4snBKPyhiIxOCEzlcXjt6YDE3xwwojY+5LnDvQ/cxS8UzDsrmzE88khvi6HDBFjsVFFNvdcU69WxU4DbDBgsEVUyTBs0MguwEiJicuMRAEJ6McQAUKBFewAsA1ADh00U4p9B4QIIrnBIZw4lxLirrwCKwScOmWLgsgWkAyCrLvRFkIUgbsA4Lui5DFEjDcEjAGQSjt6XCAOjxNBdjfBiMuUCRcBgIEGEQ6vFmk7UUfDpo2QaKC5jh7ng/WhQDpunRBioBDFKhy7emDIJRbd7FYxTUVoCJxYY2GOExZ0XkAtggIUsFMCAkXuj1lZhbm/XFaEX4AWRfzleA+Q6gDe1omcoo4N+AOS5y3ehbADGuWksIDYuYskoK4GWAmsIUfbhvMZWSVhhYDy9YsnUYTFGxhkWgAtggwC+fNAiMYmm3pxcYtF9RjBVdF+gF8WwZpnDgJQFpRbEZxFSLlMXgkQRnsZ/CMAjsEsNmxihbk2UlQzpxGNAF8GqOZxqbnIhqQIxeuQ9O8ZNgrWwV8Ru5XGCyNeHERuQB/BavDBEOLMGMbQTCawdAbWjBEI0SUAugH5D4IUQuMQoAURwTV0QpxwoTgFjmDcRUXwMMcbWmlGzTQSZiquJfKclI+5dE1XmAJdMXUCpidfAwPnJxxG+RzoqSIKl2AwWAQEPQfSFSGMKr025itCkuLYwYqk03QNXiFCFSE2gRBBdQP4qY1gxO8HmEVgFoByAXPTBgxHTwFo3rHTx4MF067k7QBEApgIqIWAhgKhT9HnCo8F1F2Ks7EMAtgFEWkDrCCwpK72F0Ud+MGgH4BgqYR87dNHugPCRJHUFHir+ZFx7QRBHPNUCXCZjgO8djBTANMdqXRQVSk4o3x4UGxAdP6T+oZAwLQ2bH7R4SRjHeGEAB3IGwXUXSneDkg5c8lqDK5iXzvPJxWDbQhTDcCwRnEdtH0PWkgm3TMsA6vHvx8JEBFqR8q5DISN0w5tHdgO8d7HhSCqZgvavjBXK+SIPpevHLmwq+oncGzRn3HJwMDH0eBplZjYhmtlBjgaKCqZo4oGvi5rOaSi3Bj3IgIZRs9DkIfxvaiAoYcAEYwvtI5qCov4x6tAJyIchpIbKgcNyC3xxpwgAThiiNcjYIagIMYvFQsJqYwsIgPsenwNBeuPGndxdWQ2JtJk2MDQM5pMA7h7kiO9jI3Sk7HJGMolJG1plJdAPCpyYKOAwQBiQnDpk+8kWI5APrxMURwHqhetdA95ndEDxAMQUXxhZEkGkkIaj2MApilMkQMIwiqOO9hFHIDk5SjWa9cTmAE7L6Snlb40KKki3yOFGSJCrxwlTxosa/F9xpMY0MIi6KGo8bAJ7ftJXl68ma25L7KokYAGnQIUA8L7Rc+9nqiUXyW6q+EmYMEyZxOJCmEBwIMCcvwMOIQ3GaknSA3L4rpKApAIICcsFAPjx4sDRnEUGnvQ0ztGJsgE8nQvtiaTZQW+RpBUSQXhBQOIvijR0QNCaGEBbdJdygQLmMzOjwJhKCum0oOTHxjUomCDL4sLqCiSjoDcRxSdireXwRzKrmwxqwwlQ/lnNLGqdBQ5UMyRbylSrurDgmqsSTSsxBkSrGmWw0ErIGXYxiy+nacg8MPMIgiUlgDtracDbNTD/WcNg2z/rJXSWA5pJZQRQd0A2hdcoxGLpyEX6N+jfSqgncDE0mrKlC/EjY7ngogDICWAOEqMlmPlwkSwxv8wyYE7hzQmSvpioBPAPoGKY8S1VB5EFgnQNXg5cOYxu8FvF4PDYb0MVCwI6YllDNo2sDwjbB1+A2jnIwCYggNYBaFoPS8nMFqoYYWK+vyREpMhBSlAUKq6Jk8prKWSfyRQ6urJ8qA5Ql/4tnHUrrL+0UVqqRgQ9Zp8cPqYLFCIlNEqLtBtAqpR98XdKaA/7o6rEFj0pyehsxL462eiBAbbLOSdr4mXwtTUpTJHqu0uDHKy0xfw5qqyMUKX/PAUtaUeKoKsAt6GBUtnLZGGEHm8bBtpgqYcN4ph2YOS3sofF2jCYKA1hu75hQ7xS8EENBHE2oxDLzGEEvQYbmHMOxL2MxkFARbKwcukrCy0kotDRynZkWvhy/pMosnPZoJCbEi4IgTA/COQMOuGNYYiYK3APa6wC8LBAcJH8zEIhnJrPYb0+YACJkoS6MTBEupJhQyEL+OXPYwDm82LkL2M8NE+JIi+6PYz04prCyaRQpXBvcNCPfAPrtcJip8TeSOKLwQlM1rOxsH5DMzCgR+AVzH6TeuzJdg5FLkvC4Dm+VTCRBuQWhH5e0/IROYeQIKqtBj6OIl+8v24BE/8yUn0Naz7PB+GgJg6C8QFgIkI+RGr7o8FnBICSAnAIgCKAsKbszmqqGD4gQVdwTi+3HFy8IgDH3sqggzLUDgzwOjjy57UnLQmM8i2FCx2TwCC8PActfMeS2MvEOFS2kyTL0zABg1L2wmczpNCKs8viX7y1EKoEFig0we/AzCQ8VMviBMu0YSqvsu6WnDxM08zYGBcvyzcS8szWG+GGxgtL1mHiiSocjYw2QOljZZiI/4TAor4wxlfA8cMnS4hkNLjGRMx5D+pGwus7qSkA+Q4QAKaV4EHiYi/QcUrii6IzPrqTNEGFngD/WDcgsrxiVQtXQB4Aakv45ulartweCKFHFIWOATOKApyzOzdYXFN2nDjNHNzPFYBPN5APM3oRahXE4UJnu+k4eCxkJjvoHngBQBW/1zikGgRakKk4i/1rVJKC0/J9anYO5B6c5GAvzkpCUxMD884kJjAgwO6Avzkc5MPPEJk5kpDzms5bOQSswTUoMgmQtG7PDXIipCJu8YmAvlCYB8WntAgae4/1nxb02k2yKwsoubP9YCpOgEg848H5TfQmNOrhS86DOKhqo1zCrI6z7pOrQhjcU1ows8LSFcCZx8XO1ic5MACYFTBK8VNBW5hHOFlT8oJJkSg0q3GxAEACeAjRnE7cxfQcAMIDPBVABYA8AFh/qMDB8QbYG8utxqU+BtPiUKNVhtYB+TQTy4DQuvjrKTEZVmSIVQzwgHZhCjMNgywwrHNcTX2AdlJs9MfcG189Sc9oM858Eqh1c8iiWq8jrm3Ahy7LQ7Hu3rsifPIdSUKyQAOiwwIEgF4JswnnHU+G2DG14DyKSz5IbQtXFyQB6xwOUKPgjfI+gpQFUQkKPgecSJxim2zisKs0Llo96QA1LpCA+pDwkIwb6QWhmg5nPvAnooYQWjJwodP3D88/iIeRw4BQssj9A4fEVEIQo8NcprBSQkWtOgJrHB0AYZnQCgOwT8zyQSwB1QGQsz+EgzCDc+QA2pfjxOOiHJABiAeg0DEaILz/LeSAvEFoBdK/Ml5QE3izZJHAkWmNRCSj4UCc0uQYnklA6yOIEAJCfsEFqoo3rnJDJeylT7yB2h1UGgWOCbBZE+9OGqnwSaMyJABbQh0HbBz9QPUIcl4A2o9weQeSNS9BsGbxPZ5IbmkISopQfJGYDtC4UJ1CEckINtCnQjT84NwCxgstCSC10JYDtQmocaHdQeDrlDPQirlI7CjPlyQ+nFqjtq1c+Yz9QWhQRQeYC8AXUQ9BM80gFpQFB6kFoDY4bCmY/SmPiDdA6hJz71ArFtz5KA2A4NS9EtQ1UTFAuf7UBtBcJ50GCH4KxhLIg2g2xHADMjBDMwg2RWoz9DWDdUNwY6j6A89CcG2G6QB7QbCu0M/RKUV9E4KZ0PDrBRZUIJyQO4HJABXQaUYdCpRYhhcNgLKIDiA9Qbg/tEoIl0VVGa900PYS4CFBFqpLMiz3lGikBHIbYZQ0CVVHEgdniyEnRzuzYnHPbAMM8ke6tcieMRhOVE947eIzxE6VSgmtAJPEBPspjSAyl5fYHlBFsfBPXIzQBbPn0C4YHSEAkk+NPoANoNFR/gHruaLQjB4WeFkOULbqMZC3aawUVyN8KuAVhLwWOKHAFdBsKFHKZUqAy0Ajh0jBAFRlmS/kwABfSYkv4WONmUk9GpSUrYFAUHb0lwNDSYUmVJnSay+IMOzPTgzNDOETd71lE8FtQfgW2tGRaqjyTx4JsYIlpYyeW8s9QB6Wws9TeTDqAHr0xB9hXDpCGEEnlKoG8yyoVyAxM05/gAWH14nC9xvlxE4S4CFpmgO9l8S0Sl50upr8MHhtgcqArA/5A8GqrlD3csKBypAYKjO/RnoO20vxPoQx0xpDZTGnvqJWF7HugK+b1OrC2mCaksVL0JzllwbJTOjbJYHS6EVYIwSj0yUCCe6UzYWuGBFQ4DKd5hAlMK/CApsOEE0jAQNsDVAr4SMCFUwYv8O2jSAM8TTgjAXANFNwQraDHvuCjILpHb8BLTUoltMumVP8RJLJYHeb7qmvU4ADRThANlOIA1gH9OQeASuEF2AdU74xyFLTTBqvTmwMVMoARU1RLDTWAFlNdTYQJsBTAgiu4I/TW03lPk5DBlVOyJkU7kBc6nPzEAwWtLJ1PwFC0+T49PHU6hmbTb03QMhTdzTCDgxPAPdPjUGLYY6sTJoa7ySNHnvi9HCSksFM4SyCc9LnTQgHdRJURGaFRARTUzo3tTR1EtM/TSVFIeRTGlzQUEZm0yJmayCNOSFGzbOS7aI0QiJkQ/TGvE9Mk2UIbivM+FgxjXUF1tgbBK2Ctd7YQ+Fr5bQa6mndDIEgDoLBx1N/IBB7QhNgjggcWcnINGRUthVx7Q19oNIgCeSDetPNQZnJB1ZTJHSR19FiHJB+WpHnIdS+E+1NSCiQDVHJ0kdKKY1T20B1PrXEdKAFsBLU/HUZ04qLj4NT3U4VQh1TQuCj1Ucc9nW1UNAU1OJ2zVFUyVHUcdIHx40dunjtU3QyUZB5MckHmYdNTG0wAUs52jqoJ/UiyZCvdUkVExkNUYm2lRYStUx9RvKLyZFSOteGoJmbVVUwQ92pVVE5LwZoAPoBYAbTfIxjUKhyrs+s1VWlNCDA0zdRXURQXAJdTSMHNWjUUGv0G7UYUzpIkS7Va1VwTmVGwcqFDnnFVjVfVVNMCZ5O/dLxTQVbhFZVkLMBOEFVA==';break;default:$f=null;break;}if(!$f){http_response_code(404);exit;}echo
lzw_decompress(base64_decode($f));exit;}if($_GET["script"]=="version"){$n=get_temp_dir()."/adminneo.version";@unlink($n);$m=open_file_with_lock($n);if($m)write_and_unlock_file($m,serialize(["version"=>$_POST["version"]]));exit;}if(!$_SERVER["REQUEST_URI"])$_SERVER["REQUEST_URI"]=$_SERVER["ORIG_PATH_INFO"];if(!strpos($_SERVER["REQUEST_URI"],'?')&&$_SERVER["QUERY_STRING"]!="")$_SERVER["REQUEST_URI"].="?$_SERVER[QUERY_STRING]";if($_SERVER["HTTP_X_FORWARDED_PREFIX"])$_SERVER["REQUEST_URI"]=$_SERVER["HTTP_X_FORWARDED_PREFIX"].$_SERVER["REQUEST_URI"];define("Adminneo\HTTPS",($_SERVER["HTTPS"]&&strcasecmp($_SERVER["HTTPS"],"off"))||ini_bool("session.cookie_secure"));@ini_set("session.use_trans_sid",false);if(!defined("SID")){session_cache_limiter("");session_name("neo_sid");session_set_cookie_params(0,preg_replace('~\?.*~','',$_SERVER["REQUEST_URI"]),"",HTTPS,true);session_start();}remove_slashes([&$_GET,&$_POST,&$_COOKIE],$de);@set_time_limit(0);@ini_set("precision",15);if(!isset($_COOKIE["neo_dump"])&&str_contains(isset($_COOKIE["neo_export"])?$_COOKIE["neo_export"]:"","db_style")){$_COOKIE["neo_dump"]=$_COOKIE["neo_export"];cookie("neo_dump",$_COOKIE["neo_dump"]);unset($_COOKIE["neo_export"]);cookie("neo_export","",-3600);}if(isset($_COOKIE["neo_import"])){$_COOKIE["neo_export"]=$_COOKIE["neo_import"];cookie("neo_export",$_COOKIE["neo_export"]);unset($_COOKIE["neo_import"]);cookie("neo_import","",-3600);}class
Locale{static$Languages=['en'=>'English','ar'=>'العربية','bg'=>'Български','bn'=>'বাংলা','bs'=>'Bosanski','ca'=>'Català','cs'=>'Čeština','da'=>'Dansk','de'=>'Deutsch','el'=>'Ελληνικά','es'=>'Español','et'=>'Eesti','fa'=>'فارسی','fi'=>'Suomi','fr'=>'Français','gl'=>'Galego','he'=>'עברית','hi'=>'हिन्दी','hu'=>'Magyar','id'=>'Bahasa Indonesia','it'=>'Italiano','ja'=>'日本語','ka'=>'ქართული','ko'=>'한국어','lv'=>'Latviešu','lt'=>'Lietuvių','ms'=>'Bahasa Melayu','nl'=>'Nederlands','no'=>'Norsk','pl'=>'Polski','pt'=>'Português','pt-BR'=>'Português (Brazil)','ro'=>'Limba Română','ru'=>'Русский','sk'=>'Slovenčina','sl'=>'Slovenski','sr'=>'Српски','sv'=>'Svenska','ta'=>'த‌மிழ்','th'=>'ภาษาไทย','tr'=>'Türkçe','uk'=>'Українська','vi'=>'Tiếng Việt','zh'=>'简体中文','zh-TW'=>'繁體中文',];private$language;private$translations;private
static$instance=null;static
function
create($Zf){if(self::$instance)die(__CLASS__." instance already exists.\n");return
self::$instance=new
static($Zf);}static
function
get(){if(!self::$instance)exit(__CLASS__." instance not found.\n");return
self::$instance;}protected
function
__construct($Zf){$this->language=$Zf;}function
getLanguage(){return$this->language;}function
setTranslations(array$Nl){$this->translations=$Nl;}function
getTranslations(){return$this->translations;}function
translate($u,$ph=null){$u=$this->convertTranslationKey($u);$Ml=isset($this->translations[$u])?$this->translations[$u]:$u;$Zf=$this->language;if(is_array($Ml)){$Bi=($ph==1?0:($Zf=='cs'||$Zf=='sk'?($ph&&$ph<5?1:2):($Zf=='fr'?(!$ph?0:1):($Zf=='pl'?($ph%10>1&&$ph%10<5&&$ph/10%10!=1?1:2):($Zf=='sl'?($ph%100==1?0:($ph%100==2?1:($ph%100==3||$ph%100==4?2:3))):($Zf=='lt'?($ph%10==1&&$ph%100!=11?0:($ph%10>1&&$ph/10%10!=1?1:2)):($Zf=='lv'?($ph%10==1&&$ph%100!=11?0:($ph?1:2)):($Zf=='bs'||$Zf=='ru'||$Zf=='sr'||$Zf=='uk'?($ph%10==1&&$ph%100!=11?0:($ph%10>1&&$ph%10<5&&$ph/10%10!=1?1:2)):1))))))));$Ml=$Ml[$Bi];}$Ml=str_replace("'",'’',$Ml);$La=func_get_args();array_shift($La);$re=str_replace("%d","%s",$Ml);if($re!=$Ml)$La[0]=format_number($ph);return
vsprintf($re,$La);}function
convertTranslationKey($u){static$qd=null;if(is_string($u)){if(!$qd)$qd=get_translations("en");if(($s=array_search($u,$qd))!==false)$u=$s;elseif(($s=get_plural_translation_id($u))!==null)$u=$s;}return$u;}}function
get_available_languages(){return
array('en'=>true,);}function
get_lang(){return
Locale::get()->getLanguage();}function
lang($u,$ph=null){return
call_user_func_array([Locale::get(),"translate"],func_get_args());}function
get_language_options(){$Wa=get_available_languages();if(count($Wa)==1)return[];$B=[];foreach(Locale::$Languages
as$Zf=>$Cl){if(isset($Wa[$Zf]))$B[$Zf]=$Cl;}return$B;}function
language_select(){$B=get_language_options();if(!$B)return;echo"<form action='' method='post'>\n",html_select("lang",$B,Locale::get()->getLanguage(),"this.form.submit();"),"<input type='submit' value='".lang(76),"' class='button hidden'>\n",input_token(),"</form>\n";}$Wa=get_available_languages();$Zf=array_keys($Wa)[0];if(isset($_POST["lang"])&&isset($Wa[$_POST["lang"]])&&verify_token()){$_SESSION["lang"]=$_COOKIE["neo_lang"]=$_POST["lang"];$_SESSION["translations"]=[];if(!isset($_GET["settings"])){cookie("neo_lang",$_POST["lang"],7776000);redirect(remove_from_uri());}}if(isset($_COOKIE["neo_lang"])&&isset($Wa[$_COOKIE["neo_lang"]])){cookie("neo_lang",$_COOKIE["neo_lang"],7776000);$Zf=$_COOKIE["neo_lang"];}elseif(isset($_SESSION["lang"])&&isset($Wa[$_SESSION["lang"]]))$Zf=$_SESSION["lang"];elseif(isset($_SERVER["HTTP_ACCEPT_LANGUAGE"])){$qa=[];preg_match_all('~([-a-z]+)(;q=([0-9.]+))?~',str_replace("_","-",strtolower($_SERVER["HTTP_ACCEPT_LANGUAGE"])),$z,PREG_SET_ORDER);foreach($z
as$y)$qa[$y[1]]=(isset($y[3])?$y[3]:1);arsort($qa);foreach($qa
as$u=>$Si){if(isset($Wa[$u])){$Zf=$u;break;}$u=preg_replace('~-.*~','',$u);if(!isset($qa[$u])&&isset($Wa[$u])){$Zf=$u;break;}}}Locale::create($Zf);abstract
class
Connection{protected$flavor=null;protected$version;protected$affectedRows=0;protected$errno=0;protected$error="";protected$multiResult;private
static$instance=null;static
function
create(){if(self::$instance)die(__CLASS__." instance already exists.\n");return
self::$instance=new
static();}static
function
createSecondary(){return
new
static();}static
function
get(){if(!self::$instance)exit(__CLASS__." instance not found.\n");return
self::$instance;}protected
function
__construct(){}function
openPasswordless($O,$V,$E,$Kk=true){$Pe=Admin::get()->getConfig()->getDefaultPasswordHash()!="";if($E!=""&&($Kk||$Pe)&&$this->open($O,$V,"")){$I=Admin::get()->verifyDefaultPassword($E);if($I!==true){$this->error=$I;return
false;}return
true;}return$this->open($O,$V,$E);}abstract
function
open($O,$V,$E);function
getFlavor(){return$this->flavor;}function
isMariaDB(){return$this->flavor=="mariadb";}function
isCockroachDB(){return$this->flavor=="cockroach";}function
getVersion(){return$this->version;}function
isMinVersion($ym){return
version_compare($this->version,$ym)>=0;}function
getAffectedRows(){return$this->affectedRows;}function
setAffectedRows($_a){$this->affectedRows=$_a;}function
getErrno(){return$this->errno;}function
getError(){return$this->error;}function
setError($j){$this->error=$j;}abstract
function
selectDatabase($_);abstract
function
quote($Q);function
formatValue($Y,array$k){return$Y;}abstract
function
query($G,$am=false);function
getQueryInfo(){return
null;}function
getResult($G,$k=0){return$this->getValue($G,$k);}function
getValue($G,$Vd=0){$I=$this->query($G);if(!is_object($I))return
false;$K=$I->fetchRow();return$K?$K[$Vd]:false;}function
multiQuery($G){$this->multiResult=$this->query($G);return(bool)($this->multiResult);}function
storeResult($I=null){return$this->multiResult;}function
nextResult(){return
false;}}abstract
class
Result{protected$rowsCount;function
__construct($Cj){$this->rowsCount=$Cj;}function
getRowsCount(){return$this->rowsCount;}abstract
function
fetchAssoc();abstract
function
fetchRow();abstract
function
fetchField();function
seek($A){return
false;}}if(extension_loaded('pdo')){abstract
class
PdoConnection
extends
Connection{protected$pdo;protected$multiResult;protected
function
dsn($gd,$V,$E,array$B=[]){$B[PDO::ATTR_ERRMODE]=PDO::ERRMODE_SILENT;try{$this->pdo=new
PDO($gd,$V,$E,$B);}catch(Exception$Ed){$this->error=$Ed->getMessage();return
false;}$this->version=preg_replace('~^\D*([\d.]+).*~',"$1",(string)@$this->pdo->getAttribute(PDO::ATTR_SERVER_VERSION));return
true;}function
quote($Q){return$this->pdo->quote($Q);}function
query($G,$am=false){$Gk=$this->pdo->query($G);$this->error="";if(!$Gk){list(,$this->errno,$this->error)=$this->pdo->errorInfo();if(!$this->error)$this->error=lang(112);return
false;}$I=new
PdoResult($Gk);$this->storeResult($I);return$I;}function
storeResult($I=null){if(!$I){$I=$this->multiResult;if(!$I)return
false;}if($I->getColumnsCount())return$I;$this->affectedRows=$I->getAffectedRowsCount();return
true;}function
nextResult(){return$this->multiResult&&$this->multiResult->nextRowset();}}class
PdoResult
extends
Result{private$statement;private$offset=0;function
__construct(PDOStatement$Gk){parent::__construct(max($Gk->columnCount()?$Gk->rowCount():0,0));$this->statement=$Gk;}function
getColumnsCount(){return$this->statement->columnCount();}function
getAffectedRowsCount(){return$this->statement->rowCount();}function
fetchAssoc(){return$this->statement->fetch(PDO::FETCH_ASSOC);}function
fetchRow(){return$this->statement->fetch(PDO::FETCH_NUM);}function
fetchField(){$K=$this->statement->getColumnMeta($this->offset++);if($K===false)return
false;$U=$K["pdo_type"];$K["type"]=($U==PDO::PARAM_INT?0:15);$K["charsetnr"]=($U==\PDO::PARAM_LOB||(isset($K["flags"])&&in_array("blob",(array)$K["flags"]))?63:0);return(object)$K;}function
seek($A){for($p=0;$p<$A;$p++){if($this->statement->fetch()===false)return
false;;}return
true;}function
nextRowset(){$this->offset=0;return@$this->statement->nextRowset();}}}class
Drivers{private
static$drivers=[];private
static$extensions=[];static
function
add($q,$_,array$Pd){self::$drivers[$q]=$_;self::$extensions[$q]=$Pd;}static
function
setName($q,$_){if(isset(self::$drivers[$q]))self::$drivers[$q]=$_;}static
function
get($q){return
isset(self::$drivers[$q])?self::$drivers[$q]:null;}static
function
getList(){return
self::$drivers;}static
function
getExtensions($q){return
isset(self::$extensions[$q])?self::$extensions[$q]:[];}}function
get_drivers(){return
Drivers::getList();}abstract
class
Driver{static$EnumLengthPattern="'(?:''|[^'\\\\]|\\\\.)*'";protected$connection;protected$admin;protected$types=[];protected$unsigned=[];protected$generated=[];protected$operators=[];protected$likeOperator=null;protected$regexpOperator=null;protected$functions=[];protected$grouping=[];protected$inOut=["IN","OUT","INOUT"];protected$onActions=["RESTRICT","CASCADE","SET NULL","SET DEFAULT","NO ACTION"];protected$editFunctions=[];protected$systemDatabases=[];protected$systemSchemas=[];private
static$instance=null;static
function
create(Connection$e,$xa){if(self::$instance)die(__CLASS__." instance already exists.\n");return
self::$instance=new
static($e,$xa);}static
function
get(){if(!self::$instance)exit(__CLASS__." instance not found.\n");return
self::$instance;}protected
function
__construct(Connection$e,$xa){$this->connection=$e;$this->admin=$xa;}function
getTypes(){return
call_user_func_array("array_merge",array_values($this->types));}function
getStructuredTypes(){return
array_map("array_keys",$this->types);}function
setUserTypes(array$Zl){$this->types[lang(113)]=array_flip($Zl);}function
getUserTypes(){$u=lang(113);return
array_keys(isset($this->types[$u])?$this->types[$u]:[]);}function
getUnsigned(){return$this->unsigned;}function
getGenerated(){return$this->generated;}function
getOperators(){return$this->operators;}function
getLikeOperator(){return$this->likeOperator;}function
getRegexpOperator(){return$this->regexpOperator;}function
getFunctions(){return$this->functions;}function
getGrouping(){return$this->grouping;}function
getInOut(){return$this->inOut;}function
getOnActions(){return$this->onActions;}function
getEditFunctions(){return$this->editFunctions;}function
getSystemDatabases(){return$this->systemDatabases;}function
getSystemSchemas(){return$this->systemSchemas;}function
getUnconvertFunction(array$k){return"";}function
select($R,array$M,array$Z,array$He,array$Lh=[],$w=1,$C=0,$Ji=false){$Df=(count($He)<count($M));$G="SELECT".limit(($_GET["page"]!="last"&&$w!==null&&$He&&$Df&&DIALECT=="sql"?"SQL_CALC_FOUND_ROWS ":"").implode(", ",$M)."\nFROM ".table($R),($Z?"\nWHERE ".implode(" AND ",$Z):"").($He&&$Df?"\nGROUP BY ".implode(", ",$He):"").($Lh?"\nORDER BY ".implode(", ",$Lh):""),($w!==null?+$w:null),($C?$w*$C:0),"\n");$Fk=microtime(true);$J=$this->connection->query($G);if($Ji)echo
Admin::get()->formatSelectQuery($G,$Fk,!$J);return$J;}function
delete($R,$Wi,$w=0){$G="FROM ".table($R);return
queries("DELETE".($w?limit1($R,$G,$Wi):" $G$Wi"));}function
update($R,array$H,$Wi,$w=0,$N="\n"){$vm=[];foreach($H
as$u=>$X)$vm[]="$u = $X";$G=table($R)." SET$N".implode(",$N",$vm);return
queries("UPDATE".($w?limit1($R,$G,$Wi,$N):" $G$Wi"));}function
insert($R,array$H){return
queries("INSERT INTO ".table($R).($H?" (".implode(", ",array_keys($H)).")\nVALUES (".implode(", ",$H).")":" DEFAULT VALUES").$this->getInsertReturningSql($R));}function
getInsertReturningSql($R){return"";}function
insertUpdate($R,array$bj,array$F){return
false;}function
begin(){return
queries("BEGIN");}function
commit(){return
queries("COMMIT");}function
rollback(){return
queries("ROLLBACK");}function
slowQuery($G,$Al){return
null;}function
convertSearch($r,array$Z,array$k){return$r;}function
quoteBinary($Q){return
q($Q);}function
warnings(){return
null;}function
tableHelp($_,$Cf=false){return
null;}function
supportsIndex(array$cl){return!is_view($cl);}function
hasCStyleEscapes(){return
false;}function
engines(){return[];}function
checkConstraints($R){return
get_key_vals("SELECT c.CONSTRAINT_NAME, CHECK_CLAUSE
FROM INFORMATION_SCHEMA.CHECK_CONSTRAINTS c
JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS t ON c.CONSTRAINT_SCHEMA = t.CONSTRAINT_SCHEMA AND c.CONSTRAINT_NAME = t.CONSTRAINT_NAME
WHERE c.CONSTRAINT_SCHEMA = ".q($_GET["ns"]!=""?$_GET["ns"]:DB)."
AND t.TABLE_NAME = ".q($R)."
AND CHECK_CLAUSE NOT LIKE '% IS NOT NULL'",$this->connection);}function
getAllFields(){if(DB=="")return[];$Fa=[];$L=get_rows("SELECT TABLE_NAME AS tab, COLUMN_NAME AS field, IS_NULLABLE AS nullable, DATA_TYPE AS type, CHARACTER_MAXIMUM_LENGTH AS length".(DIALECT=='sql'?", COLUMN_KEY = 'PRI' AS `primary`":"")."
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = ".q($_GET["ns"]!=""?$_GET["ns"]:DB)."
ORDER BY TABLE_NAME, ORDINAL_POSITION",$this->connection);foreach($L
as$K){$K["null"]=($K["nullable"]=="YES");$Fa[$K["tab"]][]=$K;}return$Fa;}}Drivers::add("mysql","MySQL",["MySQLi","PDO_MySQL"]);if(isset($_GET["mysql"])){define("AdminNeo\DRIVER","mysql");define("AdminNeo\DIALECT","sql");if(extension_loaded("mysqli")&&$_GET["ext"]!="pdo"){define("AdminNeo\DRIVER_EXTENSION","MySQLi");class
MySqlConnection
extends
Connection{private$mysqli;protected
function
__construct(){parent::__construct();$this->mysqli=new
mysqli();$this->mysqli->init();}function
open($O,$V,$E,$Bc=null,$Ai=null,$sk=null){mysqli_report(MYSQLI_REPORT_OFF);list($cf,$Ai)=explode(":",$O,2);$u=Admin::get()->getConfig()->getSslKey();$rb=Admin::get()->getConfig()->getSslCertificate();$pb=Admin::get()->getConfig()->getSslCaCertificate();$Dk=$u||$rb||$pb;if($Dk){$this->mysqli->ssl_set($u,$rb,$pb,null,null);$ke=Admin::get()->getConfig()->getSslTrustServerCertificate()?64:MYSQLI_CLIENT_SSL;}else$ke=0;$ec=@$this->mysqli->real_connect(($O!=""?$cf:ini_get("mysqli.default_host")),($O.$V!=""?$V:ini_get("mysqli.default_user")),($O.$V.$E!=""?$E:ini_get("mysqli.default_pw")),$Bc,(is_numeric($Ai)?$Ai:ini_get("mysqli.default_port")),(!is_numeric($Ai)?$Ai:$sk),$ke);$this->mysqli->options(MYSQLI_OPT_LOCAL_INFILE,false);if($ec){$sf=$this->mysqli->get_server_info();$this->version=str_replace("-MariaDB","",$sf);$this->flavor=str_contains($sf,"MariaDB")?"mariadb":null;}return$ec;}function
getAffectedRows(){return$this->mysqli->affected_rows;}function
getErrno(){return$this->mysqli->errno;}function
getError(){return$this->mysqli->error;}function
selectDatabase($_){return$this->mysqli->select_db($_);}function
setCharset($tb){if($this->mysqli->set_charset($tb))return
true;$this->mysqli->set_charset('utf8');return(bool)$this->query("SET NAMES $tb");}function
quote($Q){return"'".$this->mysqli->escape_string($Q)."'";}function
query($G,$am=false){$I=$this->mysqli->query($G);return
is_object($I)?new
MySqlResult($I):$I;}function
getQueryInfo(){return$this->mysqli->info;}function
multiQuery($G){return$this->mysqli->multi_query($G);}function
storeResult($I=null){$I=$this->mysqli->store_result();if(!$I)return
false;return
new
MySqlResult($I);}function
nextResult(){return$this->mysqli->more_results()&&$this->mysqli->next_result();}}class
MySqlResult
extends
Result{private$resource;function
__construct(mysqli_result$pj){parent::__construct($pj->num_rows);$this->resource=$pj;}function
fetchAssoc(){return$this->resource->fetch_assoc();}function
fetchRow(){return$this->resource->fetch_row();}function
fetchField(){return$this->resource->fetch_field();}function
seek($A){return$this->resource->data_seek($A);}}}elseif(extension_loaded("pdo_mysql")){define("AdminNeo\DRIVER_EXTENSION","PDO_MySQL");class
MySqlConnection
extends
PdoConnection{function
open($O,$V,$E){$gd="mysql:charset=utf8;host=".str_replace(":",";unix_socket=",preg_replace('~:(\d)~',';port=\1',$O));$B=[PDO::MYSQL_ATTR_LOCAL_INFILE=>false];$u=Admin::get()->getConfig()->getSslKey();if($u)$B[PDO::MYSQL_ATTR_SSL_KEY]=$u;$rb=Admin::get()->getConfig()->getSslCertificate();if($rb)$B[PDO::MYSQL_ATTR_SSL_CERT]=$rb;$pb=Admin::get()->getConfig()->getSslCaCertificate();if($pb)$B[PDO::MYSQL_ATTR_SSL_CA]=$pb;$Vl=Admin::get()->getConfig()->getSslTrustServerCertificate();if($Vl!==null&&defined('\PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT'))$B[PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT]=!$Vl;if(!$this->dsn($gd,$V,$E,$B))return
false;$zm=@$this->pdo->getAttribute(PDO::ATTR_SERVER_VERSION);$this->flavor=str_contains($zm,"MariaDB")?"mariadb":null;return
true;}function
setCharset($tb){return(bool)$this->query("SET NAMES $tb");}function
selectDatabase($_){return(bool)$this->query("USE ".idf_escape($_));}function
query($G,$am=false){$this->pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY,!$am);return
parent::query($G,$am);}}}class
MySqlDriver
extends
Driver{protected
function
__construct(Connection$e,$xa){parent::__construct($e,$xa);$this->types=[lang(114)=>["tinyint"=>3,"smallint"=>5,"mediumint"=>8,"int"=>10,"bigint"=>20,"decimal"=>66,"float"=>12,"double"=>21,],lang(115)=>["date"=>10,"datetime"=>19,"timestamp"=>19,"time"=>10,"year"=>4,],lang(116)=>["char"=>255,"varchar"=>65535,"tinytext"=>255,"text"=>65535,"mediumtext"=>16777215,"longtext"=>4294967295,],lang(117)=>["enum"=>65535,"set"=>64,],lang(118)=>["bit"=>20,"binary"=>255,"varbinary"=>65535,"tinyblob"=>255,"blob"=>65535,"mediumblob"=>16777215,"longblob"=>4294967295,],lang(119)=>["geometry"=>0,"point"=>0,"linestring"=>0,"polygon"=>0,"multipoint"=>0,"multilinestring"=>0,"multipolygon"=>0,"geometrycollection"=>0,],];$this->unsigned=["unsigned","zerofill","unsigned zerofill"];$vg=$e->isMariaDB();if($e->isMinVersion($vg?"10.2":"5.7"))$this->generated=["STORED","VIRTUAL"];$this->operators=["=","<",">","<=",">=","!=","LIKE","LIKE %%","NOT LIKE","IN","NOT IN","FIND_IN_SET","IS NULL","IS NOT NULL","REGEXP","NOT REGEXP","SQL",];$this->likeOperator="LIKE %%";$this->regexpOperator="REGEXP";$this->functions=["char_length","lower","upper","round","floor","ceil","date","from_unixtime","unix_timestamp","sec_to_time","time_to_sec",];$this->grouping=["sum","min","max","avg","count","count distinct","group_concat",];$this->editFunctions=[["char"=>"md5/sha1/password/encrypt/uuid","binary"=>"md5/sha1","date|time"=>"now",],[number_type()=>"+/-","date"=>"+ interval/- interval","time"=>"addtime/subtime","char|text"=>"concat",]];if($e->isMinVersion($vg?"10.2":"5.7.8"))$this->types[lang(116)]["json"]=4294967295;if($vg&&$e->isMinVersion("10.7")){$this->types[lang(116)]["uuid"]=128;$this->editFunctions[0]['uuid']='uuid';}if($e->isMinVersion("9")){$this->types[lang(114)]["vector"]=16383;$this->editFunctions[0]['vector']='string_to_vector';}$this->systemDatabases=["mysql","information_schema","performance_schema","sys"];}function
insert($R,array$H){return($H?parent::insert($R,$H):queries("INSERT INTO ".table($R)." ()\nVALUES ()"));}function
getUnconvertFunction(array$k){if(preg_match("~binary~",$k["type"]))return"<code class='jush-sql'>UNHEX</code>";elseif($k["type"]=="bit")return
doc_link(array('sql'=>'bit-value-literals.html'),"<code>b''</code>");elseif(preg_match("~geometry|point|linestring|polygon~",$k["type"]))return"<code class='jush-sql'>GeomFromText</code>";else
return"";}function
insertUpdate($R,array$bj,array$F){$d=array_keys(reset($bj));$Fi="INSERT INTO ".table($R)." (".implode(", ",$d).") VALUES\n";$vm=[];foreach($d
as$u)$vm[$u]="$u = VALUES($u)";$Rk="\nON DUPLICATE KEY UPDATE ".implode(", ",$vm);$vm=[];$v=0;foreach($bj
as$H){$Y="(".implode(", ",$H).")";if($vm&&(strlen($Fi)+$v+strlen($Y)+strlen($Rk)>1e6)){if(!queries($Fi.implode(",\n",$vm).$Rk))return
false;$vm=[];$v=0;}$vm[]=$Y;$v+=strlen($Y)+2;}return
queries($Fi.implode(",\n",$vm).$Rk);}function
slowQuery($G,$Al){$vg=$this->connection->isMariaDB();if(!$this->connection->isMinVersion($vg?"10.1.2":"5.7.8"))return
null;if($vg)return"SET STATEMENT max_statement_time=$Al FOR $G";elseif(preg_match('~^(SELECT\b)(.+)~is',$G,$y))return"$y[1] /*+ MAX_EXECUTION_TIME(".($Al*1000).") */ $y[2]";else
return
null;}function
convertSearch($r,array$Z,array$k){return(preg_match('~char|text|enum|set~',$k["type"])&&!preg_match("~^utf8~",$k["collation"])&&preg_match('~[\x80-\xFF]~',$Z['val'])?"CONVERT($r USING ".charset($this->connection).")":$r);}function
warnings(){$I=$this->connection->query("SHOW WARNINGS");if($I&&$I->getRowsCount()){ob_start();select($I);return
ob_get_clean();}return
null;}function
tableHelp($_,$Cf=false){$vg=$this->connection->isMariaDB();if(information_schema(DB))return
strtolower("information-schema-".($vg?"$_-table/":str_replace("_","-",$_)."-table.html"));if(DB=="mysql")return($vg?"mysql$_-table/":"system-schema.html");return
null;}function
hasCStyleEscapes(){static$nb;if($nb===null){$Ak=$this->connection->getValue("SHOW VARIABLES LIKE 'sql_mode'",1);$nb=(strpos($Ak,'NO_BACKSLASH_ESCAPES')===false);}return$nb;}function
engines(){$vd=[];foreach(get_rows("SHOW ENGINES")as$K){if(preg_match("~YES|DEFAULT~",$K["Support"]))$vd[]=$K["Engine"];}return$vd;}}function
create_driver(Connection$e){return
MySqlDriver::create($e,Admin::get());}function
idf_escape($r){return"`".str_replace("`","``",$r)."`";}function
table($r){return
idf_escape($r);}function
connect($F=false,&$j=null){$e=$F?MySqlConnection::create():MySqlConnection::createSecondary();list($O,$V,$E)=Admin::get()->getCredentials();if(!$e->openPasswordless($O,$V,$E,false)){$j=$e->getError();if(function_exists('iconv')&&!is_utf8($j)&&strlen($Dj=iconv("windows-1250","utf-8",$j))>strlen($j))$j=$Dj;return
null;}$e->setCharset(charset($e));$e->query("SET sql_quote_show_create = 1, autocommit = 1");if($F&&$e->isMariaDB()){Drivers::setName(DRIVER,"MariaDB");save_driver_name(DRIVER,$O,"MariaDB");}return$e;}function
get_databases($me){$J=get_session("dbs");if($J===null){$G="SELECT SCHEMA_NAME FROM information_schema.SCHEMATA ORDER BY SCHEMA_NAME";$J=($me?slow_query($G):get_vals($G));restart_session();set_session("dbs",$J);stop_session();}return$J;}function
limit($G,$Z,$w,$A=0,$N=" "){return" $G$Z".($w!==null?$N."LIMIT $w".($A?" OFFSET $A":""):"");}function
limit1($R,$G,$Z,$N="\n"){return
limit($G,$Z,1,0,$N);}function
db_collation($h,$Kb){$J=null;$rc=Connection::get()->getValue("SHOW CREATE DATABASE ".idf_escape($h),1);if(preg_match('~ COLLATE ([^ ]+)~',$rc,$y))$J=$y[1];elseif(preg_match('~ CHARACTER SET ([^ ]+)~',$rc,$y))$J=$Kb[$y[1]][-1];return$J;}function
logged_user(){return
Connection::get()->getValue("SELECT USER()");}function
tables_list(){return
get_key_vals("SELECT TABLE_NAME, TABLE_TYPE FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() ORDER BY TABLE_NAME");}function
count_tables($g){$J=[];foreach($g
as$h)$J[$h]=count(get_vals("SHOW TABLES IN ".idf_escape($h)));return$J;}function
table_status($_="",$Td=false){if($Td)$G="SELECT TABLE_NAME AS Name, ENGINE AS Engine, CREATE_OPTIONS AS Create_options, TABLES.TABLE_COLLATION AS Collation, TABLE_COMMENT AS Comment FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() ".($_!=""?"AND TABLE_NAME = ".q($_):"ORDER BY Name");else$G="SHOW TABLE STATUS".($_!=""?" LIKE ".q(addcslashes($_,"%_\\")):"");$T=[];foreach(get_rows($G)as$K){if($K["Engine"]=="InnoDB")$K["Comment"]=preg_replace('~(?:(.+); )?InnoDB free: .*~','\1',$K["Comment"]);if(!isset($K["Engine"]))$K["Comment"]="";if($_!=""){$K["Name"]=$_;return$K;}$T[$K["Name"]]=$K;}return$T;}function
is_view($S){return$S["Engine"]===null;}function
fk_support($S){return
preg_match('~InnoDB|IBMDB2I~i',$S["Engine"])||(preg_match('~NDB~i',$S["Engine"])&&Connection::get()->isMinVersion("5.6"));}function
fields($R){$vg=Connection::get()->isMariaDB();$J=[];foreach(get_rows("SELECT * FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ".q($R)." ORDER BY ORDINAL_POSITION")as$K){$k=$K["COLUMN_NAME"];$U=preg_replace('~\s?/\*.+\*/~U',"",$K["COLUMN_TYPE"]);$Qd=$K["EXTRA"];preg_match('~^(VIRTUAL|PERSISTENT|STORED)~',$Qd,$Ae);preg_match('~^([^( ]+)(?:\((.+)\))?( unsigned)?( zerofill)?$~',$U,$Xl);$i=$vg&&$K["COLUMN_DEFAULT"]=="NULL"?null:$K["COLUMN_DEFAULT"];if($i!==null){$Ff=preg_match('~(text|json)~',$Xl[1]);if(!$vg&&$Ff)$i=preg_replace("~^(_\w+)?('.*')$~",'\2',stripslashes($i));if($vg||$Ff){$i=preg_replace_callback("~^'(.*)'$~",function($z){return
stripslashes(str_replace("''","'",$z[1]));},$i);}if(!$vg&&preg_match('~binary~',$Xl[1])&&preg_match('~^0x(\w*)$~',$i,$z))$i=pack("H*",$z[1]);}$Ce=$K["GENERATION_EXPRESSION"];if(!$vg)$Ce=preg_replace("~(^|,|\()(_\w+)?('.*')($|,|\))~",'\1\3\4',stripslashes($Ce));$J[$k]=["field"=>$k,"full_type"=>$U,"type"=>$Xl[1],"length"=>$Xl[2],"unsigned"=>ltrim($Xl[3].$Xl[4]),"default"=>($Ae?$Ce:$i),"null"=>($K["IS_NULLABLE"]=="YES"),"auto_increment"=>($Qd=="auto_increment"),"on_update"=>(preg_match('~\bon update (\w+)~i',$Qd,$Xl)?$Xl[1]:""),"collation"=>$K["COLLATION_NAME"],"privileges"=>array_flip(explode(",",$K["PRIVILEGES"]))+["where"=>1,"order"=>1],"comment"=>$K["COLUMN_COMMENT"],"primary"=>($K["COLUMN_KEY"]=="PRI"),"generated"=>($Ae[1]=="PERSISTENT"?"STORED":$Ae[1]),];}return$J;}function
indexes($R,$e=null){$J=[];foreach(get_rows("SHOW INDEX FROM ".table($R),$e)as$K){$_=$K["Key_name"];$J[$_]["type"]=($_=="PRIMARY"?"PRIMARY":($K["Index_type"]=="FULLTEXT"?"FULLTEXT":($K["Non_unique"]?($K["Index_type"]=="SPATIAL"?"SPATIAL":"INDEX"):"UNIQUE")));$J[$_]["columns"][]=$K["Column_name"];$J[$_]["lengths"][]=($K["Index_type"]=="SPATIAL"?null:$K["Sub_part"]);$J[$_]["descs"][]=null;}return$J;}function
foreign_keys($R){static$si='(?:`(?:[^`]|``)+`|"(?:[^"]|"")+")';$J=[];$sc=Connection::get()->getValue("SHOW CREATE TABLE ".table($R),1);if($sc){$Ah=implode("|",Driver::get()->getOnActions());preg_match_all("~CONSTRAINT ($si) FOREIGN KEY ?\\(((?:$si,? ?)+)\\) REFERENCES ($si)(?:\\.($si))? \\(((?:$si,? ?)+)\\)(?: ON DELETE ($Ah))?(?: ON UPDATE ($Ah))?~",$sc,$z,PREG_SET_ORDER);foreach($z
as$y){preg_match_all("~$si~",$y[2],$vk);preg_match_all("~$si~",$y[5],$pl);$J[idf_unescape($y[1])]=["db"=>idf_unescape($y[4]!=""?$y[3]:$y[4]),"table"=>idf_unescape($y[4]!=""?$y[4]:$y[3]),"source"=>array_map('AdminNeo\idf_unescape',$vk[0]),"target"=>array_map('AdminNeo\idf_unescape',$pl[0]),"on_delete"=>($y[6]?:"RESTRICT"),"on_update"=>($y[7]?:"RESTRICT"),];}}return$J;}function
backward_keys($R){$G="SELECT constraint_name, table_schema, table_name, column_name, referenced_column_name
FROM information_schema.key_column_usage
WHERE table_schema = ".q(DB)."
AND referenced_table_schema = ".q(DB)."
AND referenced_table_name = ".q($R)."
ORDER BY ordinal_position";return
get_rows($G,null,"");}function
view($_){return["select"=>preg_replace('~^(?:[^`]|`[^`]*`)*\s+AS\s+~isU','',Connection::get()->getValue("SHOW CREATE VIEW ".table($_),1))];}function
collations(){$J=[];$G=Connection::get()->isMariaDB()&&Connection::get()->isMinVersion("10.10")?"SELECT CHARACTER_SET_NAME AS Charset, FULL_COLLATION_NAME AS Collation, IS_DEFAULT AS `Default` FROM information_schema.COLLATION_CHARACTER_SET_APPLICABILITY":"SHOW COLLATION";foreach(get_rows($G)as$K){if($K["Default"])$J[$K["Charset"]][-1]=$K["Collation"];else$J[$K["Charset"]][]=$K["Collation"];}ksort($J);foreach($J
as$u=>$X)asort($J[$u]);return$J;}function
information_schema($h){return($h=="information_schema")||(Connection::get()->isMinVersion("5.5")&&$h=="performance_schema");}function
error(){return
h(preg_replace('~^You have an error.*syntax to use~U',"Syntax error",Connection::get()->getError()));}function
create_database($h,$Jb){return
queries("CREATE DATABASE ".idf_escape($h).($Jb?" COLLATE ".q($Jb):""));}function
drop_databases($g){$J=apply_queries("DROP DATABASE",$g,'AdminNeo\idf_escape');restart_session();set_session("dbs",null);return$J;}function
rename_database($_,$Jb){$J=false;if(create_database($_,$Jb)){$T=[];$Bm=[];foreach(tables_list()as$R=>$U){if($U=='VIEW')$Bm[]=$R;else$T[]=$R;}$J=(!$T&&!$Bm)||move_tables($T,$Bm,$_);drop_databases($J?[DB]:[]);}return$J;}function
auto_increment(){$Ua=" PRIMARY KEY";if($_GET["create"]!=""&&$_POST["auto_increment_col"]){foreach(indexes($_GET["create"])as$s){if(in_array($_POST["fields"][$_POST["auto_increment_col"]]["orig"],$s["columns"],true)){$Ua="";break;}if($s["type"]=="PRIMARY")$Ua=" UNIQUE";}}return" AUTO_INCREMENT$Ua";}function
alter_table($R,$_,$l,$oe,$Tb,$ud,$Jb,$Ta,$ki){$b=[];foreach($l
as$k){if($k[1]){$i=$k[1][3];if(str_contains($i," GENERATED")){$k[1][3]=Connection::get()->isMariaDB()?"":$k[1][2];$k[1][2]=$i;}$b[]=($R!=""?($k[0]!=""?"CHANGE ".idf_escape($k[0]):"ADD"):" ")." ".implode($k[1]).($R!=""?$k[2]:"");}else$b[]="DROP ".idf_escape($k[0]);}$b=array_merge($b,$oe);$Ik=($Tb!==null?" COMMENT=".q($Tb):"").($ud?" ENGINE=".q($ud):"").($Jb?" COLLATE ".q($Jb):"").($Ta!=""?" AUTO_INCREMENT=$Ta":"");if($R=="")return
queries("CREATE TABLE ".table($_)." (\n".implode(",\n",$b)."\n)$Ik$ki");if($R!=$_)$b[]="RENAME TO ".table($_);if($Ik)$b[]=ltrim($Ik);return($b||$ki?queries("ALTER TABLE ".table($R)."\n".implode(",\n",$b).$ki):true);}function
alter_indexes($R,$b){foreach($b
as$u=>$X)$b[$u]=($X[2]=="DROP"?"\nDROP INDEX ".idf_escape($X[1]):"\nADD $X[0] ".($X[0]=="PRIMARY"?"KEY ":"").($X[1]!=""?idf_escape($X[1])." ":"")."(".implode(", ",$X[2]).")");return
queries("ALTER TABLE ".table($R).implode(",",$b));}function
truncate_tables($T){return
apply_queries("TRUNCATE TABLE",$T);}function
drop_views($Bm){return
queries("DROP VIEW ".implode(", ",array_map('AdminNeo\table',$Bm)));}function
drop_tables($T){return
queries("DROP TABLE ".implode(", ",array_map('AdminNeo\table',$T)));}function
move_tables($T,$Bm,$pl){$nj=[];foreach($T
as$R)$nj[]=table($R)." TO ".idf_escape($pl).".".table($R);if(!$nj||queries("RENAME TABLE ".implode(", ",$nj))){$Lc=[];foreach($Bm
as$R)$Lc[table($R)]=view($R);Connection::get()->selectDatabase($pl);$h=idf_escape(DB);foreach($Lc
as$_=>$_m){if(!queries("CREATE VIEW $_ AS ".str_replace(" $h."," ",$_m["select"]))||!queries("DROP VIEW $h.$_"))return
false;}return
true;}return
false;}function
copy_tables($T,$Bm,$pl){queries("SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO'");foreach($T
as$R){$_=($pl==DB?table("copy_$R"):idf_escape($pl).".".table($R));if(($_POST["overwrite"]&&!queries("\nDROP TABLE IF EXISTS $_"))||!queries("CREATE TABLE $_ LIKE ".table($R))||!queries("INSERT INTO $_ SELECT * FROM ".table($R)))return
false;foreach(get_rows("SHOW TRIGGERS LIKE ".q(addcslashes($R,"%_\\")))as$K){$Ql=$K["Trigger"];if(!queries("CREATE TRIGGER ".($pl==DB?idf_escape("copy_$Ql"):idf_escape($pl).".".idf_escape($Ql))." $K[Timing] $K[Event] ON $_ FOR EACH ROW\n$K[Statement];"))return
false;}}foreach($Bm
as$R){$_=($pl==DB?table("copy_$R"):idf_escape($pl).".".table($R));$_m=view($R);if(($_POST["overwrite"]&&!queries("DROP VIEW IF EXISTS $_"))||!queries("CREATE VIEW $_ AS $_m[select]"))return
false;}return
true;}function
trigger($_){if($_=="")return[];$L=get_rows("SHOW TRIGGERS WHERE `Trigger` = ".q($_));return
reset($L);}function
triggers($R){$J=[];foreach(get_rows("SHOW TRIGGERS LIKE ".q(addcslashes($R,"%_\\")))as$K)$J[$K["Trigger"]]=[$K["Timing"],$K["Event"]];return$J;}function
trigger_options(){return["Timing"=>["BEFORE","AFTER"],"Event"=>["INSERT","UPDATE","DELETE"],"Type"=>["FOR EACH ROW"],];}function
routine($_,$U){$sf=get_rows("SELECT ROUTINE_BODY, ROUTINE_COMMENT FROM information_schema.ROUTINES WHERE ROUTINE_SCHEMA = ".q(DB)." AND ROUTINE_NAME = ".q($_))[0];$Ea=["bool","boolean","integer","double precision","real","dec","numeric","fixed","national char","national varchar"];$xk="(?:\\s|/\\*[\s\S]*?\\*/|(?:#|-- )[^\n]*\n?|--\r?\n)";$wd=Driver::$EnumLengthPattern;$Yl="((".implode("|",array_merge(array_keys(Driver::get()->getTypes()),$Ea)).")\\b(?:\\s*\\(((?:[^'\")]|$wd)++)\\))?\\s*(zerofill\\s*)?(unsigned(?:\\s+zerofill)?)?)(?:\\s*(?:CHARSET|CHARACTER\\s+SET)\\s*['\"]?([^'\"\\s,]+)['\"]?)?";$nf=implode("|",Driver::get()->getInOut());$si="$xk*(".($U=="FUNCTION"?"":$nf).")?\\s*(?:`((?:[^`]|``)*)`\\s*|\\b(\\S+)\\s+)$Yl";$rc=Connection::get()->getValue("SHOW CREATE $U ".idf_escape($_),2);preg_match("~\\(((?:$si\\s*,?)*)\\)\\s*".($U=="FUNCTION"?"RETURNS\\s+$Yl\\s+":"")."(.*)~is",$rc,$y);$l=[];preg_match_all("~$si\\s*,?~is",$y[1],$z,PREG_SET_ORDER);foreach($z
as$di)$l[]=["field"=>str_replace("``","`",$di[2]).$di[3],"type"=>strtolower($di[5]),"length"=>preg_replace_callback("~$wd~s",'AdminNeo\normalize_enum',$di[6]),"unsigned"=>strtolower(preg_replace('~\s+~',' ',trim("$di[8] $di[7]"))),"null"=>1,"full_type"=>$di[4],"inout"=>strtoupper($di[1]),"collation"=>strtolower($di[9]),];return$U=="FUNCTION"?["fields"=>$l,"returns"=>["type"=>$y[12],"length"=>$y[13],"unsigned"=>$y[15],"collation"=>$y[16]],"definition"=>$y[17],"language"=>$sf["ROUTINE_BODY"],"comment"=>$sf["ROUTINE_COMMENT"],]:["fields"=>$l,"returns"=>null,"definition"=>$y[11],"language"=>$sf["ROUTINE_BODY"],"comment"=>$sf["ROUTINE_COMMENT"],];}function
routines(){return
get_rows("SELECT ROUTINE_NAME AS SPECIFIC_NAME, ROUTINE_NAME, ROUTINE_TYPE, DTD_IDENTIFIER, ROUTINE_COMMENT FROM information_schema.ROUTINES WHERE ROUTINE_SCHEMA = ".q(DB));}function
routine_languages(){return[];}function
routine_id($_,$K){return
idf_escape($_);}function
last_id($I){return
Connection::get()->getValue("SELECT LAST_INSERT_ID()");}function
explain(Connection$e,$G){return$e->query("EXPLAIN ".(Connection::get()->isMinVersion("5.1")&&!Connection::get()->isMinVersion("5.7")?"PARTITIONS ":"").$G);}function
found_rows($S,$Z){return($Z||$S["Engine"]!="InnoDB"?null:$S["Rows"]);}function
create_sql($R,$Ta,$Nk){$J=Connection::get()->getValue("SHOW CREATE TABLE ".table($R),1);if(!$Ta)$J=preg_replace('~ AUTO_INCREMENT=\d+~','',$J);return$J;}function
truncate_sql($R){return"TRUNCATE ".table($R);}function
use_sql($Bc){return"USE ".idf_escape($Bc);}function
trigger_sql($R){$J="";foreach(get_rows("SHOW TRIGGERS LIKE ".q(addcslashes($R,"%_\\")),null,"-- ")as$K)$J
.="\nCREATE TRIGGER ".idf_escape($K["Trigger"])." $K[Timing] $K[Event] ON ".table($K["Table"])." FOR EACH ROW\n$K[Statement];;\n";return$J;}function
show_variables(){return
get_rows("SHOW VARIABLES");}function
show_status(){return
get_rows("SHOW STATUS");}function
process_list(){return
get_rows("SHOW FULL PROCESSLIST");}function
convert_field($k){if(preg_match("~binary~",$k["type"]))return"HEX(".idf_escape($k["field"]).")";if($k["type"]=="bit")return"BIN(".idf_escape($k["field"])." + 0)";if(preg_match("~geometry|point|linestring|polygon~",$k["type"]))return(Connection::get()->isMinVersion("8")?"ST_":"")."AsWKT(".idf_escape($k["field"]).")";}function
unconvert_field(array$k,$J){if(preg_match("~binary~",$k["type"]))$J="UNHEX($J)";if($k["type"]=="bit")$J="CONVERT(b$J, UNSIGNED)";if(preg_match("~geometry|point|linestring|polygon~",$k["type"])){$Fi=(Connection::get()->isMinVersion("8")?"ST_":"");$J=$Fi."GeomFromText($J, $Fi"."SRID($k[field]))";}return$J;}function
support($Ud){return!preg_match("~scheme|sequence|type|view_trigger|materializedview".(Connection::get()->isMinVersion("8")?"":"|descidx".(Connection::get()->isMinVersion("5.1")?"":"|event|partitioning")).(Connection::get()->isMinVersion(Connection::get()->isMariaDB()?"10.2.1":"8.0.16")?"":"|check")."~",$Ud);}function
kill_process($X){return
queries("KILL ".number($X));}function
connection_id(){return"SELECT CONNECTION_ID()";}function
max_connections(){return
Connection::get()->getValue("SELECT @@max_connections");}}Drivers::add("pgsql","PostgreSQL",["PgSQL","PDO_PgSQL"]);if(isset($_GET["pgsql"])){define("AdminNeo\DRIVER","pgsql");define("AdminNeo\DIALECT","pgsql");if(extension_loaded("pgsql")&&$_GET["ext"]!="pdo"){define("AdminNeo\DRIVER_EXTENSION","PgSQL");class
PgSqlConnection
extends
Connection{var$timeout=0;private$connection;private$connectionString;private$hasDefaultDatabase;function
open($O,$V,$E){$h=Admin::get()->getDatabase();set_error_handler(function($yd,$j){if(ini_bool("html_errors"))$j=html_entity_decode(strip_tags($j));$j=preg_replace('~^[^:]*: ~','',$j);$this->error=$j;});$this->connectionString="host='".str_replace(":","' port='",addcslashes($O,"'\\"))."' user='".addcslashes($V,"'\\")."' password='".addcslashes($E,"'\\")."'";$Ek=Admin::get()->getConfig()->getSslMode();if($Ek)$this->connectionString
.=" sslmode='$Ek'";$this->connection=@pg_connect("$this->connectionString dbname='".($h!=""?addcslashes($h,"'\\"):"postgres")."'",PGSQL_CONNECT_FORCE_NEW);if(!$this->connection&&$h!=""){$this->hasDefaultDatabase=false;$this->connection=@pg_connect("$this->connectionString dbname='postgres'",PGSQL_CONNECT_FORCE_NEW);}else$this->hasDefaultDatabase=true;restore_error_handler();if($this->connection){$zm=$this->getValue("SELECT version()");$this->flavor=str_contains($zm,"CockroachDB")?"cockroach":null;$this->version=preg_replace('~^\D*([\d.]+[-\w]*).*~',"$1",$zm);pg_set_client_encoding($this->connection,"UTF8");}return(bool)$this->connection;}function
quote($Q){return(function_exists('pg_escape_literal')?pg_escape_literal($this->connection,$Q):"'".pg_escape_string($this->connection,$Q)."'");}function
formatValue($Y,array$k){if($k["type"]=="bytea"&&$Y!==null)return
pg_unescape_bytea($Y);return
parent::formatValue($Y,$k);}function
selectDatabase($_){if($_==Admin::get()->getDatabase())return$this->hasDefaultDatabase;$J=@pg_connect("$this->connectionString dbname='".addcslashes($_,"'\\")."'",PGSQL_CONNECT_FORCE_NEW);if($J)$this->connection=$J;return$J;}function
close(){$this->connection=@pg_connect("$this->connectionString dbname='postgres'");}function
query($G,$am=false){if(!$this->connection){$this->error="Invalid connection.";return
false;}$I=@pg_query($this->connection,$G);$this->error="";if(!$I){$this->error=pg_last_error($this->connection);$J=false;}elseif(!pg_num_fields($I)){$this->affectedRows=pg_affected_rows($I);$J=true;}else$J=new
PgSqlResult($I);if($this->timeout){$this->timeout=0;$this->query("RESET statement_timeout");}return$J;}function
getValue($G,$Vd=0){$I=$this->query($G);return
is_object($I)?$I->fetchValue($Vd):false;}function
warnings(){$I=pg_last_notice($this->connection);return$I?h($I):null;}}class
PgSqlResult
extends
Result{private$resource;private$offset=0;function
__construct($pj){parent::__construct(pg_num_rows($pj));$this->resource=$pj;}function
__destruct(){pg_free_result($this->resource);}function
fetchAssoc(){return
pg_fetch_assoc($this->resource);}function
fetchRow(){return
pg_fetch_row($this->resource);}function
fetchValue($Vd){return$this->getRowsCount()?pg_fetch_result($this->resource,0,$Vd):false;}function
fetchField(){$c=$this->offset++;$Oh=pg_field_table($this->resource,$c);if($Oh===false)return
false;$_=pg_field_name($this->resource,$c);if($_===false)return
false;$U=pg_field_type($this->resource,$c);if($U===false)return
false;return(object)['orgtable'=>$Oh,'name'=>$_,'type'=>$U,'charsetnr'=>($U=="bytea"?63:0),];}}}elseif(extension_loaded("pdo_pgsql")){define("AdminNeo\DRIVER_EXTENSION","PDO_PgSQL");class
PgSqlConnection
extends
PdoConnection{var$timeout=0;function
open($O,$V,$E){$h=Admin::get()->getDatabase();$gd="pgsql:host='".str_replace(":","' port='",addcslashes($O,"'\\"))."' client_encoding=utf8 dbname='".($h!=""?addcslashes($h,"'\\"):"postgres")."'";$Ek=Admin::get()->getConfig()->getSslMode();if($Ek)$gd
.=" sslmode='$Ek'";if(!$this->dsn($gd,$V,$E))return
false;$zm=$this->getValue("SELECT version()");$this->flavor=str_contains($zm,"CockroachDB")?"cockroach":null;return
true;}function
selectDatabase($_){return
Admin::get()->getDatabase()==$_;}function
query($G,$am=false){$J=parent::query($G,$am);if($this->timeout){$this->timeout=0;parent::query("RESET statement_timeout");}return$J;}function
warnings(){return
null;}function
close(){}}}class
PgSqlDriver
extends
Driver{protected
function
__construct(Connection$e,$xa){parent::__construct($e,$xa);$this->types=[lang(114)=>["smallint"=>5,"integer"=>10,"bigint"=>19,"boolean"=>1,"numeric"=>0,"real"=>7,"double precision"=>16,"money"=>20,],lang(115)=>["date"=>13,"time"=>17,"timestamp"=>20,"timestamptz"=>21,"interval"=>0,],lang(116)=>["character"=>0,"character varying"=>0,"text"=>0,"tsquery"=>0,"tsvector"=>0,"uuid"=>0,"xml"=>0,],lang(118)=>["bit"=>0,"bit varying"=>0,"bytea"=>0,],lang(120)=>["cidr"=>43,"inet"=>43,"macaddr"=>17,"macaddr8"=>23,"txid_snapshot"=>0,],lang(119)=>["box"=>0,"circle"=>0,"line"=>0,"lseg"=>0,"path"=>0,"point"=>0,"polygon"=>0,],];if($e->isMinVersion("9.2")){$this->types[lang(116)]["json"]=4294967295;if($e->isMinVersion("9.4"))$this->types[lang(116)]["jsonb"]=4294967295;}if($e->isMinVersion("12"))$this->generated=["STORED"];$this->operators=["=","<",">","<=",">=","!=","~","~*","!~","!~*","LIKE","LIKE %%","ILIKE","ILIKE %%","NOT LIKE","IN","NOT IN","IS NULL","IS NOT NULL",];$this->likeOperator="LIKE %%";$this->regexpOperator="~*";$this->functions=["char_length","lower","upper","round","to_hex","to_timestamp",];$this->grouping=["sum","min","max","avg","count","count distinct",];$this->editFunctions=[["char"=>"md5","date|time"=>"now",],[number_type()=>"+/-","date|time"=>"+ interval/- interval","char|text"=>"||",]];$this->systemDatabases=["template1"];$this->systemSchemas=["information_schema","pg_catalog","pg_toast","pg_temp_*","pg_toast_temp_*"];}function
getInsertReturningSql($R){$Sa=array_filter(fields($R),function($k){return$k['auto_increment'];});return
count($Sa)==1?" RETURNING ".idf_escape(key($Sa)):"";}function
insertUpdate($R,array$bj,array$F){foreach($bj
as$H){$im=[];$Z=[];foreach($H
as$u=>$X){$im[]="$u = $X";if(isset($F[idf_unescape($u)]))$Z[]="$u = $X";}if(!(($Z&&queries("UPDATE ".table($R)." SET ".implode(", ",$im)." WHERE ".implode(" AND ",$Z))&&Connection::get()->getAffectedRows())||queries("INSERT INTO ".table($R)." (".implode(", ",array_keys($H)).") VALUES (".implode(", ",$H).")")))return
false;}return
true;}function
slowQuery($G,$Al){$this->connection->query("SET statement_timeout = ".(1000*$Al));$this->connection->timeout=1000*$Al;return$G;}function
convertSearch($r,array$Z,array$k){$vl="char|text";if(strpos($Z["op"],"LIKE")===false)$vl
.="|date|time(stamp)?|boolean|uuid|inet|cidr|macaddr|".number_type();return(preg_match("~$vl~",$k["type"])?$r:"CAST($r AS text)");}function
quoteBinary($Q){return"'\\x".bin2hex($Q)."'";}function
warnings(){return$this->connection->warnings();}function
tableHelp($_,$Cf=false){$mg=["information_schema"=>"infoschema","pg_catalog"=>($Cf?"view":"catalog"),];$x=$mg[$_GET["ns"]];if($x)return"$x-".str_replace("_","-",$_).".html";return
null;}function
supportsIndex(array$cl){return$cl["Engine"]!="view";}function
hasCStyleEscapes(){static$nb;if($nb===null)$nb=($this->connection->getValue("SHOW standard_conforming_strings")=="off");return$nb;}}function
create_driver(Connection$e){return
PgSqlDriver::create($e,Admin::get());}function
idf_escape($r){return'"'.str_replace('"','""',$r).'"';}function
table($r){return
idf_escape($r);}function
connect($F=false,&$j=null){$e=$F?PgSqlConnection::create():PgSqlConnection::createSecondary();list($O,$V,$E)=Admin::get()->getCredentials();$I=$e->openPasswordless($O,$V,$E,false);$zd=[];if(!$I&&$O==""&&preg_match('~connection to server on socket .+ failed: No such file or directory~U',$e->getError())){$zd[]=$e->getError();$O="localhost";$I=$e->openPasswordless($O,$V,$E,false);}if(!$I){$zd[]=$e->getError();$j=implode("\n",$zd);return
null;}if($e->isMinVersion("9"))$e->query("SET application_name = 'AdminNeo'");if($F&&$e->isCockroachDB()){Drivers::setName(DRIVER,"CockroachDB");save_driver_name(DRIVER,$O,"CockroachDB");}return$e;}function
get_databases(){return
get_vals("SELECT datname FROM pg_database
WHERE datallowconn = TRUE AND has_database_privilege(datname, 'CONNECT')
ORDER BY datname");}function
limit($G,$Z,$w,$A=0,$N=" "){return" $G$Z".($w!==null?$N."LIMIT $w".($A?" OFFSET $A":""):"");}function
limit1($R,$G,$Z,$N="\n"){return(preg_match('~^INTO~',$G)?limit($G,$Z,1,0,$N):" $G".(is_view(table_status1($R))?$Z:$N."WHERE ctid = (SELECT ctid FROM ".table($R).$Z.$N."LIMIT 1)"));}function
db_collation($h,$Kb){return
Connection::get()->getValue("SELECT datcollate FROM pg_database WHERE datname = ".q($h));}function
logged_user(){return
Connection::get()->getValue("SELECT user");}function
tables_list(){$G="SELECT table_name, table_type FROM information_schema.tables WHERE table_schema = current_schema()";if(support("materializedview"))$G
.="
UNION ALL
SELECT matviewname, 'MATERIALIZED VIEW'
FROM pg_matviews
WHERE schemaname = current_schema()";$G
.="
ORDER BY 1";return
get_key_vals($G);}function
count_tables($g){$J=[];foreach($g
as$h){if(Connection::get()->selectDatabase($h))$J[$h]=count(tables_list());}return$J;}function
table_status($_=""){static$Se;if($Se===null)$Se=Connection::get()->getValue("SELECT 'pg_table_size'::regproc");$J=[];foreach(get_rows("SELECT
	c.relname AS \"Name\",
	CASE c.relkind WHEN 'r' THEN 'table' WHEN 'm' THEN 'materialized view' ELSE 'view' END AS \"Engine\"".($Se?",
	pg_table_size(c.oid) AS \"Data_length\",
	pg_indexes_size(c.oid) AS \"Index_length\"":"").",
	obj_description(c.oid, 'pg_class') AS \"Comment\",
	".(Connection::get()->isMinVersion("12")?"''":"CASE WHEN c.relhasoids THEN 'oid' ELSE '' END")." AS \"Oid\",
	c.reltuples as \"Rows\",
	n.nspname
FROM pg_class c
JOIN pg_namespace n ON(n.nspname = current_schema() AND n.oid = c.relnamespace)
WHERE relkind IN ('r', 'm', 'v', 'f', 'p')
".($_!=""?"AND relname = ".q($_):"ORDER BY relname"))as$K)$J[$K["Name"]]=$K;if($_!="")return
isset($J[$_])?$J[$_]:["Name"=>$_];else
return$J;}function
is_view($S){return
in_array($S["Engine"],["view","materialized view"]);}function
fk_support($S){return
true;}function
fields($R){$J=[];$Ea=['timestamp without time zone'=>'timestamp','timestamp with time zone'=>'timestamptz',];foreach(get_rows("SELECT a.attname AS field, format_type(a.atttypid, a.atttypmod) AS full_type, pg_get_expr(d.adbin, d.adrelid) AS default, a.attnotnull::int, col_description(c.oid, a.attnum) AS comment".(Connection::get()->isMinVersion("10")?", a.attidentity".(Connection::get()->isMinVersion("12")?", a.attgenerated":""):"")."
FROM pg_class c
JOIN pg_namespace n ON c.relnamespace = n.oid
JOIN pg_attribute a ON c.oid = a.attrelid
LEFT JOIN pg_attrdef d ON c.oid = d.adrelid AND a.attnum = d.adnum
WHERE c.relname = ".q($R)."
AND n.nspname = current_schema()
AND NOT a.attisdropped
AND a.attnum > 0
ORDER BY a.attnum")as$K){preg_match('~([^([]+)(\((.*)\))?([a-z ]+)?((\[[0-9]*])*)$~',$K["full_type"],$y);list(,$U,$v,$K["length"],$wa,$Ma)=$y;$K["length"].=$Ma;$xb=$U.$wa;if(isset($Ea[$xb])){$K["type"]=$Ea[$xb];$K["full_type"]=$K["type"].$v.$Ma;}else{$K["type"]=$U;$K["full_type"]=$K["type"].$v.$wa.$Ma;}if(in_array($K['attidentity'],['a','d']))$K['default']='GENERATED '.($K['attidentity']=='d'?'BY DEFAULT':'ALWAYS').' AS IDENTITY';$K["generated"]=($K["attgenerated"]=="s"?"STORED":"");$K["null"]=!$K["attnotnull"];$K["auto_increment"]=$K['attidentity']||preg_match('~^nextval\(~i',$K["default"])||preg_match('~^unique_rowid\(~',$K["default"]);$K["privileges"]=["insert"=>1,"select"=>1,"update"=>1,"where"=>1,"order"=>1];if(preg_match('~(.+)::[^,)]+(.*)~',$K["default"],$y))$K["default"]=($y[1]=="NULL"?null:idf_unescape($y[1]).$y[2]);$J[$K["field"]]=$K;}return$J;}function
indexes($R,$e=null){if(!is_object($e))$e=Connection::get();$J=[];$gl=$e->getValue("SELECT oid FROM pg_class WHERE relnamespace = (SELECT oid FROM pg_namespace WHERE nspname = current_schema()) AND relname = ".q($R));$d=get_key_vals("SELECT attnum, attname FROM pg_attribute WHERE attrelid = $gl AND attnum > 0",$e);foreach(get_rows("SELECT relname, indisunique::int, indisprimary::int, indkey, indoption, (indpred IS NOT NULL)::int as indispartial FROM pg_index i, pg_class ci WHERE i.indrelid = $gl AND ci.oid = i.indexrelid ORDER BY indisprimary DESC, indisunique DESC",$e)as$K){$kj=$K["relname"];$J[$kj]["type"]=($K["indispartial"]?"INDEX":($K["indisprimary"]?"PRIMARY":($K["indisunique"]?"UNIQUE":"INDEX")));$J[$kj]["columns"]=[];$J[$kj]["descs"]=[];if($K["indkey"]){foreach(explode(" ",$K["indkey"])as$qf)$J[$kj]["columns"][]=$d[$qf];foreach(explode(" ",$K["indoption"])as$rf)$J[$kj]["descs"][]=($rf&1?'1':null);}$J[$kj]["lengths"]=[];}return$J;}function
foreign_keys($R){$Ah=implode("|",Driver::get()->getOnActions());$J=[];foreach(get_rows("SELECT conname, condeferrable::int AS deferrable, pg_get_constraintdef(oid) AS definition
FROM pg_constraint
WHERE conrelid = (SELECT pc.oid FROM pg_class AS pc INNER JOIN pg_namespace AS pn ON (pn.oid = pc.relnamespace) WHERE pc.relname = ".q($R)." AND pn.nspname = current_schema())
AND contype = 'f'::char
ORDER BY conkey, conname")as$K){if(preg_match('~FOREIGN KEY\s*\((.+)\)\s*REFERENCES (.+)\((.+)\)(.*)$~iA',$K['definition'],$y)){$K['source']=array_map('AdminNeo\idf_unescape',array_map('trim',explode(',',$y[1])));if(preg_match('~^(("([^"]|"")+"|[^"]+)\.)?"?("([^"]|"")+"|[^"]+)$~',$y[2],$xg)){$K['ns']=idf_unescape($xg[2]);$K['table']=idf_unescape($xg[4]);}$K['target']=array_map('AdminNeo\idf_unescape',array_map('trim',explode(',',$y[3])));$K['on_delete']=(preg_match("~ON DELETE ($Ah)~",$y[4],$xg)?$xg[1]:'NO ACTION');$K['on_update']=(preg_match("~ON UPDATE ($Ah)~",$y[4],$xg)?$xg[1]:'NO ACTION');$J[$K['conname']]=$K;}}return$J;}function
backward_keys($R){$G="SELECT s.constraint_name, s.table_schema, s.table_name, s.column_name, t.column_name AS referenced_column_name
FROM information_schema.key_column_usage s
JOIN information_schema.referential_constraints r USING (constraint_catalog, constraint_schema, constraint_name)
JOIN information_schema.key_column_usage t ON r.unique_constraint_catalog = t.constraint_catalog
	AND r.unique_constraint_schema = t.constraint_schema
	AND r.unique_constraint_name = t.constraint_name
	AND s.position_in_unique_constraint = t.ordinal_position
WHERE t.table_catalog = ".q(DB)."
AND t.table_schema = ".q($_GET["ns"])."
AND t.table_name = ".q($R)."
ORDER BY s.ordinal_position";return
get_rows($G,null,"");}function
view($_){return["select"=>trim(Connection::get()->getValue("SELECT pg_get_viewdef(".Connection::get()->getValue("SELECT oid FROM pg_class WHERE relnamespace = (SELECT oid FROM pg_namespace WHERE nspname = current_schema()) AND relname = ".q($_)).")"))];}function
collations(){return[];}function
information_schema($h){return
get_schema()=="information_schema";}function
error(){$J=h(Connection::get()->getError());if(preg_match('~^(.*\n)?([^\n]*)\n( *)\^(\n.*)?$~s',$J,$y))$J=$y[1].preg_replace('~((?:[^&]|&[^;]*;){'.strlen($y[3]).'})(.*)~','\1<b>\2</b>',$y[2]).$y[4];return
nl2br($J);}function
create_database($h,$Jb){return
queries("CREATE DATABASE ".idf_escape($h).($Jb?" ENCODING ".idf_escape($Jb):""));}function
drop_databases($g){Connection::get()->close();return
apply_queries("DROP DATABASE",$g,'AdminNeo\idf_escape');}function
rename_database($_,$Jb){Connection::get()->close();return
queries("ALTER DATABASE ".idf_escape(DB)." RENAME TO ".idf_escape($_));}function
auto_increment(){return"";}function
alter_table($R,$_,$l,$oe,$Tb,$ud,$Jb,$Ta,$ki){$b=[];$Ti=[];if($R!=""&&$R!=$_)$Ti[]="ALTER TABLE ".table($R)." RENAME TO ".table($_);$Uj="";foreach($l
as$k){$c=idf_escape($k[0]);$X=$k[1];if(!$X)$b[]="DROP $c";else{$um=$X[5];unset($X[5]);if($k[0]==""){if(isset($X[6]))$X[1]=($X[1]==" bigint"?" big":($X[1]==" smallint"?" small":" "))."serial";$b[]=($R!=""?"ADD ":"  ").implode($X);if(isset($X[6]))$b[]=($R!=""?"ADD":" ")." PRIMARY KEY ($X[0])";}else{if($c!=$X[0])$Ti[]="ALTER TABLE ".table($_)." RENAME $c TO $X[0]";$b[]="ALTER $c TYPE$X[1]";$Vj=$R."_".idf_unescape($X[0])."_seq";$b[]="ALTER $c ".($X[3]?"SET".preg_replace('~GENERATED ALWAYS(.*) STORED~','EXPRESSION\1',$X[3]):(isset($X[6])?"SET DEFAULT nextval(".q($Vj).")":"DROP DEFAULT"));if(isset($X[6]))$Uj="CREATE SEQUENCE IF NOT EXISTS ".idf_escape($Vj)." OWNED BY ".idf_escape($R).".$X[0]";$b[]="ALTER $c ".($X[2]==" NULL"?"DROP NOT":"SET").$X[2];}if($k[0]!=""||$um!="")$Ti[]="COMMENT ON COLUMN ".table($_).".$X[0] IS ".($um!=""?substr($um,9):"''");}}$b=array_merge($b,$oe);if($R=="")array_unshift($Ti,"CREATE TABLE ".table($_)." (\n".implode(",\n",$b)."\n)");elseif($b)array_unshift($Ti,"ALTER TABLE ".table($R)."\n".implode(",\n",$b));if($Uj)array_unshift($Ti,$Uj);if($Tb!==null)$Ti[]="COMMENT ON TABLE ".table($_)." IS ".q($Tb);if($Ta!="");foreach($Ti
as$G){if(!queries($G))return
false;}return
true;}function
alter_indexes($R,$b){$rc=[];$bd=[];$Ti=[];foreach($b
as$X){if($X[0]!="INDEX")$rc[]=($X[2]=="DROP"?"\nDROP CONSTRAINT ".idf_escape($X[1]):"\nADD".($X[1]!=""?" CONSTRAINT ".idf_escape($X[1]):"")." $X[0] ".($X[0]=="PRIMARY"?"KEY ":"")."(".implode(", ",$X[2]).")");elseif($X[2]=="DROP")$bd[]=idf_escape($X[1]);else$Ti[]="CREATE INDEX ".idf_escape($X[1]!=""?$X[1]:uniqid($R."_"))." ON ".table($R)." (".implode(", ",$X[2]).")";}if($rc)array_unshift($Ti,"ALTER TABLE ".table($R).implode(",",$rc));if($bd)array_unshift($Ti,"DROP INDEX ".implode(", ",$bd));foreach($Ti
as$G){if(!queries($G))return
false;}return
true;}function
truncate_tables($T){return
queries("TRUNCATE ".implode(", ",array_map('AdminNeo\table',$T)));}function
drop_views($Bm){return
drop_tables($Bm);}function
drop_tables($T){foreach($T
as$R){$Ik=table_status($R);if(!queries("DROP ".strtoupper($Ik["Engine"])." ".table($R)))return
false;}return
true;}function
move_tables($T,$Bm,$pl){foreach(array_merge($T,$Bm)as$R){$Ik=table_status($R);if(!queries("ALTER ".strtoupper($Ik["Engine"])." ".table($R)." SET SCHEMA ".idf_escape($pl)))return
false;}return
true;}function
trigger($_,$R){if($_=="")return["Statement"=>"EXECUTE PROCEDURE ()"];$d=[];$Z="WHERE trigger_schema = current_schema() AND event_object_table = ".q($R)." AND trigger_name = ".q($_);foreach(get_rows("SELECT * FROM information_schema.triggered_update_columns $Z")as$K)$d[]=$K["event_object_column"];$J=[];foreach(get_rows('SELECT trigger_name AS "Trigger", action_timing AS "Timing", event_manipulation AS "Event", \'FOR EACH \' || action_orientation AS "Type", action_statement AS "Statement" FROM information_schema.triggers '."$Z ORDER BY event_manipulation DESC")as$K){if($d&&$K["Event"]=="UPDATE")$K["Event"].=" OF";$K["Of"]=implode(", ",$d);if($J)$K["Event"].=" OR $J[Event]";$J=$K;}return$J;}function
triggers($R){$J=[];foreach(get_rows("SELECT * FROM information_schema.triggers WHERE trigger_schema = current_schema() AND event_object_table = ".q($R))as$K){$Ql=trigger($K["trigger_name"],$R);$J[$Ql["Trigger"]]=[$Ql["Timing"],$Ql["Event"]];}return$J;}function
trigger_options(){return["Timing"=>["BEFORE","AFTER"],"Event"=>["INSERT","UPDATE","UPDATE OF","DELETE","INSERT OR UPDATE","INSERT OR UPDATE OF","DELETE OR INSERT","DELETE OR UPDATE","DELETE OR UPDATE OF","DELETE OR INSERT OR UPDATE","DELETE OR INSERT OR UPDATE OF"],"Type"=>["FOR EACH ROW","FOR EACH STATEMENT"],];}function
routine($_,$U){$sf=get_rows('SELECT routine_definition, external_language, type_udt_name
			FROM information_schema.routines
			WHERE routine_schema = current_schema() AND specific_name = '.q($_))[0];$l=get_rows('SELECT parameter_name AS field, data_type AS type, character_maximum_length AS length, parameter_mode AS inout
			FROM information_schema.parameters
			WHERE specific_schema = current_schema() AND specific_name = '.q($_).'
			ORDER BY ordinal_position');return["fields"=>$l,"returns"=>["type"=>$sf["type_udt_name"]],"definition"=>$sf["routine_definition"],"language"=>strtolower($sf["external_language"]),"comment"=>null,];}function
routines(){return
get_rows('SELECT specific_name AS "SPECIFIC_NAME", routine_name AS "ROUTINE_NAME", routine_type AS "ROUTINE_TYPE", type_udt_name AS "DTD_IDENTIFIER", null AS ROUTINE_COMMENT
			FROM information_schema.routines
			WHERE routine_schema = current_schema()
			ORDER BY SPECIFIC_NAME');}function
routine_languages(){return
get_vals("SELECT LOWER(lanname) FROM pg_catalog.pg_language");}function
routine_id($_,$K){$J=[];foreach($K["fields"]as$k){$v=$k["length"];$J[]=$k["type"].($v?"($v)":"");}return
idf_escape($_)."(".implode(", ",$J).")";}function
last_id($I){$K=$I
instanceof
Result?$I->fetchRow():[];return$K?$K[0]:0;}function
explain(Connection$e,$G){return$e->query("EXPLAIN $G");}function
found_rows($S,$Z){if(preg_match("~ rows=([0-9]+)~",Connection::get()->getValue("EXPLAIN SELECT * FROM ".idf_escape($S["Name"]).($Z?" WHERE ".implode(" AND ",$Z):"")),$jj))return$jj[1];return
false;}function
types(){return
get_key_vals("SELECT oid, typname
FROM pg_type
WHERE typnamespace = (SELECT oid FROM pg_namespace WHERE nspname = current_schema())
AND typtype IN ('b','d','e')
AND typelem = 0");}function
type_values($q){$xd=get_vals("SELECT enumlabel FROM pg_enum WHERE enumtypid = $q ORDER BY enumsortorder");return($xd?"'".implode("', '",array_map('addslashes',$xd))."'":"");}function
schemas(){return
get_vals("SELECT nspname FROM pg_namespace ORDER BY nspname");}function
get_schema(){return
Connection::get()->getValue("SELECT current_schema()");}function
set_schema($Gj,$e=null){if(!$e)$e=Connection::get();$I=(bool)$e->query("SET search_path TO ".idf_escape($Gj));Driver::get()->setUserTypes(types());return$I;}function
foreign_keys_sql($R){$J="";$Ik=table_status($R);$je=foreign_keys($R);ksort($je);foreach($je
as$ie=>$he)$J
.="ALTER TABLE ONLY ".idf_escape($Ik['nspname']).".".idf_escape($Ik['Name'])." ADD CONSTRAINT ".idf_escape($ie)." $he[definition] ".($he['deferrable']?'DEFERRABLE':'NOT DEFERRABLE').";\n";return($J?"$J\n":$J);}function
create_sql($R,$Ta,$Nk){$uj=[];$Wj=[];$Ik=table_status($R);if(is_view($Ik)){$_m=view($R);return
rtrim("CREATE VIEW ".idf_escape($R)." AS $_m[select]",";");}$l=fields($R);if(!$Ik||empty($l))return
false;$J="CREATE TABLE ".idf_escape($Ik['nspname']).".".idf_escape($Ik['Name'])." (\n    ";foreach($l
as$k){$gi=idf_escape($k['field']).' '.$k['full_type'].default_value($k).($k['attnotnull']?" NOT NULL":"");$uj[]=$gi;if(preg_match('~nextval\(\'([^\']+)\'\)~',$k['default'],$z)){$Vj=$z[1];$yk=first(get_rows((Connection::get()->isMinVersion("10")?"SELECT *, cache_size AS cache_value FROM pg_sequences WHERE schemaname = current_schema() AND sequencename = ".q(idf_unescape($Vj)):"SELECT * FROM $Vj"),null,"-- "));$Wj[]=($Nk=="DROP+CREATE"?"DROP SEQUENCE IF EXISTS $Vj;\n":"")."CREATE SEQUENCE $Vj INCREMENT $yk[increment_by] MINVALUE $yk[min_value] MAXVALUE $yk[max_value]".($Ta&&$yk['last_value']?" START ".($yk["last_value"]+1):"")." CACHE $yk[cache_value];";}}if(!empty($Wj))$J=implode("\n\n",$Wj)."\n\n$J";$F="";foreach(indexes($R)as$of=>$s){if($s['type']=='PRIMARY'){$F=$of;$uj[]="CONSTRAINT ".idf_escape($of)." PRIMARY KEY (".implode(', ',array_map('AdminNeo\idf_escape',$s['columns'])).")";}}foreach(Driver::get()->checkConstraints($R)as$dc=>$ic)$uj[]="CONSTRAINT ".idf_escape($dc)." CHECK $ic";$J
.=implode(",\n    ",$uj)."\n) WITH (oids = ".($Ik['Oid']?'true':'false').");";if($Ik['Comment'])$J
.="\n\nCOMMENT ON TABLE ".idf_escape($Ik['nspname']).".".idf_escape($Ik['Name'])." IS ".q($Ik['Comment']).";";foreach($l
as$Yd=>$k){if($k['comment'])$J
.="\n\nCOMMENT ON COLUMN ".idf_escape($Ik['nspname']).".".idf_escape($Ik['Name']).".".idf_escape($Yd)." IS ".q($k['comment']).";";}foreach(get_rows("SELECT indexdef FROM pg_catalog.pg_indexes WHERE schemaname = current_schema() AND tablename = ".q($R).($F?" AND indexname != ".q($F):""),null,"-- ")as$K)$J
.="\n\n$K[indexdef];";return
rtrim($J,';');}function
truncate_sql($R){return"TRUNCATE ".table($R);}function
trigger_sql($R){$Ik=table_status($R);$J="";foreach(triggers($R)as$Pl=>$Ol){$Ql=trigger($Pl,$Ik['Name']);$J
.="\nCREATE TRIGGER ".idf_escape($Ql['Trigger'])." $Ql[Timing] $Ql[Event] ON ".idf_escape($Ik["nspname"]).".".idf_escape($Ik['Name'])." $Ql[Type] $Ql[Statement];;\n";}return$J;}function
use_sql($Bc){return"\connect ".idf_escape($Bc);}function
show_variables(){return
get_rows("SHOW ALL");}function
process_list(){return
get_rows("SELECT * FROM pg_stat_activity ORDER BY ".(Connection::get()->isMinVersion("9.2")?"pid":"procpid"));}function
convert_field($k){}function
unconvert_field(array$k,$J){return$J;}function
support($Ud){if($Ud=="processlist")return!Connection::get()->isCockroachDB();elseif($Ud=="materializedview")return
Connection::get()->isMinVersion("9.3");elseif($Ud=="procedure")return
Connection::get()->isMinVersion("11");return
preg_match('~^(check|database|table|columns|sql|indexes|descidx|comment|view|scheme|routine|sequence|trigger|type|variables|drop_col|kill|dump)$~',$Ud);}function
kill_process($X){return
queries("SELECT pg_terminate_backend(".number($X).")");}function
connection_id(){return"SELECT pg_backend_pid()";}function
max_connections(){return
Connection::get()->getValue("SHOW max_connections");}}Drivers::add("mssql","MS SQL",["SQLSRV","PDO_SQLSRV","PDO_DBLIB"]);if(isset($_GET["mssql"])){define("AdminNeo\DRIVER","mssql");define("AdminNeo\DIALECT","mssql");if(extension_loaded("sqlsrv")&&$_GET["ext"]!="pdo"){define("AdminNeo\DRIVER_EXTENSION","sqlsrv");class
MsSqlConnection
extends
Connection{private$connection;protected$multiResult;function
open($O,$V,$E){$gc=["UID"=>$V,"PWD"=>$E,"CharacterSet"=>"UTF-8",];$sd=Admin::get()->getConfig()->getSslEncrypt();if($sd!==null)$gc["Encrypt"]=$sd;$Ul=Admin::get()->getConfig()->getSslTrustServerCertificate();if($Ul!==null)$gc["TrustServerCertificate"]=$Ul;$h=Admin::get()->getDatabase();if($h!="")$gc["Database"]=$h;$this->connection=@sqlsrv_connect(preg_replace('~:~',',',$O),$gc);if($this->connection){$sf=sqlsrv_server_info($this->connection);$this->version=$sf['SQLServerVersion'];}else$this->resolveError();return(bool)$this->connection;}private
function
resolveError(){$this->error="";foreach(sqlsrv_errors()as$j){$this->errno=$j["code"];$this->error
.="$j[message]\n";}$this->error=rtrim($this->error);}function
quote($Q){return(contains_unicode($Q)?"N":"")."'".str_replace("'","''",$Q)."'";}function
selectDatabase($_){return$this->query(use_sql($_));}function
query($G,$am=false){$I=sqlsrv_query($this->connection,$G);$this->error="";if(!$I){$this->resolveError();return
false;}return$this->storeResult($I);}function
multiQuery($G){$this->multiResult=sqlsrv_query($this->connection,$G);$this->error="";if(!$this->multiResult){$this->resolveError();return
false;}return
true;}function
storeResult($I=null){if(!$I){$I=$this->multiResult;if(!$I)return
false;}if(sqlsrv_field_metadata($I))return
new
MsSqlResult($I);$this->affectedRows=sqlsrv_rows_affected($I);return
true;}function
nextResult(){return$this->multiResult&&sqlsrv_next_result($this->multiResult);}}class
MsSqlResult
extends
Result{private$resource;private$fields=false;private$offset=0;function
__construct($pj){parent::__construct(0);$this->resource=$pj;}function
__destruct(){sqlsrv_free_stmt($this->resource);}function
fetchAssoc(){return$this->convertRow(sqlsrv_fetch_array($this->resource,SQLSRV_FETCH_ASSOC));}function
fetchRow(){return$this->convertRow(sqlsrv_fetch_array($this->resource,SQLSRV_FETCH_NUMERIC));}private
function
convertRow($K){if(is_array($K)){foreach($K
as$u=>$X){if(is_a($X,'DateTime'))$K[$u]=$X->format("Y-m-d H:i:s");}}return$K;}function
fetchField(){if(!$this->fields){$this->fields=sqlsrv_field_metadata($this->resource);if(!$this->fields)return
false;}$k=$this->fields[$this->offset++];return(object)['name'=>$k["Name"],'type'=>($k["Type"]==1?254:15),'charsetnr'=>0,];}function
seek($A){for($p=0;$p<$A;$p++){if(!sqlsrv_fetch($this->resource))return
false;}return
true;}}function
last_id($I){return
Connection::get()->getValue("SELECT SCOPE_IDENTITY()");}function
explain(Connection$e,$G){$e->query("SET SHOWPLAN_ALL ON");$J=$e->query($G);$e->query("SET SHOWPLAN_ALL OFF");return$J;}}else{abstract
class
MsSqlPdoConnection
extends
PdoConnection{function
selectDatabase($_){return(bool)$this->query(use_sql($_));}function
quote($Q){return(contains_unicode($Q)?"N":"").parent::quote($Q);}function
lastInsertId(){return$this->pdo->lastInsertId();}}if(extension_loaded("pdo_sqlsrv")){define("AdminNeo\DRIVER_EXTENSION","PDO_SQLSRV");class
MsSqlConnection
extends
MsSqlPdoConnection{function
open($O,$V,$E){$B=[];$sd=Admin::get()->getConfig()->getSslEncrypt();if($sd!==null)$B[]="Encrypt=$sd";$Ul=Admin::get()->getConfig()->getSslTrustServerCertificate();if($Ul!==null)$B[]="TrustServerCertificate=$Ul";$Jh=$B?(";".implode(";",$B)):"";return$this->dsn("sqlsrv:Server=".str_replace(":",",",$O).$Jh,$V,$E);}}}elseif(extension_loaded("pdo_dblib")){define("AdminNeo\DRIVER_EXTENSION","PDO_DBLIB");class
MsSqlConnection
extends
MsSqlPdoConnection{function
open($O,$V,$E){return$this->dsn("dblib:charset=utf8;host=".str_replace(":",";unix_socket=",preg_replace('~:(\d)~',';port=\1',$O)),$V,$E);}}}function
last_id($I){$e=Connection::get();return$e->lastInsertId();}function
explain(Connection$e,$G){}}class
MsSqlDriver
extends
Driver{protected
function
__construct(Connection$e,$xa){parent::__construct($e,$xa);$this->types=[lang(114)=>["tinyint"=>3,"smallint"=>5,"int"=>10,"bigint"=>20,"bit"=>1,"decimal"=>0,"real"=>12,"float"=>53,"smallmoney"=>10,"money"=>20,],lang(115)=>["date"=>10,"smalldatetime"=>19,"datetime"=>19,"datetime2"=>19,"time"=>8,"datetimeoffset"=>10,],lang(116)=>["char"=>8000,"varchar"=>8000,"text"=>2147483647,"nchar"=>4000,"nvarchar"=>4000,"ntext"=>1073741823,],lang(118)=>["binary"=>8000,"varbinary"=>8000,"image"=>2147483647,],];$this->generated=["PERSISTED","VIRTUAL"];$this->operators=["=","<",">","<=",">=","!=","LIKE","LIKE %%","NOT LIKE","IN","NOT IN","IS NULL","IS NOT NULL",];$this->likeOperator="LIKE %%";$this->functions=["len","lower","upper","round",];$this->grouping=["sum","min","max","avg","count","count distinct",];$this->onActions=["CASCADE","SET NULL","SET DEFAULT","NO ACTION"];$this->editFunctions=[["date|time"=>"getdate",],["int|decimal|real|float|money|datetime"=>"+/-","char|text"=>"+",]];$this->systemDatabases=["INFORMATION_SCHEMA","guest","sys","db_*"];}function
insertUpdate($R,array$bj,array$F){$l=fields($R);$im=[];$Z=[];$H=reset($bj);$d="c".implode(", c",range(1,count($H)));$mb=0;$vf=[];foreach($H
as$u=>$X){$mb++;$_=idf_unescape($u);if(!$l[$_]["auto_increment"])$vf[$u]="c$mb";if(isset($F[$_]))$Z[]="$u = c$mb";else$im[]="$u = c$mb";}$vm=[];foreach($bj
as$H)$vm[]="(".implode(", ",$H).")";if($Z){$hf=queries("SET IDENTITY_INSERT ".table($R)." ON");$J=queries("MERGE ".table($R)." USING (VALUES\n\t".implode(",\n\t",$vm)."\n) AS source ($d) ON ".implode(" AND ",$Z).($im?"\nWHEN MATCHED THEN UPDATE SET ".implode(", ",$im):"")."\nWHEN NOT MATCHED THEN INSERT (".implode(", ",array_keys($hf?$H:$vf)).") VALUES (".($hf?$d:implode(", ",$vf)).");");if($hf)queries("SET IDENTITY_INSERT ".table($R)." OFF");}else$J=queries("INSERT INTO ".table($R)." (".implode(", ",array_keys($H)).") VALUES\n".implode(",\n",$vm));return$J;}function
begin(){return
queries("BEGIN TRANSACTION");}function
tableHelp($_,$Cf=false){$mg=["sys"=>"catalog-views/sys-","INFORMATION_SCHEMA"=>"information-schema-views/",];$x=$mg[get_schema()];if($x)return"relational-databases/system-$x".preg_replace('~_~','-',strtolower($_))."-transact-sql";return
null;}}function
create_driver(Connection$e){return
MsSqlDriver::create($e,Admin::get());}function
contains_unicode($Q){return
strlen($Q)!=strlen(utf8_decode($Q));}function
idf_escape($r){return"[".str_replace("]","]]",$r)."]";}function
table($r){return($_GET["ns"]!=""?idf_escape($_GET["ns"]).".":"").idf_escape($r);}function
connect($F=false,&$j=null){$e=$F?MsSqlConnection::create():MsSqlConnection::createSecondary();$uc=Admin::get()->getCredentials();if($uc[0]=="")$uc[0]="localhost:1433";if(!$e->open($uc[0],$uc[1],$uc[2])){$j=$e->getError();return
null;}return$e;}function
get_databases(){return
get_vals("SELECT name FROM sys.databases WHERE name NOT IN ('master', 'tempdb', 'model', 'msdb') ORDER BY name");}function
limit($G,$Z,$w,$A=0,$N=" "){return($w!==null?" TOP (".($w+$A).")":"")." $G$Z";}function
limit1($R,$G,$Z,$N="\n"){return
limit($G,$Z,1,0,$N);}function
db_collation($h,$Kb){return
Connection::get()->getValue("SELECT collation_name FROM sys.databases WHERE name = ".q($h));}function
logged_user(){return
Connection::get()->getValue("SELECT SUSER_NAME()");}function
tables_list(){return
get_key_vals("SELECT name, type_desc FROM sys.all_objects WHERE schema_id = SCHEMA_ID(".q(get_schema()).") AND type IN ('S', 'U', 'V') ORDER BY name");}function
count_tables($g){$J=[];foreach($g
as$h){Connection::get()->selectDatabase($h);$J[$h]=Connection::get()->getValue("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES");}return$J;}function
table_status($_=""){$J=[];foreach(get_rows("SELECT ao.name AS Name, ao.type_desc AS Engine, (SELECT value FROM fn_listextendedproperty(default, 'SCHEMA', schema_name(schema_id), 'TABLE', ao.name, null, null)) AS Comment FROM sys.all_objects AS ao WHERE schema_id = SCHEMA_ID(".q(get_schema()).") AND type IN ('S', 'U', 'V') ".($_!=""?"AND name = ".q($_):"ORDER BY name"))as$K){if($_!="")return$K;$J[$K["Name"]]=$K;}return$J;}function
is_view($S){return$S["Engine"]=="VIEW";}function
fk_support($S){return
true;}function
fields($R){$Vb=get_key_vals("SELECT objname, cast(value as varchar(max)) FROM fn_listextendedproperty('MS_DESCRIPTION', 'schema', ".q(get_schema()).", 'table', ".q($R).", 'column', NULL)");$J=[];$el=Connection::get()->getValue("SELECT object_id FROM sys.all_objects WHERE schema_id = SCHEMA_ID(".q(get_schema()).") AND type IN ('S', 'U', 'V') AND name = ".q($R));foreach(get_rows("SELECT c.max_length, c.precision, c.scale, c.name, c.is_nullable, c.is_identity, c.collation_name, t.name type, d.definition [default], d.name default_constraint, i.is_primary_key
FROM sys.all_columns c
JOIN sys.types t ON c.user_type_id = t.user_type_id
LEFT JOIN sys.default_constraints d ON c.default_object_id = d.object_id
LEFT JOIN sys.index_columns ic ON c.object_id = ic.object_id AND c.column_id = ic.column_id
LEFT JOIN sys.indexes i ON ic.object_id = i.object_id AND ic.index_id = i.index_id
WHERE c.object_id = ".q($el))as$K){$U=$K["type"];$v=(preg_match("~char|binary~",$U)?$K["max_length"]/($U[0]=='n'?2:1):($U=="decimal"?"$K[precision],$K[scale]":""));$J[$K["name"]]=["field"=>$K["name"],"full_type"=>$U.($v?"($v)":""),"type"=>$U,"length"=>$v,"default"=>(preg_match("~^\('(.*)'\)$~",$K["default"],$y)?str_replace("''","'",$y[1]):$K["default"]),"default_constraint"=>$K["default_constraint"],"null"=>$K["is_nullable"],"auto_increment"=>$K["is_identity"],"collation"=>$K["collation_name"],"privileges"=>["insert"=>1,"select"=>1,"update"=>1,"where"=>1,"order"=>1],"primary"=>$K["is_primary_key"],"comment"=>$Vb[$K["name"]],];}foreach(get_rows("SELECT * FROM sys.computed_columns WHERE object_id = ".q($el))as$K){$J[$K["name"]]["generated"]=($K["is_persisted"]?"PERSISTED":"VIRTUAL");$J[$K["name"]]["default"]=$K["definition"];}return$J;}function
indexes($R,$e=null){$J=[];foreach(get_rows("SELECT i.name, key_ordinal, is_unique, is_primary_key, c.name AS column_name, is_descending_key
FROM sys.indexes i
INNER JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
INNER JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
WHERE OBJECT_NAME(i.object_id) = ".q($R),$e)as$K){$_=$K["name"];$J[$_]["type"]=($K["is_primary_key"]?"PRIMARY":($K["is_unique"]?"UNIQUE":"INDEX"));$J[$_]["lengths"]=[];$J[$_]["columns"][$K["key_ordinal"]]=$K["column_name"];$J[$_]["descs"][$K["key_ordinal"]]=($K["is_descending_key"]?'1':null);}return$J;}function
view($_){return["select"=>preg_replace('~^(?:[^[]|\[[^]]*])*\s+AS\s+~isU','',Connection::get()->getValue("SELECT VIEW_DEFINITION FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_SCHEMA = SCHEMA_NAME() AND TABLE_NAME = ".q($_)))];}function
collations(){$J=[];foreach(get_vals("SELECT name FROM fn_helpcollations()")as$Jb)$J[preg_replace('~_.*~','',$Jb)][]=$Jb;return$J;}function
information_schema($h){return
get_schema()=="INFORMATION_SCHEMA";}function
error(){return
nl2br(h(preg_replace('~^(\[[^]]*])+~m','',Connection::get()->getError())));}function
create_database($h,$Jb){return
queries("CREATE DATABASE ".idf_escape($h).(preg_match('~^[a-z0-9_]+$~i',$Jb)?" COLLATE $Jb":""));}function
drop_databases($g){return
queries("DROP DATABASE ".implode(", ",array_map('AdminNeo\idf_escape',$g)));}function
rename_database($_,$Jb){if(preg_match('~^[a-z0-9_]+$~i',$Jb))queries("ALTER DATABASE ".idf_escape(DB)." COLLATE $Jb");queries("ALTER DATABASE ".idf_escape(DB)." MODIFY NAME = ".idf_escape($_));return
true;}function
auto_increment(){return" IDENTITY".($_POST["Auto_increment"]!=""?"(".number($_POST["Auto_increment"]).",1)":"")." PRIMARY KEY";}function
alter_table($R,$_,$l,$oe,$Tb,$ud,$Jb,$Ta,$ki){$b=[];$Vb=[];$Sh=fields($R);foreach($l
as$k){$c=idf_escape($k[0]);$X=$k[1];if(!$X)$b["DROP"][]=" COLUMN $c";else{$X[1]=preg_replace("~( COLLATE )'(\\w+)'~",'\1\2',$X[1]);$Vb[$k[0]]=$X[5];unset($X[5]);if(preg_match('~ AS ~',$X[3]))unset($X[1],$X[2]);if($k[0]=="")$b["ADD"][]="\n  ".implode("",$X).($R==""?substr($oe[$X[0]],16+strlen($X[0])):"");else{$i=$X[3];unset($X[3]);unset($X[6]);if($c!=$X[0])queries("EXEC sp_rename ".q(table($R).".$c").", ".q(idf_unescape($X[0])).", 'COLUMN'");$b["ALTER COLUMN ".implode("",$X)][]="";$Rh=$Sh[$k[0]];if(default_value($Rh)!=$i){if($Rh["default"]!==null)$b["DROP"][]=" ".idf_escape($Rh["default_constraint"]);if($i)$b["ADD"][]="\n $i FOR $c";}}}}if($R=="")return
queries("CREATE TABLE ".table($_)." (".implode(",",(array)$b["ADD"])."\n)");if($R!=$_)queries("EXEC sp_rename ".q(table($R)).", ".q($_));if($oe)$b[""]=$oe;foreach($b
as$u=>$X){if(!queries("ALTER TABLE ".table($_)." $u".implode(",",$X)))return
false;}foreach($Vb
as$u=>$X){$Tb=substr($X,9);queries("EXEC sp_dropextendedproperty @name = N'MS_Description', @level0type = N'Schema', @level0name = ".q(get_schema()).", @level1type = N'Table', @level1name = ".q($_).", @level2type = N'Column', @level2name = ".q($u));queries("EXEC sp_addextendedproperty @name = N'MS_Description', @value = ".$Tb.", @level0type = N'Schema', @level0name = ".q(get_schema()).", @level1type = N'Table', @level1name = ".q($_).", @level2type = N'Column', @level2name = ".q($u));}return
true;}function
alter_indexes($R,$b){$s=[];$bd=[];foreach($b
as$X){if($X[2]=="DROP"){if($X[0]=="PRIMARY")$bd[]=idf_escape($X[1]);else$s[]=idf_escape($X[1])." ON ".table($R);}elseif(!queries(($X[0]!="PRIMARY"?"CREATE $X[0] ".($X[0]!="INDEX"?"INDEX ":"").idf_escape($X[1]!=""?$X[1]:uniqid($R."_"))." ON ".table($R):"ALTER TABLE ".table($R)." ADD PRIMARY KEY")." (".implode(", ",$X[2]).")"))return
false;}return(!$s||queries("DROP INDEX ".implode(", ",$s)))&&(!$bd||queries("ALTER TABLE ".table($R)." DROP ".implode(", ",$bd)));}function
found_rows($S,$Z){}function
foreign_keys($R){$J=[];$Ah=Driver::get()->getOnActions();foreach(get_rows("EXEC sp_fkeys @fktable_name = ".q($R).", @fktable_owner = ".q(get_schema()))as$K){$o=&$J[$K["FK_NAME"]];$o["db"]=$K["PKTABLE_QUALIFIER"];$o["ns"]=$K["PKTABLE_OWNER"];$o["table"]=$K["PKTABLE_NAME"];$o["on_update"]=$Ah[$K["UPDATE_RULE"]];$o["on_delete"]=$Ah[$K["DELETE_RULE"]];$o["source"][]=$K["FKCOLUMN_NAME"];$o["target"][]=$K["PKCOLUMN_NAME"];}return$J;}function
backward_keys($R){$G="SELECT fk.name AS constraint_name,
OBJECT_SCHEMA_NAME(fkc.parent_object_id) AS table_schema,
OBJECT_NAME(fkc.parent_object_id) AS table_name,
COL_NAME(fkc.parent_object_id, fkc.parent_column_id) AS column_name,
COL_NAME(fkc.referenced_object_id, fkc.referenced_column_id) AS referenced_column_name
FROM sys.foreign_key_columns fkc
JOIN sys.foreign_keys fk ON fkc.constraint_object_id = fk.object_id
WHERE OBJECT_SCHEMA_NAME(fkc.referenced_object_id) = ".q($_GET["ns"])."
AND OBJECT_NAME(fkc.referenced_object_id) = ".q($R)."
ORDER BY table_schema, table_name";return
get_rows($G,null,"");}function
truncate_tables($T){return
apply_queries("TRUNCATE TABLE",$T);}function
drop_views($Bm){return
queries("DROP VIEW ".implode(", ",array_map('AdminNeo\table',$Bm)));}function
drop_tables($T){return
queries("DROP TABLE ".implode(", ",array_map('AdminNeo\table',$T)));}function
move_tables($T,$Bm,$pl){return
apply_queries("ALTER SCHEMA ".idf_escape($pl)." TRANSFER",array_merge($T,$Bm));}function
trigger($_){if($_=="")return[];$L=get_rows("SELECT s.name [Trigger],
CASE WHEN OBJECTPROPERTY(s.id, 'ExecIsInsertTrigger') = 1 THEN 'INSERT' WHEN OBJECTPROPERTY(s.id, 'ExecIsUpdateTrigger') = 1 THEN 'UPDATE' WHEN OBJECTPROPERTY(s.id, 'ExecIsDeleteTrigger') = 1 THEN 'DELETE' END [Event],
CASE WHEN OBJECTPROPERTY(s.id, 'ExecIsInsteadOfTrigger') = 1 THEN 'INSTEAD OF' ELSE 'AFTER' END [Timing],
c.text
FROM sysobjects s
JOIN syscomments c ON s.id = c.id
WHERE s.xtype = 'TR' AND s.name = ".q($_));$J=reset($L);if($J)$J["Statement"]=preg_replace('~^.+\s+AS\s+~isU','',$J["text"]);return$J;}function
triggers($R){$J=[];foreach(get_rows("SELECT sys1.name,
CASE WHEN OBJECTPROPERTY(sys1.id, 'ExecIsInsertTrigger') = 1 THEN 'INSERT' WHEN OBJECTPROPERTY(sys1.id, 'ExecIsUpdateTrigger') = 1 THEN 'UPDATE' WHEN OBJECTPROPERTY(sys1.id, 'ExecIsDeleteTrigger') = 1 THEN 'DELETE' END [Event],
CASE WHEN OBJECTPROPERTY(sys1.id, 'ExecIsInsteadOfTrigger') = 1 THEN 'INSTEAD OF' ELSE 'AFTER' END [Timing]
FROM sysobjects sys1
JOIN sysobjects sys2 ON sys1.parent_obj = sys2.id
WHERE sys1.xtype = 'TR' AND sys2.name = ".q($R))as$K)$J[$K["name"]]=[$K["Timing"],$K["Event"]];return$J;}function
trigger_options(){return["Timing"=>["AFTER","INSTEAD OF"],"Event"=>["INSERT","UPDATE","DELETE"],"Type"=>["AS"],];}function
schemas(){return
get_vals("SELECT name FROM sys.schemas");}function
get_schema(){if($_GET["ns"]!="")return$_GET["ns"];return
Connection::get()->getValue("SELECT SCHEMA_NAME()");}function
set_schema($Gj,$e=null){$_GET["ns"]=$Gj;return
true;}function
create_sql($R,$Ta,$Nk){if(is_view(table_status($R))){$_m=view($R);return"CREATE VIEW ".table($R)." AS $_m[select]";}$l=[];$F=false;foreach(fields($R)as$_=>$k){$X=process_field($k,$k);if($X[6])$F=true;$l[]=implode("",$X);}foreach(indexes($R)as$_=>$s){if(!$F||$s["type"]!="PRIMARY"){$d=[];foreach($s["columns"]as$u=>$X)$d[]=idf_escape($X).($s["descs"][$u]?" DESC":"");$_=idf_escape($_);$l[]=($s["type"]=="INDEX"?"INDEX $_":"CONSTRAINT $_ ".($s["type"]=="UNIQUE"?"UNIQUE":"PRIMARY KEY"))." (".implode(", ",$d).")";}}foreach(Driver::get()->checkConstraints($R)as$_=>$vb)$l[]="CONSTRAINT ".idf_escape($_)." CHECK ($vb)";return"CREATE TABLE ".table($R)." (\n\t".implode(",\n\t",$l)."\n)";}function
foreign_keys_sql($R){$l=[];foreach(foreign_keys($R)as$oe)$l[]=ltrim(format_foreign_key($oe));return($l?"ALTER TABLE ".table($R)." ADD\n\t".implode(",\n\t",$l).";\n\n":"");}function
truncate_sql($R){return"TRUNCATE TABLE ".table($R);}function
use_sql($Bc){return"USE ".idf_escape($Bc);}function
trigger_sql($R){$J="";foreach(triggers($R)as$_=>$Ql)$J
.=create_trigger(" ON ".table($R),trigger($_)).";";return$J;}function
convert_field($k){}function
unconvert_field(array$k,$J){return$J;}function
support($Ud){return
preg_match('~^(check|comment|columns|database|drop_col|dump|indexes|descidx|scheme|sql|table|trigger|view|view_trigger)$~',$Ud);}}Drivers::add("sqlite","SQLite",["SQLite3","PDO_SQLite"]);if(isset($_GET["sqlite"])){define("AdminNeo\DRIVER","sqlite");define("AdminNeo\DIALECT","sqlite");if(class_exists("SQLite3")&&$_GET["ext"]!="pdo"){define("AdminNeo\DRIVER_EXTENSION","SQLite3");abstract
class
SqLiteConnectionBase
extends
Connection{private$sqlite;function
open($O,$V,$E){$this->sqlite=new
SQLite3($O);$this->version=$this->sqlite->version()["versionString"];return
true;}function
query($G,$am=false){$I=@$this->sqlite->query($G);$this->error="";if(!$I){$this->errno=$this->sqlite->lastErrorCode();$this->error=$this->sqlite->lastErrorMsg();return
false;}elseif($I->numColumns())return
new
SqLiteResult($I);$this->affectedRows=$this->sqlite->changes();return
true;}function
quote($Q){if(is_utf8($Q))return"'".$this->sqlite->escapeString($Q)."'";else
return"x'".first(unpack('H*',$Q))."'";}}class
SqLiteResult
extends
Result{private$resource;private$offset=0;function
__construct(SQLite3Result$pj){parent::__construct(0);$this->resource=$pj;}function
__destruct(){return$this->resource->finalize();}function
fetchAssoc(){return$this->resource->fetchArray(SQLITE3_ASSOC);}function
fetchRow(){return$this->resource->fetchArray(SQLITE3_NUM);}function
fetchField(){$c=$this->offset++;$U=$this->resource->columnType($c);if($U===false)return
false;return(object)["name"=>$this->resource->columnName($c),"type"=>($U==SQLITE3_TEXT?15:0),"charsetnr"=>($U==SQLITE3_BLOB?63:0),];}}}elseif(extension_loaded("pdo_sqlite")){define("AdminNeo\DRIVER_EXTENSION","PDO_SQLite");abstract
class
SqLiteConnectionBase
extends
PdoConnection{function
open($O,$V,$E){return$this->dsn(DRIVER.":$O","","");}}}if(class_exists('AdminNeo\SqLiteConnectionBase')){class
SqLiteConnection
extends
SqLiteConnectionBase{protected
function
__construct(){parent::__construct();$this->open(":memory:","","");}function
open($O,$V,$E){if(!parent::open($O,$V,$E))return
false;$this->query("PRAGMA foreign_keys = 1");$this->query("PRAGMA busy_timeout = 500");return
true;}function
close(){$this->open(":memory:","","");}function
selectDatabase($_){if(is_readable($_)&&$this->query("ATTACH ".$this->quote(preg_match("~(^[/\\\\]|:)~",$_)?$_:dirname($_SERVER["SCRIPT_FILENAME"])."/$_")." AS a"))return
self::open($_,"","");return
false;}}}class
SqliteDriver
extends
Driver{protected
function
__construct(Connection$e,$xa){parent::__construct($e,$xa);$this->types=[["integer"=>0,"real"=>0,"numeric"=>0,"text"=>0,"blob"=>0,]];if($e->isMinVersion("3.31"))$this->generated=["STORED","VIRTUAL"];$this->operators=["=","<",">","<=",">=","!=","LIKE","LIKE %%","NOT LIKE","IN","NOT IN","IS NULL","IS NOT NULL","SQL",];$this->likeOperator="LIKE %%";$this->functions=["length","lower","upper","round","hex","unixepoch",];$this->grouping=["sum","min","max","avg","count","count distinct","group_concat",];$this->editFunctions=[[],["integer|real|numeric"=>"+/-","text"=>"||",]];}function
getStructuredTypes(){return
parent::getStructuredTypes()[0];}function
insertUpdate($R,array$bj,array$F){$vm=[];foreach($bj
as$H)$vm[]="(".implode(", ",$H).")";return
queries("REPLACE INTO ".table($R)." (".implode(", ",array_keys(reset($bj))).") VALUES\n".implode(",\n",$vm));}function
tableHelp($_,$Cf=false){if($_=="sqlite_sequence")return"fileformat2.html#seqtab";if($_=="sqlite_master")return"fileformat2.html#$_";return
null;}function
checkConstraints($R){preg_match_all('~ CHECK *(\( *(((?>[^()]*[^() ])|(?1))*) *\))~',$this->connection->getValue("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = ".q($R)),$z);return
array_combine($z[2],$z[2]);}function
getAllFields(){$Fa=[];foreach(tables_list()as$R=>$U){foreach(fields($R)as$k)$Fa[$R][]=$k;}return$Fa;}}function
create_driver(Connection$e){return
SqliteDriver::create($e,Admin::get());}function
idf_escape($r){return'"'.str_replace('"','""',$r).'"';}function
table($r){return
idf_escape($r);}function
connect($F=false,&$j=null){$e=$F?SqLiteConnection::create():SqLiteConnection::createSecondary();$E=Admin::get()->getCredentials()[2];if($E!=""){$I=Admin::get()->verifyDefaultPassword($E);if($I!==true){$j=$I;return
null;}}return$e;}function
get_databases(){return[];}function
limit($G,$Z,$w,$A=0,$N=" "){return" $G$Z".($w!==null?$N."LIMIT $w".($A?" OFFSET $A":""):"");}function
limit1($R,$G,$Z,$N="\n"){return(preg_match('~^INTO~',$G)||Connection::get()->getValue("SELECT sqlite_compileoption_used('ENABLE_UPDATE_DELETE_LIMIT')")?limit($G,$Z,1,0,$N):" $G WHERE rowid = (SELECT rowid FROM ".table($R).$Z.$N."LIMIT 1)");}function
db_collation($h,$Kb){return
Connection::get()->getValue("PRAGMA encoding");}function
logged_user(){return
get_current_user();}function
tables_list(){return
get_key_vals("SELECT name, type FROM sqlite_master WHERE type IN ('table', 'view') ORDER BY (name = 'sqlite_sequence'), name");}function
count_tables($g){return[];}function
table_status($_=""){$J=[];foreach(get_rows("SELECT name AS Name, type AS Engine, 'rowid' AS Oid, '' AS Auto_increment FROM sqlite_master WHERE type IN ('table', 'view') ".($_!=""?"AND name = ".q($_):"ORDER BY name"))as$K){$K["Rows"]=Connection::get()->getValue("SELECT COUNT(*) FROM ".idf_escape($K["Name"]));$J[$K["Name"]]=$K;}foreach(get_rows("SELECT * FROM sqlite_sequence",null,"")as$K)$J[$K["name"]]["Auto_increment"]=$K["seq"];return($_!=""?$J[$_]:$J);}function
is_view($S){return$S["Engine"]=="view";}function
fk_support($S){return!Connection::get()->getValue("SELECT sqlite_compileoption_used('OMIT_FOREIGN_KEY')");}function
fields($R){$J=[];$F="";foreach(get_rows("PRAGMA table_".(Connection::get()->isMinVersion("3.31")?"x":"")."info(".table($R).")")as$K){$_=$K["name"];$U=strtolower($K["type"]);$i=$K["dflt_value"];$J[$_]=["field"=>$_,"type"=>(preg_match('~int~i',$U)?"integer":(preg_match('~char|clob|text~i',$U)?"text":(preg_match('~blob~i',$U)?"blob":(preg_match('~real|floa|doub~i',$U)?"real":"numeric")))),"full_type"=>$U,"default"=>(preg_match("~^'(.*)'$~",$i,$y)?str_replace("''","'",$y[1]):($i=="NULL"?null:$i)),"null"=>!$K["notnull"],"privileges"=>["select"=>1,"insert"=>1,"update"=>1,"where"=>1,"order"=>1],"primary"=>$K["pk"],];if($K["pk"]){if($F!="")$J[$F]["auto_increment"]=false;elseif(preg_match('~^integer$~i',$U))$J[$_]["auto_increment"]=true;$F=$_;}}$zk=Connection::get()->getValue("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = ".q($R));$r='(("[^"]*+")+|[a-z0-9_]+)';preg_match_all('~'.$r.'\s+text\s+COLLATE\s+(\'[^\']+\'|\S+)~i',$zk,$z,PREG_SET_ORDER);foreach($z
as$y){$_=str_replace('""','"',preg_replace('~^"|"$~','',$y[1]));if($J[$_])$J[$_]["collation"]=trim($y[3],"'");}preg_match_all('~'.$r.'\s.*GENERATED ALWAYS AS \((.+)\) (STORED|VIRTUAL)~i',$zk,$z,PREG_SET_ORDER);foreach($z
as$y){$_=str_replace('""','"',preg_replace('~^"|"$~','',$y[1]));$J[$_]["default"]=$y[3];$J[$_]["generated"]=strtoupper($y[4]);}return$J;}function
indexes($R,$e=null){if(!is_object($e))$e=Connection::get();$J=[];$zk=$e->getValue("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = ".q($R));if(preg_match('~\bPRIMARY\s+KEY\s*\((([^)"]+|"[^"]*"|`[^`]*`)++)~i',$zk,$y)){$J[""]=["type"=>"PRIMARY","columns"=>[],"lengths"=>[],"descs"=>[]];preg_match_all('~((("[^"]*+")+|(?:`[^`]*+`)+)|(\S+))(\s+(ASC|DESC))?(,\s*|$)~i',$y[1],$z,PREG_SET_ORDER);foreach($z
as$y){$J[""]["columns"][]=idf_unescape($y[2]).$y[4];$J[""]["descs"][]=(preg_match('~DESC~i',$y[5])?'1':null);}}if(!$J){foreach(fields($R)as$_=>$k){if($k["primary"])$J[""]=["type"=>"PRIMARY","columns"=>[$_],"lengths"=>[],"descs"=>[null]];}}$Ck=get_key_vals("SELECT name, sql FROM sqlite_master WHERE type = 'index' AND tbl_name = ".q($R),$e);foreach(get_rows("PRAGMA index_list(".table($R).")",$e)as$K){$_=$K["name"];$s=["type"=>($K["unique"]?"UNIQUE":"INDEX")];$s["lengths"]=[];$s["descs"]=[];foreach(get_rows("PRAGMA index_info(".idf_escape($_).")",$e)as$Aj){$s["columns"][]=$Aj["name"];$s["descs"][]=null;}if(preg_match('~^CREATE( UNIQUE)? INDEX '.preg_quote(idf_escape($_).' ON '.idf_escape($R),'~').' \((.*)\)$~i',$Ck[$_],$jj)){preg_match_all('/("[^"]*+")+( DESC)?/',$jj[2],$z);foreach($z[2]as$u=>$X){if($X)$s["descs"][$u]='1';}}if(!$J[""]||$s["type"]!="UNIQUE"||$s["columns"]!=$J[""]["columns"]||$s["descs"]!=$J[""]["descs"]||!preg_match("~^sqlite_~",$_))$J[$_]=$s;}return$J;}function
foreign_keys($R){$J=[];foreach(get_rows("PRAGMA foreign_key_list(".table($R).")")as$K){$o=&$J[$K["id"]];if(!$o)$o=$K;$o["source"][]=$K["from"];$o["target"][]=$K["to"];}return$J;}function
backward_keys($R){return[];}function
view($_){return["select"=>preg_replace('~^(?:[^`"[]+|`[^`]*`|"[^"]*")* AS\s+~iU','',Connection::get()->getValue("SELECT sql FROM sqlite_master WHERE type = 'view' AND name = ".q($_)))];}function
collations(){return(isset($_GET["create"])?get_vals("PRAGMA collation_list",1):[]);}function
information_schema($h){return
false;}function
error(){return
h(Connection::get()->getError());}function
check_sqlite_name($_){$Pd="db|sdb|sqlite";if(!preg_match("~^[^\\0]*\\.($Pd)\$~",$_)){Connection::get()->setError(lang(121,str_replace("|",", ",$Pd)));return
false;}return
true;}function
create_database($h,$Jb){if(file_exists($h)){Connection::get()->setError(lang(122));return
false;}if(!check_sqlite_name($h))return
false;try{$x=SqLiteConnection::createSecondary();$x->open($h,"","");}catch(Exception$Cd){Connection::get()->setError($Cd->getMessage());return
false;}$x->query('PRAGMA encoding = "UTF-8"');$x->query('CREATE TABLE adminneo (i)');$x->query('DROP TABLE adminneo');return
true;}function
drop_databases($g){Connection::get()->close();foreach($g
as$h){if(!@unlink($h)){Connection::get()->setError(lang(122));return
false;}}return
true;}function
rename_database($_,$Jb){if(!check_sqlite_name($_))return
false;Connection::get()->close();Connection::get()->setError(lang(122));return@rename(DB,$_);}function
auto_increment(){return" PRIMARY KEY AUTOINCREMENT";}function
alter_table($R,$_,$l,$oe,$Tb,$ud,$Jb,$Ta,$ki){$nm=($R==""||$oe);foreach($l
as$k){if($k[0]!=""||!$k[1]||$k[2]){$nm=true;break;}}$Ja=[];$Wh=[];foreach($l
as$k){if(!$k[1])continue;if($k[0]!="")$Wh[$k[0]]=$k[1][0];$Ja[]=($nm?$k[1]:"ADD ".implode($k[1]));}if(!$nm){foreach($Ja
as$X){if(!queries("ALTER TABLE ".table($R)." $X"))return
false;}if($R!=$_&&!queries("ALTER TABLE ".table($R)." RENAME TO ".table($_)))return
false;}elseif(!recreate_table($R,$_,$Ja,$Wh,$oe,$Ta))return
false;if($Ta){queries("BEGIN");queries("UPDATE sqlite_sequence SET seq = $Ta WHERE name = ".q($_));if(!Connection::get()->getAffectedRows())queries("INSERT INTO sqlite_sequence (name, seq) VALUES (".q($_).", $Ta)");queries("COMMIT");}return
true;}function
recreate_table($R,$_,$l,$Wh,$oe,$Ta=0,$t=[],$cd="",$va=""){if($R!=""){if(!$l){foreach(fields($R)as$u=>$k){if($t)$k["auto_increment"]=0;$l[]=process_field($k,$k);$Wh[$u]=idf_escape($u);}}$Ii=false;foreach($l
as$k){if($k[6])$Ii=true;}$ed=[];foreach($t
as$u=>$X){if($X[2]=="DROP"){$ed[$X[1]]=true;unset($t[$u]);}}foreach(indexes($R)as$Sf=>$s){$d=[];foreach($s["columns"]as$u=>$c){if(!isset($Wh[$c]))continue
2;$d[]=$Wh[$c].($s["descs"][$u]?" DESC":"");}if(!$ed[$Sf]){if($s["type"]!="PRIMARY"||!$Ii){$Sf=preg_replace('~^sqlite_~',"",$Sf);$t[]=[$s["type"],$Sf,$d];}}}foreach($t
as$u=>$X){if($X[0]=="PRIMARY"){unset($t[$u]);$oe[]="  PRIMARY KEY (".implode(", ",$X[2]).")";}}foreach(foreign_keys($R)as$Sf=>$o){foreach($o["source"]as$u=>$c){if(!$Wh[$c])continue
2;$o["source"][$u]=idf_unescape($Wh[$c]);}if(!isset($oe[" $Sf"]))$oe[]=" ".format_foreign_key($o);}queries("BEGIN");}foreach($l
as$u=>$k){if(preg_match('~GENERATED~',$k[3]))unset($Wh[array_search($k[0],$Wh)]);$l[$u]="  ".implode($k);}$l=array_merge($l,array_filter($oe));foreach(Driver::get()->checkConstraints($R)as$vb){if($vb!=$cd)$l[]="  CHECK ($vb)";}if($va)$l[]="  CHECK ($va)";$rl=($R==$_?"adminneo_$_":$_);if(!queries("CREATE TABLE ".table($rl)." (\n".implode(",\n",$l)."\n)"))return
false;if($R!=""){if($Wh&&!queries("INSERT INTO ".table($rl)." (".implode(", ",$Wh).") SELECT ".implode(", ",array_map('AdminNeo\idf_escape',array_keys($Wh)))." FROM ".table($R)))return
false;$Tl=[];foreach(triggers($R)as$Rl=>$Bl){$Ql=trigger($Rl);$Tl[]="CREATE TRIGGER ".idf_escape($Rl)." ".implode(" ",$Bl)." ON ".table($_)."\n$Ql[Statement]";}$Ta=$Ta?0:Connection::get()->getValue("SELECT seq FROM sqlite_sequence WHERE name = ".q($R));if(!queries("DROP TABLE ".table($R))||($R==$_&&!queries("ALTER TABLE ".table($rl)." RENAME TO ".table($_)))||!alter_indexes($_,$t))return
false;if($Ta)queries("UPDATE sqlite_sequence SET seq = $Ta WHERE name = ".q($_));foreach($Tl
as$Ql){if(!queries($Ql))return
false;}queries("COMMIT");}return
true;}function
index_sql($R,$U,$_,$d){return"CREATE $U ".($U!="INDEX"?"INDEX ":"").idf_escape($_!=""?$_:uniqid($R."_"))." ON ".table($R)." $d";}function
alter_indexes($R,$b){foreach($b
as$s){if($s[0]=="PRIMARY"||(preg_match('~^sqlite_~',$s[1])))return
recreate_table($R,$R,[],[],[],0,$b);}foreach(array_reverse($b)as$X){if(!queries($X[2]=="DROP"?"DROP INDEX ".idf_escape($X[1]):index_sql($R,$X[0],$X[1],"(".implode(", ",$X[2]).")")))return
false;}return
true;}function
truncate_tables($T){return
apply_queries("DELETE FROM",$T);}function
drop_views($Bm){return
apply_queries("DROP VIEW",$Bm);}function
drop_tables($T){return
apply_queries("DROP TABLE",$T);}function
move_tables($T,$Bm,$pl){return
false;}function
trigger($_){if($_=="")return["Statement"=>"BEGIN\n\t;\nEND"];$r='(?:[^`"\s]+|`[^`]*`|"[^"]*")+';$Sl=trigger_options();preg_match("~^CREATE\\s+TRIGGER\\s*$r\\s*(".implode("|",$Sl["Timing"]).")\\s+([a-z]+)(?:\\s+OF\\s+($r))?\\s+ON\\s*$r\\s*(?:FOR\\s+EACH\\s+ROW\\s)?(.*)~is",Connection::get()->getValue("SELECT sql FROM sqlite_master WHERE type = 'trigger' AND name = ".q($_)),$y);$sh=$y[3];return["Timing"=>strtoupper($y[1]),"Event"=>strtoupper($y[2]).($sh?" OF":""),"Of"=>idf_unescape($sh),"Trigger"=>$_,"Statement"=>$y[4],];}function
triggers($R){$J=[];$Sl=trigger_options();foreach(get_rows("SELECT * FROM sqlite_master WHERE type = 'trigger' AND tbl_name = ".q($R))as$K){preg_match('~^CREATE\s+TRIGGER\s*(?:[^`"\s]+|`[^`]*`|"[^"]*")+\s*('.implode("|",$Sl["Timing"]).')\s*(.*?)\s+ON\b~i',$K["sql"],$y);$J[$K["name"]]=[$y[1],$y[2]];}return$J;}function
trigger_options(){return["Timing"=>["BEFORE","AFTER","INSTEAD OF"],"Event"=>["INSERT","UPDATE","UPDATE OF","DELETE"],"Type"=>["FOR EACH ROW"],];}function
begin(){return
queries("BEGIN");}function
last_id($I){return
Connection::get()->getValue("SELECT LAST_INSERT_ROWID()");}function
explain(Connection$e,$G){return$e->query("EXPLAIN QUERY PLAN $G");}function
found_rows($S,$Z){}function
types(){return[];}function
create_sql($R,$Ta,$Nk){$J=Connection::get()->getValue("SELECT sql FROM sqlite_master WHERE type IN ('table', 'view') AND name = ".q($R));foreach(indexes($R)as$_=>$s){if($_==''||strpos($_,"sqlite_")===0)continue;$J
.=";\n\n".index_sql($R,$s['type'],$_,"(".implode(", ",array_map('AdminNeo\idf_escape',$s['columns'])).")");}return$J;}function
truncate_sql($R){return"DELETE FROM ".table($R);}function
use_sql($Bc){}function
trigger_sql($R){return
implode(get_vals("SELECT sql || ';;\n' FROM sqlite_master WHERE type = 'trigger' AND tbl_name = ".q($R)));}function
show_variables(){$J=[];foreach(get_rows("PRAGMA pragma_list")as$K){$_=$K["name"];if($_!="pragma_list"&&$_!="compile_options"){$J[$_]=[$_,''];foreach(get_rows("PRAGMA $_")as$Bj)$J[$_][1].=implode(", ",$Bj)."\n";}}return$J;}function
show_status(){$J=[];foreach(get_vals("PRAGMA compile_options")as$Ih)$J[]=explode("=",$Ih,2);return$J;}function
convert_field($k){}function
unconvert_field(array$k,$J){return$J;}function
support($Ud){return
preg_match('~^(check|columns|database|drop_col|dump|indexes|descidx|move_col|sql|status|table|trigger|variables|view|view_trigger)$~',$Ud);}}Drivers::add("oracle","Oracle (beta)",["OCI8","PDO_OCI"]);if(isset($_GET["oracle"])){define("AdminNeo\DRIVER","oracle");define("AdminNeo\DIALECT","oracle");if(extension_loaded("oci8")&&$_GET["ext"]!="pdo"){define("AdminNeo\DRIVER_EXTENSION","oci8");class
OracleConnection
extends
Connection{private$connection;private$dbName=null;function
open($O,$V,$E){$this->connection=@oci_new_connect($V,$E,$O,"AL32UTF8");if($this->connection){$this->version=oci_server_version($this->connection);return
true;}$j=oci_error();$this->error=$j["message"];return
false;}function
quote($Q){return"'".str_replace("'","''",$Q)."'";}function
selectDatabase($_){$this->dbName=$_;return
true;}function
getAndClearDbName(){$_=$this->dbName?:DB;$this->dbName=null;return$_;}function
query($G,$am=false){$I=oci_parse($this->connection,$G);$this->error="";if(!$I){$j=oci_error($this->connection);$this->errno=$j["code"];$this->error=$j["message"];return
false;}set_error_handler(function($yd,$j){if(ini_bool("html_errors"))$j=html_entity_decode(strip_tags($j));$j=preg_replace('~^[^:]*: ~','',$j);$this->error=$j;});$J=@oci_execute($I);restore_error_handler();if($J){if(oci_num_fields($I))return
new
OracleResult($I);$this->affectedRows=oci_num_rows($I);oci_free_statement($I);}return$J;}function
getValue($G,$Vd=0){$I=$this->query($G);return
is_object($I)?$I->fetchValue($Vd):false;}}class
OracleResult
extends
Result{private$resource;private$offset=1;function
__construct($I){parent::__construct(0);$this->resource=$I;}function
__destruct(){oci_free_statement($this->resource);}function
fetchAssoc(){return$this->convertRow(oci_fetch_assoc($this->resource));}function
fetchRow(){return$this->convertRow(oci_fetch_row($this->resource));}function
fetchValue($Vd){return
oci_fetch($this->resource)?oci_result($this->resource,$Vd+1):false;}private
function
convertRow($K){if(is_array($K)){foreach($K
as$u=>$X){if(is_a($X,'OCI-Lob'))$K[$u]=$X->load();}}return$K;}function
fetchField(){$c=$this->offset++;$_=oci_field_name($this->resource,$c);if($_===false)return
false;$U=oci_field_type($this->resource,$c);if($U===false)return
false;return(object)['name'=>$_,'type'=>$U,'charsetnr'=>(preg_match("~raw|blob|bfile~",$U)?63:0),];}}}elseif(extension_loaded("pdo_oci")){define("AdminNeo\DRIVER_EXTENSION","PDO_OCI");class
OracleConnection
extends
PdoConnection{private$dbName=null;function
open($O,$V,$E){return$this->dsn("oci:dbname=//$O;charset=AL32UTF8",$V,$E);}function
selectDatabase($_){$this->dbName=$_;return
true;}function
getAndClearDbName(){$_=$this->dbName?:DB;$this->dbName=null;return$_;}}}class
OracleDriver
extends
Driver{protected
function
__construct(Connection$e,$xa){parent::__construct($e,$xa);$this->types=[lang(114)=>["number"=>38,"binary_float"=>12,"binary_double"=>21,],lang(115)=>["date"=>10,"timestamp"=>29,"interval year"=>12,"interval day"=>28,],lang(116)=>["char"=>2000,"varchar2"=>4000,"nchar"=>2000,"nvarchar2"=>4000,"clob"=>4294967295,"nclob"=>4294967295,],lang(118)=>["raw"=>2000,"long raw"=>2147483648,"blob"=>4294967295,"bfile"=>4294967296,],];$this->operators=["=","<",">","<=",">=","!=","LIKE","LIKE %%","NOT LIKE","IN","NOT IN","IS NULL","IS NOT NULL","SQL",];$this->likeOperator="LIKE %%";$this->functions=["length","lower","upper","round",];$this->grouping=["sum","min","max","avg","count","count distinct",];$this->editFunctions=[["date"=>"current_date","timestamp"=>"current_timestamp",],["number|float|double"=>"+/-","date|timestamp"=>"+ interval/- interval","char|clob"=>"||",]];}function
begin(){return
true;}function
insertUpdate($R,array$bj,array$F){foreach($bj
as$H){$im=[];$Z=[];foreach($H
as$u=>$X){$im[]="$u = $X";if(isset($F[idf_unescape($u)]))$Z[]="$u = $X";}if(!(($Z&&queries("UPDATE ".table($R)." SET ".implode(", ",$im)." WHERE ".implode(" AND ",$Z))&&Connection::get()->getAffectedRows())||queries("INSERT INTO ".table($R)." (".implode(", ",array_keys($H)).") VALUES (".implode(", ",$H).")")))return
false;}return
true;}function
hasCStyleEscapes(){return
true;}}function
create_driver(Connection$e){return
OracleDriver::create($e,Admin::get());}function
is_server_host_valid($df){return(bool)preg_match('~^[^/]+(/([^/:]+)?(:[^/:]+)?(/[^/:]+)?)?$~',$df);}function
idf_escape($r){return'"'.str_replace('"','""',$r).'"';}function
table($r){return
idf_escape($r);}function
connect($F=false,&$j=null){$e=$F?OracleConnection::create():OracleConnection::createSecondary();$uc=Admin::get()->getCredentials();if(!$e->open($uc[0],$uc[1],$uc[2])){$j=$e->getError();return
null;}return$e;}function
get_databases(){return
get_vals("SELECT DISTINCT tablespace_name FROM (
SELECT tablespace_name FROM user_tablespaces
UNION SELECT tablespace_name FROM all_tables WHERE tablespace_name IS NOT NULL
)
ORDER BY 1");}function
limit($G,$Z,$w,$A=0,$N=" "){return($A?" * FROM (SELECT t.*, rownum AS rnum FROM (SELECT $G$Z) t WHERE rownum <= ".($w+$A).") WHERE rnum > $A":($w!==null?" * FROM (SELECT $G$Z) WHERE rownum <= ".($w+$A):" $G$Z"));}function
limit1($R,$G,$Z,$N="\n"){return" $G$Z";}function
db_collation($h,$Kb){return
Connection::get()->getValue("SELECT value FROM nls_database_parameters WHERE parameter = 'NLS_CHARACTERSET'");}function
logged_user(){return
Connection::get()->getValue("SELECT USER FROM DUAL");}function
where_owner($Fi,$ai="owner"){if(!$_GET["ns"])return'';return"$Fi$ai = sys_context('USERENV', 'CURRENT_SCHEMA')";}function
views_table($d){$ai=where_owner('');return"(SELECT $d FROM all_views WHERE ".($ai?:"rownum < 0").")";}function
tables_list(){$_m=views_table("view_name");$ai=where_owner(" AND ");return
get_key_vals("SELECT table_name, 'table' FROM all_tables WHERE tablespace_name = ".q(DB)."$ai
UNION SELECT view_name, 'view' FROM $_m
ORDER BY 1");}function
count_tables($g){$J=[];foreach($g
as$h)$J[$h]=Connection::get()->getValue("SELECT COUNT(*) FROM all_tables WHERE tablespace_name = ".q($h));return$J;}function
table_status($_=""){$J=[];$Jj=q($_);$h=Connection::get()->getAndClearDbName();$_m=views_table("view_name");$ai=where_owner(" AND ");foreach(get_rows('SELECT table_name "Name", \'table\' "Engine", avg_row_len * num_rows "Data_length", num_rows "Rows" FROM all_tables WHERE tablespace_name = '.q($h).$ai.($_!=""?" AND table_name = $Jj":"")."
UNION SELECT view_name, 'view', 0, 0 FROM $_m".($_!=""?" WHERE view_name = $Jj":"")."
ORDER BY 1")as$K){if($_!="")return$K;$J[$K["Name"]]=$K;}return$J;}function
is_view($S){return$S["Engine"]=="view";}function
fk_support($S){return
true;}function
fields($R){$J=[];$ai=where_owner(" AND ");foreach(get_rows("SELECT * FROM all_tab_columns WHERE table_name = ".q($R)."$ai ORDER BY column_id")as$K){$U=$K["DATA_TYPE"];$v="$K[DATA_PRECISION],$K[DATA_SCALE]";if($v==",")$v=$K["CHAR_COL_DECL_LENGTH"];$J[$K["COLUMN_NAME"]]=["field"=>$K["COLUMN_NAME"],"full_type"=>$U.($v?"($v)":""),"type"=>strtolower($U),"length"=>$v,"default"=>$K["DATA_DEFAULT"],"null"=>($K["NULLABLE"]=="Y"),"privileges"=>["insert"=>1,"select"=>1,"update"=>1,"where"=>1,"order"=>1],];}return$J;}function
indexes($R,$e=null){$J=[];$ai=where_owner(" AND ","aic.table_owner");foreach(get_rows("SELECT aic.*, ac.constraint_type, atc.data_default
FROM all_ind_columns aic
LEFT JOIN all_constraints ac ON aic.index_name = ac.constraint_name AND aic.table_name = ac.table_name AND aic.index_owner = ac.owner
LEFT JOIN all_tab_cols atc ON aic.column_name = atc.column_name AND aic.table_name = atc.table_name AND aic.index_owner = atc.owner
WHERE aic.table_name = ".q($R)."$ai
ORDER BY ac.constraint_type, aic.column_position",$e)as$K){$of=$K["INDEX_NAME"];$Pb=$K["DATA_DEFAULT"];$Pb=($Pb?trim($Pb,'"'):$K["COLUMN_NAME"]);$J[$of]["type"]=($K["CONSTRAINT_TYPE"]=="P"?"PRIMARY":($K["CONSTRAINT_TYPE"]=="U"?"UNIQUE":"INDEX"));$J[$of]["columns"][]=$Pb;$J[$of]["lengths"][]=($K["CHAR_LENGTH"]&&$K["CHAR_LENGTH"]!=$K["COLUMN_LENGTH"]?$K["CHAR_LENGTH"]:null);$J[$of]["descs"][]=($K["DESCEND"]&&$K["DESCEND"]=="DESC"?'1':null);}return$J;}function
view($_){$_m=views_table("view_name, text");$L=get_rows('SELECT text "select" FROM '.$_m.' WHERE view_name = '.q($_));return
reset($L);}function
collations(){return[];}function
information_schema($h){return
get_schema()=="INFORMATION_SCHEMA";}function
error(){return
h(Connection::get()->getError());}function
explain(Connection$e,$G){$e->query("EXPLAIN PLAN FOR $G");return$e->query("SELECT * FROM plan_table");}function
found_rows($S,$Z){}function
auto_increment(){return"";}function
alter_table($R,$_,$l,$oe,$Tb,$ud,$Jb,$Ta,$ki){$b=$bd=[];$Sh=($R?fields($R):[]);foreach($l
as$k){$X=$k[1];if($X&&$k[0]!=""&&idf_escape($k[0])!=$X[0])queries("ALTER TABLE ".table($R)." RENAME COLUMN ".idf_escape($k[0])." TO $X[0]");$Rh=$Sh[$k[0]];if($X&&$Rh){$vh=process_field($Rh,$Rh);if($X[2]==$vh[2])$X[2]="";}if($X)$b[]=($R!=""?($k[0]!=""?"MODIFY (":"ADD ("):"  ").implode($X).($R!=""?")":"");else$bd[]=idf_escape($k[0]);}if($R=="")return
queries("CREATE TABLE ".table($_)." (\n".implode(",\n",$b)."\n)");return(!$b||queries("ALTER TABLE ".table($R)."\n".implode("\n",$b)))&&(!$bd||queries("ALTER TABLE ".table($R)." DROP (".implode(", ",$bd).")"))&&($R==$_||queries("ALTER TABLE ".table($R)." RENAME TO ".table($_)));}function
alter_indexes($R,$b){$bd=[];$Ti=[];foreach($b
as$X){if($X[0]!="INDEX"){$X[2]=preg_replace('~ DESC$~','',$X[2]);$rc=($X[2]=="DROP"?"\nDROP CONSTRAINT ".idf_escape($X[1]):"\nADD".($X[1]!=""?" CONSTRAINT ".idf_escape($X[1]):"")." $X[0] ".($X[0]=="PRIMARY"?"KEY ":"")."(".implode(", ",$X[2]).")");array_unshift($Ti,"ALTER TABLE ".table($R).$rc);}elseif($X[2]=="DROP")$bd[]=idf_escape($X[1]);else$Ti[]="CREATE INDEX ".idf_escape($X[1]!=""?$X[1]:uniqid($R."_"))." ON ".table($R)." (".implode(", ",$X[2]).")";}if($bd)array_unshift($Ti,"DROP INDEX ".implode(", ",$bd));foreach($Ti
as$G){if(!queries($G))return
false;}return
true;}function
foreign_keys($R){$J=[];$G="SELECT c_list.CONSTRAINT_NAME as NAME,
c_src.COLUMN_NAME as SRC_COLUMN,
c_dest.OWNER as DEST_DB,
c_dest.TABLE_NAME as DEST_TABLE,
c_dest.COLUMN_NAME as DEST_COLUMN,
c_list.DELETE_RULE as ON_DELETE
FROM ALL_CONSTRAINTS c_list, ALL_CONS_COLUMNS c_src, ALL_CONS_COLUMNS c_dest
WHERE c_list.CONSTRAINT_NAME = c_src.CONSTRAINT_NAME
AND c_list.R_CONSTRAINT_NAME = c_dest.CONSTRAINT_NAME
AND c_list.CONSTRAINT_TYPE = 'R'
AND c_src.TABLE_NAME = ".q($R);foreach(get_rows($G)as$K)$J[$K['NAME']]=["db"=>$K['DEST_DB'],"table"=>$K['DEST_TABLE'],"source"=>[$K['SRC_COLUMN']],"target"=>[$K['DEST_COLUMN']],"on_delete"=>$K['ON_DELETE'],"on_update"=>null,];return$J;}function
backward_keys($R){return[];}function
truncate_tables($T){return
apply_queries("TRUNCATE TABLE",$T);}function
drop_views($Bm){return
apply_queries("DROP VIEW",$Bm);}function
drop_tables($T){return
apply_queries("DROP TABLE",$T);}function
last_id($I){return
0;}function
schemas(){$J=get_vals("SELECT DISTINCT owner FROM dba_segments WHERE owner IN (SELECT username FROM dba_users WHERE default_tablespace NOT IN ('SYSTEM','SYSAUX')) ORDER BY 1");return$J?:get_vals("SELECT DISTINCT owner FROM all_tables WHERE tablespace_name = ".q(DB)." ORDER BY 1");}function
get_schema(){return
Connection::get()->getValue("SELECT sys_context('USERENV', 'SESSION_USER') FROM dual");}function
set_schema($Gj,$e=null){if(!$e)$e=Connection::get();return(bool)$e->query("ALTER SESSION SET CURRENT_SCHEMA = ".idf_escape($Gj));}function
show_variables(){return
get_rows('SELECT name, display_value FROM v$parameter');}function
show_status(){$J=[];$L=get_rows('SELECT * FROM v$instance');foreach(reset($L)as$u=>$X)$J[]=[$u,$X];return$J;}function
process_list(){return
get_rows('SELECT sess.process AS "process", sess.username AS "user", sess.schemaname AS "schema", sess.status AS "status", sess.wait_class AS "wait_class", sess.seconds_in_wait AS "seconds_in_wait", sql.sql_text AS "sql_text", sess.machine AS "machine", sess.port AS "port"
FROM v$session sess LEFT OUTER JOIN v$sql sql
ON sql.sql_id = sess.sql_id
WHERE sess.type = \'USER\'
ORDER BY PROCESS
');}function
convert_field($k){}function
unconvert_field(array$k,$J){return$J;}function
support($Ud){return
preg_match('~^(columns|database|drop_col|indexes|descidx|processlist|scheme|sql|status|table|variables|view)$~',$Ud);}}Drivers::add("mongo","MongoDB (alpha)",["mongodb"]);if(isset($_GET["mongo"])){define("AdminNeo\DRIVER","mongo");define("AdminNeo\DIALECT","mongo");if(class_exists('MongoDB\Driver\Manager')){define("AdminNeo\DRIVER_EXTENSION","MongoDB");class
MongoConnection
extends
Connection{private$manager;private$dbName;function
open($O,$V,$E,$Dc=null,$Ra=null){$this->version=MONGODB_VERSION;$B=[];if($V.$E!=""){$B["username"]=$V;$B["password"]=$E;}if($Dc)$B["db"]=$Dc;if($Ra)$B["authSource"]=$Ra;$this->manager=new
Manager($O,$B);$this->dbName=$Dc?:"default";return(bool)$this->executeCommand(['ping'=>1]);}function
executeCommand(array$Rb,$ya=false){try{return$this->manager->executeCommand($ya?"admin":$this->dbName,new
Command($Rb));}catch(\MongoDB\Driver\Exception\Exception$Ed){$this->error=$Ed->getMessage();return
null;}}function
executeQuery($ch,Query$G,$B=null){try{return$this->manager->executeQuery($ch,$G,$B);}catch(\MongoDB\Driver\Exception\Exception$Ed){$this->error=$Ed->getMessage();return
null;}}function
executeBulkWrite($ch,BulkWrite$lb,$qc){try{$tj=$this->manager->executeBulkWrite($ch,$lb);$this->affectedRows=$tj->$qc();return
true;}catch(Exception$Ed){$this->error=$Ed->getMessage();return
false;}}function
query($G,$am=false){return
false;}function
selectDatabase($_){$this->dbName=$_;return
true;}function
getDbName(){return$this->dbName;}function
quote($Q){return$Q;}}class
MongoResult
extends
Result{private$rows;private$charset;private$offset=0;function
__construct($I){$this->rows=$this->charset=[];foreach($I
as$Hf){$K=[];foreach($Hf
as$u=>$X){if(is_a($X,'MongoDB\BSON\Binary'))$this->charset[$u]=63;$K[$u]=(is_a($X,'MongoDB\BSON\ObjectID')?'MongoDB\BSON\ObjectID("'."$X\")":(is_a($X,'MongoDB\BSON\UTCDatetime')?$X->toDateTime()->format('Y-m-d H:i:s'):(is_a($X,'MongoDB\BSON\Binary')?$X->getData():(is_a($X,'MongoDB\BSON\Regex')?"$X":(is_object($X)||is_array($X)?json_encode($X,256):$X)))));}$this->rows[]=$K;foreach($K
as$u=>$X){if(!isset($this->rows[0][$u]))$this->rows[0][$u]=null;}}parent::__construct(count($this->rows));}function
fetchAssoc(){$K=current($this->rows);if(!$K)return$K;$f=[];foreach($this->rows[0]as$u=>$X)$f[$u]=$K[$u];next($this->rows);return$f;}function
fetchRow(){$f=$this->fetchAssoc();if(!$f)return$f;return
array_values($f);}function
fetchField(){$Tf=array_keys($this->rows[0]);$_=$Tf[$this->offset++];return(object)['name'=>$_,'type'=>15,'charsetnr'=>$this->charset[$_],];}}}class
MongoDriver
extends
Driver{var$primary="_id";protected
function
__construct(Connection$e,$xa){parent::__construct($e,$xa);$this->operators=["=","!=",">","<",">=","<=","regex","(f)=","(f)!=","(f)>","(f)<","(f)>=","(f)<=","(date)=","(date)!=","(date)>","(date)<","(date)>=","(date)<=",];$this->likeOperator="LIKE %%";$this->regexpOperator="regex";$this->editFunctions=[["json"]];$this->systemDatabases=["admin","config","local"];}function
select($R,array$M,array$Z,array$He,array$Lh=[],$w=1,$C=0,$Ji=false){$M=($M==["*"]?[]:array_fill_keys($M,1));if(count($M)&&!isset($M['_id']))$M['_id']=0;$Z=where_to_query($Z);$tk=[];foreach($Lh
as$X){$X=preg_replace('~ DESC$~','',$X,1,$pc);$tk[$X]=($pc?-1:1);}$w=min(200,max(1,(int)$w));$qk=$C*$w;$G=new
Query($Z,['projection'=>$M,'limit'=>$w,'skip'=>$qk,'sort'=>$tk]);try{return
new
MongoResult(Connection::get()->executeQuery(Connection::get()->getDbName().".$R",$G));}catch(Exception$id){Connection::get()->setError($id->getMessage());return
false;}}function
update($R,array$H,$Wi,$w=0,$N="\n"){$h=Connection::get()->getDbName();$Z=sql_query_where_parser($Wi);$lb=new
BulkWrite([]);if(isset($H['_id']))unset($H['_id']);$mj=[];foreach($H
as$u=>$Y){if($Y=='NULL'){$mj[$u]=1;unset($H[$u]);}}$im=['$set'=>$H];if(count($mj))$im['$unset']=$mj;$lb->update($Z,$im,['upsert'=>false]);return
Connection::get()->executeBulkWrite("$h.$R",$lb,'getModifiedCount');}function
delete($R,$Wi,$w=0){$lb=new
BulkWrite([]);$lb->delete(sql_query_where_parser($Wi),['limit'=>$w]);return
Connection::get()->executeBulkWrite(Connection::get()->getDbName().".$R",$lb,'getDeletedCount');}function
insert($R,array$H){if($H['_id']=='')unset($H['_id']);$lb=new
BulkWrite([]);$lb->insert($H);return
Connection::get()->executeBulkWrite(Connection::get()->getDbName().".$R",$lb,'getInsertedCount');}}function
create_driver(Connection$e){return
MongoDriver::create($e,Admin::get());}function
get_databases($me){$yc=Connection::get()->executeCommand(['listDatabases'=>1],true);if(!$yc)return[];$g=[];foreach($yc
as$Fc){foreach($Fc->databases
as$h)$g[]=$h->name;}return$g;}function
count_tables($g){$J=[];return$J;}function
tables_list(){$yc=Connection::get()->executeCommand(['listCollections'=>1]);if(!$yc)return[];$Lb=[];foreach($yc
as$I)$Lb[$I->name]='table';return$Lb;}function
drop_databases($g){return
false;}function
indexes($R,$e=null){$yc=Connection::get()->executeCommand(['listIndexes'=>$R]);if(!$yc)return[];$t=[];foreach($yc
as$s){$Pc=[];$d=[];foreach(get_object_vars($s->key)as$c=>$U){$Pc[]=($U==-1?'1':null);$d[]=$c;}$t[$s->name]=["type"=>($s->name=="_id_"?"PRIMARY":(isset($s->unique)?"UNIQUE":"INDEX")),"columns"=>$d,"lengths"=>[],"descs"=>$Pc,];}return$t;}function
fields($R){$l=fields_from_edit();if(!$l){$I=Driver::get()->select($R,["*"],[],[],[],10);if($I){while($K=$I->fetchAssoc()){foreach($K
as$u=>$X){$K[$u]=null;$l[$u]=["field"=>$u,"type"=>"string","null"=>($u!=Driver::get()->primary),"auto_increment"=>($u==Driver::get()->primary),"privileges"=>["insert"=>1,"select"=>1,"update"=>1,"where"=>1,"order"=>1,],];}}}}return$l;}function
found_rows($S,$Z){$Z=where_to_query($Z);$yc=Connection::get()->executeCommand(['count'=>$S['Name'],'query'=>$Z]);if(!$yc)return
0;return$yc->toArray()[0]->n;}function
sql_query_where_parser($Wi){$Wi=preg_replace('~^\s*WHERE\s*~',"",$Wi);while($Wi[0]=="(")$Wi=preg_replace('~^\((.*)\)$~',"$1",$Wi);$Om=explode(' AND ',$Wi);$Pm=explode(') OR (',$Wi);$Z=[];foreach($Om
as$Mm)$Z[]=trim($Mm);if(count($Pm)==1)$Pm=[];elseif(count($Pm)>1)$Z=[];return
where_to_query($Z,$Pm);}function
where_to_query($Km=[],$Lm=[]){$f=[];foreach(['and'=>$Km,'or'=>$Lm]as$U=>$Z){if(is_array($Z)){foreach($Z
as$Md){list($Hb,$Dh,$X)=explode(" ",$Md,3);if($Hb=="_id"&&preg_match('~^(MongoDB\\\\BSON\\\\ObjectID)\("(.+)"\)$~',$X,$y)){list(,$Eb,$X)=$y;$X=new$Eb($X);}if(!in_array($Dh,Admin::get()->getOperators()))continue;if(preg_match('~^\(f\)(.+)~',$Dh,$y)){$X=(float)$X;$Dh=$y[1];}elseif(preg_match('~^\(date\)(.+)~',$Dh,$y)){$Cc=new
DateTime($X);$X=new
BSON\UTCDatetime($Cc->getTimestamp()*1000);$Dh=$y[1];}switch($Dh){case'=':$Dh='$eq';break;case'!=':$Dh='$ne';break;case'>':$Dh='$gt';break;case'<':$Dh='$lt';break;case'>=':$Dh='$gte';break;case'<=':$Dh='$lte';break;case'regex':$Dh='$regex';break;default:continue
2;}if($U=='and')$f['$and'][]=[$Hb=>[$Dh=>$X]];elseif($U=='or')$f['$or'][]=[$Hb=>[$Dh=>$X]];}}}return$f;}function
table($r){return$r;}function
idf_escape($r){return$r;}function
table_status($_="",$Td=false){$J=[];foreach(tables_list()as$R=>$U){$J[$R]=["Name"=>$R];if($_==$R)return$J[$R];}return$J;}function
create_database($h,$Jb){return
true;}function
last_id($I){return
0;}function
error(){return
h(Connection::get()->getError());}function
collations(){return[];}function
logged_user(){$uc=Admin::get()->getCredentials();return$uc[1];}function
connect($F=false,&$j=null){$e=$F?MongoConnection::create():MongoConnection::createSecondary();list($O,$V,$E)=Admin::get()->getCredentials();if($O=="")$O="localhost:27017";$Dc=Admin::get()->getDatabase();$Ra=getenv("MONGO_AUTH_SOURCE")?:null;if(!$e->open("mongodb://$O",$V,$E,$Dc,$Ra)){$j=$e->getError();return
null;}return$e;}function
alter_indexes($R,$b){foreach($b
as$X){list($U,$_,$ik)=$X;if($ik=="DROP")$yc=Connection::get()->executeCommand(["dropIndexes"=>$R,"index"=>$_]);else{$d=[];foreach($ik
as$c){$c=preg_replace('~ DESC$~','',$c,1,$pc);$d[$c]=$pc?-1:1;}$Rb=["createIndexes"=>$R,"indexes"=>[["key"=>$d,"name"=>$_,"unique"=>$U=="UNIQUE",]],];$yc=Connection::get()->executeCommand($Rb);}if(!$yc)return
false;}return
true;}function
support($Ud){return
preg_match("~database|indexes|descidx~",$Ud);}function
db_collation($h,$Kb){}function
information_schema(){}function
is_view($S){}function
convert_field($k){}function
unconvert_field(array$k,$J){return$J;}function
foreign_keys($R){return[];}function
backward_keys($R){return[];}function
fk_support($S){}function
alter_table($R,$_,$l,$oe,$Tb,$ud,$Jb,$Ta,$ki){if($R=="")return(bool)Connection::get()->executeCommand(["create"=>$_]);return
false;}function
drop_tables($T){foreach($T
as$_){if(!Connection::get()->executeCommand(["drop"=>$_]))return
false;}return
true;}function
truncate_tables($T){foreach($T
as$_){$Rb=["delete"=>$_,"deletes"=>[["q"=>(object)[],"limit"=>0,]],];if(!Connection::get()->executeCommand($Rb))return
false;}return
true;}}Drivers::add("elastic","Elasticsearch 7 (beta)",["json + allow_url_fopen"]);if(isset($_GET["elastic"])){define("AdminNeo\DRIVER","elastic");define("AdminNeo\DIALECT","elastic");if(ini_bool('allow_url_fopen')){define("AdminNeo\ELASTIC_DB_NAME","elastic");define("AdminNeo\DRIVER_EXTENSION","JSON");class
ElasticConnection
extends
Connection{private$serviceUrl;function
rootQuery($qi,$kc=null,$Pg='GET'){$B=['http'=>['method'=>$Pg,'content'=>$kc!==null?json_encode($kc):null,'header'=>$kc!==null?'Content-Type: application/json':[],'ignore_errors'=>1,'follow_location'=>0,'max_redirects'=>0,],];$Ul=Admin::get()->getConfig()->getSslTrustServerCertificate();if($Ul)$B["ssl"]=["verify_peer"=>false];$m=@file_get_contents("$this->serviceUrl/".ltrim($qi,'/'),false,stream_context_create($B));if($m===false){$this->error=lang(3);return
false;}$J=json_decode($m,true);if($J===null){$this->error=lang(3);return
false;}if(!preg_match('~^HTTP/[0-9.]+ 2~i',$http_response_header[0])){if(isset($J['error']['root_cause'][0]['type']))$this->error=$J['error']['root_cause'][0]['type'].": ".$J['error']['root_cause'][0]['reason'];elseif(isset($J['status'])&&isset($J['error'])&&is_string($J['error']))$this->error=$J['error'];return
false;}return$J;}function
query($G,$am=false){return
false;}function
sendRequest($qi,$kc=null,$Pg='GET'){if($qi!=""&&$qi[0]=="S"&&preg_match('/SELECT 1 FROM ([^ ]+) WHERE (.+) LIMIT ([0-9]+)/',$qi,$z)){$Z=explode(" AND ",$z[2]);return
Driver::get()->select($z[1],["*"],$Z,[],[],$z[3]);}return$this->rootQuery($qi,$kc,$Pg);}function
open($O,$V,$E){$this->serviceUrl=build_http_url($O,$V,$E,"localhost",9200);if(!$this->serviceUrl){$this->error=lang(3);return
false;}$J=$this->sendRequest('');if(!$J)return
false;if(!isset($J['version']['number'])){$this->error=lang(3);return
false;}$this->version=$J['version']['number'];return
true;}function
selectDatabase($_){return
true;}function
quote($Q){return$Q;}}class
ElasticResult
extends
Result{private$rows;function
__construct(array$L){parent::__construct(count($L));$this->rows=$L;reset($this->rows);}function
fetchAssoc(){$J=current($this->rows);next($this->rows);return$J;}function
fetchRow(){$K=$this->fetchAssoc();return$K?array_values($K):false;}function
fetchField(){return
false;}}}class
ElasticDriver
extends
Driver{protected
function
__construct(Connection$e,$xa){parent::__construct($e,$xa);$this->types=[lang(114)=>["long"=>3,"integer"=>5,"short"=>8,"byte"=>10,"double"=>20,"float"=>66,"half_float"=>12,"scaled_float"=>21,"boolean"=>1,],lang(115)=>["date"=>10,],lang(116)=>["string"=>65535,"text"=>65535,"keyword"=>65535,],lang(118)=>["binary"=>255,],];$this->operators=["must(term)","must(match)","must(regexp)","should(term)","should(match)","should(regexp)","must_not(term)","must_not(match)","must_not(regexp)",];$this->likeOperator="should(match)";$this->regexpOperator="should(regexp)";$this->editFunctions=[["json"]];}function
select($R,array$M,array$Z,array$He,array$Lh=[],$w=1,$C=0,$Ji=false){$f=[];if($M!=["*"])$f["fields"]=array_values($M);if($Lh){$tk=[];foreach($Lh
as$Hb){$Hb=preg_replace('~ DESC$~','',$Hb,1,$pc);$tk[]=($pc?[$Hb=>"desc"]:$Hb);}$f["sort"]=$tk;}if($w!==null){$f["size"]=+$w;if($C)$f["from"]=($C*$w);}foreach($Z
as$X){if(preg_match('~^\((.+ OR .+)\)$~',$X,$z)){$ni=explode(" OR ",$z[1]);foreach($ni
as$gi)$this->addQueryCondition($gi,$f);}else$this->addQueryCondition($X,$f);}$G="$R/_search";$Fk=microtime(true);$Jj=$this->connection->rootQuery($G,$f);if($Ji)echo$this->admin->formatSelectQuery("\"GET $G\": ".json_encode($f),$Fk,!$Jj);if(empty($Jj))return
false;if($M==["*"])$al=array_keys(fields($R));$J=[];foreach($Jj["hits"]["hits"]as$Ze){$K=[];if($M==["*"])$K["_id"]=$Ze["_id"];if($M!=["*"]){$l=[];foreach($M
as$u)$l[$u]=$u=="_id"?$Ze["_id"]:$Ze["_source"][$u];}else{foreach($al
as$u)$l[$u]=$u=="_id"?$Ze["_id"]:$Ze["_source"][$u];}foreach($l
as$u=>$X)$K[$u]=(is_array($X)?json_encode($X):$X);$J[]=$K;}return
new
ElasticResult($J);}private
function
addQueryCondition($X,&$f){list($Hb,$Dh,$X)=explode(" ",$X,3);if($Hb=="_id"&&$Dh=="="){$f["query"]["bool"]["must"][]=["term"=>[$Hb=>$X]];return;}if(!preg_match('~^([^(]+)\(([^)]+)\)$~',$Dh,$z))return;$Vi=$z[1];$yg=$z[2];if($yg=="regexp")$f["query"]["bool"][$Vi][]=["regexp"=>[$Hb=>["value"=>$X,"flags"=>"ALL","case_insensitive"=>true,]]];else$f["query"]["bool"][$Vi][]=[$yg=>[$Hb=>$X]];}function
update($R,array$H,$Wi,$w=0,$N="\n"){$ni=preg_split('~ *= *~',$Wi);if(count($ni)!=2)return
false;$q=trim($ni[1]);$G="$R/_doc/$q";queries("\"POST $G\": ".json_encode($H));$qj=$this->connection->sendRequest($G,$H,'POST');if($qj)$this->connection->sendRequest("$R/_refresh");return$qj;}function
insert($R,array$H){$G="$R/_doc/";if(isset($H["_id"])&&$H["_id"]!="NULL"){$G
.=$H["_id"];unset($H["_id"]);}foreach($H
as$u=>$Y){if($Y=="NULL")unset($H[$u]);}queries("\"POST $G\": ".json_encode($H));$qj=$this->connection->sendRequest($G,$H,'POST');if(!$qj)return
false;$this->connection->sendRequest("$R/_refresh");$this->connection->last_id=$qj['_id'];return$qj['result'];}function
delete($R,$Wi,$w=0){$jf=[];if(isset($_GET["where"]["_id"])?$_GET["where"]["_id"]:null)$jf[]=$_GET["where"]["_id"];if(isset($_POST['check'])){foreach($_POST['check']as$vb){$ni=preg_split('~ *= *~',$vb);if(count($ni)==2)$jf[]=trim($ni[1]);}}$Aa=0;foreach($jf
as$q){$G="$R/_doc/$q";queries("\"DELETE $G\"");$qj=$this->connection->sendRequest($G,null,'DELETE');if(isset($qj['result'])&&$qj['result']=='deleted')$Aa++;}$this->connection->sendRequest("$R/_refresh");$this->connection->setAffectedRows($Aa);return$Aa;}}function
create_driver(Connection$e){return
ElasticDriver::create($e,Admin::get());}function
connect($F=false,&$j=null){$e=$F?ElasticConnection::create():ElasticConnection::createSecondary();list($O,$V,$E)=Admin::get()->getCredentials();if(!$e->openPasswordless($O,$V,$E)){$j=$e->getError();return
null;}return$e;}function
support($Ud){return
preg_match("~table|columns~",$Ud);}function
logged_user(){$uc=Admin::get()->getCredentials();return$uc[1];}function
get_databases(){return[ELASTIC_DB_NAME];}function
limit($G,$Z,$w,$A=0,$N=" "){return" $G$Z".($w!==null?$N."LIMIT $w".($A?" OFFSET $A":""):"");}function
collations(){return[];}function
db_collation($h,$Kb){}function
count_tables($g){$J=Connection::get()->rootQuery('_aliases');if(empty($J))return[ELASTIC_DB_NAME=>0];return[ELASTIC_DB_NAME=>count($J)];}function
tables_list(){$Ea=Connection::get()->rootQuery('_aliases');if(empty($Ea))return[];ksort($Ea);$T=[];foreach($Ea
as$_=>$s){if($_[0]==".")continue;$T[$_]="table";ksort($s["aliases"]);$T+=array_fill_keys(array_keys($s["aliases"]),"view");}return$T;}function
table_status($_="",$Td=false){$Hk=Connection::get()->rootQuery('_stats');$Ea=Connection::get()->rootQuery('_aliases');if(empty($Hk)||empty($Ea))return[];$I=[];if($_!=""){if(isset($Hk["indices"][$_]))return
format_index_status($_,$Hk["indices"][$_]);else
foreach($Ea
as$of=>$s){foreach($s["aliases"]as$Da=>$Ca){if($Da==$_)return
format_alias_status($Da,$Hk["indices"][$of]);}}}ksort($Hk["indices"]);foreach($Hk["indices"]as$_=>$s){if($_[0]==".")continue;$I[$_]=format_index_status($_,$s);if(!empty($Ea[$_]["aliases"])){ksort($Ea[$_]["aliases"]);foreach($Ea[$_]["aliases"]as$Da=>$Ca)$I[$Da]=format_alias_status($Da,$Hk["indices"][$_]);}}return$I;}function
format_index_status($_,$s){return["Name"=>$_,"Engine"=>"Lucene","Oid"=>$s["uuid"],"Rows"=>$s["total"]["docs"]["count"],"Auto_increment"=>0,"Data_length"=>$s["total"]["store"]["size_in_bytes"],"Index_length"=>0,"Data_free"=>$s["total"]["store"]["reserved_in_bytes"],];}function
format_alias_status($_,$s){return["Name"=>$_,"Engine"=>"view","Rows"=>$s["total"]["docs"]["count"],];}function
is_view($S){return$S["Engine"]=="view";}function
error(){return
h(Connection::get()->getError());}function
information_schema(){}function
indexes($R,$e=null){return[["type"=>"PRIMARY","columns"=>["_id"]],];}function
fields($R){$tg=Connection::get()->rootQuery("_mapping");if(!isset($tg[$R])){$Ea=Connection::get()->rootQuery('_aliases');foreach($Ea
as$of=>$s){foreach($s["aliases"]as$Da=>$Ca){if($Da==$R){$R=$of;break;}}}}$ug=isset($tg[$R]["mappings"]["properties"])?$tg[$R]["mappings"]["properties"]:[];$I=["_id"=>["field"=>"_id","full_type"=>"_id","type"=>"_id","null"=>true,"privileges"=>["insert"=>1,"select"=>1,"where"=>1,"order"=>1],]];foreach($ug
as$_=>$k)$I[$_]=["field"=>$_,"full_type"=>$k["type"],"type"=>$k["type"],"null"=>true,"privileges"=>["insert"=>1,"select"=>1,"update"=>1,"where"=>!isset($k["index"])||$k["index"]?:null,"order"=>$k["type"]!="text"?:null],];return$I;}function
foreign_keys($R){return[];}function
backward_keys($R){return[];}function
table($r){return$r;}function
idf_escape($r){return$r;}function
convert_field($k){}function
unconvert_field(array$k,$J){return$J;}function
fk_support($S){}function
found_rows($S,$Z){return
null;}function
alter_table($R,$_,$l,$oe,$Tb,$ud,$Jb,$Ta,$ki){$Qi=[];foreach($l
as$k){if(!isset($k[1]))continue;$Yd=trim($k[1][0]);$Zd=trim($k[1][1]?:"text");$Qi[$Yd]=["type"=>$Zd,];}$ug=$Qi?["properties"=>$Qi]:new
\stdClass();if($R!=""){queries("\"POST $_/_mapping\": ".json_encode($ug));return
Connection::get()->rootQuery("$_/_mapping",$ug,"POST");}else{$kc=["mappings"=>$ug];queries("\"PUT $_\": ".json_encode($kc));return
Connection::get()->rootQuery($_,$kc,"PUT");}}function
drop_tables($T){$J=true;foreach($T
as$R){$R=urlencode($R);queries("\"DELETE $R\"");$J=$J&&Connection::get()->sendRequest($R,null,'DELETE');}return$J;}function
last_id($I){return
Connection::get()->last_id;}}Drivers::add("clickhouse","ClickHouse (alpha)",["allow_url_fopen"]);if(isset($_GET["clickhouse"])){define("AdminNeo\DRIVER","clickhouse");define("AdminNeo\DIALECT","clickhouse");if(ini_bool('allow_url_fopen')){define("AdminNeo\DRIVER_EXTENSION","JSON");class
ClickHouseConnection
extends
Connection{private$serviceUrl;private$dbName='default';function
rootQuery($h,$G){$m=@file_get_contents("$this->serviceUrl/?database=$h",false,stream_context_create(['http'=>['method'=>'POST','content'=>$this->isQuerySelectLike($G)?"$G FORMAT JSONCompact":$G,'header'=>'Content-type: application/x-www-form-urlencoded','ignore_errors'=>1,'follow_location'=>0,'max_redirects'=>0,]]));if($m===false){$this->error=lang(3);return
false;}if(!preg_match('~^HTTP/[0-9.]+ 2~i',$http_response_header[0])){foreach($http_response_header
as$Ve){if(preg_match('~^X-ClickHouse-Exception-Code:~i',$Ve)){$this->error=preg_replace('~\(version [^(]+\(.+$~','',$m);return
false;}}$this->error=lang(3);return
false;}if(!$this->isQuerySelectLike($G)&&$m==='')return
true;$J=json_decode($m,true);if($J===null){$this->error=lang(3);return
false;}if(!isset($J['rows'])||!isset($J['data'])||!isset($J['meta'])){$this->error=lang(3);return
false;}return
new
ClickHouseResult($J['rows'],$J['data'],$J['meta']);}private
function
isQuerySelectLike($G){return(bool)preg_match('~^(select|show)~i',$G);}function
query($G,$am=false){return$this->rootQuery($this->dbName,$G);}function
open($O,$V,$E){$this->serviceUrl=build_http_url($O,$V,$E,"localhost",8123);if(!$this->serviceUrl){$this->error=lang(3);return
false;}$I=$this->query("SELECT version()");if(!$I)return
false;$this->version=$I->fetchRow()[0];return
true;}function
selectDatabase($_){$this->dbName=$_;return
true;}function
getDbName(){return$this->dbName;}function
quote($Q){return"'".addcslashes($Q,"\\'")."'";}function
getValue($G,$Vd=0){$I=$this->query($G);return$I['data'];}}class
ClickHouseResult
extends
Result{private$rows;private$columns;private$meta;private$offset=0;function
__construct($Cj,array$f,array$Og){parent::__construct($Cj);$this->rows=[];foreach($f
as$Hf){$this->rows[]=array_map(function($X){return
is_scalar($X)?$X:json_encode($X,JSON_UNESCAPED_UNICODE);},$Hf);}$this->meta=$Og;$this->columns=array_column($Og,'name');reset($this->rows);}function
fetchAssoc(){$K=current($this->rows);next($this->rows);return$K!==false?array_combine($this->columns,$K):false;}function
fetchRow(){$K=current($this->rows);next($this->rows);return$K;}function
fetchField(){$c=$this->offset++;if($c>=count($this->columns))return
false;$c=$this->meta[$c];return(object)['name'=>$c['name'],'type'=>$c['type'],'charsetnr'=>0,];}}}class
ClickHouseDriver
extends
Driver{protected
function
__construct(Connection$e,$xa){parent::__construct($e,$xa);$this->types=[lang(114)=>["Int8"=>3,"Int16"=>5,"Int32"=>10,"Int64"=>19,"UInt8"=>3,"UInt16"=>5,"UInt32"=>10,"UInt64"=>20,"Float32"=>7,"Float64"=>16,'Decimal'=>38,'Decimal32'=>9,'Decimal64'=>18,'Decimal128'=>38,],lang(115)=>["Date"=>13,"DateTime"=>20,],lang(116)=>["String"=>0,],lang(118)=>["FixedString"=>0,],];$this->operators=["=","<",">","<=",">=","!=","~","!~","LIKE","LIKE %%","NOT LIKE","IN","NOT IN","IS NULL","IS NOT NULL","SQL",];$this->likeOperator="LIKE %%";$this->grouping=["sum","min","max","avg","count","count distinct",];$this->systemDatabases=["INFORMATION_SCHEMA","information_schema","system"];}function
delete($R,$Wi,$w=0){if($Wi==='')$Wi='WHERE 1=1';return
queries("ALTER TABLE ".table($R)." DELETE $Wi");}function
update($R,array$H,$Wi,$w=0,$N="\n"){$vm=[];foreach($H
as$u=>$X)$vm[]="$u = $X";$G=$N.implode(",$N",$vm);return
queries("ALTER TABLE ".table($R)." UPDATE $G$Wi");}function
engines(){return['MergeTree'];}}function
create_driver(Connection$e){return
ClickHouseDriver::create($e,Admin::get());}function
idf_escape($r){return"`".str_replace("`","``",$r)."`";}function
table($r){return
idf_escape($r);}function
explain(Connection$e,$G){return
false;}function
found_rows($S,$Z){$L=get_vals("SELECT COUNT(*) FROM ".idf_escape($S["Name"]).($Z?" WHERE ".implode(" AND ",$Z):""));return
empty($L)?false:$L[0];}function
alter_table($R,$_,$l,$oe,$Tb,$ud,$Jb,$Ta,$ki){$b=$Lh=[];foreach($l
as$k){if($k[1][2]===" NULL")$k[1][1]=" Nullable({$k[1][1]})";elseif($k[1][2]===' NOT NULL')$k[1][2]='';if($k[1][3])$k[1][3]='';$b[]=($k[1]?($R!=""?($k[0]!=""?"MODIFY COLUMN ":"ADD COLUMN "):" ").implode($k[1]):"DROP COLUMN ".idf_escape($k[0]));$Lh[]=$k[1][0];}$b=array_merge($b,$oe);$Ik=($ud?" ENGINE ".$ud:"");if($R=="")return
queries("CREATE TABLE ".table($_)." (\n".implode(",\n",$b)."\n)$Ik$ki".' ORDER BY ('.implode(',',$Lh).')');if($R!=$_){$I=queries("RENAME TABLE ".table($R)." TO ".table($_));if($b)$R=$_;else
return$I;}if($Ik)$b[]=ltrim($Ik);return($b||$ki?queries("ALTER TABLE ".table($R)."\n".implode(",\n",$b).$ki):true);}function
truncate_tables($T){return
apply_queries("TRUNCATE TABLE",$T);}function
drop_views($Bm){return
drop_tables($Bm);}function
drop_tables($T){return
apply_queries("DROP TABLE",$T);}function
is_server_host_valid($df){return
strpos(rtrim($df,'/'),'/')===false;}function
connect($F=false,&$j=null){$e=$F?ClickHouseConnection::create():ClickHouseConnection::createSecondary();$uc=Admin::get()->getCredentials();if(!$e->open($uc[0],$uc[1],$uc[2])){$j=$e->getError();return
null;}return$e;}function
get_databases($me){$I=get_rows('SHOW DATABASES');$J=[];foreach($I
as$K)$J[]=$K['name'];sort($J);return$J;}function
limit($G,$Z,$w,$A=0,$N=" "){return" $G$Z".($w!==null?$N."LIMIT $w".($A?", $A":""):"");}function
limit1($R,$G,$Z,$N="\n"){return
limit($G,$Z,1,0,$N);}function
db_collation($h,$Kb){}function
logged_user(){$uc=Admin::get()->getCredentials();return$uc[1];}function
tables_list(){$I=get_rows('SHOW TABLES');$J=[];foreach($I
as$K)$J[$K['name']]='table';ksort($J);return$J;}function
count_tables($g){return[];}function
table_status($_="",$Td=false){$J=[];$T=get_rows("SELECT name, engine FROM system.tables WHERE database = ".q(Connection::get()->getDbName()));foreach($T
as$R){$J[$R['name']]=['Name'=>$R['name'],'Engine'=>$R['engine'],];if($_===$R['name'])return$J[$R['name']];}return$J;}function
is_view($S){return
false;}function
fk_support($S){return
false;}function
convert_field($k){}function
unconvert_field(array$k,$J){if(in_array($k['type'],["Int8","Int16","Int32","Int64","UInt8","UInt16","UInt32","UInt64","Float32","Float64"]))return"to$k[type]($J)";return$J;}function
fields($R){$J=[];$I=get_rows("SELECT name, type, default_expression FROM system.columns WHERE ".idf_escape('table')." = ".q($R));foreach($I
as$K){$U=trim($K['type']);$nh=strpos($U,'Nullable(')===0;$J[trim($K['name'])]=["field"=>trim($K['name']),"full_type"=>$U,"type"=>$U,"default"=>trim($K['default_expression']),"null"=>$nh,"auto_increment"=>'0',"privileges"=>["insert"=>1,"select"=>1,"update"=>0,"where"=>1,"order"=>1],];}return$J;}function
indexes($R,$e=null){return[];}function
foreign_keys($R){return[];}function
backward_keys($R){return[];}function
collations(){return[];}function
information_schema($h){return
false;}function
error(){return
h(Connection::get()->getError());}function
types(){return[];}function
auto_increment(){return'';}function
last_id($I){return
0;}function
support($Ud){return
preg_match("~^(columns|sql|status|table|drop_col)$~",$Ud);}}Drivers::add("simpledb","SimpleDB",["SimpleXML + allow_url_fopen"]);if(isset($_GET["simpledb"])){define("AdminNeo\DRIVER","simpledb");define("AdminNeo\DIALECT","simpledb");if(class_exists('SimpleXMLElement')&&ini_bool('allow_url_fopen')){define("AdminNeo\DRIVER_EXTENSION","SimpleXML");class
SimpleDbConnection
extends
Connection{private$serviceUrl;var$timeout=0;var$next;function
open($O,$V,$E){if($O==''){$this->error=lang(3);return
false;}$ni=parse_url($O);if(!$ni||!isset($ni['host'])||!preg_match('~^sdb\.([a-z0-9-]+\.)?amazonaws\.com$~i',$ni['host'])||isset($ni['port'])){$this->error=lang(3);return
false;}$this->serviceUrl=build_http_url($O,"","","");if(!$this->serviceUrl){$this->error=lang(3);return
false;}$this->version='2009-04-15';return(bool)sdb_request('ListDomains',['MaxNumberOfDomains'=>1],$this);}function
getServiceUrl(){return$this->serviceUrl;}function
selectDatabase($_){return$_=="domain";}function
query($G,$am=false){$D=['SelectExpression'=>$G,'ConsistentRead'=>'true'];if($this->next)$D['NextToken']=$this->next;$I=sdb_request_all('Select','Item',$D,$this->timeout);$this->timeout=0;if($I===false)return
false;if(preg_match('~^\s*SELECT\s+COUNT\(~i',$G)){$Sk=0;foreach($I
as$Hf)$Sk+=$Hf->Attribute->Value;$I=[(object)['Attribute'=>[(object)['Name'=>'Count','Value'=>$Sk,]]]];}return
new
SimpleDbResult($I);}function
quote($Q){return"'".str_replace("'","''",$Q)."'";}}class
SimpleDbResult
extends
Result{private$rows;private$offset=0;function
__construct(array$I){$this->rows=[];foreach($I
as$Hf){$K=[];if($Hf->Name!='')$K['itemName()']=(string)$Hf->Name;foreach($Hf->Attribute
as$Oa){$_=$this->processValue($Oa->Name);$Y=$this->processValue($Oa->Value);if(isset($K[$_])){$K[$_]=(array)$K[$_];$K[$_][]=$Y;}else$K[$_]=$Y;}$this->rows[]=$K;foreach($K
as$u=>$X){if(!isset($this->rows[0][$u]))$this->rows[0][$u]=null;}}parent::__construct(count($this->rows));}private
function
processValue($od){return(is_object($od)&&$od['encoding']=='base64'?base64_decode($od):(string)$od);}function
fetchAssoc(){$K=current($this->rows);if(!$K)return$K;$f=[];foreach($this->rows[0]as$u=>$X)$f[$u]=$K[$u];next($this->rows);return$f;}function
fetchRow(){$f=$this->fetchAssoc();return$f?array_values($f):$f;}function
fetchField(){$Tf=array_keys($this->rows[0]);return(object)['name'=>$Tf[$this->offset++],'type'=>15,'charsetnr'=>0,];}}}class
SimpleDbDriver
extends
Driver{var$primary="itemName()";protected
function
__construct(Connection$e,$xa){parent::__construct($e,$xa);$this->operators=["=","<",">","<=",">=","!=","LIKE","LIKE %%","NOT LIKE","IN","IS NULL","IS NOT NULL",];$this->likeOperator="LIKE %%";$this->grouping=["count",];$this->editFunctions=[["json"]];}private
function
chunkRequest($jf,$ra,$D,$Hd=[]){foreach(array_chunk($jf,25)as$Bb){$ei=$D;foreach($Bb
as$p=>$q){$ei["Item.$p.ItemName"]=$q;foreach($Hd
as$u=>$X)$ei["Item.$p.$u"]=$X;}if(!sdb_request($ra,$ei))return
false;}Connection::get()->setAffectedRows(count($jf));return
true;}private
function
extractIds($R,$Wi,$w){$J=[];if(preg_match_all("~itemName\(\) = (('[^']*+')+)~",$Wi,$z))$J=array_map('AdminNeo\idf_unescape',$z[1]);else{foreach(sdb_request_all('Select','Item',['SelectExpression'=>'SELECT itemName() FROM '.table($R).$Wi.($w?" LIMIT 1":"")])as$Hf)$J[]=$Hf->Name;}return$J;}function
select($R,array$M,array$Z,array$He,array$Lh=[],$w=1,$C=0,$Ji=false){Connection::get()->next=$_GET["next"];$J=parent::select($R,$M,$Z,$He,$Lh,$w,$C,$Ji);Connection::get()->next=0;return$J;}function
delete($R,$Wi,$w=0){return$this->chunkRequest($this->extractIds($R,$Wi,$w),'BatchDeleteAttributes',['DomainName'=>$R]);}function
update($R,array$H,$Wi,$w=0,$N="\n"){$Mc=[];$vf=[];$p=0;$jf=$this->extractIds($R,$Wi,$w);$q=idf_unescape($H["`itemName()`"]);unset($H["`itemName()`"]);foreach($H
as$u=>$X){$u=idf_unescape($u);if($X=="NULL"||($q!=""&&[$q]!=$jf))$Mc["Attribute.".count($Mc).".Name"]=$u;if($X!="NULL"){foreach((array)$X
as$Nf=>$W){$vf["Attribute.$p.Name"]=$u;$vf["Attribute.$p.Value"]=(is_array($X)?$W:idf_unescape($W));if(!$Nf)$vf["Attribute.$p.Replace"]="true";$p++;}}}$D=['DomainName'=>$R];return(!$vf||$this->chunkRequest(($q!=""?[$q]:$jf),'BatchPutAttributes',$D,$vf))&&(!$Mc||$this->chunkRequest($jf,'BatchDeleteAttributes',$D,$Mc));}function
insert($R,array$H){$D=["DomainName"=>$R];$p=0;foreach($H
as$_=>$Y){if($Y!="NULL"){$_=idf_unescape($_);if($_=="itemName()")$D["ItemName"]=idf_unescape($Y);else{foreach((array)$Y
as$X){$D["Attribute.$p.Name"]=$_;$D["Attribute.$p.Value"]=(is_array($Y)?$X:idf_unescape($Y));$p++;}}}}return
sdb_request('PutAttributes',$D);}function
insertUpdate($R,array$bj,array$F){foreach($bj
as$H){if(!$this->update($R,$H,"WHERE `itemName()` = ".q($H["`itemName()`"])))return
false;}return
true;}function
begin(){return
false;}function
commit(){return
false;}function
rollback(){return
false;}function
slowQuery($G,$Al){$this->connection->timeout=$Al;return$G;}}function
create_driver(Connection$e){return
SimpleDbDriver::create($e,Admin::get());}function
is_server_host_valid($df){return
strpos(rtrim($df,'/'),'/')===false;}function
connect($F=false,&$j=null){$e=$F?SimpleDbConnection::create():SimpleDbConnection::createSecondary();list($O,,$E)=Admin::get()->getCredentials();if(!$e->openPasswordless($O,"",$E)){$j=$e->getError();return
null;}return$e;}function
support($Ud){return
preg_match('~sql~',$Ud);}function
logged_user(){$uc=Admin::get()->getCredentials();return$uc[1];}function
get_databases(){return["domain"];}function
collations(){return[];}function
db_collation($h,$Kb){}function
tables_list(){$J=[];foreach(sdb_request_all('ListDomains','DomainName')as$R)$J[(string)$R]='table';if(Connection::get()->getError()&&defined("AdminNeo\PAGE_HEADER"))echo"<p class='error'>".error()."\n";return$J;}function
table_status($_="",$Td=false){$J=[];foreach(($_!=""?[$_=>true]:tables_list())as$R=>$U){$K=["Name"=>$R,"Auto_increment"=>""];if(!$Td){$Og=sdb_request('DomainMetadata',['DomainName'=>$R]);if($Og){foreach(["Rows"=>"ItemCount","Data_length"=>"ItemNamesSizeBytes","Index_length"=>"AttributeValuesSizeBytes","Data_free"=>"AttributeNamesSizeBytes",]as$u=>$X)$K[$u]=(string)$Og->$X;}}if($_!="")return$K;$J[$R]=$K;}return$J;}function
explain(Connection$e,$G){return
false;}function
error(){return
h(Connection::get()->getError());}function
information_schema(){}function
indexes($R,$e=null){return[["type"=>"PRIMARY","columns"=>["itemName()"]],];}function
fields($R){return
fields_from_edit();}function
foreign_keys($R){return[];}function
backward_keys($R){return[];}function
table($r){return
idf_escape($r);}function
idf_escape($r){return"`".str_replace("`","``",$r)."`";}function
limit($G,$Z,$w,$A=0,$N=" "){return" $G$Z".($w!==null?$N."LIMIT $w":"");}function
unconvert_field(array$k,$J){return$J;}function
fk_support($S){}function
alter_table($R,$_,$l,$oe,$Tb,$ud,$Jb,$Ta,$ki){return($R==""&&sdb_request('CreateDomain',['DomainName'=>$_]));}function
drop_tables($T){foreach($T
as$R){if(!sdb_request('DeleteDomain',['DomainName'=>$R]))return
false;}return
true;}function
count_tables($g){foreach($g
as$h)return[$h=>count(tables_list())];}function
found_rows($S,$Z){return($Z?null:$S["Rows"]);}function
last_id($I){return
0;}function
sdb_request($ra,$D=[],$e=null){if(!$e)$e=Connection::get();list($cf,$D['AWSAccessKeyId'],$Lj)=Admin::get()->getCredentials();$D['Action']=$ra;$D['Timestamp']=gmdate('Y-m-d\TH:i:s+00:00');$D['Version']='2009-04-15';$D['SignatureVersion']=2;$D['SignatureMethod']='HmacSHA1';ksort($D);$G='';foreach($D
as$u=>$X)$G
.='&'.rawurlencode($u).'='.rawurlencode($X);$G=str_replace('%7E','~',substr($G,1));$G
.="&Signature=".urlencode(base64_encode(hash_hmac('sha1',"POST\n".preg_replace('~^https?://~','',$cf)."\n/\n$G",$Lj,true)));$m=@file_get_contents($e->getServiceUrl(),false,stream_context_create(['http'=>['method'=>'POST','content'=>$G,'ignore_errors'=>1,'follow_location'=>0,'max_redirects'=>0,]]));if(!$m){$e->setError(error_get_last()['message']);return
false;}libxml_use_internal_errors(true);libxml_disable_entity_loader();$Rm=simplexml_load_string($m);if(!$Rm){$j=libxml_get_last_error();$e->setError($j->message);return
false;}if($Rm->Errors){$j=$Rm->Errors->Error;$e->setError("$j->Message ($j->Code)");return
false;}$e->setError('');$nl=$ra."Result";return$Rm->$nl?:true;}function
sdb_request_all($ra,$nl,$D=[],$Al=0){$J=[];$Fk=($Al?microtime(true):0);$w=(preg_match('~LIMIT\s+(\d+)\s*$~i',$D['SelectExpression'],$y)?$y[1]:0);do{$Rm=sdb_request($ra,$D);if(!$Rm)break;foreach($Rm->$nl
as$od)$J[]=$od;if($w&&count($J)>=$w){$_GET["next"]=$Rm->NextToken;break;}if($Al&&microtime(true)-$Fk>$Al)return
false;$D['NextToken']=$Rm->NextToken;if($w)$D['SelectExpression']=preg_replace('~\d+\s*$~',$w-count($J),$D['SelectExpression']);}while($Rm->NextToken);return$J;}}$zi="adminneo-plugins";if(is_dir($zi)){foreach(glob("$zi/*.php")as$n)include_once$n;}function
get_translations($Yf){switch($Yf){case"en":$Zb="WxEJTmIDadTmdBAcjKdDqcjcIDDDzCcjkYTyLhELBETTfChAaTcZo6bTCdDSbzdGI0RJKYTEYTmZRAZDeZYGbjfCDmdTgcI7CDhMDmd46ZJUIiSbjsYTYaTIIJicjsZTkII6IDHCjIZTdJqYc6OQTIbZATjKb5nNZvOahPJ8coQYTGY5sc5AZ4hM5bL5iIDuaToaDedbiIKCc6HRRYIB4YRAaIUZh6XBEaDodDgcx0XBfnDvnxcYbHIDdZxdHTPnMPiTkZMpAh8bY7MpBIjlJJNKB5nDCPqOTDeZ8GdIyIrMd4+dDKbeKVJcbDLxSZETOdTCZ+jGiEeageYPy+kaTPluLLDka+KQzebKuczGaOX2RERDKZjCdTZxJWaTmcDYiziiQpz5CkMr/tyNw5vCNw1oGOi0Do56bIS+qqK4Ma7hAwKZDGhqFK6hI3juo8CjGoqBjgqjDOu+T6Ps/CEDcOo2jFFQ3jNCkTNagYyP4/yLDKp6QL1CMNQko6zKmOTiiCNg7otBSNI4jyljYOsJsCiIQBKMjiiLGQ2oggaYugMb9BEKjIJswQ2Ke2yZx8/48wyx0yDLMyToeNquDqEE3z5MIzDTAwyLA4opqpJVDu85TmI0KqojcMM9uKKChKI1ryr2mD5OAM6QUqqiSNLED2U+N1DwNO6EDIltDsE5CDjkOszIa+UmuUqo7UGO8mPzFUIjE6DiqSkUvR7M4romNy7yiEQpiiJisDeNtRy6jQkCoKgoQoOMroOjKAS4EAxDy5Ti3HcrlQULqNPVKw21QjQqDzFL0vXA883vaquTOILCLQpKsvirryvq+78hBKsr0qiaTQRZ1LLgwF9I0KymW+4roDcM7A1TMsziMOo3TwlFnCCM4zoUM6S4qEUCtkqdUom97ioiPI7vghVDp+4qtvcrke448KyTOKgyjwhGN46NEmZLeQRZENg2SNYSZPciLijmMOZI0N8U6hXEVVbYNOV9XKoPe5Yw01sq+vc+CSUqOQ0126DsWcJI2rfM4ijxvj0oUkqZbIl2zXdwTlbTuO2cQMvB6rYaNCdCEJUNR6Y0PtW5I0KY073yT5usNjiwLJSY2u42uPFlqUIIN6tukizhqtHCSSHSVd5ZBC/MANHIpkpsGcvNEJBB4UG7nz6Ju4uXeTepmqWC6HjpBBskLQOUReIIzZvEh41jK7zixNqfW6gJ4nBAKooCIIIqCK4v0hAIgiiYIv4XveCH0lSiNMSUmQtFT/T5BPDgxBJgZCnmlaScUjhUwQE8gcG+CBNA7tQBKC4GaOFnBVUk1ZDRaCeHsNEXlQR0CjhNDCHhz6MyINTREkFPwaXqF2D0bQgZAghFHCNDRwhagQE4IQ0g/gdCjkaI0DAGIMgZg0BqDYG4OAcpMI8HkwZbSFA/OKcuA4eTikdPESApixEElUTOFmK4aGuEyJwYZujdgyt4hDBEODZCZGBP48Ao4U41qHjWRANxT0TFdJAlcECQTAR+ggRFIUZS4RBaQmePiu2hkrVUudR6DCcQXkORQjpR1ILAXqTY4oTkZo1Dks4ljipGIac+fIKYdG6McWcEyIqzghRiDlF4jQRyzp7llLw4xC1MHof+dBTkES+koJkjdDR8JDtJK4XZkyW3uQ+mjLco5ApAFPm4QUg6FCGEOkAVYMQalVlYcTDJcs1iCELMEUZjUsjixoT6ROZoZgzPCDKUcJC1JYELJNLRe4bjSp4Y5HMOEb4fHYKe3wgceYhQvPYHdIJKiABUDeWhUZ3GRk7LmXUMx+HjnBJAHMxcwSIMsSGkNcZZEZHKKPRqjjN4IoJVoXQxFI2qKmpPSmXdKww0tIfS+Qq6yMLtTQzqHBeT+lyNoQ9DZHw3BwMIisxCmCns5DSe8gh4jLLkjvNAMZ9yYm/OC7SkFOg508j2XVPM0Q4BpK0Ys/zjy+0+IlSwlMZEqlOMMqIiK/aSqnrtMivNJq91Dr652uDridk9J+QQgxCEayHg+dCeS85oPOriX9qdYrAhyNsnsp4YQzNorXSKklenemBme1eAM6kgr9DSV8o8q3DF9DJG+AZbCRMjs2cYtFvW6lUlLMx2tsS22SLhDIKASFuSRmmnkgYKCBApIgR5rlQz/tWexNE5SCWXFJr+U8IYUwpBGhC+ElIIFESBuZaWoRIIUwrhamFMEqLlvRhim5QabSBtILpbUowIAoWIqiwOZJAijhJRxFZPqPYFlsJjfKPBAyFLeJsQgMz2kwlipgWZCB8CHhjPYX3DKKzsUzo2uQ8WCAnhTCokQMILgQIFDIrSsbhCWlWKqSDBmKpoTckGoI6pFXeI9IUngqZR57FYS1CMN8JTHBixitBaUJyZK7McEZbc3SPt7smYBP2ICoKJKpg8pRTLAOFL5P1ttu0JxqggjUrhM3tE9ou3MN9bHqrgYsRO27VlnSxJKQZdBA3Tp5B1O4wL2g6njwRdK8V1XXECOkcGhyYtH6aI0gXD6azmuWUOGmG6+6rSYWeqpMyQTy57r9m4p7cG133VzbcpsNynq7DKr1iyvEvMcJAfJiTD64rljIVsPEpCNNiyDIFpGzlnmDDkXTUocjsL+V+kvZ8Ck/PeDO+B8R6T4BjeS45yDat0HNboykqjJ9wSyPEdjbwIgoWCVI0p6xxXum3JK6U4exVnBFKmV2VSriNBPMJqtwLj3FEGuRs9bQQQhhIBBhxuiE58RBwsW4n+fSNBFk9tHjKV5droKeZwEC4SAlPe1sDl6IQ7rsBYQAKPKDubTQ6cop4TwlmLXHzEiE+lV8iBFzkqnO9m89hl0DoXMHt9FDN0eeVSnKLTWrIxBxaOeGEzlzfmfGumJ37Bz8Jc2yn8aUHgPpvZwQdAqTyPt+rJbNF5os6Hr1MqGi39NjvqhbtuEP4hK4YRs0FRUURoK4ZQxeKRVlyazpWRwzdDLFr5ViHlUe1vcKasPNBs53yVZyAiDkdmEEOZG9wirIoosRRpjyYVizyVs6HPsH+xjUQPPBDyeR2uGElRs3Pd+0IfSeM3SDnQg+L73PTX0U3D+W9T5oZc8lMVz8p431c84M9xqWEEBIt7ENLrHzJAotP/YcxR134iNFJ2ZnWP/zvsIW+DtIPAIF6L2cnAE6QrhpjObOL2T3j6wh63r6DpC3UAb7gh5D6AK4cBaZMBq2hwcCJTYvsCj+orSPZzYx0CkBDPi4YKcD0Aj40Cr75zsEsDTbrpAIZ6LlwKTgY0sEz5yspqZILqLmjqjqxEkGYmUCkG6zUHTmIga1DqrV7q4jTf4Mp74EB8I7kEDPb6KHjcTckKL2b+kFrw8K0J58UGsA0FDpAKbawujMRCLbQhZaZ/YgacAhDOzHoqC2ZwpDSUalKpiyicKy5LQkDZjzS5kNDbcNZGZBLMQyJCxkiGUOkNybIg8KohUJ0KDbMQR6ZFoITcw6hW7cB8sQg4oKxXkMD68LYo8T7X8UMA8KbpEUo5EIKda4YIadZhTYTkbg8N8LMMMEMKhL0WsU6F77K4bgywkVriDpDaCQ8Wrh5yAMsZBzsNBvqQMXbpZ+TE5aiu53ihYmzNTgQwjYsXsXLpEGUbkGkFkX8H0cUIEW77sVwsLbpPxkZp5s5FShbP5IJW0ZJxSkZkhBEe4mUeYujHZnbUIhYhqqSUZVLDkRMb0VMEYMshEM0YcCyt8h0dEAsUUcseIqomMicfjNMjbdRxQOkgxeaUchUBL6UkkiEFIEUY0kL/gEQIbc4NcksEQo8mBO8mUcj+0msmMXr70YsdrdiYxNDd7e0mcXRecohFUnMDjdzespUdLE8dcjBDUpLe8WEYkqkpze4KiV8aJgpzEp8isVEkyUAqMXsDbpCUIqslLpAJAmA+B1McKgY+QI4isr5l8ZYN58LlxccfwusXoNaGizTtSN0egxD+TO8MMwMHEJUl49j8ojRcZIZB5CJ0gjQJcwUvhIT3UqEHkJMwgwA5YgcOEE8I8HoESpQIaWQNgFbFCrsmR1wxxhaO6jh2ANIMw7gwCHibERiy5IYKoKgIwFoHCzBExoQM6jDmbokChz5vjpDobqc0j505rkMxqDx4xB7NJkEQBCSCZHs3A4qUKQ71x5COY2U747jFc2atCEo2QjxwrTY0Qu5ho7BjQmBZJNgmQhQnY/L8A6E0b+cMKWUd8iM/0xAmT5xmL7TQz2UxL7pr5Qb6Ry1BtBEXEhamdCc6UMJr4kwsjXkDpxhZzrLWwkh4jz5ERxZtdA0Iy+TXzmpmba538OkybUwjT2YxxlY/AiauU/aahqEGVF7Z4FwJLOYEAJkABjz97/FI1JBpolbH7xD60TwuQOpGZ+SA5z7VA+UmzdrZ5ST0TVMgQoKujd1AjViB82gqxDYqrOBw4jaClLZr6YVOAOQO5ujVhREibQ5tTHZ0IIIhBT7g6VxSgLo=";break;}return
json_decode(lzw_decompress(base64_decode($Zb)),true);}function
get_plural_translation_id($u){$_i=array('Too many unsuccessful logins, try again in %d minute(s).'=>129,'%d process(es) have been killed.'=>279,'%d query(s) executed OK.'=>186,'Query executed OK, %d row(s) affected.'=>184,'%d row(s) have been imported.'=>286,'Routine has been called, %d row(s) affected.'=>221,'%d row(s)'=>183,'%d byte(s)'=>41,'%d item(s) have been affected.'=>283,);return
isset($_i[$u])?$_i[$u]:null;}$Nl=$_SESSION["translations"];$Zf=Locale::get()->getLanguage();if($_SESSION["translations_version"]!=1913433917){$Nl=[];$_SESSION["translations_version"]=1913433917;}if($_SESSION["translations_language"]!=$Zf){$Nl=[];$_SESSION["translations_language"]=$Zf;}if(!$Nl){$Nl=get_translations($Zf);$_SESSION["translations"]=$Nl;}Locale::get()->setTranslations($Nl);$xa=null;$zc=false;$xf=null;if(function_exists('\adminneo_instance')){$xa=\adminneo_instance();$zc=true;}elseif(file_exists("adminneo-instance.php")){$xa=include_once"adminneo-instance.php";$zc=true;}if($zc&&!$xa
instanceof
Admin&&!$xa
instanceof
Pluginer){$xa=null;$lg="href=https://github.com/adminneo-org/adminneo#advanced-customizations ".target_blank();$xf=lang(123,"<b>adminneo-instance.php</b>","<b>adminneo_instance()</b>","Admin::create()")." <a $lg>".lang(1)."</a>";}if(!$xa)$xa=Admin::create();if($xf)$xa->addError($xf);if(!defined("AdminNeo\DRIVER")){define("AdminNeo\DRIVER",null);define("AdminNeo\DIALECT",null);}define("AdminNeo\SERVER",DRIVER?$_GET[DRIVER]:null);define("AdminNeo\DB",$_GET["db"]!=""?$_GET["db"]:null);define("AdminNeo\BASE_URL",preg_replace('~\?.*~','',relative_uri()));define("AdminNeo\ME",BASE_URL.'?'.(sid()?session_name()."=".urlencode(session_id()).'&':'').(SERVER!==null?DRIVER."=".urlencode(SERVER).'&':'').($_GET["ext"]?"ext=".urlencode($_GET["ext"]).'&':'').(isset($_GET["username"])?"username=".urlencode($_GET["username"]).'&':'').(DB!=""?'db='.urlencode(DB).'&'.(isset($_GET["ns"])?"ns=".urlencode($_GET["ns"])."&":""):''));define("AdminNeo\HOME_URL",BASE_URL?:".");define("AdminNeo\SERVER_HOME_URL",substr(preg_replace('~\b(username|db|ns)=[^&]*&~','',ME),0,-1)?:".");const
VERSION="5.3.0-dev";if(!ob_get_level())ob_start(null,4096);function
page_header($Cl,$hb=[]){page_headers();if(is_ajax()&&Admin::get()->getErrors()){page_messages();exit;}if(!ob_get_level())ob_start(null,4096);$Cl=strip_tags($Cl);$dk=$hb!==false&&$hb!==null&&SERVER!=""?" - ".h(Admin::get()->getServerName(SERVER)):"";$gk=strip_tags(Admin::get()->getServiceTitle());$El=$Cl.$dk." - ".($gk!=""?$gk:"AdminNeo");if(Admin::get()->getConfig()->isVersionVerificationEnabled()){$n=get_temp_dir()."/adminneo.version";if(!isset($_COOKIE["neo_version"])&&file_exists($n)&&($ig=filemtime($n)+86400-time())>0){$f=unserialize(file_get_contents($n));$_COOKIE["neo_version"]=$f["version"];cookie("neo_version",$f["version"],$ig);}}?>
<!DOCTYPE html>
<html lang="<?=Locale::get()->getLanguage();?>" dir="<?=lang(124);?>">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="robots" content="noindex, nofollow">
	<meta name="viewport" content="width=device-width, initial-scale=1"/>

	<title><?=$El;echo'</title>

	';$Nb=validate_color_variant(Admin::get()->getConfig()->getColorVariant());echo"<link rel='stylesheet' href='",link_files("default-$Nb.css",[]),"'>\n";if(!Admin::get()->isLightModeForced())echo"<link rel='stylesheet' ".(!Admin::get()->isDarkModeForced()?"media='(prefers-color-scheme: dark)' ":"")."href='",link_files("default-$Nb-dark.css",[]),"'>\n";$xl=Admin::get()->getConfig()->getTheme();list($xl,$Nb)=validate_theme($xl,$Nb);if($xl!="default"){echo"<link rel='stylesheet' href='",link_files("$xl-$Nb.css",[]),"'>\n";if(!Admin::get()->isLightModeForced())echo"<link rel='stylesheet' ".(!Admin::get()->isDarkModeForced()?"media='(prefers-color-scheme: dark)' ":"")."href='",link_files("$xl-$Nb-dark.css",[]),"'>\n";}foreach(Admin::get()->getCssUrls()as$km){if(strpos($km,"adminneo-dark.css")===0&&!Admin::get()->isDarkModeForced())echo"<link rel='stylesheet' media='(prefers-color-scheme: dark)' href='",h($km),"'>\n";else
echo"<link rel='stylesheet' href='",h($km),"'>\n";}echo
script_src(link_files("main.js",[]));foreach(Admin::get()->getJsUrls()as$km)echo
script_src($km);Admin::get()->printFavicons();Admin::get()->printToHead();echo'</head>
<body class="',lang(124),' nojs">
<script',nonce(),'>
	const body = document.body;

	body.onkeydown = bodyKeydown;
	body.onclick = bodyClick;
	body.classList.replace("nojs", "js");

	const offlineMessage = \'',js_escape(lang(125)),'\';
	const thousandsSeparator = \'',js_escape(lang(100)),'\';
</script>


',"<div id='help' class='jush-".DIALECT." jsonly hidden'></div>",script("initHelpPopup();"),"<div id='content'>\n","<div class='header'>\n";if($hb!==null){echo'<nav class="breadcrumbs"><ul>','<li><a href="'.h(HOME_URL).'" title="',lang(126),'">',icon_solo("home"),'</a></li>';$bk=SERVER!==null?Admin::get()->getServerName(SERVER):"";$bk=$bk!=""?h($bk):lang(25);if($hb===false)echo"<li>$bk</li>";else{$x=substr(preg_replace('~\b(db|ns)=[^&]*&~','',ME),0,-1);echo"<li><a href='".h($x)."' accesskey='1' title='Alt+Shift+1'>$bk</a></li>";if($_GET["ns"]!=""||(DB!=""&&is_array($hb)))echo'<li><a href="'.h($x."&db=".urlencode(DB).(support("scheme")?"&ns=":"")).'">'.h(DB).'</a></li>';if($hb===true){if($_GET["ns"]!="")echo'<li>'.h($_GET["ns"]).'</li>';else
echo"<li>",h(DB),"</li>";}else{if($_GET["ns"]!="")echo'<li><a href="'.h(substr(ME,0,-1)).'">'.h($_GET["ns"]).'</a></li>';foreach($hb
as$u=>$X){if(is_string($u)){$Oc=(is_array($X)?$X[1]:h($X));if($Oc!="")echo"<li><a href='".h(ME."$u=").urlencode(is_array($X)?$X[0]:$X)."'>$Oc</a></li>";}else
echo"<li>$X</li>\n";}}}echo"</ul></nav>";}echo"</div>\n","<h1>$Cl</h1>\n","<div id='ajaxstatus' class='jsonly hidden'></div>\n";restart_session();page_messages();$g=&get_session("dbs");if(DB!=""&&$g&&!in_array(DB,$g,true))$g=null;stop_session();define("AdminNeo\PAGE_HEADER",1);}function
validate_color_variant($Nb){list(,$Nb)=validate_theme("default",$Nb);return$Nb;}function
validate_theme($xl,$Nb){$yl=get_available_themes();if(!isset($yl[$xl]))$xl="default";if(!isset($yl[$xl][$Nb])){reset($yl[$xl]);$Nb=key($yl[$xl]);}return[$xl,$Nb];}function
get_available_themes(){return
array('default'=>array('green'=>true,),);}function
page_headers(){header("Content-Type: text/html; charset=utf-8");header("Cache-Control: no-cache");header("X-XSS-Protection: 0");header("X-Content-Type-Options: nosniff");header("Referrer-Policy: origin-when-cross-origin");header("X-Frame-Options: DENY");$vc=["script-src"=>"'self' 'unsafe-inline' 'nonce-".get_nonce()."' 'strict-dynamic'","connect-src"=>"'self' https://api.github.com/repos/adminneo-org/adminneo/releases/latest","frame-src"=>"'self'","object-src"=>"'none'","base-uri"=>"'none'","form-action"=>"'self'",];Admin::get()->updateCspHeader($vc);$Tc=[];foreach($vc
as$Sc=>$wk)$Tc[]="$Sc $wk";header("Content-Security-Policy: ".implode("; ",$Tc));Admin::get()->sendHeaders();}function
get_nonce(){static$kh;if(!$kh)$kh=Random::strongKey();return$kh;}function
page_messages(){$jm=preg_replace('~^[^?]*~','',$_SERVER["REQUEST_URI"]);$Ng=isset($_SESSION["messages"][$jm])?$_SESSION["messages"][$jm]:null;if($Ng){foreach($Ng
as$Jg)echo"<div class='message'>$Jg</div>\n",script("initToggles(qsl('.message'));");unset($_SESSION["messages"][$jm]);}foreach(Admin::get()->getErrors()as$j)echo"<div class='error'>$j</div>\n";}function
page_footer($Rg=null){echo"</div>\n","<button id='navigation-button' class='button light navigation-button'>",icon_solo("menu"),icon_solo("close"),"</button>","<div id='navigation-panel' class='navigation-panel'>\n";Admin::get()->printNavigation($Rg);echo"<div class='footer'>\n","<div class='toolbox'>";if($Rg=="auth")language_select();else{$x=h(preg_replace('~\b(db|ns)=[^&]*&~',"",ME)."settings=");echo"<a class='button light' title='",lang(127),"' href='$x'>",icon_solo("settings"),"</a>";}echo"</div>";if($Rg!="auth")Admin::get()->printLogout();echo"</div>\n","</div>\n",script("initNavigation();");}function
int32($Zg){while($Zg>=2147483648)$Zg-=4294967296;while($Zg<=-2147483649)$Zg+=4294967296;return(int)$Zg;}function
long2str($W,$Em){$Dj='';foreach($W
as$X)$Dj
.=pack('V',$X);return$Em?substr($Dj,0,end($W)):$Dj;}function
str2long($Dj,$Em){$W=array_values(unpack('V*',str_pad($Dj,4*ceil(strlen($Dj)/4),"\0")));if($Em)$W[]=strlen($Dj);return$W;}function
xxtea_mx($Tm,$Sm,$Sk,$Nf){return
int32((($Tm>>5&0x7FFFFFF)^$Sm<<2)+(($Sm>>3&0x1FFFFFFF)^$Tm<<4))^int32(($Sk^$Sm)+($Nf^$Tm));}function
xxtea_encrypt_string($wi,$u){$u=array_values(unpack("V*",pack("H*",md5($u))));$W=str2long($wi,true);$Zg=count($W)-1;$Tm=$W[$Zg];$Sm=$W[0];$Si=floor(6+52/($Zg+1));$Sk=0;while($Si-->0){$Sk=int32($Sk+0x9E3779B9);$id=$Sk>>2&3;for($bi=0;$bi<$Zg;$bi++){$Sm=$W[$bi+1];$Xg=xxtea_mx($Tm,$Sm,$Sk,$u[$bi&3^$id]);$Tm=int32($W[$bi]+$Xg);$W[$bi]=$Tm;}$Sm=$W[0];$Xg=xxtea_mx($Tm,$Sm,$Sk,$u[$bi&3^$id]);$Tm=int32($W[$Zg]+$Xg);$W[$Zg]=$Tm;}return
long2str($W,false);}function
xxtea_decrypt_string($f,$u){$u=array_values(unpack("V*",pack("H*",md5($u))));$W=str2long($f,false);$Zg=count($W)-1;$Tm=$W[$Zg];$Sm=$W[0];$Si=floor(6+52/($Zg+1));$Sk=int32($Si*0x9E3779B9);while($Sk){$id=$Sk>>2&3;for($bi=$Zg;$bi>0;$bi--){$Tm=$W[$bi-1];$Xg=xxtea_mx($Tm,$Sm,$Sk,$u[$bi&3^$id]);$Sm=int32($W[$bi]-$Xg);$W[$bi]=$Sm;}$Tm=$W[$Zg];$Xg=xxtea_mx($Tm,$Sm,$Sk,$u[$bi&3^$id]);$Sm=int32($W[0]-$Xg);$W[0]=$Sm;$Sk=int32($Sk-0x9E3779B9);}return
long2str($W,true);}const
ENCRYPTION_GCM='aes-256-gcm';const
ENCRYPTION_CBC='aes-256-cbc';const
ENCRYPTION_TAG_LENGTH=16;const
ENCRYPTION_HMAC_LENGTH=64;function
generate_iv($v){if(function_exists('random_bytes')){try{return
random_bytes($v);}catch(Exception$id){}}return
openssl_random_pseudo_bytes($v);}function
hash_key($u){return
substr(hash('sha512',$u,true),0,32);}function
aes_encrypt_string($wi,$u){$Pg=PHP_VERSION_ID>=70100&&in_array(ENCRYPTION_GCM,openssl_get_cipher_methods())?ENCRYPTION_GCM:ENCRYPTION_CBC;$u=hash_key($u);$If=generate_iv(openssl_cipher_iv_length($Pg)?:16);if($Pg==ENCRYPTION_GCM)$Db=openssl_encrypt($wi,$Pg,$u,OPENSSL_RAW_DATA,$If,$nl,"",ENCRYPTION_TAG_LENGTH);else{$Db=openssl_encrypt($wi,$Pg,$u,OPENSSL_RAW_DATA,$If);$nl=hash_hmac("sha512",$If.$Db,$u,true);}if($Db===false)return
false;return$If.$nl.$Db;}function
aes_decrypt_string($f,$u){$Pg=PHP_VERSION_ID>=70100&&in_array(ENCRYPTION_GCM,openssl_get_cipher_methods())?ENCRYPTION_GCM:ENCRYPTION_CBC;$Jf=openssl_cipher_iv_length($Pg)?:16;$ol=$Pg==ENCRYPTION_GCM?ENCRYPTION_TAG_LENGTH:ENCRYPTION_HMAC_LENGTH;if(strlen($f)<$Jf+$ol)return
false;$u=hash_key($u);$If=substr($f,0,$Jf);$nl=substr($f,$Jf,$ol);$Db=substr($f,$Jf+$ol);if($If===false||$nl===false||$Db===false)return
false;if($Pg==ENCRYPTION_GCM)return
openssl_decrypt($Db,$Pg,$u,OPENSSL_RAW_DATA,$If,$nl);else{$af=hash_hmac('sha512',$If.$Db,$u,true);if(!hash_equals($nl,$af))return
false;return
openssl_decrypt($Db,$Pg,$u,OPENSSL_RAW_DATA,$If);}}function
encrypt_string($wi,$u){if($wi=="")return"";if(extension_loaded('openssl'))return
aes_encrypt_string($wi,$u);else
return
xxtea_encrypt_string($wi,$u);}function
decrypt_string($f,$u){if($f=="")return"";if(extension_loaded('openssl'))return
aes_decrypt_string($f,$u);else
return
xxtea_decrypt_string($f,$u);}$ui=[];if($_COOKIE["neo_permanent"]){foreach(explode(" ",$_COOKIE["neo_permanent"])as$X){list($u)=explode(":",$X);$ui[$u]=$X;}}function
validate_server_input(array&$ui){if(SERVER=="")return;$ni=parse_url(SERVER);if(!$ni)auth_error($ui);if(isset($ni['user'])||isset($ni['pass'])||isset($ni['query'])||isset($ni['fragment']))auth_error($ui);if(isset($ni['scheme'])&&!preg_match('~^(https?)$~i',$ni['scheme']))auth_error($ui);$df=(isset($ni['host'])?$ni['host']:'').(isset($ni['path'])?$ni['path']:'');if(!is_server_host_valid($df))auth_error($ui);if(isset($ni['port'])&&($ni['port']<1024||$ni['port']>65535))auth_error($ui,lang(128));}if(!function_exists('AdminNeo\is_server_host_valid')){function
is_server_host_valid($df){return
strpos($df,'/')===false;}}function
build_http_url($O,$V,$E,$Ic,$Hc=null){if(!preg_match('~^(https?://)?([^:]*)(:\d+)?$~',rtrim($O,'/'),$z))return
null;return($z[1]?:"http://").($V!==""||$E!==""?urlencode($V).":".urlencode($E)."@":"").($z[2]!==""?$z[2]:$Ic).(isset($z[3])?$z[3]:($Hc?":$Hc":""));}function
add_invalid_login(){$bb=get_temp_dir()."/adminneo.invalid";$m=null;foreach(glob("$bb*")?:[$bb]as$n){$m=open_file_with_lock($n);if($m)break;}if(!$m){$m=open_file_with_lock("$bb-".Random::strongKey());if(!$m)return;}$_f=unserialize(stream_get_contents($m));$_l=time();if($_f){foreach($_f
as$Af=>$X){if($X[0]<$_l)unset($_f[$Af]);}}$zf=&$_f[Admin::get()->getBruteForceKey()];if(!$zf)$zf=[$_l+30*60,0];$zf[1]++;write_and_unlock_file($m,serialize($_f));}function
check_invalid_login(array&$ui){$bb=get_temp_dir()."/adminneo.invalid";$_f=[];foreach(glob("$bb*")as$n){$m=open_file_with_lock($n);if($m){$_f=unserialize(stream_get_contents($m));unlock_file($m);break;}}$zf=($_f?$_f[Admin::get()->getBruteForceKey()]:[]);$jh=($zf&&$zf[1]>29?$zf[0]-time():0);if($jh>0)auth_error($ui,lang(129,ceil($jh/60)));}function
connect_to_db(array&$ui){if(Admin::get()->getConfig()->hasServers()&&!Admin::get()->getConfig()->getServer(SERVER))auth_error($ui);$e=connect(true,$j);if(!$e)connection_error(nl2br(h($j)),$ui);return$e;}function
authenticate(array&$ui){$I=Admin::get()->authenticate($_GET["username"],get_password());if($I!==true)connection_error($I,$ui);}function
connection_error($j,array&$ui){$j=$j?:lang(3);if(preg_match('~^ +| +$~',get_password()))$j
.="<br>".lang(130);auth_error($ui,$j);}Admin::get()->init();$Qa=isset($_POST["auth"])?$_POST["auth"]:null;if($Qa){session_regenerate_id();$O=isset($Qa["server"])?$Qa["server"]:"";$ck=Admin::get()->getConfig()->getServer($O);$Yc=$ck?$ck->getDriver():(isset($Qa["driver"])?$Qa["driver"]:"");$O=$ck?$O:trim($O);$V=isset($Qa["username"])?$Qa["username"]:"";$E=isset($Qa["password"])?$Qa["password"]:"";if($ck&&$ck->hasCredentials()&&$V==""&&$E==""){$V=$ck->getUsername();$E=$ck->getPassword();}$h=$ck?$ck->getDatabase():(isset($Qa["db"])?$Qa["db"]:"");save_login($Yc,$O,$V,$E,$h);if($Qa["permanent"]){$u=implode("-",array_map("base64_encode",[$Yc,$O,$V,$h]));$Ki=Admin::get()->getPrivateKey(true);$td=$Ki?encrypt_string($E,$Ki):false;$ui[$u]="$u:".base64_encode($td?:"");cookie("neo_permanent",implode(" ",$ui));}if(count($_POST)==1||DRIVER!=$Yc||SERVER!=$O||$_GET["username"]!==$V||DB!=$h)redirect(auth_url($Yc,$O,$V,$h));}elseif($_POST["logout"]&&(!$_SESSION["token"]||verify_token())){foreach(["pwds","db","dbs","queries"]as$u)set_session($u,null);unset_permanent($ui);redirect(SERVER_HOME_URL,lang(131));}elseif($ui&&!$_SESSION["pwds"]){session_regenerate_id();$Ki=Admin::get()->getPrivateKey();foreach($ui
as$u=>$X){list(,$Cb)=explode(":",$X);list($Yc,$O,$V,$h)=array_map("base64_decode",explode("-",$u));$E=$Ki?decrypt_string(base64_decode($Cb),$Ki):false;save_login($Yc,$O,$V,$E,$h);}}function
save_login($Yc,$O,$V,$E,$h=""){set_password($Yc,$O,$V,$E);$_SESSION["db"][$Yc][$O][$V][$h]=true;}function
unset_permanent(array&$ui){foreach($ui
as$u=>$X){list($Yc,$O,$V,$h)=array_map("base64_decode",explode("-",$u));if($Yc==DRIVER&&$O==SERVER&&$V==$_GET["username"]&&$h==DB)unset($ui[$u]);}cookie("neo_permanent",implode(" ",$ui));}function
auth_error(array&$ui,$j=null){$hk=session_name();if(isset($_GET["username"])){header("HTTP/1.1 403 Forbidden");if(($_COOKIE[$hk]||$_GET[$hk])&&!$_SESSION["token"])$j=lang(132);else{restart_session();add_invalid_login();$E=get_password();if($E!==null){if($E===false)$j=lang(133);set_password(DRIVER,SERVER,$_GET["username"],null);}unset_permanent($ui);}}if(!$_COOKIE[$hk]&&$_GET[$hk]&&ini_bool("session.use_only_cookies"))$j=lang(134);if(!$j)$j=lang(3);Admin::get()->addError($j);print_login_page();}function
print_login_page(){$D=session_get_cookie_params();cookie("neo_key",($_COOKIE["neo_key"]?:Random::strongKey()),$D["lifetime"]);if(!$_SESSION["token"])$_SESSION["token"]=rand(1,1e6);page_header(lang(30),null);echo"<form action='' method='post'>\n","<div>";if(print_hidden_fields($_POST,["auth"]))echo"<p class='message'>".lang(135)."\n";echo"</div>\n";Admin::get()->printLoginForm();echo"</form>\n";page_footer("auth");exit;}if(isset($_GET["username"])&&!DRIVER){Admin::get()->addError(lang(136));page_header(lang(137),false);page_footer("auth");exit;}if(isset($_GET["username"])&&!defined('AdminNeo\DRIVER_EXTENSION')){Admin::get()->addError(lang(138,implode(", ",Drivers::getExtensions(DRIVER))));unset($_SESSION["pwds"][DRIVER]);unset_permanent($ui);page_header(lang(139),false);page_footer("auth");exit;}if(!isset($_GET["username"])||get_password()===null)print_login_page();validate_server_input($ui);check_invalid_login($ui);Admin::get()->getConfig()->applyServer(SERVER);$e=connect_to_db($ui);authenticate($ui);create_driver($e);if($_POST["logout"]&&$_SESSION["token"]&&!verify_token()){Admin::get()->addError(lang(140));page_header(lang(5));page_footer("db");exit;}if(!$_SESSION["token"])$_SESSION["token"]=rand(1,1e6);stop_session(true);if($Qa&&$_POST["token"])$_POST["token"]=get_token();if($_POST){if(!verify_token()){$tf="max_input_vars";$Eg=ini_get($tf);if(extension_loaded("suhosin")){foreach(["suhosin.request.max_vars","suhosin.post.max_vars"]as$u){$X=ini_get($u);if($X&&(!$Eg||$X<$Eg)){$tf=$u;$Eg=$X;}}}if(!$_POST["token"]&&$Eg)Admin::get()->addError(lang(141,"'$tf'"));else
Admin::get()->addError(lang(140).' '.lang(142));$_POST=[];}}elseif($_SERVER["REQUEST_METHOD"]=="POST"){$j=lang(143,"'post_max_size'");if(isset($_GET["sql"]))$j
.=' '.lang(144);Admin::get()->addError($j);}if(isset($_GET["settings"])){$P=Admin::get()->getSettings();$kk=array_merge(Admin::get()->getSettingsRows(1),Admin::get()->getSettingsRows(2),Admin::get()->getSettingsRows(3));if($_POST){$D=[];foreach($kk
as$u=>$K){if($u!="lang"&&isset($_POST[$u])){$mm=$_POST[$u]===""||(is_array($_POST[$u])&&in_array("",$_POST[$u]));$D[$u]=(!$mm?$_POST[$u]:null);}}$P->updateParameters($D);redirect(remove_from_uri());}$Cl=lang(127);page_header($Cl,[$Cl]);echo"<form id='settings' action='' method='post'>\n","<table class='box'>\n";foreach($kk
as$K)echo$K;echo"</table>\n","<p>","<input type='submit' value='".lang(107),"' class='button default hidden'>",input_token(),"</p>\n","</form>\n",script("initSettingsForm();");page_footer();exit;}if(isset($_GET["status"]))$_GET["variables"]=$_GET["status"];if(isset($_GET["import"]))$_GET["sql"]=$_GET["import"];if(!(DB!=""?Connection::get()->selectDatabase(DB):isset($_GET["sql"])||isset($_GET["dump"])||isset($_GET["database"])||isset($_GET["processlist"])||isset($_GET["privileges"])||isset($_GET["user"])||isset($_GET["variables"])||$_GET["script"]=="connect"||$_GET["script"]=="kill")){if(DB!=""||$_GET["refresh"]){restart_session();set_session("dbs",null);}if(DB!=""){Admin::get()->addError(lang(145));header("HTTP/1.1 404 Not Found");page_header(lang(29).": ".h(DB),true);}else{if($_POST["db"])queries_redirect(substr(ME,0,-1),lang(146),drop_databases($_POST["db"]));$bk=Admin::get()->getServerName(SERVER);$Cl=h(Drivers::get(DRIVER)).": ".($bk!=""?h($bk):lang(25));page_header($Cl,false);$mg=['privileges'=>[lang(69),"users"],'processlist'=>[lang(147),"list"],'variables'=>[lang(148),"variable"],'status'=>[lang(149),"status"],];$ng="";foreach($mg
as$u=>$X){if(support($u))$ng
.="<a href='".h(ME)."$u='>".icon($X[1])."$X[0]</a>";}if($ng)echo"<p class='links top-links'>$ng</p>\n";echo"<p>".lang(150,Drivers::get(DRIVER),"<b>".h(Connection::get()->getVersion())."</b>","<b>".DRIVER_EXTENSION."</b>")."\n","<p>".lang(151,"<b>".h(logged_user())."</b>")."\n";$g=Admin::get()->getDatabases();if($g){$Ij=support("scheme");$Ha=collations();echo"<form action='' method='post'>\n","<div class='table-footer-parent'>\n","<div class='scrollable'>\n","<table class='checkable'>\n",script("mixin(qsl('table'), {onclick: tableClick, ondblclick: partialArg(tableClick, true)});"),"<thead><tr>".(support("database")?"<td>":"")."<th>".lang(29).(get_session("dbs")!==null?" - <a href='".h(ME)."refresh=1'>".lang(152)."</a>":"")."<td>".lang(44)."<td>".lang(153)."<td>".lang(154)." - <a href='".h(ME)."dbsize=1'>".lang(155)."</a>".script("qsl('a').onclick = partial(ajaxSetHtml, '".js_escape(ME)."script=connect');","")."</thead>\n";$g=($_GET["dbsize"]?count_tables($g):array_flip($g));foreach($g
as$h=>$T){$xj=h(ME)."db=".urlencode($h);$q=h("Db-".$h);echo"<tr>".(support("database")?"<td class='actions'>".checkbox("db[]",$h,in_array($h,(array)$_POST["db"]),"","","",$q):""),"<th><a href='$xj' id='$q'>".h($h)."</a>";$Jb=h(db_collation($h,$Ha));echo"<td>".(support("database")?"<a href='$xj".($Ij?"&amp;ns=":"")."&amp;database=' title='".lang(66)."'>$Jb</a>":$Jb),"<td align='right'><a href='$xj&amp;schema=' id='tables-".h($h)."' title='".lang(68)."'>".($_GET["dbsize"]?$T:"?")."</a>","<td align='right' id='size-".h($h)."'>".($_GET["dbsize"]?db_size($h):"?"),"\n";}echo"</table>\n","</div>\n";if(support("database"))echo"<div class='table-footer'><div class='field-sets'>\n","<fieldset><legend>",lang(156)," <span id='selected'></span></legend><div class='fieldset-content'>\n",input_hidden("all"),script("qsl('input').onclick = function () { selectCount('selected', formChecked(this, /^db/)); };"),"<input type='submit' class='button' name='drop' value='",lang(157),"'>",confirm(),"\n","</div></fieldset>\n","</div></div>\n",script("initTableFooter()");echo"</div>\n",input_token(),"</form>\n",script("tableCheck();");}}echo'<p class="links"><a href="'.h(ME).'database=">'.icon("database-add").lang(72)."</a>\n";page_footer("db");exit;}if(support("scheme")){if(DB!=""&&$_GET["ns"]!==""){if(!isset($_GET["ns"]))redirect(preg_replace('~ns=[^&]*&~','',ME)."ns=".get_schema());if(!set_schema($_GET["ns"])){Admin::get()->addError(lang(158));header("HTTP/1.1 404 Not Found");page_header(lang(77).": ".h($_GET["ns"]),true);page_footer("ns");exit;}}}if(isset($_GET["select"])&&($_POST["edit"]||$_POST["clone"])&&!$_POST["save"])$_GET["edit"]=$_GET["select"];if(isset($_GET["callf"]))$_GET["call"]=$_GET["callf"];if(isset($_GET["function"]))$_GET["procedure"]=$_GET["function"];if(isset($_GET["download"])){$a=$_GET["download"];$l=fields($a);header("Content-Type: application/octet-stream");header("Content-Disposition: attachment; filename=".friendly_url("$a-".implode("_",$_GET["where"])).".".friendly_url($_GET["field"]));$M=[idf_escape($_GET["field"])];$I=Driver::get()->select($a,$M,[where($_GET,$l)],$M);$K=($I?$I->fetchRow():[]);echo
Connection::get()->formatValue($K[0],$l[$_GET["field"]]);exit;}elseif(isset($_GET["table"])){$a=$_GET["table"];$l=fields($a);if(!$l)Admin::get()->addError(error());$S=table_status1($a,true);$_=Admin::get()->getTableName($S);$wj=[];foreach($l
as$u=>$k)$wj+=$k["privileges"];$Cl=$l&&is_view($S)?$S['Engine']=='materialized view'?lang(159):lang(160):lang(7);$fl=$_!=""?$_:h($a);page_header("$Cl: $fl",[$fl]);$ik=null;if(isset($wj["insert"])||!support("table"))$ik="";Admin::get()->printTableMenu($S,$ik);$sf=[];if(!preg_match("~sqlite|mssql|pgsql~",DIALECT)&&isset($S["Engine"]))$sf[]=lang(161).": ".h($S["Engine"]);if(isset($S["Collation"]))$sf[]=lang(44).": ".h($S["Collation"]);if($sf)echo"<p>",implode(", ",$sf),"</p>";if($l)Admin::get()->printTableStructure($l);$Tb=$S["Comment"];if($Tb!="")echo"<p class='keep-lines'>",lang(45),": ",Admin::get()->formatComment($Tb),"</p>\n";if(is_view($S))$kd='<p class="links"><a href="'.h(ME).'view='.urlencode($a).'">'.icon("edit").lang(34)."</a>\n";else$kd='<p class="links"><a href="'.h(ME).'create='.urlencode($a).'">'.icon("edit").lang(35)."</a>\n";if($sf||$l||$Tb!="")echo$kd;if(support("partitioning")&&preg_match("~partitioned~",$S["Create_options"])){echo"<h2 id='partition-by'>".lang(162)."</h2>\n";$mi=get_partitions_info($a);Admin::get()->printTablePartitions($mi);echo$kd;}if(support("indexes")&&Driver::get()->supportsIndex($S)){echo"<h2 id='indexes'>".lang(163)."</h2>\n";$t=indexes($a);if($t)Admin::get()->printTableIndexes($t);echo'<p class="links"><a href="'.h(ME).'indexes='.urlencode($a).'">'.icon("edit").lang(164)."</a>\n";}if(!is_view($S)){if(fk_support($S)){echo"<h2 id='foreign-keys'>".lang(86)."</h2>\n";$qe=foreign_keys($a);if($qe){echo"<table>\n","<thead><tr><th>".lang(165)."<td>".lang(166)."<td>".lang(89)."<td>".lang(88)."<td></thead>\n";foreach($qe
as$_=>$o)echo"<tr title='".h($_)."'>","<th><i>".implode("</i>, <i>",array_map('AdminNeo\h',$o["source"]))."</i>","<td><a href='".h($o["db"]!=""?preg_replace('~db=[^&]*~',"db=".urlencode($o["db"]),ME):($o["ns"]!=""?preg_replace('~ns=[^&]*~',"ns=".urlencode($o["ns"]),ME):ME))."table=".urlencode($o["table"])."'>".($o["db"]!=""&&$o["db"]!=DB?"<b>".h($o["db"])."</b>.":"").($o["ns"]!=""&&$o["ns"]!=$_GET["ns"]?"<b>".h($o["ns"])."</b>.":"").h($o["table"])."</a>","(<i>".implode("</i>, <i>",array_map('AdminNeo\h',$o["target"]))."</i>)","<td>".h($o["on_delete"]),"<td>".h($o["on_update"]),'<td><a href="'.h(ME.'foreign='.urlencode($a).'&name='.urlencode($_)).'">'.lang(167).'</a>',"\n";echo"</table>\n";}echo'<p class="links"><a href="'.h(ME).'foreign='.urlencode($a).'">'.icon("add").lang(168)."</a>\n";}if(support("check")){echo"<h2 id='checks'>".lang(169)."</h2>\n";$wb=Driver::get()->checkConstraints($a);if($wb){echo"<table cellspacing='0'>\n";foreach($wb
as$u=>$X)echo"<tr title='".h($u)."'>","<td><code class='jush-".DIALECT."'>".h($X),"<td><a href='".h(ME.'check='.urlencode($a).'&name='.urlencode($u))."'>".lang(167)."</a>","\n";echo"</table>\n";}echo'<p class="links"><a href="'.h(ME).'check='.urlencode($a).'">'.icon("add").lang(170)."</a>\n";}}if(support(is_view($S)?"view_trigger":"trigger")){echo"<h2 id='triggers'>".lang(171)."</h2>\n";$Tl=triggers($a);if($Tl){echo"<table>\n";foreach($Tl
as$u=>$X)echo"<tr><td>".h($X[0])."<td>".h($X[1])."<th>".h($u)."<td><a href='".h(ME.'trigger='.urlencode($a).'&name='.urlencode($u))."'>".lang(167)."</a>\n";echo"</table>\n";}echo'<p class="links"><a href="'.h(ME).'trigger='.urlencode($a).'">'.icon("add").lang(172)."</a>\n";}}elseif(isset($_GET["schema"])){$Dl=h(": ".DB.($_GET["ns"]?".$_GET[ns]":""));page_header(lang(68).$Dl,[lang(68)]);$hl=[];$il=[];$la=($_GET["schema"]?:$_COOKIE["neo_schema-".str_replace(".","_",DB)]);preg_match_all('~([^:]+):([-0-9.]+)x([-0-9.]+)(_|$)~',$la,$z,PREG_SET_ORDER);foreach($z
as$p=>$y){$hl[$y[1]]=[$y[2],$y[3]];$il[]="\n\t'".js_escape($y[1])."': [ $y[2], $y[3] ]";}$Il=0;$ab=-1;$Gj=[];$gj=[];$fg=[];$Ia=Driver::get()->getAllFields();foreach(table_status('',true)as$R=>$S){if(is_view($S))continue;$Bi=0;$Gj[$R]["fields"]=[];foreach($Ia[$R]as$k){$Bi+=1.25;$k["pos"]=$Bi;$Gj[$R]["fields"][$k["field"]]=$k;}$Gj[$R]["pos"]=(isset($hl[$R])?$hl[$R]:[$Il,0]);foreach(Admin::get()->getForeignKeys($R)as$X){if(!$X["db"]){$dg=$ab;if((isset($hl[$R][1])?$hl[$R][1]:0)||(isset($hl[$X["table"]][1])?$hl[$X["table"]][1]:0))$dg=min(floatval(isset($hl[$R][1])?$hl[$R][1]:0),floatval(isset($hl[$X["table"]][1])?$hl[$X["table"]][1]:0))-1;else$ab-=.1;while($fg[(string)$dg])$dg-=.0001;$Gj[$R]["references"][$X["table"]][(string)$dg]=[$X["source"],$X["target"]];$gj[$X["table"]][$R][(string)$dg]=$X["target"];$fg[(string)$dg]=true;}}$Il=max($Il,$Gj[$R]["pos"][0]+2.5+$Bi);}echo"<div id='schema' style='height: {$Il}em;'>\n","<script",nonce(),">\n","gid('schema').onselectstart = () => false;\n","const tablePos = {",implode(",",$il),"\n};\n","const em = gid('schema').offsetHeight / $Il;\n","document.onmousemove = schemaMousemove;\n","document.onmouseup = partialArg(schemaMouseup, '",js_escape(DB),"');\n","</script>\n";foreach($Gj
as$_=>$R){echo"<div class='table' style='top: ".$R["pos"][0]."em; left: ".$R["pos"][1]."em;'>",'<a href="'.h(ME).'table='.urlencode($_).'"><b>'.h($_)."</b></a>",script("qsl('div').onmousedown = schemaMousedown;");foreach($R["fields"]as$k){$X='<span'.type_class($k["type"]).' title="'.h($k["type"].($k["length"]?"($k[length])":"").($k["null"]?" NULL":'')).'">'.h($k["field"]).'</span>';echo"<br>".($k["primary"]?"<i>$X</i>":$X);}foreach((array)$R["references"]as$ql=>$hj){foreach($hj
as$dg=>$dj){$eg=$dg-(isset($hl[$_][1])?$hl[$_][1]:0);$p=0;foreach($dj[0]as$vk){echo"\n<div class='references' title='",h($ql),"' id='refs$dg-$p' style='left: {$eg}em; top: ",$R["fields"][$vk]["pos"],"em; padding-top: .5em;'>","<div style='border-top: 1px solid Gray; width: ".(-$eg)."em;'></div>","</div>";$p++;}}}foreach((array)$gj[$_]as$ql=>$hj){foreach($hj
as$dg=>$d){$eg=$dg-(isset($hl[$_][1])?$hl[$_][1]:0);$p=0;foreach($d
as$pl){echo"\n<div class='references' title='",h($ql),"' id='refd$dg-$p' style='left: {$eg}em; top: ".$R["fields"][$pl]["pos"]."em; height: 1.25em;'>","<svg style='width: 1em; height: 1em; float: right;' viewBox='0 0 22 22' fill='currentColor'><path d='M11,19l10,-8l-10,-8l0,16Z'/></svg>","<div style='height: .5em; border-bottom: 1px solid Gray; width: ".(-$eg)."em;'></div>","</div>";$p++;}}}echo"\n</div>\n";}foreach($Gj
as$R){foreach((array)$R["references"]as$ql=>$hj){foreach($hj
as$dg=>$dj){$Qg=$Il;$Cg=-10;foreach($dj[0]as$u=>$vk){$Ci=$R["pos"][0]+$R["fields"][$vk]["pos"];$Di=$Gj[$ql]["pos"][0]+$Gj[$ql]["fields"][$dj[1][$u]]["pos"];$Qg=min($Qg,$Ci,$Di);$Cg=max($Cg,$Ci,$Di);}echo"<div class='references' id='refl$dg' style='left: $dg"."em; top: $Qg"."em; padding: .5em 0;'><div style='border-right: 1px solid Gray; margin-top: 1px; height: ".($Cg-$Qg)."em;'></div></div>\n";}}}echo"</div>\n","<p class='links'>","<a href='",(ME."schema=".urlencode($la)),"' id='schema-link'>",lang(173),"</a>","</p>\n";}elseif(isset($_GET["dump"])){$a=$_GET["dump"];$P=Admin::get()->getSettings();if($_POST){$P->updateParameters(["dumpFormat"=>$_POST["format"],"dumpDbStyle"=>$_POST["db_style"],"dumpTypes"=>isset($_POST["types"])?$_POST["types"]:null,"dumpRoutines"=>isset($_POST["routines"])?$_POST["routines"]:null,"dumpEvents"=>isset($_POST["events"])?$_POST["events"]:null,"dumpTableStyle"=>$_POST["table_style"],"dumpAutoIncrement"=>isset($_POST["auto_increment"])?$_POST["auto_increment"]:null,"dumpTriggers"=>isset($_POST["triggers"])?$_POST["triggers"]:null,"dumpDataStyle"=>$_POST["data_style"],"dumpOutput"=>$_POST["output"],]);$Pk=array_flip(isset($_POST["databases"])?$_POST["databases"]:[])+array_flip(isset($_POST["tables"])?$_POST["tables"]:[])+array_flip(isset($_POST["data"])?$_POST["data"]:[]);if(count($Pk)==1)$gf=key($Pk);elseif(DB!==null)$gf=DB;else$gf=SERVER!=""?Admin::get()->getServerName(SERVER):"localhost";$Nd=dump_headers($gf,DB==null||count($Pk)>1);$Ef=preg_match('~sql~',$_POST["format"]);if($Ef){echo"-- AdminNeo ".VERSION." ".Drivers::get(DRIVER)." ".Connection::get()->getVersion()." dump\n\n";if(DIALECT=="sql"){echo"SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
".($_POST["data_style"]?"SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';
":"")."
";Connection::get()->query("SET time_zone = '+00:00'");Connection::get()->query("SET sql_mode = ''");}}$Nk=$_POST["db_style"];$g=[DB];if(DB==""){$g=$_POST["databases"];if(is_string($g))$g=explode("\n",rtrim(str_replace("\r","",$g),"\n"));}foreach((array)$g
as$h){Admin::get()->dumpDatabase($h);if(Connection::get()->selectDatabase($h)){if($Ef&&preg_match('~CREATE~',$Nk)&&($rc=Connection::get()->getValue("SHOW CREATE DATABASE ".idf_escape($h),1))){set_utf8mb4($rc);if($Nk=="DROP+CREATE")echo"DROP DATABASE IF EXISTS ".idf_escape($h).";\n";echo"$rc;\n";}if($Ef){if($Nk)echo
use_sql($h).";\n\n";$Xh="";if($_POST["types"]){foreach(types()as$q=>$U){$xd=type_values($q);if($xd)$Xh
.=($Nk!='DROP+CREATE'?"DROP TYPE IF EXISTS ".idf_escape($U).";;\n":"")."CREATE TYPE ".idf_escape($U)." AS ENUM ($xd);\n\n";else$Xh
.="-- Could not export type $U\n\n";}}if($_POST["routines"]){foreach(routines()as$K){$_=$K["ROUTINE_NAME"];$yj=$K["ROUTINE_TYPE"];$rc=create_routine($yj,["name"=>$_]+routine($K["SPECIFIC_NAME"],$yj));set_utf8mb4($rc);$Xh
.=($Nk!='DROP+CREATE'?"DROP $yj IF EXISTS ".idf_escape($_).";;\n":"")."$rc;\n\n";}}if($_POST["events"]){foreach(get_rows("SHOW EVENTS",null,"-- ")as$K){$rc=remove_definer(Connection::get()->getValue("SHOW CREATE EVENT ".idf_escape($K["Name"]),3));set_utf8mb4($rc);$Xh
.=($Nk!='DROP+CREATE'?"DROP EVENT IF EXISTS ".idf_escape($K["Name"]).";;\n":"")."$rc;;\n\n";}}echo($Xh&&DIALECT=='sql'?"DELIMITER ;;\n\n$Xh"."DELIMITER ;\n\n":$Xh);}if($_POST["table_style"]||$_POST["data_style"]){$Bm=[];foreach(table_status('',true)as$_=>$S){$R=(DB==""||in_array($_,(array)$_POST["tables"]));$f=(DB==""||in_array($_,(array)$_POST["data"]));if($R||$f){if($Nd=="tar"){$Fl=new
TmpFile;ob_start([$Fl,'write'],1e5);}Admin::get()->dumpTable($_,($R?$_POST["table_style"]:""),(is_view($S)?2:0));if(is_view($S))$Bm[]=$_;elseif($f){$l=fields($_);Admin::get()->dumpData($_,$_POST["data_style"],"SELECT *".convert_fields($l,$l)." FROM ".table($_));}if($Ef&&$_POST["triggers"]&&$R&&($Tl=trigger_sql($_)))echo"\nDELIMITER ;;\n$Tl\nDELIMITER ;\n";if($Nd=="tar"){ob_end_flush();tar_file((DB!=""?"":"$h/")."$_.csv",$Fl);}elseif($Ef)echo"\n";}}if(function_exists('AdminNeo\foreign_keys_sql')){foreach(table_status('',true)as$_=>$S){$R=(DB==""||in_array($_,(array)$_POST["tables"]));if($R&&!is_view($S))echo
foreign_keys_sql($_);}}foreach($Bm
as$_m)Admin::get()->dumpTable($_m,$_POST["table_style"],1);if($Nd=="tar")echo
pack("x512");}}}if($Ef)echo"-- ".gmdate("Y-m-d H:i:s e")."\n";exit;}$_=DB!==null?h(DB):(SERVER!=""?h(Admin::get()->getServerName(SERVER)):lang(25));page_header(lang(71).": $_",($_GET["export"]!=""?["table"=>$_GET["export"]]:[lang(71)]));echo"<form action='' method='post'>\n","<table class='box'>\n";$Ec=['','USE','DROP+CREATE','CREATE'];$jl=['','DROP+CREATE','CREATE'];$Ac=['','TRUNCATE+INSERT','INSERT'];if(DIALECT=="sql")$Ac[]='INSERT+UPDATE';echo"<tr><th>",lang(174),"</th><td>",html_radios("format",Admin::get()->getDumpFormats(),$P->getParameter("dumpFormat","sql")),"</td></tr>\n";if(DIALECT!="sqlite"){echo"<tr><th>",lang(29),"</th>","<td>",html_select('db_style',$Ec,$P->getParameter("dumpDbStyle",DB==""?"CREATE":"")),"<span class='labels'>";if(support("type"))echo
checkbox("types",1,$P->getParameter("dumpTypes"),lang(113));if(support("routine"))echo
checkbox("routines",1,$P->getParameter("dumpRoutines",$_GET["dump"]==""?"1":""),lang(175));if(support("event"))echo
checkbox("events",1,$P->getParameter("dumpEvents",$_GET["dump"]==""?"1":""),lang(176));echo"</span></td></tr>";}echo"<tr><th>",lang(153),"</th><td>",html_select('table_style',$jl,$P->getParameter("dumpTableStyle","DROP+CREATE"))," <span class='labels'>",checkbox("auto_increment",1,$P->getParameter("dumpAutoIncrement"),lang(46));if(support("trigger"))echo
checkbox("triggers",1,$P->getParameter("dumpTriggers","1"),lang(171));echo"</span></td></tr>","<tr><th>",lang(177),"</th><td>",html_select("data_style",$Ac,$P->getParameter("dumpDataStyle","INSERT")),"</td></tr>","<tr><th>",lang(178),"</th><td>",html_radios("output",Admin::get()->getDumpOutputs(),$P->getParameter("dumpOutput","file")),"</td></tr>\n","</table>\n","<p>","<input type='submit' class='button default' value='",lang(71),"'>",input_token(),"</p>\n","<table>\n",script("qsl('table').onclick = dumpClick;");$Gi=[];if(DB!=""){$zb=($a!=""?"":" checked");echo"<thead><tr>","<th><label class='block'><input type='checkbox' id='check-tables'$zb>".lang(153)."</label>".script("gid('check-tables').onclick = partial(formCheck, /^tables\\[/);",""),"<th class='right'><label class='block'>".lang(177)."<input type='checkbox' id='check-data'$zb></label>".script("gid('check-data').onclick = partial(formCheck, /^data\\[/);",""),"</thead>\n";$Bm="";$ll=tables_list();foreach($ll
as$_=>$U){$Fi=preg_replace('~_.*~','',$_);$zb=($a==""||$a==(substr($a,-1)=="%"?"$Fi%":$_));$Ji="<tr><td>".checkbox("tables[]",$_,$zb,$_,"","block");if($U!==null&&!preg_match('~table~i',$U))$Bm
.="$Ji\n";else
echo"$Ji<td class='right'><label class='block'><span id='Rows-".h($_)."'></span>".checkbox("data[]",$_,$zb)."</label>\n";$Gi[$Fi]++;}echo$Bm;if($ll)echo
script("ajaxSetHtml('".js_escape(ME)."script=db');");}else{echo"<thead><tr><th>","<label class='block'><input type='checkbox' id='check-databases'".($a==""?" checked":"").">".lang(29)."</label>",script("gid('check-databases').onclick = partial(formCheck, /^databases\\[/);",""),"</thead>\n";$g=Admin::get()->getDatabases();if($g){foreach($g
as$h){if(!information_schema($h)){$Fi=preg_replace('~_.*~','',$h);echo"<tr><td>".checkbox("databases[]",$h,$a==""||$a=="$Fi%",$h,"","block")."\n";$Gi[$Fi]++;}}}else
echo"<tr><td><textarea name='databases' rows='10' cols='20'></textarea>";}echo"</table>\n","</form>\n";$mg=[];foreach($Gi
as$u=>$X){if($u!=""&&$X>1)$mg[]="<a href='".h(ME)."dump=".urlencode("$u%")."'>".icon("check").h($u)."*</a>";}if($mg)echo"<p class='links'>",implode("",$mg),"</p>\n";}elseif(isset($_GET["privileges"])){$Dl=DB!=""?h(": ".DB):"";page_header(lang(69).$Dl,[lang(69)]);echo'<p class="links top-links"><a href="',h(ME),'user=">',icon("user-add"),lang(179),"</a></p>\n";$I=Connection::get()->query("SELECT User, Host FROM mysql.".(DB==""?"user":"db WHERE ".q(DB)." LIKE Db")." ORDER BY Host, User");$Ee=$I;if(!$I)$I=Connection::get()->query("SELECT SUBSTRING_INDEX(CURRENT_USER, '@', 1) AS User, SUBSTRING_INDEX(CURRENT_USER, '@', -1) AS Host");echo"<form action=''>\n";hidden_fields_get();echo
input_hidden("db",DB);if(!$Ee)echo
input_hidden("grant");echo"\n","<div class='scrollable'>\n","<table class='checkable'>\n","<thead><tr><th>".lang(27)."<th>".lang(25)."<th></thead>\n";while($K=$I->fetchAssoc())echo'<tr><td>'.h($K["User"])."<td>".h($K["Host"]).'<td><a href="'.h(ME.'user='.urlencode($K["User"]).'&host='.urlencode($K["Host"])).'">'.lang(37)."</a>\n";if(!$Ee||DB!="")echo"<tr><td><input class='input' name='user' autocapitalize='off'><td><input class='input' name='host' value='localhost' autocapitalize='off'><td><input type='submit' class='button' value='".lang(37)."'>\n";echo"</table>\n","</div>\n","</form>\n";}elseif(isset($_GET["sql"])){$P=Admin::get()->getSettings();if($_POST["export"]){$P->updateParameters(["exportFormat"=>$_POST["format"],"exportOutput"=>$_POST["output"],]);dump_headers("sql");Admin::get()->dumpTable("","");Admin::get()->dumpData("","table",$_POST["query"]);exit;}restart_session();$Ye=&get_session("queries");$Xe=&$Ye[DB];if($_POST["clear"]){$Xe=[];redirect(remove_from_uri("history"));}$Cl=isset($_GET["import"])?lang(70):lang(39);page_header($Cl,[$Cl]);if($_POST){$we=false;if(!isset($_GET["import"]))$G=$_POST["query"];elseif($_POST["webfile"]){$lf=Admin::get()->getImportFilePath();if($lf){if(file_exists($lf))$we=fopen($lf,"rb");elseif(file_exists("$lf.gz"))$we=fopen("compress.zlib://$lf.gz","rb");}$G=$we?fread($we,1e6):false;}else$G=get_file("sql_file",true,";");if(is_string($G)){if(function_exists('memory_get_usage')&&($Hg=ini_bytes("memory_limit"))!="-1")@ini_set("memory_limit",max($Hg,2*strlen($G)+memory_get_usage()+8e6));if($G!=""&&strlen($G)<1e6){$Si=$G.(preg_match("~;[ \t\r\n]*\$~",$G)?"":";");if(!$Xe||first(end($Xe))!=$Si){restart_session();$Xe[]=[$Si,time()];set_session("queries",$Ye);stop_session();}}$xk="(?:\\s|/\\*[\s\S]*?\\*/|(?:#|-- )[^\n]*\n?|--\r?\n)";$Nc=";";$A=0;$pd=true;$fc=connect();if($fc&&DB!=""){$fc->selectDatabase(DB);if($_GET["ns"]!="")set_schema($_GET["ns"],$fc);}$Sb=0;$zd=[];$fi='[\'"'.(DIALECT=="sql"?'`#':(DIALECT=="sqlite"?'`[':(DIALECT=="mssql"?'[':''))).']|/\*|-- |$'.(DIALECT=="pgsql"?'|\$[^$]*\$':'');$Jl=microtime(true);$hd=Admin::get()->getDumpFormats();unset($hd["sql"]);while($G!=""){if(!$A&&preg_match("~^$xk*+DELIMITER\\s+(\\S+)~i",$G,$y)){$Nc=$y[1];$se=Admin::get()->formatSqlCommandQuery(trim($y[0]));if($se!="")echo"<pre><code class='jush-".DIALECT."'>$se</code></pre>\n";$G=substr($G,strlen($y[0]));}else{preg_match('('.preg_quote($Nc)."\\s*|$fi)",$G,$y,PREG_OFFSET_CAPTURE,$A);list($ue,$Bi)=$y[0];if(!$ue&&$we&&!feof($we))$G
.=fread($we,1e5);else{if(!$ue&&rtrim($G)=="")break;$A=$Bi+strlen($ue);if($ue&&rtrim($ue)!=$Nc){$ob=Driver::get()->hasCStyleEscapes()||(DIALECT=="pgsql"&&($Bi>0&&strtolower($G[$Bi-1])=="e"));$si='(';if($ue=='/*')$si
.='\*/';elseif($ue=='[')$si
.=']';elseif(preg_match('~^-- |^#~',$ue))$si
.="\n";else$si
.=preg_quote($ue).($ob?"|\\\\.":"");$si
.='|$)s';while(preg_match($si,$G,$y,PREG_OFFSET_CAPTURE,$A)){$Dj=$y[0][0];if(!$Dj&&$we&&!feof($we))$G
.=fread($we,1e5);else{$A=$y[0][1]+strlen($Dj);if(!isset($Dj[0])||$Dj[0]!="\\")break;}}}else{$pd=false;$Si=substr($G,0,$Bi+strlen($Nc));$Sb++;$Ji="<pre id='sql-$Sb'><code class='jush-".DIALECT."'>".Admin::get()->formatSqlCommandQuery(trim($Si))."</code></pre>\n";if(DIALECT=="sqlite"&&preg_match("~^$xk*+ATTACH\\b~i",$Si,$y)){echo$Ji,"<p class='error'>".lang(180)."\n";$zd[]=" <a href='#sql-$Sb'>$Sb</a>";if($_POST["error_stops"])break;}else{if(!$_POST["only_errors"]){echo$Ji;ob_flush();flush();}$Fk=microtime(true);if(Connection::get()->multiQuery($Si)&&is_object($fc)&&preg_match("~^$xk*+USE\\b~i",$Si))$fc->query($Si);do{$I=Connection::get()->storeResult();if(Connection::get()->getError()){echo($_POST["only_errors"]?$Ji:""),"<p class='error'>",lang(181),(!empty(Connection::get()->getErrno())?" (".Connection::get()->getErrno().")":""),": ",error()."</p>\n";$zd[]=" <a href='#sql-$Sb'>$Sb</a>";if($_POST["error_stops"])break
2;}else{$_l=" <span class='time'>(".format_time($Fk).")</span>";$ld=(strlen($Si)<1000?" <a href='".h(ME)."sql=".urlencode(trim($Si))."'>".icon("edit").lang(37)."</a>":"");$Xi=Connection::get()->getQueryInfo();$za=Connection::get()->getAffectedRows();$Fm=($_POST["only_errors"]?null:Driver::get()->warnings());$Hm="warnings-$Sb";$Im=$Fm?"<a href='#$Hm' class='toggle'>".lang(38).icon_chevron_down()."</a>":null;$Id=null;$Jd="explain-$Sb";$Kd=false;$Ld="export-$Sb";if(is_object($I)){if(!$_POST["only_errors"])echo"<div class='table-result'>\n";$w=$_POST["limit"];$Ph=select($I,$fc,[],$w);if(!$_POST["only_errors"]){echo"<p class='links'>";$oh=$I->getRowsCount();echo($oh?($w&&$oh>$w?lang(182,$w):"").lang(183,$oh):""),$_l,$ld,$Im;if($fc&&preg_match("~^($xk|\\()*+SELECT\\b~i",$Si)&&($Id=explain($fc,$Si)))echo"<a href='#$Jd' class='toggle'>Explain".icon_chevron_down()."</a>";$Kd=true;echo"<a href='#$Ld' class='toggle'>".lang(71).icon_chevron_down()."</a>","</p>\n";}}else{if(preg_match("~^$xk*+(CREATE|DROP|ALTER)$xk++(DATABASE|SCHEMA)\\b~i",$Si)){restart_session();set_session("dbs",null);stop_session();}if(!$_POST["only_errors"]){echo"<p class='message' title='".h($Xi)."'>",lang(184,$za),"$_l $ld";if($Im)echo", $Im";echo"</p>\n";}}if(!$_POST["only_errors"])echo
script("initToggles(qsl('p'));");if($Fm)echo"<div id='$Hm' class='hidden'>\n$Fm</div>\n";if($Id){echo"<div id='$Jd' class='hidden explain'>\n";select($Id,$fc,$Ph);echo"</div>\n";}if($Kd)echo"<form id='$Ld' action='' method='post' class='hidden'><p>\n",html_select("format",$hd,$P->getParameter("exportFormat")),html_select("output",Admin::get()->getDumpOutputs(),$P->getParameter("exportOutput"))." ",input_hidden("query",$Si),input_token()," <input type='submit' class='button' name='export' value='".lang(71)."'>","</p></form>\n";if(is_object($I)&&!$_POST["only_errors"])echo"</div>\n";}$Fk=microtime(true);}while(Connection::get()->nextResult());}$G=substr($G,$A);$A=0;}}}}if($pd)echo"<p class='message'>".lang(185)."\n";elseif($_POST["only_errors"])echo"<p class='message'>".lang(186,$Sb-count($zd))," <span class='time'>(".format_time($Jl).")</span>\n";elseif($zd&&$Sb>1)echo"<p class='error'>".lang(181).": ".implode("",$zd)."\n";}else
echo"<p class='error'>".upload_error($G)."\n";}echo"<form action='' method='post' enctype='multipart/form-data' id='form'>\n";if(!isset($_GET["import"])){$Si=$_GET["sql"];if($_POST)$Si=$_POST["query"];elseif($_GET["history"]=="all")$Si=$Xe;elseif($_GET["history"]!="")$Si=$Xe[$_GET["history"]][0];echo"<p>";textarea("query",$Si,20);echo
script(($_POST?"":"qs('textarea').focus();\n")."gid('form').onsubmit = partial(sqlSubmit, gid('form'), '".js_escape(remove_from_uri("sql|limit|error_stops|only_errors|history"))."');"),"</p>","<p><input type='submit' class='button default' value='".lang(187)."' title='Ctrl+Enter'>",lang(188).": <input type='number' name='limit' class='input size' value='".h($_POST?$_POST["limit"]:$_GET["limit"])."'>\n";}else{echo"<div class='field-sets'>\n","<fieldset><legend>".lang(189)."</legend><div class='fieldset-content'>";$Me=(extension_loaded("zlib")?"[.gz]":"");if(ini_bool("file_uploads"))echo"SQL$Me (&lt; ".ini_get("upload_max_filesize")."B): <input type='file' name='sql_file[]' multiple>","<input type='submit' class='button default' value='".lang(187)."'>";else
echo
lang(190);echo"</div></fieldset>\n";$lf=Admin::get()->getImportFilePath();if($lf)echo"<fieldset><legend>".lang(191)."</legend><div class='fieldset-content'>",lang(192,"<code>".h($lf)."$Me</code>"),' <input type="submit" class="button default" name="webfile" value="'.lang(193).'">',"</div></fieldset>\n";echo"</div>\n","<p>";}echo
checkbox("error_stops",1,($_POST?$_POST["error_stops"]:isset($_GET["import"])||$_GET["error_stops"]),lang(194)),checkbox("only_errors",1,($_POST?$_POST["only_errors"]:isset($_GET["import"])||$_GET["only_errors"]),lang(195)),input_token(),"</p>\n";if(!isset($_GET["import"]))Admin::get()->printAfterSqlCommand();if(!isset($_GET["import"])&&$Xe){echo"<div class='field-sets'>\n";print_fieldset_start("history",lang(196),"history",$_GET["history"]!="");for($X=end($Xe);$X;$X=prev($Xe)){$u=key($Xe);list($Si,$_l,$nd)=$X;echo" <pre><code class='jush-".DIALECT."'>",truncate_utf8(ltrim(str_replace("\n"," ",str_replace("\r","",preg_replace('~^(#|-- ).*~m','',$Si))))),"</code></pre>",'<p class="links">',"<a href='".h(ME."sql=&history=$u")."'>".icon("edit").lang(37)."</a>"," <span class='time' title='".@date('Y-m-d',$_l)."'>".@date("H:i:s",$_l).($nd?" ($nd)":"")."</span>","</p>";}echo"<p><input type='submit' class='button' name='clear' value='".lang(197)."'>\n","<a href='",h(ME."sql=&history=all")."' class='button light'>",icon("edit"),lang(198),"</a></p>\n";print_fieldset_end("history");echo"</div>\n";}echo"</form>\n";}elseif(isset($_GET["edit"])){$a=$_GET["edit"];$l=fields($a);$Z=(isset($_GET["select"])?($_POST["check"]&&count($_POST["check"])==1?where_check($_POST["check"][0],$l):""):where($_GET,$l));$im=(isset($_GET["select"])?$_POST["edit"]:$Z);foreach($l
as$_=>$k){if(!isset($k["privileges"][$im?"update":"insert"])||Admin::get()->getFieldName($k)==""||$k["generated"])unset($l[$_]);}if($_POST&&!isset($_GET["select"])){$qg=$_POST["referer"];if($_POST["insert"])$qg=($im?null:$_SERVER["REQUEST_URI"]);elseif(!preg_match('~^.+&select=.+$~',$qg))$qg=ME."select=".urlencode($a);$t=indexes($a);$cm=unique_array($_GET["where"],$t);$Yi="\nWHERE $Z";if(isset($_POST["delete"]))queries_redirect($qg,lang(199),Driver::get()->delete($a,$Yi,!$cm));else{$ik=[];foreach($l
as$_=>$k){$X=process_input($k);if($X!==false&&$X!==null)$ik[idf_escape($_)]=$X;}if($im){if(!$ik)redirect($qg);queries_redirect($qg,lang(200),Driver::get()->update($a,$ik,$Yi,!$cm));if(is_ajax()){page_headers();page_messages();exit;}}else{$I=Driver::get()->insert($a,$ik);$bg=($I?last_id($I):0);queries_redirect($qg,lang(201,($bg?" $bg":"")),$I);}}}$K=null;if($_POST["save"])$K=(array)$_POST["fields"];elseif($Z){$M=[];foreach($l
as$_=>$k){if(isset($k["privileges"]["select"])){$Na=($_POST["clone"]&&$k["auto_increment"]?"''":convert_field($k));$M[]=($Na?"$Na AS ":"").idf_escape($_);}}$K=[];if(!support("table"))$M=["*"];if($M){$I=Driver::get()->select($a,$M,[$Z],$M,[],(isset($_GET["select"])?2:1));if(!$I)Admin::get()->addError(error());else{$K=$I->fetchAssoc();if(!$K)$K=false;}if(isset($_GET["select"])&&(!$K||$I->fetchAssoc()))$K=null;}}if(!support("table")&&!$l){if(!$Z){$I=Driver::get()->select($a,["*"],[],["*"]);$K=($I?$I->fetchAssoc():false);if(!$K)$K=[Driver::get()->primary=>""];}if($K){foreach($K
as$u=>$X){if(!$Z)$K[$u]=null;$l[$u]=["field"=>$u,"null"=>($u!=Driver::get()->primary),"auto_increment"=>($u==Driver::get()->primary)];}}}edit_form($a,$l,$K,$im);}elseif(isset($_GET["create"])){$a=$_GET["create"];$ii=[];foreach(['HASH','LINEAR HASH','KEY','LINEAR KEY','RANGE','LIST']as$u)$ii[$u]=$u;$fj=referencable_primary($a);$qe=[];foreach($fj
as$fl=>$k)$qe[str_replace("`","``",$fl)."`".str_replace("`","``",$k["field"])]=$fl;$Sh=[];$S=[];if($a!=""){$Sh=fields($a);$S=table_status($a);if(!$S)Admin::get()->addError(lang(75));}$K=$_POST;$K["fields"]=(array)$K["fields"];if($K["auto_increment_col"])$K["fields"][$K["auto_increment_col"]]["auto_increment"]=true;if($_POST)Admin::get()->getSettings()->updateParameter("commentsOpened",isset($_POST["comments"])?$_POST["comments"]:null);if($_POST&&!process_fields($K["fields"])&&!Admin::get()->getErrors()){if($_POST["drop"])queries_redirect(substr(ME,0,-1),lang(202),drop_tables([$a]));else{$l=[];$Ia=[];$nm=false;$oe=[];$Rh=reset($Sh);$Ba=" FIRST";foreach($K["fields"]as$u=>$k){$o=$qe[$k["type"]];$Wl=($o!==null?$fj[$o]:$k);if($k["field"]!=""){if(!$k["generated"])$k["default"]=null;$Pi=process_field($k,$Wl);$Ia[]=[$k["orig"],$Pi,$Ba];if(!$Rh||$Pi!==process_field($Rh,$Rh)){$l[]=[$k["orig"],$Pi,$Ba];if($k["orig"]!=""||$Ba)$nm=true;}if($o!==null)$oe[idf_escape($k["field"])]=($a!=""&&DIALECT!="sqlite"?"ADD":" ").format_foreign_key(['table'=>$qe[$k["type"]],'source'=>[$k["field"]],'target'=>[$Wl["field"]],'on_delete'=>$k["on_delete"],]);$Ba=" AFTER ".idf_escape($k["field"]);}elseif($k["orig"]!=""){$nm=true;$l[]=[$k["orig"]];}if($k["orig"]!=""){$Rh=next($Sh);if(!$Rh)$Ba="";}}$ki="";if(support("partitioning")){if(isset($ii[$K["partition_by"]])){$D=[];foreach($K
as$u=>$X){if(preg_match('~^partition~',$u))$D[$u]=$X;}foreach($D["partition_names"]as$u=>$_){if($_===""){unset($D["partition_names"][$u]);unset($D["partition_values"][$u]);}}if($D!=get_partitions_info($a)){$li=[];if($D["partition_by"]=='RANGE'||$D["partition_by"]=='LIST'){foreach($D["partition_names"]as$u=>$_){$Y=$D["partition_values"][$u];$li[]="\n  PARTITION ".idf_escape($_)." VALUES ".($D["partition_by"]=='RANGE'?"LESS THAN":"IN").($Y!=""?" ($Y)":" MAXVALUE");}}$ki
.="\nPARTITION BY {$D["partition_by"]}({$D["partition"]})";if($li)$ki
.=" (".implode(",",$li)."\n)";elseif($D["partitions"])$ki
.=" PARTITIONS ".(int)$D["partitions"];}}elseif(preg_match("~partitioned~",$S["Create_options"]))$ki
.="\nREMOVE PARTITIONING";}$Jg=lang(203);if($a==""){cookie("neo_engine",isset($K["Engine"])?$K["Engine"]:"");$Jg=lang(204);}$_=trim($K["name"]);queries_redirect(ME.(support("table")?"table=":"select=").urlencode($_),$Jg,alter_table($a,$_,(DIALECT=="sqlite"&&($nm||$oe)?$Ia:$l),$oe,($K["Comment"]!=$S["Comment"]?$K["Comment"]:null),($K["Engine"]&&$K["Engine"]!=$S["Engine"]?$K["Engine"]:""),($K["Collation"]&&$K["Collation"]!=$S["Collation"]?$K["Collation"]:""),($K["Auto_increment"]!=""?number($K["Auto_increment"]):""),$ki));}}if($a!="")page_header(lang(35).": ".h($a),["table"=>$a,lang(35)]);else
page_header(lang(74),[lang(74)]);if(!$_POST){$Zl=Driver::get()->getTypes();$K=["Engine"=>$_COOKIE["neo_engine"],"fields"=>[["field"=>"","type"=>(isset($Zl["int"])?"int":(isset($Zl["integer"])?"integer":"")),"on_update"=>""]],"partition_names"=>[""],];if($a!=""){$K=$S;$K["name"]=$a;$K["fields"]=[];if(!$_GET["auto_increment"])$K["Auto_increment"]="";foreach($Sh
as$k){$k["generated"]=$k["generated"]?:(isset($k["default"])?"DEFAULT":"");$K["fields"][]=$k;}if(support("partitioning")){$K+=get_partitions_info($a);$K["partition_names"][]="";$K["partition_values"][]="";}}}$Pf=[];if($K["Collation"])$Pf[$K["Collation"]]=true;foreach($K["fields"]as$k){if($k["collation"])$Pf[$k["collation"]]=true;}$Kb=Admin::get()->getCollations(array_keys($Pf));$vd=Driver::get()->engines();foreach($vd
as$ud){if(!strcasecmp($ud,$K["Engine"])){$K["Engine"]=$ud;break;}}echo"<form action='' method='post' id='form'>\n";if(support("columns")||$a==""){echo"<p>",lang(205),": ","<input class='input' name='name' data-maxlength='64' value='",h($K["name"]),"' autocapitalize='off'",(($a==""&&!$_POST)?" autofocus":""),">";if($vd)echo" ",html_select("Engine",[""=>"(".lang(206).")"]+$vd,$K["Engine"]),help_script_command("value",true);if($Kb&&!preg_match("~sqlite|mssql~",DIALECT))echo" ",html_select("Collation",[""=>"(".lang(87).")"]+$Kb,$K["Collation"]);echo" <input type='submit' class='button default' value='",lang(107),"'>","</p>";}if(support("columns")){echo"<div class='scrollable'>\n","<table id='edit-fields' class='nowrap'>\n";edit_fields($K["fields"],$Kb,"TABLE",$qe);echo"</table>\n",script("initFieldsEditing(gid('edit-fields'));");if(support("move_col"))echo
script("initSortable('#edit-fields tbody');");echo"</div>\n","<p>",lang(46),": ","<input type='number' class='input size' name='Auto_increment' size='6' value='",h($K["Auto_increment"]),"'>";$Xb=$_POST?$_POST["comments"]:Admin::get()->getSettings()->getParameter("commentsOpened");$Ub=$Xb?"":"hidden";if(support("comment")){echo
checkbox("comments",1,$Xb,lang(45),"editingCommentsClick(this, true);","jsonly")," ";if(preg_match('~\n~',$K["Comment"]))echo"<textarea name='Comment' rows='2' cols='20'",($Ub?" class='$Ub'":""),">",h($K["Comment"]),"</textarea>";else
echo"<input name='Comment' value='",h($K["Comment"]),"' data-maxlength='",(Connection::get()->isMinVersion("5.5")?2048:60),"' class='input $Ub'>";}echo"</p>\n<p>","<input type='submit' class='button default' value='",lang(107),"'>";}elseif($a!="")echo"<p>";if($a!="")echo"<input type='submit' class='button' name='drop' value='",lang(157),"'>",confirm(lang(207,$a)),"</p>\n";if(support("partitioning")){echo"<div class='field-sets'>\n";$ji=preg_match('~RANGE|LIST~',$K["partition_by"]);print_fieldset_start("partition",lang(162),"split",(bool)$K["partition_by"]);echo"<p>",html_select("partition_by",[""=>""]+$ii,$K["partition_by"]),help_script_command("value.replace(/./, 'PARTITION BY \$&')",true),script("qsl('select').onchange = partitionByChange;"),"(<input class='input' name='partition' value='",h($K["partition"]),"'>) ",lang(48),": ","<input type='number' name='partitions' class='input size ",($ji||!$K["partition_by"]?"hidden":""),"' value='",h($K["partitions"]),"'>","</p>\n","<table id='partition-table'",($ji?"":" class='hidden'"),">\n","<thead><tr><th>",lang(208),"</th><th>",lang(50),"</th></tr></thead>\n";foreach($K["partition_names"]as$u=>$X){echo"<tr>","<td><input class='input' name='partition_names[]' value='",h($X),"' autocapitalize='off'>";if($u==count($K["partition_names"])-1)echo
script("qsl('input').oninput = partitionNameChange;");echo"</td>","<td><input class='input' name='partition_values[]' value='",h($K["partition_values"][$u]),"'></td>","</tr>\n";}echo"</table>\n","</p>\n";print_fieldset_end("partition");echo"</div>\n";}echo
input_token(),"</form>\n";}elseif(isset($_GET["indexes"])){$a=$_GET["indexes"];$pf=["PRIMARY","UNIQUE","INDEX"];$S=table_status($a,true);$e=Connection::get();$vg=$e->isMariaDB();if(preg_match('~MyISAM|M?aria'.($e->isMinVersion($vg?"10.0.5":"5.6")?'|InnoDB':'').'~i',$S["Engine"]))$pf[]="FULLTEXT";if(preg_match('~MyISAM|M?aria'.($e->isMinVersion($vg?"10.2.2":"5.7")?'|InnoDB':'').'~i',$S["Engine"]))$pf[]="SPATIAL";$t=indexes($a);$F=[];if(DIALECT=="mongo"){$F=$t["_id_"];unset($pf[0]);unset($t["_id_"]);}$K=$_POST;if($K)Admin::get()->getSettings()->updateParameter("indexOptions",isset($K["options"])?$K["options"]:null);if($_POST&&!$_POST["add"]&&!$_POST["drop_col"]){$b=[];foreach($K["indexes"]as$s){$_=$s["name"];if(in_array($s["type"],$pf)){$d=[];$hg=[];$Pc=[];$ik=[];ksort($s["columns"]);foreach($s["columns"]as$u=>$c){if($c!=""){$v=isset($s["lengths"][$u])?$s["lengths"][$u]:null;$Oc=isset($s["descs"][$u])?$s["descs"][$u]:null;$ik[]=idf_escape($c).($v?"(".(+$v).")":"").($Oc?" DESC":"");$d[]=$c;$hg[]=($v?:null);$Pc[]=$Oc;}}$Gd=$t[$_];if($Gd){ksort($Gd["columns"]);ksort($Gd["lengths"]);ksort($Gd["descs"]);if($s["type"]==$Gd["type"]&&array_values($Gd["columns"])===$d&&(!$Gd["lengths"]||array_values($Gd["lengths"])===$hg)&&array_values($Gd["descs"])===$Pc){unset($t[$_]);continue;}}if($d)$b[]=[$s["type"],$_,$ik];}}foreach($t
as$_=>$Gd)$b[]=[$Gd["type"],$_,"DROP"];if(!$b)redirect(ME."table=".urlencode($a));queries_redirect(ME."table=".urlencode($a),lang(209),alter_indexes($a,$b));}page_header(lang(164),["table"=>$a,lang(164)],h($a));$l=array_keys(fields($a));if($_POST["add"]){foreach($K["indexes"]as$u=>$s){if($s["columns"][count($s["columns"])]!="")$K["indexes"][$u]["columns"][]="";}$s=end($K["indexes"]);if($s["type"]||array_filter($s["columns"],'strlen'))$K["indexes"][]=["columns"=>[1=>""]];}if(!$K){foreach($t
as$u=>$s){$t[$u]["name"]=$u;$t[$u]["columns"][]="";}$t[]=["columns"=>[1=>""]];$K["indexes"]=$t;}$hg=(DIALECT=="sql"||DIALECT=="mssql");$mk=$_POST?$_POST["options"]:Admin::get()->getSettings()->getParameter("indexOptions");echo"<form action='' method='post'>\n","<div class='scrollable'>\n","<table class='nowrap'>\n","<thead><tr>","<th id='label-type'>",lang(210),"</th>","<th><input type='submit' class='button invisible'>",lang(42).($hg?"<span class='idxopts".($mk?"":" hidden")."'> (".lang(51).")</span>":"");if($hg||support("descidx"))echo
checkbox("options",1,$mk,lang(92),"indexOptionsShow(this.checked)","jsonly")."\n";echo"</th>","<th id='label-name'>",lang(211),"</th>","<th>","<button name='add[0]' value='1' title='",lang(93),"' class='button light hidden'>",icon_solo("add"),"</button>","</th>","</tr></thead>\n";if($F){echo"<tr><td>PRIMARY<td>";foreach($F["columns"]as$u=>$c)echo
select_input(" disabled",$l,$c),"<label><input type='checkbox' disabled>".lang(59)."</label> ";echo"<td><td>\n";}$Kf=1;foreach($K["indexes"]as$s){if(!$_POST["drop_col"]||$Kf!=key($_POST["drop_col"])){echo"<tr><td>",html_select("indexes[$Kf][type]",[-1=>""]+$pf,$s["type"],($Kf==count($K["indexes"])?"indexesAddRow.call(this);":""),"label-type"),"</td>","<td>";ksort($s["columns"]);$p=1;foreach($s["columns"]as$u=>$c){echo"<span>".select_input(" name='indexes[$Kf][columns][$p]' title='".lang(42)."'",($l?array_combine($l,$l):$l),$c,"partial(".($p==count($s["columns"])?"indexesAddColumn":"indexesChangeColumn").", '".js_escape(DIALECT=="sql"?"":$_GET["indexes"]."_")."')"),"<span class='idxopts".($mk?"":" hidden")."'>",($hg?"<input type='number' name='indexes[$Kf][lengths][$p]' class='input size' value='".(h(isset($s["lengths"][$u])?$s["lengths"][$u]:""))."' title='".lang(212)."'>":""),(support("descidx")?checkbox("indexes[$Kf][descs][$p]",1,isset($s["descs"][$u])?$s["descs"][$u]:false,lang(59)):""),"</span> </span>";$p++;}echo"</td>","<td><input name='indexes[$Kf][name]' value='",h($s["name"]),"' class='input' autocapitalize='off' aria-labelledby='label-name'></td>\n","<td>","<button name='drop_col[$Kf]' value='1' title='",h(lang(55)),"' class='button light'>",icon_solo("remove"),"</button>",script("qsl('button').onclick = onRemoveIndexRowClick;"),"</td>\n";}$Kf++;}echo"</table>\n","</div>\n","<p>","<input type='submit' class='button default' value='",lang(107),"'>",input_token(),"</p>\n","</form>\n";}elseif(isset($_GET["database"])){$K=$_POST;if($_POST&&!isset($_POST["add_x"])){$_=trim($K["name"]);if($_POST["drop"]){$_GET["db"]="";queries_redirect(remove_from_uri("db|database"),lang(213),drop_databases([DB]));}elseif(DB!==$_){if(DB!=""){$_GET["db"]=$_;queries_redirect(preg_replace('~\bdb=[^&]*&~','',ME)."db=".urlencode($_),lang(214),rename_database($_,$K["collation"]));}else{$g=explode("\n",str_replace("\r","",$_));$Qk=true;$ag="";foreach($g
as$h){if(count($g)==1||$h!=""){if(!create_database($h,$K["collation"]))$Qk=false;$ag=$h;}}restart_session();set_session("dbs",null);queries_redirect(ME."db=".urlencode($ag),lang(215),$Qk);}}else{if(!$K["collation"])redirect(substr(ME,0,-1));query_redirect("ALTER DATABASE ".idf_escape($_).(preg_match('~^[a-z0-9_]+$~i',$K["collation"])?" COLLATE $K[collation]":""),substr(ME,0,-1),lang(216));}}if(DB!="")page_header(lang(66).": ".h(DB),[lang(66)]);else
page_header(lang(72),[lang(72)]);$_=DB;if($_POST)$_=$K["name"];elseif(DB!="")$K["collation"]=db_collation(DB,collations());elseif(DIALECT=="sql"){foreach(get_vals("SHOW GRANTS")as$Ee){if(preg_match('~ ON (`(([^\\\\`]|``|\\\\.)*)%`\.\*)?~',$Ee,$y)&&$y[1]){$_=stripcslashes(idf_unescape("`$y[2]`"));break;}}}$Kb=Admin::get()->getCollations($K["collation"]?[$K["collation"]]:[]);echo"<form action='' method='post'>\n","<p>";if($_POST["add_x"]||strpos($_,"\n"))echo"<textarea id='name' name='name' rows='10' cols='40'>",h($_),"</textarea><br>\n";else
echo"<input class='input' name='name' id='name' value='",h($_),"' data-maxlength='64' autocapitalize='off' autofocus>\n";if($Kb)echo
html_select("collation",[""=>"(".lang(87).")"]+$Kb,$K["collation"]),doc_link(['sql'=>"charset-charsets.html",'mariadb'=>"supported-character-sets-and-collations/",'mssql'=>"relational-databases/system-functions/sys-fn-helpcollations-transact-sql",]),"\n";echo"<input type='submit' class='button default' value='",lang(107),"'>\n";if(DB!="")echo"<input type='submit' class='button' name='drop' value='".lang(157)."'>".confirm(lang(207,DB))."\n";elseif(!$_POST["add_x"]&&$_GET["db"]=="")echo"<button name='add_x' value='1' title='",h(lang(93)),"' class='button light'>",icon_solo("add"),"</button>\n";echo
input_token(),"</p>\n","</form>\n";}elseif(isset($_GET["scheme"])){$K=$_POST;if($_POST){$x=preg_replace('~ns=[^&]*&~','',ME)."ns=";if($_POST["drop"])query_redirect("DROP SCHEMA ".idf_escape($_GET["ns"]),$x,lang(217));else{$_=trim($K["name"]);$x
.=urlencode($_);if($_GET["ns"]=="")query_redirect("CREATE SCHEMA ".idf_escape($_),$x,lang(218));elseif($_GET["ns"]!=$_)query_redirect("ALTER SCHEMA ".idf_escape($_GET["ns"])." RENAME TO ".idf_escape($_),$x,lang(219));else
redirect($x);}}if($_GET["ns"]!="")page_header(lang(67).": ".h($_GET["ns"]),[lang(67)]);else
page_header(lang(73),[lang(73)]);if(!$K)$K["name"]=$_GET["ns"];echo"<form action='' method='post'>\n","<p>","<input class='input' name='name' id='name' value='",h($K["name"]),"' autocapitalize='off' autofocus>","<input type='submit' class='button default' value='",lang(107),"'>";if($_GET["ns"]!="")echo"<input type='submit' class='button' name='drop' value='".lang(157)."'>".confirm(lang(207,$_GET["ns"]))."\n";echo
input_token(),"</p>\n","</form>\n";}elseif(isset($_GET["call"])){$ka=$_GET["name"]?:$_GET["call"];page_header(lang(220).": ".h($ka),[lang(220)]);$yj=routine($_GET["call"],(isset($_GET["callf"])?"FUNCTION":"PROCEDURE"));$mf=[];$Xh=[];foreach($yj["fields"]as$p=>$k){if(substr($k["inout"],-3)=="OUT")$Xh[$p]="@".idf_escape($k["field"])." AS ".idf_escape($k["field"]);if(!$k["inout"]||substr($k["inout"],0,2)=="IN")$mf[]=$p;}if($_POST){$qb=[];foreach($yj["fields"]as$u=>$k){if(in_array($u,$mf)){$X=process_input($k);if($X===false)$X="''";if(isset($Xh[$u]))Connection::get()->query("SET @".idf_escape($k["field"])." = $X");}$qb[]=(isset($Xh[$u])?"@".idf_escape($k["field"]):$X);}$G=(isset($_GET["callf"])?"SELECT":"CALL")." ".table($ka)."(".implode(", ",$qb).")";$Fk=microtime(true);$I=Connection::get()->multiQuery($G);$za=Connection::get()->getAffectedRows();echo
Admin::get()->formatSelectQuery($G,$Fk,!$I);if(!$I)echo"<p class='error'>".error()."\n";else{$fc=connect();if($fc)$fc->selectDatabase(DB);do{$I=Connection::get()->storeResult();if(is_object($I))select($I,$fc);else
echo"<p class='message'>".lang(221,$za)." <span class='time'>".@date("H:i:s")."</span>\n";}while(Connection::get()->nextResult());if($Xh)select(Connection::get()->query("SELECT ".implode(", ",$Xh)));}}echo"<form action='' method='post'>\n";if($mf){echo"<table class='box'>\n";foreach($mf
as$u){$k=$yj["fields"][$u];$_=$k["field"];echo"<tr><th>".Admin::get()->getFieldName($k);$Y=isset($_POST["fields"][$_])?$_POST["fields"][$_]:"";if($Y!=""){if($k["type"]=="set")$Y=implode(",",$Y);}input($k,$Y,(string)(isset($_POST["function"][$_])?$_POST["function"][$_]:""));echo"\n";}echo"</table>\n";}echo"<p>\n","<input type='submit' class='button' value='",lang(220),"'>\n",input_token(),"</p>\n","</form>\n";$Tb=$yj["comment"];if($Tb!==null&&$Tb!==""){$Tb=h(trim($yj["comment"],"\n"));if(preg_match('~^ +~',$Tb,$z)){preg_match_all("~^($z[0]|$)~m",$Tb,$kg);if(count($kg[0])==substr_count($Tb,"\n"))$Tb=preg_replace("~^($z[0])~m","",$Tb);}$Tb=preg_replace('~(^|[^\n]\n)(Description|Parameters|Example)\n~',"$1\n<strong>$2</strong>\n",$Tb);echo"<pre class='comment'>$Tb</pre>\n";}}elseif(isset($_GET["foreign"])){$a=$_GET["foreign"];$_=$_GET["name"];$K=$_POST;if($_POST&&!$_POST["add"]&&!$_POST["change"]&&!$_POST["change-js"]){if(!$_POST["drop"]){$K["source"]=array_filter($K["source"],'strlen');ksort($K["source"]);$pl=[];foreach($K["source"]as$u=>$X)$pl[$u]=$K["target"][$u];$K["target"]=$pl;}if(DIALECT=="sqlite")$I=recreate_table($a,$a,[],[],[" $_"=>($K["drop"]?"":" ".format_foreign_key($K))]);else{$b="ALTER TABLE ".table($a);$I=($_==""||queries("$b DROP ".(DIALECT=="sql"?"FOREIGN KEY ":"CONSTRAINT ").idf_escape($_)));if(!$K["drop"])$I=queries("$b ADD".format_foreign_key($K));}queries_redirect(ME."table=".urlencode($a),($K["drop"]?lang(222):($_!=""?lang(223):lang(224))),$I);if(!$K["drop"])Admin::get()->addError(lang(225));}page_header(lang(226).": ".h($a),["table"=>$a,lang(226)]);if($_POST){ksort($K["source"]);if($_POST["add"])$K["source"][]="";elseif($_POST["change"]||$_POST["change-js"])$K["target"]=[];}elseif($_!=""){$qe=foreign_keys($a);$K=$qe[$_];$K["source"][]="";}else{$K["table"]=$a;$K["source"]=[""];}echo"<form action='' method='post'>\n";$vk=array_keys(fields($a));if($K["db"]!="")Connection::get()->selectDatabase($K["db"]);if($K["ns"]!=""){$Th=get_schema();set_schema($K["ns"]);}$ej=array_keys(array_filter(table_status('',true),'AdminNeo\fk_support'));$pl=array_keys(fields(in_array($K["table"],$ej)?$K["table"]:reset($ej)));$Bh="this.form['change-js'].value = '1'; this.form.submit();";echo"<p>",lang(227),": ",html_select("table",$ej,$K["table"],$Bh);if(support("scheme")){$Hj=array_filter(Admin::get()->getSchemas(),function($Gj){return!preg_match('~^information_schema$~i',$Gj);});echo
lang(77),": ",html_select("ns",$Hj,$K["ns"]!=""?$K["ns"]:$_GET["ns"],$Bh);if($K["ns"]!="")set_schema($Th);}elseif(DIALECT!="sqlite"){$Fc=[];foreach(Admin::get()->getDatabases()as$h){if(!information_schema($h))$Fc[]=$h;}echo
lang(228),": ",html_select("db",$Fc,$K["db"]!=""?$K["db"]:$_GET["db"],$Bh);}echo
input_hidden("change-js"),"<noscript><input type='submit' class='button' name='change' value='",lang(229),"'></noscript>","</p>\n","<table>","<thead><tr><th id='label-source'>",lang(165),"<th id='label-target'>",lang(166),"</thead>\n";$Kf=0;foreach($K["source"]as$u=>$X){echo"<tr>","<td>".html_select("source[".(+$u)."]",[-1=>""]+$vk,$X,($Kf==count($K["source"])-1?"foreignAddRow.call(this);":""),"label-source"),"<td>".html_select("target[".(+$u)."]",$pl,isset($K["target"][$u])?$K["target"][$u]:null,"","label-target");$Kf++;}echo"</table>\n","<noscript><p><input type='submit' class='button' name='add' value='",lang(230),"'></p></noscript>","<p>\n",lang(89),": ",html_select("on_delete",[-1=>""]+Driver::get()->getOnActions(),$K["on_delete"]),lang(88),": ",html_select("on_update",[-1=>""]+Driver::get()->getOnActions(),$K["on_update"]),doc_link(['sql'=>"innodb-foreign-key-constraints.html",'mariadb'=>"foreign-keys/",'pgsql'=>"sql-createtable.html#SQL-CREATETABLE-REFERENCES",'mssql'=>"t-sql/statements/create-table-transact-sql",'oracle'=>"SQLRF01111",]),"</p>\n<p>","<input type='submit' class='button default' value='",lang(107),"'>";if($_!="")echo"<input type='submit' class='button' name='drop' value='",lang(157),"'>",confirm(lang(207,$_));echo
input_token(),"</p>\n","</form>\n";}elseif(isset($_GET["view"])){$a=$_GET["view"];$K=$_POST;$Uh="VIEW";if(DIALECT=="pgsql"&&$a!=""){$Ik=table_status($a);$Uh=strtoupper($Ik["Engine"]);}if($_POST){$_=trim($K["name"]);$Na=" AS\n$K[select]";$qg=ME."table=".urlencode($_);$Jg=lang(231);$U=($_POST["materialized"]?"MATERIALIZED VIEW":"VIEW");if(!$_POST["drop"]&&$a==$_&&DIALECT!="sqlite"&&$U=="VIEW"&&$Uh=="VIEW")query_redirect((DIALECT=="mssql"?"ALTER":"CREATE OR REPLACE")." VIEW ".table($_).$Na,$qg,$Jg);else{$rl=$_."_adminneo_".uniqid();drop_create("DROP $Uh ".table($a),"CREATE $U ".table($_).$Na,"DROP $U ".table($_),"CREATE $U ".table($rl).$Na,"DROP $U ".table($rl),($_POST["drop"]?substr(ME,0,-1):$qg),lang(232),$Jg,lang(233),$a,$_);}}if(!$_POST&&$a!=""){$K=view($a);$K["name"]=$a;$K["materialized"]=($Uh!="VIEW");if($j=error())Admin::get()->addError($j);}if($a!="")page_header(lang(34).": ".h($a),["table"=>$a,lang(34)]);else
page_header(lang(234),[lang(234)]);echo"<form action='' method='post'>\n","<p>",lang(211),":","<input class='input' name='name' value='",h($K["name"]),"' data-maxlength='64' autocapitalize='off'>\n";if(support("materializedview"))echo
checkbox("materialized",1,$K["materialized"],lang(159));echo"</p>\n<p>";textarea("select",$K["select"]);echo"</p>\n<p>","<input type='submit' class='button default' value='",lang(107),"'>\n";if($a!="")echo"<input type='submit' class='button' name='drop' value='",lang(157),"'>\n",confirm(lang(207,$a));echo
input_token(),"</p>\n","</form>\n";}elseif(isset($_GET["event"])){$da=$_GET["event"];$yf=["YEAR","QUARTER","MONTH","DAY","HOUR","MINUTE","WEEK","SECOND","YEAR_MONTH","DAY_HOUR","DAY_MINUTE","DAY_SECOND","HOUR_MINUTE","HOUR_SECOND","MINUTE_SECOND"];$Jk=["ENABLED"=>"ENABLE","DISABLED"=>"DISABLE","SLAVESIDE_DISABLED"=>"DISABLE ON SLAVE"];$K=$_POST;if($_POST){if($_POST["drop"])query_redirect("DROP EVENT ".idf_escape($da),substr(ME,0,-1),lang(235));elseif(in_array($K["INTERVAL_FIELD"],$yf)&&isset($Jk[$K["STATUS"]])){$Fj="\nON SCHEDULE ".($K["INTERVAL_VALUE"]?"EVERY ".q($K["INTERVAL_VALUE"])." $K[INTERVAL_FIELD]".($K["STARTS"]?" STARTS ".q($K["STARTS"]):"").($K["ENDS"]?" ENDS ".q($K["ENDS"]):""):"AT ".q($K["STARTS"]))." ON COMPLETION".($K["ON_COMPLETION"]?"":" NOT")." PRESERVE";queries_redirect(substr(ME,0,-1),($da!=""?lang(236):lang(237)),queries(($da!=""?"ALTER EVENT ".idf_escape($da).$Fj.($da!=$K["EVENT_NAME"]?"\nRENAME TO ".idf_escape($K["EVENT_NAME"]):""):"CREATE EVENT ".idf_escape($K["EVENT_NAME"]).$Fj)."\n".$Jk[$K["STATUS"]]." COMMENT ".q($K["EVENT_COMMENT"]).rtrim(" DO\n$K[EVENT_DEFINITION]",";").";"));}}if($da!="")page_header(lang(238).": ".h($da),[lang(238)]);else
page_header(lang(239),[lang(239)]);if(!$K&&$da!=""){$L=get_rows("SELECT * FROM information_schema.EVENTS WHERE EVENT_SCHEMA = ".q(DB)." AND EVENT_NAME = ".q($da));$K=reset($L);}echo"<form action='' method='post'>\n","<table class='box box-light'>\n","<tr><th>",lang(211),"</th><td>","<input class='input' name='EVENT_NAME' value='",h($K["EVENT_NAME"]),"' data-maxlength='64' autocapitalize='off'>","</td></tr>\n","<tr><th title='datetime'>",lang(240),"</th><td>","<input class='input' name='STARTS' value='",h("$K[EXECUTE_AT]$K[STARTS]"),"'>","</td></tr>\n","<tr><th title='datetime'>",lang(241),"</th><td>","<input class='input' name='ENDS' value='",h($K["ENDS"]),"'>","</td></tr>\n","<tr><th>",lang(242),"</th><td>","<input type='number' name='INTERVAL_VALUE' value='",h($K["INTERVAL_VALUE"]),"' class='input size'> ",html_select("INTERVAL_FIELD",$yf,$K["INTERVAL_FIELD"]),"</td></tr>\n","<tr><th>",lang(149),"</th><td>",html_select("STATUS",$Jk,$K["STATUS"]),"</td></tr>\n","<tr><th>",lang(45),"</th><td>","<input class='input' name='EVENT_COMMENT' value='",h($K["EVENT_COMMENT"]),"' data-maxlength='64'>","</td></tr>\n","<tr><th></th><td>",checkbox("ON_COMPLETION","PRESERVE",$K["ON_COMPLETION"]=="PRESERVE",lang(243)),"</td></tr>\n","</table>\n","<p>";textarea("EVENT_DEFINITION",$K["EVENT_DEFINITION"]);echo"</p>\n","<p>","<input type='submit' class='button default' value='",lang(107),"'>";if($da!="")echo"<input type='submit' class='button' name='drop' value='",lang(157),"'>",confirm(lang(207,$da));echo"</p>\n",input_token(),"</form>\n";}elseif(isset($_GET["procedure"])){$ka=($_GET["name"]?:$_GET["procedure"]);$yj=(isset($_GET["function"])?"FUNCTION":"PROCEDURE");$K=$_POST;$K["fields"]=(array)$K["fields"];if($_POST&&!process_fields($K["fields"])){$Qh=routine($_GET["procedure"],$yj);$rl="$K[name]_adminneo_".uniqid();foreach($K["fields"]as$u=>$k){if($k["field"]=="")unset($K["fields"][$u]);}drop_create("DROP $yj ".routine_id($ka,$Qh),create_routine($yj,$K),"DROP $yj ".routine_id($K["name"],$K),create_routine($yj,["name"=>$rl]+$K),"DROP $yj ".routine_id($rl,$K),substr(ME,0,-1),lang(244),lang(245),lang(246),$ka,$K["name"]);}if($ka!=""){$Cl=isset($_GET["function"])?lang(247):lang(248);page_header($Cl.": ".h($ka),[$Cl]);}else{$Cl=isset($_GET["function"])?lang(249):lang(250);page_header($Cl,[$Cl]);}if(!$_POST){if($ka=="")$K["language"]="sql";else{$K=routine($_GET["procedure"],$yj);$K["name"]=$ka;}}$ub=get_vals("SHOW CHARACTER SET");sort($ub);$zj=routine_languages();echo"<form action='' method='post' id='form'>\n","<p>",lang(211),": ","<input class='input' name='name' value='",h($K["name"]),"' data-maxlength='64' autocapitalize='off'>";if($zj)echo
lang(8),": ",html_select("language",$zj,$K["language"]);echo"<input type='submit' class='button default' value='",lang(107),"'>","</p>\n","<div class='scrollable'>\n","<table class='nowrap' id='edit-fields'>\n";edit_fields($K["fields"],$ub,$yj);if(isset($_GET["function"])){echo"<tbody><tr>";if(support("move_col"))echo"<th></th>";echo"<th>",lang(251),"</th>";edit_type("returns",$K["returns"],$ub,[],(DIALECT=="pgsql"?["void","trigger"]:[]));echo"<td></td>","</tr></tbody>\n";}echo"</table>\n",script("initFieldsEditing(gid('edit-fields'));");if(support("move_col"))echo
script("initSortable('#edit-fields tbody');");echo"</div>\n","<p>";textarea("definition",$K["definition"]);echo"</p>\n<p>","<input type='submit' class='button default' value='",lang(107),"'>";if($ka!="")echo"<input type='submit' class='button' name='drop' value='",lang(157),"'>",confirm(lang(207,$ka));echo
input_token(),"</p>\n","</form>\n";}elseif(isset($_GET["sequence"])){$ma=$_GET["sequence"];$K=$_POST;if($_POST){$x=substr(ME,0,-1);$_=trim($K["name"]);if($_POST["drop"])query_redirect("DROP SEQUENCE ".idf_escape($ma),$x,lang(252));elseif($ma=="")query_redirect("CREATE SEQUENCE ".idf_escape($_),$x,lang(253));elseif($ma!=$_)query_redirect("ALTER SEQUENCE ".idf_escape($ma)." RENAME TO ".idf_escape($_),$x,lang(254));else
redirect($x);}if($ma!="")page_header(lang(255).": ".h($ma),[h($ma)]);else
page_header(lang(256),[lang(257)]);if(!$K)$K["name"]=$ma;echo"<form action='' method='post'>\n","<p>","<input class='input' name='name' value='",h($K["name"]),"' autocapitalize='off'>","<input type='submit' class='button default' value='",lang(107),"'>";if($ma!="")echo"<input type='submit' class='button' name='drop' value='".lang(157)."'>".confirm(lang(207,$ma))."\n";echo
input_token(),"</p>\n","</form>\n";}elseif(isset($_GET["type"])){$na=$_GET["type"];$K=$_POST;if($_POST){$x=substr(ME,0,-1);if($_POST["drop"])query_redirect("DROP TYPE ".idf_escape($na),$x,lang(258));else
query_redirect("CREATE TYPE ".idf_escape(trim($K["name"]))." $K[as]",$x,lang(259));}if($na!="")page_header(lang(260).": ".h($na),[h($na)]);else
page_header(lang(257),[lang(257)]);if(!$K)$K["as"]="AS ";echo"<form action='' method='post'>\n";if($na!=""){$Zl=Driver::get()->getTypes();$xd=type_values($Zl[$na]);if($xd)echo"<p><code class='jush-".DIALECT."'>ENUM (".h($xd).")</code><p>\n";echo"<p>","<input type='submit' class='button' name='drop' value='".lang(157)."'>".confirm(lang(207,$na)),"</p>\n";}else{echo"<p>",lang(211).": <input class='input' name='name' value='".h($K['name'])."' autocapitalize='off'>\n",doc_link(['pgsql'=>"datatype-enum.html",],"?"),"</p>\n<p>";textarea("as",$K["as"]);echo"</p>\n","<p><input type='submit' class='button default' value='".lang(107)."'></p>\n";}echo
input_token(),"</form>\n";}elseif(isset($_GET["check"])){$a=$_GET["check"];$_=$_GET["name"];$K=$_POST;if($K){if(DIALECT=="sqlite")$I=recreate_table($a,$a,[],[],[],0,[],$_,($K["drop"]?"":$K["clause"]));else{$I=($_==""||queries("ALTER TABLE ".table($a)." DROP CONSTRAINT ".idf_escape($_)));if(!$K["drop"])$I=queries("ALTER TABLE ".table($a)." ADD".($K["name"]!=""?" CONSTRAINT ".idf_escape($K["name"]):"")." CHECK ($K[clause])");}queries_redirect(ME."table=".urlencode($a),($K["drop"]?lang(261):($_!=""?lang(262):lang(263))),$I);}page_header(($_!=""?lang(264).": ".h($_):lang(170)),["table"=>$a]);if(!$K){$_b=Driver::get()->checkConstraints($a);$K=["name"=>$_,"clause"=>$_b[$_]];}echo"<form action='' method='post'>\n","<p>";if(DIALECT!="sqlite")echo
lang(211).': <input name="name" value="'.h($K["name"]).'" class="input" data-maxlength="64" autocapitalize="off"> ';echo
doc_link(['sql'=>"create-table-check-constraints.html",'mariadb'=>"constraint/",'pgsql'=>"ddl-constraints.html#DDL-CONSTRAINTS-CHECK-CONSTRAINTS",'mssql'=>"relational-databases/tables/create-check-constraints",'sqlite'=>"lang_createtable.html#check_constraints",],"?"),"</p>\n<p>";textarea("clause",$K["clause"]);echo"</p>\n<p>","<input type='submit' class='button default' value='",lang(107),"'>";if($_!="")echo"<input type='submit' class='button' name='drop' value='",lang(157),"'>",confirm(lang(207,$_));echo
input_token(),"</p>\n","</form>\n";}elseif(isset($_GET["trigger"])){$a=$_GET["trigger"];$_=$_GET["name"];$Sl=trigger_options();$K=(array)trigger($_,$a)+["Trigger"=>$a."_bi"];if($_POST){if(in_array($_POST["Timing"],$Sl["Timing"])&&in_array($_POST["Event"],$Sl["Event"])&&in_array($_POST["Type"],$Sl["Type"])){$_h=" ON ".table($a);$bd="DROP TRIGGER ".idf_escape($_).(DIALECT=="pgsql"?$_h:"");$qg=ME."table=".urlencode($a);if($_POST["drop"])query_redirect($bd,$qg,lang(265));else{if($_!="")queries($bd);queries_redirect($qg,($_!=""?lang(266):lang(267)),queries(create_trigger($_h,$_POST)));if($_!="")queries(create_trigger($_h,$K+["Type"=>reset($Sl["Type"])]));}}$K=$_POST;}if($_!="")page_header(lang(268).": ".h($_),["table"=>$a,h($_)]);else
page_header(lang(269),["table"=>$a,lang(269)]);echo"<form action='' method='post' id='form'>\n","<table class='box box-light'>\n","<tr><th>",lang(270),"</th><td>",html_select("Timing",$Sl["Timing"],$K["Timing"],"triggerChange(/^".preg_quote($a,"/")."_[ba][iud]$/, '".js_escape($a)."', this.form);"),"</td></tr>\n","<tr><th>",lang(271),"</th><td>",html_select("Event",$Sl["Event"],$K["Event"],"this.form['Timing'].onchange();");if(in_array("UPDATE OF",$Sl["Event"]))echo" <input name='Of' value='".h($K["Of"])."' class='input hidden'>";echo"</td></tr>\n","<tr><th>",lang(43),"</th><td>",html_select("Type",$Sl["Type"],$K["Type"]),"</td></tr>\n","</table>\n","<p>",lang(211),"<input class='input' name='Trigger' value='",h($K["Trigger"]),"' data-maxlength='64' autocapitalize='off'>","</p>\n",script("gid('form')['Timing'].onchange();"),"<p>";textarea("Statement",$K["Statement"]);echo"</p>\n","<p>","<input type='submit' class='button default' value='",lang(107),"'>";if($_!="")echo"<input type='submit' class='button' name='drop' value='",lang(157),"'>",confirm(lang(207,$_));echo"</p>\n",input_token(),"</form>\n";}elseif(isset($_GET["user"])){$oa=$_GET["user"];$Mi=[""=>["All privileges"=>""]];foreach(get_rows("SHOW PRIVILEGES")as$K){foreach(explode(",",($K["Privilege"]=="Grant option"?"":$K["Context"]))as$mc)$Mi[$mc][$K["Privilege"]]=$K["Comment"];}$Mi["Server Admin"]+=$Mi["File access on server"];$Mi["Databases"]["Create routine"]=$Mi["Procedures"]["Create routine"];unset($Mi["Procedures"]["Create routine"]);$Mi["Columns"]=[];foreach(["Select","Insert","Update","References"]as$X)$Mi["Columns"][$X]=$Mi["Tables"][$X];unset($Mi["Server Admin"]["Usage"]);foreach($Mi["Tables"]as$u=>$X)unset($Mi["Databases"][$u]);$fh=[];if($_POST){foreach($_POST["objects"]as$u=>$X)$fh[$X]=(array)$fh[$X]+(array)$_POST["grants"][$u];}$Ge=[];$yh="";if(isset($_GET["host"])&&($I=Connection::get()->query("SHOW GRANTS FOR ".q($oa)."@".q($_GET["host"])))){while($K=$I->fetchRow()){if(preg_match('~GRANT (.*) ON (.*) TO ~',$K[0],$y)&&preg_match_all('~ *([^(,]*[^ ,(])( *\([^)]+\))?~',$y[1],$z,PREG_SET_ORDER)){foreach($z
as$X){if($X[1]!="USAGE")$Ge["$y[2]$X[2]"][$X[1]]=true;if(preg_match('~ WITH GRANT OPTION~',$K[0]))$Ge["$y[2]$X[2]"]["GRANT OPTION"]=true;}}if(preg_match("~ IDENTIFIED BY PASSWORD '([^']+)~",$K[0],$y))$yh=$y[1];}}if($_POST){$zh=(isset($_GET["host"])?q($oa)."@".q($_GET["host"]):"''");if($_POST["drop"])query_redirect("DROP USER $zh",ME."privileges=",lang(272));else{$hh=q($_POST["user"])."@".q($_POST["host"]);$oi=$_POST["pass"];if($oi!=''&&!$_POST["hashed"]&&!Connection::get()->isMinVersion("8")){$oi=Connection::get()->getValue("SELECT PASSWORD(".q($oi).")");$j=!$oi;}else$j=false;$tc=false;if(!$j){if($zh!=$hh){$tc=queries((Connection::get()->isMinVersion("5")?"CREATE USER":"GRANT USAGE ON *.* TO")." $hh IDENTIFIED BY ".(Connection::get()->isMinVersion("8")?"":"PASSWORD ").q($oi));$j=!$tc;}elseif($oi!=$yh){$pi=q($oi);if(Connection::get()->isMariaDB())$pi="PASSWORD($pi)";queries("SET PASSWORD FOR $hh = $pi");}}if(!$j){$vj=[];foreach($fh
as$rh=>$Ee){if(isset($_GET["grant"]))$Ee=array_filter($Ee);$Ee=array_keys($Ee);if(isset($_GET["grant"]))$vj=array_diff(array_keys(array_filter($fh[$rh],'strlen')),$Ee);elseif($zh==$hh){$wh=array_keys((array)$Ge[$rh]);$vj=array_diff($wh,$Ee);$Ee=array_diff($Ee,$wh);unset($Ge[$rh]);}if(preg_match('~^(.+)\s*(\(.*\))?$~U',$rh,$y)&&(!grant(false,$vj,$y[2],$y[1],$hh)||!grant(true,$Ee,$y[2],$y[1],$hh))){$j=true;break;}}}if(!$j&&isset($_GET["host"])){if($zh!=$hh)queries("DROP USER $zh");elseif(!isset($_GET["grant"])){foreach($Ge
as$rh=>$vj){if(preg_match('~^(.+)(\(.*\))?$~U',$rh,$y))grant(false,array_keys($vj),$y[2],$y[1],$hh);}}}queries_redirect(ME."privileges=",(isset($_GET["host"])?lang(273):lang(274)),!$j);if($tc)Connection::get()->query("DROP USER $hh");}}$Cl=isset($_GET["host"])?lang(27).": ".h("$oa@$_GET[host]"):lang(179);$Dl=isset($_GET["host"])?h($oa):lang(179);page_header($Cl,["privileges"=>['',lang(69)],$Dl]);if($_POST){$K=$_POST;$Ge=$fh;}else{$K=$_GET+["host"=>Connection::get()->getValue("SELECT SUBSTRING_INDEX(CURRENT_USER, '@', -1)")];$K["pass"]=$yh;if($yh!="")$K["hashed"]=true;if($Ge)$Ge[".*"]=[];elseif(DB!="")$Ge[idf_escape(addcslashes(DB,"%_\\")).".*"]=[];else$Ge["*.* "]=[];}echo"<form action='' method='post'>\n","<table class='box box-light'>\n","<tr><th>",lang(25),"</th>","<td><input class='input' name='host' data-maxlength='60' value='",h($K["host"]),"' autocapitalize='off'></td>\n","<tr><th>",lang(27),"</th>","<td><input class='input' name='user' data-maxlength='80' value='",h($K["user"]),"' autocapitalize='off'></td>\n",'<tr><th>',lang(28),"</th>","<td><input class='input' name='pass' id='pass' value='",h($K["pass"]),"' autocomplete='new-password'></td>\n";if(!$K["hashed"])echo
script("typePassword(gid('pass'));");if(!Connection::get()->isMinVersion("8"))echo
checkbox("hashed",1,$K["hashed"],lang(275),"typePassword(this.form['pass'], this.checked);");echo"</table>\n","<div class='scrollable'><table class='checkable'>\n","<thead><tr><th colspan='2'>".lang(69).doc_link(['sql'=>"grant.html#priv_level"])."</th>";$p=0;foreach($Ge
as$rh=>$Ee){echo"<th>";if($rh=="*.*")echo"*.*",input_hidden("objects[$p]","*.*");else
echo"<input class='input' name='objects[$p]' value='".h(trim($rh))."' size='10' autocapitalize='off'>";echo"</th>";$p++;}echo"</tr></thead>\n";foreach([""=>"","Server Admin"=>lang(25),"Databases"=>lang(29),"Tables"=>lang(7),"Columns"=>lang(42),"Procedures"=>lang(276),]as$mc=>$Oc){foreach((array)$Mi[$mc]as$Li=>$Tb){echo"<tr>";if($Oc)echo"<td>$Oc</td>";echo"<td".(!$Oc?" colspan='2'":"").' lang="en" title="'.h($Tb).'">'.h($Li)."</td>";$p=0;foreach($Ge
as$rh=>$Ee){$_="'grants[$p][".h(strtoupper($Li))."]'";$Y=$Ee[strtoupper($Li)];$Ri=strpos($rh,"@")!==false;$eh=$rh==".*";$Ga=$Li=="All privileges";$Fe=$Li=="Grant option";if($rh=="*.*"&&$Li=="Proxy")echo"<td></td>";elseif($Ri&&$Li!="Proxy"&&!$Fe)echo"<td></td>";elseif($mc=="Server Admin"&&$rh!=(isset($Ge["*.*"])?"*.*":".*")&&!(($Ri||$eh)&&$Li=="Proxy"))echo"<td></td>";elseif(isset($_GET["grant"]))echo"<td><select name=$_>"."<option></option>"."<option value='1'".($Y?" selected":"").">".lang(277)."</option>"."<option value='0'".($Y=="0"?" selected":"").">".lang(278)."</option>"."</select></td>";else{echo"<td class='center'><label class='block'>","<input type='checkbox' name=$_ value='1'".($Y?" checked":"").($Ga?" id='grants-$p-all'":(!$Fe?" class='grants-$p'":"")).">";if($Ga)echo
script("qsl('input').onclick = function () { if (this.checked) formUncheckAll('.grants-$p'); };");elseif(!$Fe)echo
script("qsl('input').onclick = function () { if (this.checked) formUncheck('grants-$p-all'); };");echo"</label>";}$p++;}echo"</tr>";}}echo"</table></div>\n","<p>","<input type='submit' class='button default' value='",lang(107),"'>\n";if(isset($_GET["host"]))echo"<input type='submit' class='button' name='drop' value='",lang(157),"'>\n",confirm(lang(207,"$oa@$_GET[host]"));echo
input_token(),"</p>\n","</form>\n";}elseif(isset($_GET["processlist"])){if(support("kill")){if($_POST){$Vf=0;foreach((array)$_POST["kill"]as$X){if(kill_process($X))$Vf++;}queries_redirect(ME."processlist=",lang(279,$Vf),$Vf||!$_POST["kill"]);}}page_header(lang(147),[lang(147)]);echo"<form action='' method='post'>\n","<div class='scrollable'>\n","<table class='nowrap checkable'>\n",script("mixin(qsl('table'), {onclick: tableClick, ondblclick: partialArg(tableClick, true)});");$p=-1;foreach(process_list()as$p=>$K){if(!$p){echo"<thead><tr lang='en'>".(support("kill")?"<th>":"");foreach($K
as$u=>$X)echo"<th>$u".doc_link(['sql'=>"show-processlist.html#processlist_".strtolower($u),'pgsql'=>"monitoring-stats.html#PG-STAT-ACTIVITY-VIEW",'oracle'=>"REFRN30223",]);echo"</thead>\n";}echo"<tr>".(support("kill")?"<td>".checkbox("kill[]",$K[DIALECT=="sql"?"Id":"pid"],0):"");foreach($K
as$u=>$X)echo"<td>".((DIALECT=="sql"&&$u=="Info"&&preg_match("~Query|Killed~",$K["Command"])&&$X!="")||(DIALECT=="pgsql"&&$u=="current_query"&&$X!="<IDLE>")||(DIALECT=="oracle"&&$u=="sql_text"&&$X!="")?"<code class='jush-".DIALECT."'>".truncate_utf8($X,100).'</code> <a href="'.h(ME.($K["db"]!=""?"db=".urlencode($K["db"])."&":"")."sql=".urlencode($X)).'">'.icon("edit").lang(280).'</a>':h($X));echo"\n";}echo"</table>\n","</div>\n","<p>";if(support("kill"))echo($p+1)."/".lang(281,max_connections()),"<p><input type='submit' class='button' value='".lang(282)."'>\n";echo
input_token(),"</p>\n","</form>\n",script("tableCheck();");}elseif(isset($_GET["select"])){$a=$_GET["select"];$S=table_status1($a);$t=indexes($a);$l=fields($a);$qe=column_foreign_keys($a);$th=$S["Oid"];$wj=[];$d=[];$Kj=[];$Mh=[];$wl=null;foreach($l
as$u=>$k){$_=Admin::get()->getFieldName($k);$ah=html_entity_decode(strip_tags($_),ENT_QUOTES);if(isset($k["privileges"]["select"])&&$_!=""){$d[$u]=$ah;if(is_shortable($k))$wl=Admin::get()->processSelectionLength();}if(isset($k["privileges"]["where"])&&$_!="")$Kj[$u]=$ah;if(isset($k["privileges"]["order"])&&$_!="")$Mh[$u]=$ah;$wj+=$k["privileges"];}list($M,$He)=Admin::get()->processSelectionColumns($d,$t);$M=array_unique($M);$He=array_unique($He);$Df=count($He)<count($M);$Z=Admin::get()->processSelectionSearch($l,$t);$Lh=Admin::get()->processSelectionOrder($l,$t);$w=Admin::get()->processSelectionLimit();if($_GET["modify"]&&!Admin::get()->isDataEditAllowed())redirect(ME."select=".urlencode($a));if($_GET["val"]&&is_ajax()){header("Content-Type: text/plain; charset=utf-8");foreach($_GET["val"]as$dm=>$K){$Na=convert_field($l[key($K)]);$M=[$Na?:idf_escape(key($K))];$Z[]=where_check($dm,$l);$J=Driver::get()->select($a,$M,$Z,$M);if($J)echo
first($J->fetchRow());}exit;}$F=$gm=null;foreach($t
as$s){if($s["type"]=="PRIMARY"){$F=array_flip($s["columns"]);$gm=($M?$F:[]);foreach($gm
as$u=>$X){if(in_array(idf_escape($u),$M))unset($gm[$u]);}break;}}if($th&&!$F){$F=$gm=[$th=>0];$t[]=["type"=>"PRIMARY","columns"=>[$th]];}$P=Admin::get()->getSettings();if($_POST){$Nm=$Z;if(!$_POST["all"]&&is_array($_POST["check"])){$_b=[];foreach($_POST["check"]as$vb)$_b[]=where_check($vb,$l);$Nm[]="((".implode(") OR (",$_b)."))";}$Nm=($Nm?"\nWHERE ".implode(" AND ",$Nm):"");if($_POST["export"]){$P->updateParameters(["exportFormat"=>$_POST["format"],"exportOutput"=>$_POST["output"],]);dump_headers($a);Admin::get()->dumpTable($a,"");$xe=($M?implode(", ",$M):"*").convert_fields($d,$l,$M)."\nFROM ".table($a);$Ke=($He&&$Df?"\nGROUP BY ".implode(", ",$He):"").($Lh?"\nORDER BY ".implode(", ",$Lh):"");if(!is_array($_POST["check"])||$F)$G="SELECT $xe$Nm$Ke";else{$bm=[];foreach($_POST["check"]as$X)$bm[]="(SELECT".limit($xe,"\nWHERE ".($Z?implode(" AND ",$Z)." AND ":"").where_check($X,$l).$Ke,1).")";$G=implode(" UNION ALL ",$bm);}Admin::get()->dumpData($a,"table",$G);exit;}if($_POST["save"]||$_POST["delete"]){$I=true;$za=0;$ik=[];if(!$_POST["delete"]){$Tj=array_keys($_POST["fields"]+$_POST["function"]);foreach($Tj
as$_){$X=process_input($l[$_]);if($X!==null&&($_POST["clone"]||$X!==false))$ik[idf_escape($_)]=($X!==false?$X:idf_escape($_));}}if($_POST["delete"]||$ik){if($_POST["clone"])$G="INTO ".table($a)." (".implode(", ",array_keys($ik)).")\nSELECT ".implode(", ",$ik)."\nFROM ".table($a);if($_POST["all"]||($F&&is_array($_POST["check"]))||$Df){$I=($_POST["delete"]?Driver::get()->delete($a,$Nm):($_POST["clone"]?queries("INSERT $G$Nm".Driver::get()->getInsertReturningSql($a)):Driver::get()->update($a,$ik,$Nm)));$za=Connection::get()->getAffectedRows();if(is_object($I))$za+=$I->getRowsCount();}else{foreach((array)$_POST["check"]as$X){$Jm="\nWHERE ".($Z?implode(" AND ",$Z)." AND ":"").where_check($X,$l);$I=($_POST["delete"]?Driver::get()->delete($a,$Jm,1):($_POST["clone"]?queries("INSERT".limit1($a,$G,$Jm)):Driver::get()->update($a,$ik,$Jm,1)));if(!$I)break;$za+=Connection::get()->getAffectedRows();}}}$Jg=lang(283,$za);if($_POST["clone"]&&$I&&$za==1){$bg=last_id($I);if($bg)$Jg=lang(201," $bg");}queries_redirect(remove_from_uri($_POST["all"]&&$_POST["delete"]?"page":""),$Jg,$I);if(!$_POST["delete"]){$Ei=(array)$_POST["fields"];edit_form($a,array_intersect_key($l,$Ei),$Ei,!$_POST["clone"]);page_footer();exit;}}elseif(!$_POST["import"]){if(!$_POST["val"])Admin::get()->addError(lang(284));else{$I=true;$za=0;foreach($_POST["val"]as$dm=>$K){$ik=[];foreach($K
as$u=>$X){$u=bracket_escape($u,1);$ik[idf_escape($u)]=(preg_match('~char|text~',$l[$u]["type"])||$X!=""?Admin::get()->processFieldInput($l[$u],$X):"NULL");}$I=Driver::get()->update($a,$ik," WHERE ".($Z?implode(" AND ",$Z)." AND ":"").where_check($dm,$l),!$Df&&!$F," ");if(!$I)break;$za+=Connection::get()->getAffectedRows();}queries_redirect(remove_from_uri(),lang(283,$za),$I);}}elseif(!is_string($m=get_file("csv_file",true)))Admin::get()->addError(upload_error($m));elseif(!preg_match('~~u',$m))Admin::get()->addError(lang(285));else{$P->updateParameter("exportFormat",$_POST["import_format"]);$Ob=array_keys($l);preg_match_all('~(?>"[^"]*"|[^"\r\n]+)+~',$m,$z);$za=count($z[0]);Driver::get()->begin();$N=($_POST["import_format"]=="csv;"?";":($_POST["import_format"]=="tsv"?"\t":","));$L=[];foreach($z[0]as$u=>$X){preg_match_all("~((?>\"[^\"]*\")+|[^$N]*)$N~",$X.$N,$zg);if(!$u&&!array_diff($zg[1],$Ob)){$Ob=$zg[1];$za--;}else{$ik=[];foreach($zg[1]as$p=>$Hb)$ik[idf_escape($Ob[$p])]=($Hb==""&&$l[$Ob[$p]]["null"]?"NULL":q(preg_match('~^".*"$~s',$Hb)?str_replace('""','"',substr($Hb,1,-1)):$Hb));$L[]=$ik;}}$I=(!$L||Driver::get()->insertUpdate($a,$L,$F));if($I)Driver::get()->commit();queries_redirect(remove_from_uri("page"),lang(286,$za),$I);Driver::get()->rollback();}}$fl=Admin::get()->getTableName($S);if(is_ajax()){page_headers();ob_start();}else
page_header(lang(52).": $fl",[$fl]);$ik=null;if(isset($wj["insert"])||!support("table")){$D=[];foreach((array)$_GET["where"]as$X){if(isset($qe[$X["col"]])&&count($qe[$X["col"]])==1&&($X["op"]=="="||(!$X["op"]&&(is_array($X["val"])||!preg_match('~[_%]~',$X["val"])))))$D["set"."[".bracket_escape($X["col"])."]"]=$X["val"];}$ik=$D?"&".http_build_query($D):"";}Admin::get()->printTableMenu($S,$ik);if(!$d&&support("table"))echo"<p class='error'>".lang(287).($l?".":": ".error())."\n";else{echo"<form action='' id='form'>\n","<div style='display: none;'>";hidden_fields_get();if(DB!=""){echo
input_hidden("db",DB);if(isset($_GET["ns"]))echo
input_hidden("ns",$_GET["ns"]);}echo
input_hidden("select",$a),'<input type="submit" class="button" value="'.h(lang(52)).'">',"</div>\n","<div class='field-sets'>\n";Admin::get()->printSelectionColumns($M,$d);Admin::get()->printSelectionSearch($Z,$Kj,$t);Admin::get()->printSelectionOrder($Lh,$Mh,$t);Admin::get()->printSelectionLimit($w);Admin::get()->printSelectionLength($wl);Admin::get()->printSelectionAction($t);echo"</div>\n</form>\n";$C=isset($_GET["page"])?$_GET["page"]:null;if($C=="last"){$ve=Connection::get()->getValue(count_rows($a,$Z,$Df,$He));$C=(int)floor(max(0,$ve-1)/$w);}else{$ve=false;$C=(int)$C;}$Mj=$M;$Ie=$He;if(!$Mj){$Mj[]="*";$nc=convert_fields($d,$l,$M);if($nc)$Mj[]=substr($nc,2);}foreach($M
as$u=>$X){$k=$l[idf_unescape($X)];if($k&&($Na=convert_field($k)))$Mj[$u]="$Na AS $X";}if(!$Df&&$gm){foreach($gm
as$u=>$X){$Mj[]=idf_escape($u);if($Ie)$Ie[]=idf_escape($u);}}$I=Driver::get()->select($a,$Mj,$Z,$Ie,$Lh,$w,$C,true);if(!$I)echo"<p class='error'>".error()."\n";else{if(DIALECT=="mssql"&&$C)$I->seek($w*$C);echo"<form action='' method='post' enctype='multipart/form-data'>\n","<div class='table-footer-parent'>\n";$L=[];while($K=$I->fetchAssoc()){if($C&&DIALECT=="oracle")unset($K["RNUM"]);$L[]=$K;}if($_GET["page"]!="last"&&$w!==null&&$He&&$Df&&DIALECT=="sql")$ve=Connection::get()->getValue(" SELECT FOUND_ROWS()");if(!$L)echo"<p class='message'>".lang(85)."\n";else{$Za=Admin::get()->getBackwardKeys($a,$fl);echo"<div class='scrollable'>\n","<table id='table' class='nowrap checkable'>\n",script("mixin(gid('table'), {onclick: partialArg(tableClick, false, ".(Admin::get()->isDataEditAllowed()?"true":"false")."), ondblclick: partialArg(tableClick, true), onkeydown: onEditingKeydown});"),"<thead><tr>";if($He||!$M){echo"<th class='actions'><input type='checkbox' id='all-page' class='jsonly'>".script("gid('all-page').onclick = partial(formCheck, /check/);","");if(Admin::get()->isDataEditAllowed())echo" <a href='",h($_GET["modify"]?remove_from_uri("modify"):$_SERVER["REQUEST_URI"]."&modify=1")."' title='",lang(288),"'>",icon_solo("edit-all"),"</a>";}$bh=[];$_e=[];reset($M);$aj=1;foreach($L[0]as$u=>$X){if(!isset($gm[$u])){$Oj=key($M);$X=isset($_GET["columns"][$Oj])?$_GET["columns"][$Oj]:null;$k=$l[$M?($X?$X["col"]:current($M)):$u];$_=($k?Admin::get()->getFieldName($k,$aj):(isset($X["fun"])?"*":h($u)));if($_!=""){$aj++;$bh[$u]=$_;$c=idf_escape($u);$ef=remove_from_uri('(order|desc)[^=]*|page').'&order%5B0%5D='.urlencode($u);$Oc="&desc%5B0%5D=1";echo"<th id='th[".h(bracket_escape($u))."]'>".script("mixin(qsl('th'), {onmouseover: partial(columnMouse), onmouseout: partial(columnMouse, ' hidden')});","");$ye=apply_sql_function(isset($X["fun"])?$X["fun"]:null,$_);$uk=isset($k["privileges"]["order"])||$ye;if($uk)echo'<a href="',h($ef.($Lh[0]==$c||$Lh[0]==$u||(!$Lh&&$Df&&$He[0]==$c)?$Oc:'')),'">',"$ye</a>";else
echo$ye;echo"<span class='column hidden'>";if($uk)echo"<a href='".h($ef.$Oc)."' title='".lang(59)."' class='button light'>",icon_solo("arrow-down"),"</a>";if(!isset($X["fun"])&&isset($k["privileges"]["where"]))echo'<a href="#fieldset-search" title="'.lang(56).'" class="button light jsonly">',icon_solo("search"),'</a>',script("qsl('a').onclick = partial(selectSearch, '".js_escape($u)."');");echo"</span>";}$_e[$u]=isset($X["fun"])?$X["fun"]:null;next($M);}}$hg=[];if($_GET["modify"]){foreach($L
as$K){foreach($K
as$u=>$X)$hg[$u]=max($hg[$u],min(40,strlen(utf8_decode($X))));}}if($Za)echo"<th>".lang(16)."</th>";echo"</thead>\n";if(is_ajax())ob_end_clean();foreach(Admin::get()->fillForeignDescriptions($L,$qe)as$Zg=>$K){$cm=unique_array($L[$Zg],$t);if(!$cm){$cm=[];foreach($L[$Zg]as$u=>$X){if(!preg_match('~^(COUNT\((\*|(DISTINCT )?`(?:[^`]|``)+`)\)|(AVG|GROUP_CONCAT|MAX|MIN|SUM)\(`(?:[^`]|``)+`\))$~',$u))$cm[$u]=$X;}}$dm="";foreach($cm
as$u=>$X){$k=isset($l[$u])?$l[$u]:null;if((DIALECT=="sql"||DIALECT=="pgsql")&&$k&&preg_match('~char|text|enum|set~',$k["type"])&&strlen($X)>64){$u=(strpos($u,'(')?$u:idf_escape($u));$u="MD5(".(DIALECT!='sql'||preg_match("~^utf8~",isset($k["collation"])?$k["collation"]:"")?$u:"CONVERT($u USING ".charset(Connection::get()).")").")";$X=md5($X);}$dm
.="&".($X!==null?urlencode("where[".bracket_escape($u)."]")."=".urlencode($X===false?"f":$X):"null%5B%5D=".urlencode($u));}echo"<tr>";if($He||!$M){echo"<td class='actions'>",checkbox("check[]",substr($dm,1),in_array(substr($dm,1),(array)$_POST["check"]));if(!$Df&&Admin::get()->isDataEditAllowed())echo" <a href='",h(ME."edit=".urlencode($a).$dm),"' class='edit' title='",lang(37),"'>",icon_solo("edit"),"</a>";}foreach($K
as$u=>$X){if(isset($bh[$u])){$k=isset($l[$u])?$l[$u]:null;$X=$k?Connection::get()->formatValue($X,$k):$X;$x="";if($k&&preg_match('~blob|bytea|raw|file~',$k["type"])&&$X!="")$x=ME.'download='.urlencode($a).'&field='.urlencode($u).$dm;if(!$x&&$X!==null){foreach((array)$qe[$u]as$o){if(count($qe[$u])==1||end($o["source"])==$u){$x="";foreach($o["source"]as$p=>$vk)$x
.=where_link($p,$o["target"][$p],$L[$Zg][$vk]);$x=($o["db"]!=""?preg_replace('~([?&]db=)[^&]+~','\1'.urlencode($o["db"]),ME):ME).'select='.urlencode($o["table"]).$x;if($o["ns"])$x=preg_replace('~([?&]ns=)[^&]+~','\1'.urlencode($o["ns"]),$x);if(count($o["source"])==1)break;}}}if($u=="COUNT(*)"){$x=ME."select=".urlencode($a);$p=0;foreach((array)$_GET["where"]as$W){if(!array_key_exists($W["col"],$cm))$x
.=where_link($p++,$W["col"],$W["val"],$W["op"]);}foreach($cm
as$Nf=>$W)$x
.=where_link($p++,$Nf,$W);}$mh=$X===null;$X=select_value($X,$x,$k,$wl);$Ad=bracket_escape($u);$q=h("val[$dm][$Ad]");$Y=isset($_POST["val"][$dm][$Ad])?$_POST["val"][$dm][$Ad]:null;$md=!is_array($K[$u])&&is_utf8($X)&&$L[$Zg][$u]==$K[$u]&&!$_e[$u]&&!(isset($k["generated"])?$k["generated"]:false);$tl=$k&&preg_match('~text|json|lob~',$k["type"]);$qh=($k&&preg_match(number_type(),$k["type"]))||(!$k&&preg_match('~^ROUND|CHAR_LENGTH|FLOOR|CEIL|UNIX_TIMESTAMP|TIME_TO_SEC|SUM|MIN|MAX|AVG|COUNT\(~',$u));$Eb=$qh&&($mh||is_numeric(strip_tags($X)))?"class='number'":"";echo"<td id='$q' $Eb";if(($_GET["modify"]&&$md)||$Y!==null){$Ne=h($Y!==null?$Y:$K[$u]);echo">".($tl?"<textarea name='$q' cols='30' rows='".(substr_count($K[$u],"\n")+1)."'>$Ne</textarea>":"<input class='input' name='$q' value='$Ne' size='$hg[$u]'>");}else{$rg=strpos($X,"<i>…</i>");echo" data-text='".($rg?2:($tl?1:0))."'".($md?"":" data-warning='".h(lang(289))."'").">$X";}}}if($Za){echo"<td>";Admin::get()->printBackwardKeys($Za,$L[$Zg]);echo"</td>";}echo"</tr>\n";}if(is_ajax())exit;echo"</table>\n",script("initToggles(gid('table'));"),"</div>\n";}if(!is_ajax()){if($L||$C){$Dd=true;if($_GET["page"]!="last"){if($w==""||(count($L)<$w&&($L||!$C)))$ve=($C?$C*$w:0)+count($L);elseif(DIALECT!="sql"||!$Df){$ve=($Df?false:found_rows($S,$Z));if($ve<max(1e4,2*($C+1)*$w))$ve=first(slow_query(count_rows($a,$Z,$Df,$He)));else$Dd=false;}}$ci=($w!==null&&($ve===false||$ve>$w||$C));if($ci){if(($ve===false?count($L)+1:$ve-$C*$w)>$w)echo'<p class="links">','<a href="',h(remove_from_uri("page")."&page=".($C+1)),'" class="loadmore">',icon("expand"),lang(290),'</a>',script("qsl('a').onclick = partial(loadNextPage, ".(+$w).", '".lang(291)."…');","");echo"\n";}echo"<div class='table-footer'><div class='field-sets'>\n";if($ci){$Bg=($ve===false?$C+(count($L)>=$w?2:1):(int)floor(($ve-1)/$w));$Xc="<li>…</li>";echo"<fieldset>";if(DIALECT!="simpledb"){echo"<legend><a href='".h(remove_from_uri("page"))."'>".lang(292)."</a></legend>",script("qsl('a').onclick = function () { pageClick(this.href, +prompt('".lang(292)."', '".($C+1)."')); return false; };"),"<div id='fieldset-pagination' class='fieldset-content'><ul class='pagination'>",pagination(0,$C);if($C>5)echo$Xc;for($p=max(1,$C-4);$p<min($Bg,$C+5);$p++)echo
pagination($p,$C);if($Bg>0){if($C+5<$Bg)echo$Xc;echo($Dd&&$ve!==false?pagination($Bg,$C):" <a href='".h(remove_from_uri("page")."&page=last")."' title='~$Bg'>".lang(293)."</a>");}echo"</ul></div>";}else{echo"<legend>".lang(292)."</legend>","<div id='fieldset-pagination'><ul class='pagination'>",pagination(0,$C);if($C>1)echo$Xc;if($C)echo
pagination($C,$C);if($Bg>$C){echo
pagination($C+1,$C);if($Bg>$C+1)echo$Xc;}echo"</ul></div>";}echo"</fieldset>\n";}echo"<fieldset>","<legend>".lang(294)."</legend><div class='fieldset-content'>";$Wc=($Dd?"":"~ ").$ve;echo
checkbox("all",1,0,($ve!==false?($Dd?"":"~ ").lang(183,$ve):""),"const checked = formChecked(this, /check/); selectCount('selected', this.checked ? '$Wc' : checked); selectCount('selected2', this.checked || !checked ? '$Wc' : checked);")."\n","</div></fieldset>\n";if(Admin::get()->isDataEditAllowed())echo"<fieldset",($_GET["modify"]?'':' class="jsonly"'),">","<legend>",lang(288),"</legend>","<div class='fieldset-content'>","<input type='submit' class='button' value='",lang(107),"'",($_GET["modify"]?"":" title='".lang(284)."'"),">","</div>","</fieldset>\n","<fieldset>","<legend>",lang(156)," <span id='selected'></span></legend>","<div class='fieldset-content'>","<input type='submit' class='button' name='edit' value='",lang(37),"'> ","<input type='submit' class='button' name='clone' value='",lang(280),"'> ","<input type='submit' class='button' name='delete' value='",lang(111),"'>",confirm(),"</div>","</fieldset>\n";$re=Admin::get()->getDumpFormats();foreach((array)$_GET["columns"]as$c){if($c["fun"]){unset($re['sql']);break;}}if($re){print_fieldset_start("export",lang(71)." <span id='selected2'></span>","export");echo
html_select("format",$re,$P->getParameter("exportFormat"));$Yh=Admin::get()->getDumpOutputs();echo($Yh?" ".html_select("output",$Yh,$P->getParameter("exportOutput")):"")," <input type='submit' class='button' name='export' value='".lang(71)."'>\n";print_fieldset_end("export");}echo"</div></div>\n",script("initTableFooter()");}echo"</div>\n";if(Admin::get()->isDataEditAllowed())echo"<p>","<a href='#import'>",icon("import"),lang(70)."</a>",script("qsl('a').onclick = partial(toggle, 'import');",""),"</p>","<p id='import'".($_POST["import"]?"":" class='hidden'").">","<input type='file' name='csv_file'> ",html_select("import_format",["csv"=>"CSV,","csv;"=>"CSV;","tsv"=>"TSV"],$P->getParameter("exportFormat"))," <input type='submit' class='button default' name='import' value='".lang(70)."'>","</p>";echo
input_token(),"</form>\n",(!$He&&$M?"":script("tableCheck();"));}else
echo"</div>\n";}}if(is_ajax()){ob_end_clean();exit;}}elseif(isset($_GET["variables"])){$Ik=isset($_GET["status"]);$Cl=$Ik?lang(149):lang(148);page_header($Cl,[$Cl]);$wm=($Ik?show_status():show_variables());if(!$wm)echo"<p class='message'>",lang(85),"</p>\n";else{echo"<div class='scrollable'><table>\n";foreach($wm
as$K){echo"<tr>";$u=array_shift($K);echo"<th><code class='jush-".DIALECT.($Ik?"status":"set")."'>".h($u)."</code></th>";foreach($K
as$X)echo"<td>",nl2br(h($X)),"</td>";echo"</tr>\n";}echo"</table></div>\n";}}elseif(isset($_GET["script"])){header("Content-Type: text/javascript; charset=utf-8");if($_GET["script"]=="db"){$Tk=["Data_length"=>0,"Index_length"=>0,"Data_free"=>0];$f=[];foreach(table_status()as$_=>$S){$f["Comment-$_"]=h($S["Comment"]);if(!is_view($S)){foreach(["Engine","Collation"]as$u)$f["$u-$_"]=h($S[$u]);foreach($Tk+["Auto_increment"=>0,"Rows"=>0]as$u=>$X){if($S[$u]!=""){$X=format_number($S[$u]);if($X>=0)$f["$u-$_"]=($u=="Rows"&&$X&&$S["Engine"]==(DIALECT=="pgsql"?"table":"InnoDB")?"~ $X":$X);if(isset($Tk[$u]))$Tk[$u]+=($S["Engine"]!="InnoDB"||$u!="Data_free"?$S[$u]:0);}elseif(array_key_exists($u,$S))$f["$u-$_"]="?";}}}foreach($Tk
as$u=>$X)$f["sum-$u"]=format_number($X);echo
json_encode($f,JSON_UNESCAPED_UNICODE);}elseif($_GET["script"]=="kill")Connection::get()->query("KILL ".number($_POST["kill"]));else{$f=[];foreach(count_tables(Admin::get()->getDatabases())as$h=>$X){$f["tables-$h"]=$X;$f["size-$h"]=db_size($h);}echo
json_encode($f,JSON_UNESCAPED_UNICODE);}exit;}else{$ml=array_merge((array)$_POST["tables"],(array)$_POST["views"]);if($ml&&!$_POST["search"]){$I=true;$Jg="";if(DIALECT=="sql"&&$_POST["tables"]&&count($_POST["tables"])>1&&($_POST["drop"]||$_POST["truncate"]||$_POST["copy"]))queries("SET foreign_key_checks = 0");if($_POST["truncate"]){if($_POST["tables"])$I=truncate_tables($_POST["tables"]);$Jg=lang(295);}elseif($_POST["move"]){$I=move_tables((array)$_POST["tables"],(array)$_POST["views"],$_POST["target"]);$Jg=lang(296);}elseif($_POST["copy"]){$I=copy_tables((array)$_POST["tables"],(array)$_POST["views"],$_POST["target"]);$Jg=lang(297);}elseif($_POST["drop"]){if($_POST["views"])$I=drop_views($_POST["views"]);if($I&&$_POST["tables"])$I=drop_tables($_POST["tables"]);$Jg=lang(298);}elseif(DIALECT=="sqlite"&&$_POST["check"]){foreach((array)$_POST["tables"]as$R){foreach(get_rows("PRAGMA integrity_check(".q($R).")")as$K)$Jg
.="<b>".h($R)."</b>: ".h($K["integrity_check"])."<br>";}}elseif(DIALECT!="sql"){$I=(DIALECT=="sqlite"?queries("VACUUM"):apply_queries("VACUUM".($_POST["optimize"]?"":" ANALYZE"),$_POST["tables"]));$Jg=lang(299);}elseif(!$_POST["tables"])$Jg=lang(75);elseif($I=queries(($_POST["optimize"]?"OPTIMIZE":($_POST["check"]?"CHECK":($_POST["repair"]?"REPAIR":"ANALYZE")))." TABLE ".implode(", ",array_map('AdminNeo\idf_escape',$_POST["tables"])))){while($K=$I->fetchAssoc())$Jg
.="<b>".h($K["Table"])."</b>: ".h($K["Msg_text"])."<br>";}queries_redirect(substr(ME,0,-1),$Jg,$I);}if($_GET["ns"]=="")page_header(lang(29).": ".h(DB),true);else
page_header(lang(77).": ".h($_GET["ns"]),true);Admin::get()->printDatabaseMenu();if($_GET["ns"]===""){echo"<h2 id='schemas'>".lang(300)."</h2>\n";$Hj=Admin::get()->getSchemas();if(!$Hj)echo"<p class='message'>".lang(301)."\n";else{echo"<div class='scrollable'>\n","<table class='nowrap'>\n",'<thead><tr class="wrap"><th>',lang(77),"</th></tr></thead>";foreach($Hj
as$_)echo"<tr><th><a href='",h(ME),"ns=".urlencode($_),"' title='",lang(302),"'>".h($_)."</a></th></tr>";echo'</table></div>';}echo'<p class="links"><a href="'.h(ME).'scheme=">'.icon("database-add").lang(73)."</a>\n";}else{echo"<h2 id='tables-views'>".lang(303)."</h2>\n";$ll=tables_list();if(!$ll)echo"<p class='message'>".lang(75)."\n";else{echo"<form action='' method='post'>\n","<div class='table-footer-parent'>\n";if(support("table")){echo"<div class='field-sets'>\n","<fieldset><legend>".lang(304)." <span id='selected2'></span></legend><div class='fieldset-content'>","<input type='search' class='input' name='query' value='".h($_POST["query"])."'>",script("qsl('input').onkeydown = partialArg(bodyKeydown, 'search');","")," <input type='submit' class='button' name='search' value='".lang(56)."'>\n";if(Admin::get()->getRegexpOperator())echo"<p><label><input type='checkbox' name='regexp' value='1'".(empty($_POST['regexp'])?'':' checked').'>'.lang(305).'</label>',doc_link(['sql'=>'regexp.html','pgsql'=>'functions-matching.html#FUNCTIONS-POSIX-REGEXP','elastic'=>"regexp-syntax.html"])."</p>\n";echo"</div></fieldset>\n","</div>\n";if($_POST["search"]&&$_POST["query"]!=""){$_GET["where"][0]["op"]=Admin::get()->getRegexpOperator()&&!empty($_POST['regexp'])?Admin::get()->getRegexpOperator():Admin::get()->getLikeOperator();search_tables();}}echo"<div class='scrollable'>\n","<table class='nowrap checkable'>\n",script("mixin(qsl('table'), {onclick: tableClick, ondblclick: partialArg(tableClick, true)});"),'<thead><tr class="wrap">','<td class="actions"><input id="check-all" type="checkbox" class="input jsonly">'.script("gid('check-all').onclick = partial(formCheck, /^(tables|views)\[/);",""),'<th>'.lang(7),'<td>'.lang(306).doc_link(['sql'=>'show-table-status.html','pgsql'=>'catalog-pg-class.html#CATALOG-PG-CLASS','oracle'=>'REFRN20286']),'<td>'.lang(307).doc_link(['sql'=>'example-auto-increment.html','mariadb'=>'auto_increment/']),'<td>'.lang(161).doc_link(['sql'=>'storage-engines.html']),'<td>'.lang(44).doc_link(['sql'=>'charset-charsets.html','mariadb'=>'supported-character-sets-and-collations/']),'<td>'.lang(308).doc_link(['sql'=>'show-table-status.html','pgsql'=>'functions-admin.html#FUNCTIONS-ADMIN-DBOBJECT','oracle'=>'REFRN20286']),'<td>'.lang(309).doc_link(['sql'=>'show-table-status.html','pgsql'=>'functions-admin.html#FUNCTIONS-ADMIN-DBOBJECT']),'<td>'.lang(310).doc_link(['sql'=>'show-table-status.html']),(support("comment")?'<td>'.lang(45).doc_link(['sql'=>'show-table-status.html','pgsql'=>'functions-info.html#FUNCTIONS-INFO-COMMENT-TABLE']):''),"</thead>\n";$T=0;foreach($ll
as$_=>$U){$_m=($U!==null&&!preg_match('~table|sequence~i',$U));$q=h("Table-".$_);echo'<tr><td class="actions">'.checkbox(($_m?"views[]":"tables[]"),$_,in_array($_,$ml,true),"","","",$q);if(!Admin::get()->getSettings()->isSelectionPreferred()&&(support("table")||support("indexes")))$ra="table";else$ra="select";echo"<th><a href='",h(ME),"$ra=",urlencode($_),"' id='$q'>",h($_),"</a></th>";if($_m)echo'<td colspan="6"><a href="'.h(ME)."view=".urlencode($_).'" title="'.lang(34).'">'.(preg_match('~materialized~i',$U)?lang(159):lang(160)).'</a>','<td align="right"><a href="'.h(ME)."select=".urlencode($_).'" title="'.lang(32).'">?</a>';else{foreach(["Rows"=>["select",lang(32)],"Auto_increment"=>["auto_increment=1&create",lang(35)],"Engine"=>[],"Collation"=>[],"Data_length"=>["create",lang(35)],"Index_length"=>["indexes",lang(164)],"Data_free"=>["edit",lang(6)],]as$u=>$x){$q=" id='$u-".h($_)."'";echo($x?"<td align='right'>".(support("table")||$u=="Rows"||(support("indexes")&&$u!="Data_length")?"<a href='".h(ME."$x[0]=").urlencode($_)."'$q title='$x[1]'>?</a>":"<span$q>?</span>"):"<td id='$u-".h($_)."'>");}$T++;}echo(support("comment")?"<td id='Comment-".h($_)."'>":""),"\n";}echo"<tfoot><tr>","<td><td><td><th>".lang(281,count($ll)),"<td>".h(DIALECT=="sql"?Connection::get()->getValue("SELECT @@default_storage_engine"):""),"<td>".h(db_collation(DB,collations()));foreach(["Data_length","Index_length","Data_free"]as$u)echo"<td align='right' id='sum-$u'>";echo"<td></td><td></td>";if(support("comment"))echo"<td></td>";echo"</tr></tfoot>\n","</table>\n","</div>\n";if(Admin::get()->isDataEditAllowed()){echo"<div class='table-footer'><div class='field-sets'>\n";$tm="<input type='submit' class='button' value='".lang(311)."'> ".help_script("VACUUM");$Hh="<input type='submit' class='button' name='optimize' value='".lang(312)."'> ".help_script(DIALECT=="sql"?"OPTIMIZE TABLE":"VACUUM OPTIMIZE");echo"<fieldset><legend>".lang(156)." <span id='selected'></span></legend><div class='fieldset-content'>".(DIALECT=="sqlite"?$tm."<input type='submit' class='button' name='check' value='".lang(313)."'> ".help_script("PRAGMA integrity_check"):(DIALECT=="pgsql"?$tm.$Hh:(DIALECT=="sql"?"<input type='submit' class='button' value='".lang(314)."'> ".help_script("ANALYZE TABLE").$Hh."<input type='submit' class='button' name='check' value='".lang(313)."'> ".help_script("CHECK TABLE")."<input type='submit' class='button' name='repair' value='".lang(315)."'> ".help_script("REPAIR TABLE"):"")))."<input type='submit' class='button' name='truncate' value='".lang(316)."'> ".help_script(DIALECT=="sqlite"?"DELETE":("TRUNCATE".(DIALECT=="pgsql"?"":" TABLE"))).confirm()."<input type='submit' class='button' name='drop' value='".lang(157)."'>".help_script("DROP TABLE").confirm()."\n";$g=(support("scheme")?Admin::get()->getSchemas():Admin::get()->getDatabases());if(count($g)!=1&&DIALECT!="sqlite"){$h=(isset($_POST["target"])?$_POST["target"]:(support("scheme")?$_GET["ns"]:DB));echo"<p>".lang(317).": ",($g?html_select("target",$g,$h):'<input class="input" name="target" value="'.h($h).'" autocapitalize="off">')," <input type='submit' class='button' name='move' value='".lang(318)."'>",(support("copy")?" <input type='submit' class='button' name='copy' value='".lang(319)."'> ".checkbox("overwrite",1,$_POST["overwrite"],lang(320)):""),"\n";}echo
input_hidden("all"),script("qsl('input').onclick = function () { selectCount('selected', formChecked(this, /^(tables|views)\[/));".(support("table")?" selectCount('selected2', formChecked(this, /^tables\[/) || $T);":"")." }"),input_token(),"</div></fieldset>\n","</div></div>\n",script("initTableFooter()");}echo"</div>\n","</form>\n",script("tableCheck();");}echo'<p class="links"><a href="',h(ME),'create=">',icon("table-add"),lang(74),"</a>\n";if(support("view"))echo'<a href="',h(ME),'view=">',icon("view-add"),lang(234),"</a>\n";if(support("routine")){echo"<h2 id='routines'>".lang(175)."</h2>\n";$_j=routines();if($_j){$Wb=$_j[0]["ROUTINE_COMMENT"]!==null;echo"<table>\n",'<thead><tr>','<th>',lang(211),'</th><td>',lang(43),'</td><td>',lang(251),"</td>";if($Wb)echo"<td>",lang(45),"</td>";echo"<td></td>","</tr></thead>\n";foreach($_j
as$K){$_=($K["SPECIFIC_NAME"]==$K["ROUTINE_NAME"]?"":"&name=".urlencode($K["ROUTINE_NAME"]));echo'<tr>','<th><a href="',h(ME.($K["ROUTINE_TYPE"]!="PROCEDURE"?'callf=':'call=').urlencode($K["SPECIFIC_NAME"]).$_),'">',h($K["ROUTINE_NAME"]),'</a></th>','<td>',h($K["ROUTINE_TYPE"]),'</td>','<td>',h($K["DTD_IDENTIFIER"]),'</td>';if($Wb)echo'<td>',truncate_utf8(preg_replace('~\s{2,}~'," ",trim($K["ROUTINE_COMMENT"])),50),'</td>';echo'<td><a href="'.h(ME.($K["ROUTINE_TYPE"]!="PROCEDURE"?'function=':'procedure=').urlencode($K["SPECIFIC_NAME"]).$_).'">'.lang(167)."</a></td>";}echo"</table>\n";}echo'<p class="links">';if(support("procedure"))echo'<a href="',h(ME),'procedure=">',icon("function-add"),lang(250),"</a>";echo'<a href="',h(ME),'function=">',icon("function-add"),lang(249),"</a>\n","</p>\n";}if(support("sequence")){echo"<h2 id='sequences'>".lang(321)."</h2>\n";$Wj=get_vals("SELECT sequence_name FROM information_schema.sequences WHERE sequence_schema = current_schema() ORDER BY sequence_name");if($Wj){echo"<table>\n","<thead><tr><th>",lang(211),"</th><td></td></tr></thead>\n";foreach($Wj
as$X)echo"<tr>","<th>",h($X),"</th>","<td><a href='",h(ME),"sequence=",urlencode($X),"'>",lang(167),"</a></td>\n";echo"</table>\n";}echo"<p class='links'><a href='",h(ME),"sequence='>",icon("add"),lang(256),"</a></p>\n";}if(support("type")){echo"<h2 id='user-types'>".lang(113)."</h2>\n";$rm=types();if($rm){echo"<table>\n","<thead><tr><th>",lang(211),"</th><td></td></tr></thead>\n";foreach($rm
as$X)echo"<tr>","<th>",h($X),"</th>","<td><a href='",h(ME),"type=",urlencode($X),"'>",lang(167),"</a></td>\n";echo"</table>\n";}echo"<p class='links'><a href='",h(ME),"type='>",icon("add"),lang(257),"</a></p>\n";}if(support("event")){echo"<h2 id='events'>".lang(176)."</h2>\n";$L=get_rows("SHOW EVENTS");if($L){echo"<table>\n","<thead><tr><th>".lang(211)."<td>".lang(322)."<td>".lang(240)."<td>".lang(241)."<td></thead>\n";foreach($L
as$K)echo"<tr>","<th>".h($K["Name"]),"<td>".($K["Execute at"]?lang(323)."<td>".$K["Execute at"]:lang(242)." ".$K["Interval value"]." ".$K["Interval field"]."<td>$K[Starts]"),"<td>$K[Ends]",'<td><a href="'.h(ME).'event='.urlencode($K["Name"]).'">'.lang(167).'</a>';echo"</table>\n";$Bd=Connection::get()->getValue("SELECT @@event_scheduler");if($Bd&&$Bd!="ON")echo"<p class='error'><code class='jush-sqlset'>event_scheduler</code>: ".h($Bd)."\n";}echo'<p class="links"><a href="',h(ME),'event=">',icon("event-add"),lang(239),"</a></p>\n";}if($ll)echo
script("ajaxSetHtml('".js_escape(ME)."script=db');");}}page_footer();